"""Fetch open-access full texts for the post-SLR include and check records (SEARCH_PROTOCOL.md).

Links come from OpenAlex (best and other open-access locations, by DOI), Semantic Scholar (openAccessPdf)
and arXiv. A file is kept only if it is a PDF (it starts with %PDF) under 60 MB. Each paper gets its own
folder, .research-private/postslr-2026-11/papers/<id>/paper.pdf, never committed. Writes fulltext.json
(every link tried and the outcome) beside the search exports, and prints what still needs library access.
"""

from __future__ import annotations

import csv
import hashlib
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from postslr_candidates import SEARCH  # noqa: E402
from postslr_search import AGENT, get  # noqa: E402

PAPERS = ROOT / ".research-private/postslr-2026-11/papers"
MAX_BYTES = 60_000_000


def openalex_links(dois: list[str]) -> dict[str, list[str]]:
    links: dict[str, list[str]] = {}
    for i in range(0, len(dois), 50):
        url = "https://api.openalex.org/works?" + urllib.parse.urlencode(
            {"filter": "doi:" + "|".join(dois[i:i + 50]), "per-page": 50,
             "select": "doi,best_oa_location,locations"})
        for w in json.loads(get(url))["results"]:
            doi = w["doi"].lower().removeprefix("https://doi.org/")
            found = [(w.get("best_oa_location") or {}).get("pdf_url")]
            found += [loc.get("pdf_url") for loc in w.get("locations") or [] if loc.get("is_oa")]
            links[doi] = [u for u in dict.fromkeys(found) if u]
    return links


def semantic_scholar_links(dois: list[str]) -> dict[str, list[str]]:
    body = json.dumps({"ids": ["DOI:" + d for d in dois]}).encode()
    for n in range(6):
        try:
            request = urllib.request.Request(
                "https://api.semanticscholar.org/graph/v1/paper/batch?fields=openAccessPdf,externalIds",
                data=body, headers={"Content-Type": "application/json", "User-Agent": AGENT})
            with urllib.request.urlopen(request, timeout=60) as response:
                rows = json.loads(response.read())
            break
        except urllib.error.HTTPError as error:
            if error.code != 429 or n == 5:
                raise
            time.sleep(15 * (n + 1))
    links = {}
    for doi, row in zip(dois, rows, strict=True):
        found = [((row or {}).get("openAccessPdf") or {}).get("url")]
        arxiv = ((row or {}).get("externalIds") or {}).get("ArXiv")
        if arxiv:
            found.append(f"https://arxiv.org/pdf/{arxiv}")
        links[doi] = [u for u in found if u]
    return links


def download(url: str) -> tuple[bytes | None, str]:
    request = urllib.request.Request(url, headers={"User-Agent": AGENT, "Accept": "application/pdf"})
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            data = response.read(MAX_BYTES + 1)
    except (urllib.error.URLError, TimeoutError, ConnectionError) as error:
        return None, f"error: {getattr(error, 'code', '') or type(error).__name__}"
    if len(data) > MAX_BYTES:
        return None, "too large"
    if not data.startswith(b"%PDF"):
        return None, "not a PDF"
    return data, "ok"


def main() -> None:
    with (SEARCH / "screening.csv").open() as f:
        rows = [r for r in csv.DictReader(f) if r["decision"] in ("include", "check")]
    dois = sorted({r["doi"] for r in rows if r["doi"]})
    found_oa, found_s2 = openalex_links(dois), semantic_scholar_links(dois)
    arxiv_ids = {}
    for path in SEARCH.glob("arxiv*.json"):
        for r in json.loads(path.read_text())["records"]:
            arxiv_ids[r["title"].lower()] = r["id"].replace("http://arxiv.org/abs/", "https://arxiv.org/pdf/")
    log = {}
    for r in rows:
        links = found_oa.get(r["doi"], []) + found_s2.get(r["doi"], [])
        if r["title"].lower() in arxiv_ids:
            links.append(arxiv_ids[r["title"].lower()])
        links = list(dict.fromkeys(links))
        tried = []
        for url in links:
            data, status = download(url)
            tried.append({"url": url, "status": status})
            if data:
                folder = PAPERS / r["id"]
                folder.mkdir(parents=True, exist_ok=True)
                (folder / "paper.pdf").write_bytes(data)
                tried[-1].update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                break
            time.sleep(1)
        log[r["id"]] = {"decision": r["decision"], "doi": r["doi"], "title": r["title"], "tried": tried,
                        "pdf": any(t["status"] == "ok" for t in tried)}
    (SEARCH / "fulltext.json").write_text(json.dumps(log, indent=1, ensure_ascii=False) + "\n")
    got = [k for k, v in log.items() if v["pdf"]]
    print(json.dumps({"records": len(log), "pdf": len(got),
                      "no_link": sum(not v["tried"] for v in log.values()),
                      "link_but_failed": sum(bool(v["tried"]) and not v["pdf"] for v in log.values())}))


if __name__ == "__main__":
    main()
