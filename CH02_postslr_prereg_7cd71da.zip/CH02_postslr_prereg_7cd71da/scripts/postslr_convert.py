"""Convert the post-SLR full-text includes into md-v1 inputs as the 65 were; no provider calls, no overwrites.

The conversion core, thresholds and review rule are those of convert_papers_markdown.py (md-v1); only the
input list differs. Inputs are the records marked include at full text in screening.csv, each read from
.research-private/postslr-2026-11/papers/<record>/paper.pdf. The describer and the run address papers by an
integer study ID, so record S0021 becomes study 10021: never colliding with the packet's 1-82, and the record
stays recoverable. Paper text and figures stay private (copyright); only a text-free manifest is public.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from convert_papers_markdown import RECALL_REVIEW, UNRESOLVED_REVIEW  # noqa: E402

from pipeline.study.markdown_inputs import convert, fidelity, legacy_text, sha256, toolchain  # noqa: E402

POSTSLR = ROOT / ".research-private/postslr-2026-11"
ID_OFFSET = 10000


def study_id(record: str) -> int:
    """S0021 -> 10021. Raises on anything that is not S followed by four digits."""
    if len(record) != 5 or record[0] != "S" or not record[1:].isdigit():
        raise ValueError(f"Not a post-SLR record ID: {record!r}")
    return ID_OFFSET + int(record[1:])


def includes(screening: Path) -> list[str]:
    """Record IDs included at full text. Refuses an include that skipped full-text screening."""
    out = []
    for row in csv.DictReader(screening.open()):
        if row["decision"] != "include":
            continue
        if row["stage"] != "fulltext":
            raise ValueError(f"{row['id']} is included but was not screened at full text")
        out.append(row["id"])
    if not out:
        raise ValueError("No full-text includes in screening.csv")
    return sorted(out)


def run(out: Path, public: Path, papers: Path, screening: Path) -> dict:
    if out.exists() or public.exists():
        raise FileExistsError("Refusing to overwrite an existing conversion; choose new output paths")
    records = includes(screening)
    missing = [r for r in records if not (papers / r / "paper.pdf").is_file()]
    if missing:
        raise FileNotFoundError(f"No PDF for included records: {missing}")
    out.mkdir(parents=True)
    rows = []
    for record in records:
        sid = study_id(record)
        pdf = papers / record / "paper.pdf"
        folder = out / f"study-{sid}"
        result = convert(pdf, folder / "figures")
        (folder / "paper.md").write_text(result["markdown"])
        check = fidelity(result["markdown"], legacy_text(pdf))
        row = {
            "study_id": sid,
            "record_id": record,
            "pdf_sha256": sha256(pdf.read_bytes()),
            "md_sha256": sha256(result["markdown"]),
            "md_bytes": len(result["markdown"].encode()),
            "pages": result["pages"],
            "ocr": result["ocr"],
            "figures_total": len(result["figures"]),
            "figures_to_describe": sum(f["to_describe"] for f in result["figures"]),
            "fidelity": check,
            "spacing": result["spacing"],
            "needs_review": check["recall"] is None
            or check["recall"] < RECALL_REVIEW
            or result["ocr"]
            or result["spacing"]["unresolved_runs"] >= UNRESOLVED_REVIEW,
        }
        (folder / "conversion.json").write_text(json.dumps({**row, "figures": result["figures"]}, indent=1))
        rows.append(row)
        print(f"{record} (study {sid}): {result['pages']}p, {row['figures_to_describe']} figures, "
              f"recall {check['recall']}")
    manifest = {
        "version": "md-v1",
        "set": "post-SLR (full-text includes, screening.csv)",
        "toolchain": toolchain(),
        "recall_review_threshold": RECALL_REVIEW,
        "study_id_rule": f"study_id = {ID_OFFSET} + the number in the record ID (S0021 -> {ID_OFFSET + 21})",
        "papers": rows,
        "note": "Hashes and counts only; paper text and images are private (copyright).",
    }
    public.parent.mkdir(parents=True, exist_ok=True)
    public.write_text(json.dumps(manifest, indent=1) + "\n")
    return manifest


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", type=Path, required=True, help="new private directory for md-v1 papers")
    ap.add_argument("--public-manifest", type=Path, required=True, help="new text-free manifest path")
    ap.add_argument("--papers", type=Path, default=POSTSLR / "papers")
    ap.add_argument("--screening", type=Path, default=POSTSLR / "search/screening.csv")
    a = ap.parse_args()
    m = run(a.out, a.public_manifest, a.papers, a.screening)
    review = [r["record_id"] for r in m["papers"] if r["needs_review"]]
    print(f"{len(m['papers'])} papers converted; needs review: {review}")


if __name__ == "__main__":
    main()
