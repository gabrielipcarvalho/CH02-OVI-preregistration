"""Run the post-SLR searches that have public APIs (docs/postslr-2026-11/SEARCH_PROTOCOL.md) and save them.

arXiv and PubMed are two of the SLR's four databases. OpenAlex is supplementary: it stands in for Google
Scholar and SciSpace, which have no public search API. Each run writes the exact query, the time, the hit
count and every returned record to .research-private/postslr-2026-11/search/ (never committed). Nothing is
screened here; screening follows the protocol.
"""

from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / ".research-private/postslr-2026-11/search"
# The union of the SLR's two term lists (2-methods.tex line 19; supplementary.tex §S1).
DOMAIN = ("drowning detection", "swimmer monitoring", "aquatic safety", "water safety", "swimmer distress",
          "aquatic emergency")
TECHNOLOGY = ("artificial intelligence", "machine learning", "deep learning", "computer vision",
              "wearable sensor")
START = "2025-11-01"
# A recall query beside the SLR string (added 1 Nov 2026, before any screening). arXiv's API returned no
# hits for any quoted phrase that day, even "drowning detection" with no date, so the SLR string cannot run
# there; and phrase-only strings miss papers that say "drowning" and "YOLO" but none of the SLR's phrases.
RECALL_DOMAIN = ("drowning", "swimmer", "swimmers", "lifeguard", "lifeguards", "rip current", "rip currents")
RECALL_TECHNOLOGY = ("detect*", "monitor*", "deep learning", "machine learning", "artificial intelligence",
                     "neural network*", "computer vision", "sensor*", "camera*", "YOLO")
AGENT = "ch2-postslr-search/1.0 (academic literature search)"


def get(url: str, tries: int = 4) -> bytes:
    """One GET; a rate-limit refusal (OpenAlex answers 401 or 429 without a key) is retried after a pause."""
    request = urllib.request.Request(url, headers={"User-Agent": AGENT})
    for n in range(tries):
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                return response.read()
        except urllib.error.HTTPError as error:
            if error.code not in (401, 429) or n == tries - 1:
                raise
            time.sleep(10 * (n + 1))
    raise AssertionError("unreachable")


def boolean(prefix: str = "") -> str:
    """("a" OR "b" …) AND ("c" OR …), with an optional field prefix on each phrase."""
    def group(terms):
        return "(" + " OR ".join(f'{prefix}"{t}"' for t in terms) + ")"
    return f"{group(DOMAIN)} AND {group(TECHNOLOGY)}"


def arxiv(recall: bool = False) -> dict:
    stop = datetime.now(UTC).strftime("%Y%m%d%H%M")
    # Recall on arXiv: words, not phrases; a two-word term must have both words (rip AND current).
    words = " OR ".join(
        f"all:{w}" if " " not in w else "(" + " AND ".join(f"all:{x}" for x in w.split()) + ")"
        for w in RECALL_DOMAIN
    )
    query = f"({words})" if recall else boolean("all:")
    query += f" AND submittedDate:[{START.replace('-', '')}0000 TO {stop}]"
    ns = {"a": "http://www.w3.org/2005/Atom", "x": "http://arxiv.org/schemas/atom"}
    records, start, total = [], 0, None
    while total is None or start < total:
        url = "https://export.arxiv.org/api/query?" + urllib.parse.urlencode(
            {"search_query": query, "start": start, "max_results": 200}
        )
        feed = ET.fromstring(get(url))
        total = int(feed.find("{http://a9.com/-/spec/opensearch/1.1/}totalResults").text)
        entries = feed.findall("a:entry", ns)
        for e in entries:
            doi = e.find("x:doi", ns)
            records.append({
                "id": e.find("a:id", ns).text,
                "title": " ".join(e.find("a:title", ns).text.split()),
                "first_version": e.find("a:published", ns).text[:10],
                "authors": [a.find("a:name", ns).text for a in e.findall("a:author", ns)],
                "doi": doi.text if doi is not None else None,
                "abstract": " ".join(e.find("a:summary", ns).text.split()),
            })
        if not entries:
            break
        start += len(entries)
        time.sleep(3)  # arXiv asks for a pause between requests
    return {"query": query, "hits": total, "records": records}


def pubmed(recall: bool = False) -> dict:
    def tiab(terms):
        return "(" + " OR ".join(f'"{x}"[tiab]' if " " in x else f"{x}[tiab]" for x in terms) + ")"
    words = f"{tiab(RECALL_DOMAIN)} AND {tiab(RECALL_TECHNOLOGY)}" if recall else boolean()
    term = f'({words}) AND ("{START.replace("-", "/")}"[dp] : "3000"[dp])'
    base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
    found = json.loads(get(base + "esearch.fcgi?" + urllib.parse.urlencode(
        {"db": "pubmed", "term": term, "retmax": 1000, "retmode": "json"})))["esearchresult"]
    records = []
    if found["idlist"]:
        summary = json.loads(get(base + "esummary.fcgi?" + urllib.parse.urlencode(
            {"db": "pubmed", "id": ",".join(found["idlist"]), "retmode": "json"})))["result"]
        for pmid in found["idlist"]:
            s = summary[pmid]
            doi = next((i["value"] for i in s.get("articleids", []) if i["idtype"] == "doi"), None)
            records.append({
                "id": "PMID:" + pmid, "title": s["title"], "journal": s.get("fulljournalname"),
                "pubdate": s.get("pubdate"), "epubdate": s.get("epubdate"), "doi": doi,
                "authors": [a["name"] for a in s.get("authors", [])],
            })
    return {"query": term, "hits": int(found["count"]), "warnings": found.get("warninglist"),
            "translation": found.get("querytranslation"), "records": records}


def openalex(recall: bool = False) -> dict:
    def group(terms):
        return "(" + " OR ".join(f'"{x.rstrip("*")}"' if " " in x else x.rstrip("*") for x in terms) + ")"
    words = f"{group(RECALL_DOMAIN)} AND {group(RECALL_TECHNOLOGY)}" if recall else boolean()
    filters = f"title_and_abstract.search:{words},from_publication_date:{START}"
    # Page numbers, not cursors: without an API key OpenAlex refuses cursor paging past the first page.
    records, number, total = [], 1, None
    while total is None or len(records) < total:
        url = "https://api.openalex.org/works?" + urllib.parse.urlencode(
            {"filter": filters, "per-page": 200, "page": number})
        page = json.loads(get(url))
        total = page["meta"]["count"]
        number += 1
        for w in page["results"]:
            records.append({
                "id": w["id"], "title": w.get("title"), "first_version": w.get("publication_date"),
                "type": w.get("type"), "doi": w.get("doi"),
                "venue": ((w.get("primary_location") or {}).get("source") or {}).get("display_name"),
                "authors": [a["author"]["display_name"] for a in w.get("authorships", [])],
            })
        if not page["results"]:
            break
    return {"query": "filter=" + filters, "hits": total, "records": records}


SOURCES = {
    "arxiv": arxiv, "pubmed": pubmed, "openalex": openalex,
    "arxiv_recall": lambda: arxiv(True), "pubmed_recall": lambda: pubmed(True),
    "openalex_recall": lambda: openalex(True),
}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("sources", nargs="*", default=list(SOURCES), choices=list(SOURCES))
    OUT.mkdir(parents=True, exist_ok=True)
    for name in ap.parse_args().sources:
        when = datetime.now(UTC).isoformat(timespec="seconds")
        result = {"source": name, "run_at": when, **SOURCES[name]()}
        path = OUT / f"{name}_{when.replace(':', '')}.json"
        path.write_text(json.dumps(result, indent=1, ensure_ascii=False) + "\n")
        print(json.dumps({"source": name, "run_at": when, "hits": result["hits"],
                          "records": len(result["records"]), "file": str(path.relative_to(ROOT))}))


if __name__ == "__main__":
    main()
