"""Screening support for the post-SLR set (SEARCH_PROTOCOL.md, "Screening"); nothing here decides relevance.

  inputs  numbers every candidate still to screen (S0001…) and gathers an abstract for each: from the saved
          arXiv export, PubMed (efetch by PMID) or OpenAlex (by DOI). Writes screening_inputs.json.
  table   joins the analyst's recorded decisions (decisions.json) to the inputs, refuses a candidate left
          undecided or an unknown reason, and writes screening.csv for Gabriel's check, plus the counts.

All files stay in .research-private/postslr-2026-11/search/ (never committed).
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from postslr_candidates import SEARCH, norm_doi, norm_title  # noqa: E402
from postslr_search import get  # noqa: E402

# One reason per exclusion, in the SLR's terms (2-methods.tex), plus the protocol's own.
REASONS = {
    "not_ai": "non-AI/ML approach",
    "not_aquatic_safety": "not drowning detection or aquatic safety monitoring",
    "no_technical_detail": "not empirical, or insufficient technical detail",
    "review": "review without original data",
    "duplicate": "duplicate publication",
    "not_english": "not in English",
    "not_publication": "not a peer-reviewed publication, preprint or patent",
    "before_window": "earliest public version before 1 Nov 2025",
    # PRISMA's "reports not retrieved": dropped at full text by Gabriel's ruling of 10 Nov 2026.
    "not_retrieved": "full text not retrieved",
}


def openalex_abstract(index: dict | None) -> str | None:
    if not index:
        return None
    words = sorted((p, w) for w, places in index.items() for p in places)
    return " ".join(w for _, w in words)


def inputs() -> None:
    with (SEARCH / "candidates.csv").open() as f:
        rows = [r for r in csv.DictReader(f) if r["date_rule"] in ("in", "unclear")]
    abstracts, pmids = {}, {}
    for path in SEARCH.glob("*.json"):
        data = json.loads(path.read_text()) if path.name.startswith(("arxiv", "pubmed")) else None
        for r in (data or {}).get("records", []):
            if r.get("abstract"):
                abstracts[norm_title(r["title"])] = r["abstract"]
            if r["id"].startswith("PMID:"):
                pmids[norm_title(r["title"])] = r["id"][5:]
    wanted = [r for r in rows if norm_title(r["title"]) not in abstracts]
    ids = [pmids[norm_title(r["title"])] for r in wanted if norm_title(r["title"]) in pmids]
    for i in range(0, len(ids), 150):
        xml = get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?" + urllib.parse.urlencode(
            {"db": "pubmed", "id": ",".join(ids[i:i + 150]), "retmode": "xml"}))
        for article in ET.fromstring(xml).iter("PubmedArticle"):
            title = "".join(article.find(".//ArticleTitle").itertext())
            text = " ".join("".join(a.itertext()) for a in article.iter("AbstractText"))
            if text:
                abstracts[norm_title(title)] = text
        time.sleep(1)
    dois = sorted({r["doi"] for r in rows if r["doi"] and norm_title(r["title"]) not in abstracts})
    by_doi = {}
    for i in range(0, len(dois), 50):
        url = "https://api.openalex.org/works?" + urllib.parse.urlencode(
            {"filter": "doi:" + "|".join(dois[i:i + 50]), "per-page": 50,
             "select": "doi,title,abstract_inverted_index,type,language"})
        for w in json.loads(get(url))["results"]:
            by_doi[norm_doi(w["doi"])] = w
    out = []
    for n, r in enumerate(rows, 1):
        w = by_doi.get(r["doi"]) or {}
        out.append({
            "id": f"S{n:04d}", "title": r["title"], "doi": r["doi"], "first_date": r["first_date"],
            "date_rule": r["date_rule"], "sources": r["sources"], "type": w.get("type"),
            "language": w.get("language"),
            "abstract": abstracts.get(norm_title(r["title"]))
            or openalex_abstract(w.get("abstract_inverted_index")),
        })
    (SEARCH / "screening_inputs.json").write_text(json.dumps(out, indent=1, ensure_ascii=False) + "\n")
    print(json.dumps({"candidates": len(out), "with_abstract": sum(bool(o["abstract"]) for o in out)}))


def table() -> None:
    items = json.loads((SEARCH / "screening_inputs.json").read_text())
    decisions = json.loads((SEARCH / "decisions.json").read_text())
    rows = []
    for item in items:
        d = decisions.get(item["id"])
        if d is None:
            raise SystemExit(f"{item['id']} has no decision")
        if d["decision"] == "exclude" and d.get("reason") not in REASONS:
            raise SystemExit(f"{item['id']}: unknown reason {d.get('reason')}")
        if d["decision"] not in ("include", "exclude", "check"):
            raise SystemExit(f"{item['id']}: unknown decision {d['decision']}")
        # A full-text include carries the paper's own date and the DEC-0010 hazard-detector flag.
        if d.get("stage") == "fulltext" and d["decision"] == "include" and not (
            d.get("paper_date") and isinstance(d.get("hazard"), bool)
        ):
            raise SystemExit(f"{item['id']}: full-text include without paper_date or hazard flag")
        rows.append({"id": item["id"], "decision": d["decision"], "reason": REASONS.get(d.get("reason"), ""),
                     "stage": d.get("stage", "title"), "note": d.get("note", ""),
                     "hazard": {True: "yes", False: "no"}.get(d.get("hazard"), ""),
                     "paper_date": d.get("paper_date", ""), "title": item["title"],
                     "doi": item["doi"], "first_date": item["first_date"], "sources": item["sources"]})
    order = {"include": 0, "check": 1, "exclude": 2}
    rows.sort(key=lambda r: (order[r["decision"]], r["reason"], r["id"]))
    with (SEARCH / "screening.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(json.dumps({
        "decisions": dict(Counter(r["decision"] for r in rows)),
        "exclusions_by_reason": dict(Counter(r["reason"] for r in rows if r["decision"] == "exclude")),
        "by_stage": dict(Counter(f"{r['stage']}:{r['decision']}" for r in rows)),
    }, indent=1))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("step", choices=("inputs", "table"))
    {"inputs": inputs, "table": table}[ap.parse_args().step]()


if __name__ == "__main__":
    main()
