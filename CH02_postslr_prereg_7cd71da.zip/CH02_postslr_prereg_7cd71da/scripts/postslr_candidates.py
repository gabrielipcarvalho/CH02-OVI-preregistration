"""Merge the post-SLR search exports, remove duplicates, apply the date rule and drop packet papers.

Mechanical stage 1 of SEARCH_PROTOCOL.md "Screening": no judgment about relevance is made here. Reads every
export in .research-private/postslr-2026-11/search/ and writes candidates.csv beside them (never committed),
and prints the counts for the search log.
"""

from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline.study.final_phase import CORPUS, DEV, HELDOUT  # noqa: E402

SEARCH = ROOT / ".research-private/postslr-2026-11/search"
START = "2025-11-01"
MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1
)}


def norm_title(title: str) -> str:
    return re.sub(r"[^a-z0-9]", "", re.sub(r"<[^>]+>", "", title or "").lower())


def norm_doi(doi: str | None) -> str | None:
    return re.sub(r"^https?://(dx\.)?doi\.org/", "", doi.strip().lower()) if doi else None


def iso(value: str | None) -> str | None:
    """'2026-03-04', '2026 Mar 4', '2026 Mar' or '2026' → the most precise ISO prefix available."""
    if not value:
        return None
    if re.match(r"^\d{4}-\d{2}-\d{2}", value):
        return value[:10]
    m = re.match(r"^(\d{4})(?: (\w{3}))?(?: (\d{1,2}))?", value)
    if not m:
        return None
    year, month, day = m.groups()
    if month not in MONTHS:
        return year
    return f"{year}-{MONTHS[month]:02d}" + (f"-{int(day):02d}" if day else "")


def date_status(date: str | None) -> str:
    """in, out, or unclear (no date, or a year or month that straddles 1 Nov 2025)."""
    if not date:
        return "unclear"
    if len(date) == 4:
        return "in" if date > START[:4] else "out" if date < START[:4] else "unclear"
    return "in" if date >= START[: len(date)] else "out"


def first_date(source: str, r: dict) -> str | None:
    if source.startswith("pubmed"):
        dates = [d for d in (iso(r.get("epubdate")), iso(r.get("pubdate"))) if d]
        return min(dates) if dates else None
    return iso(r.get("first_version"))


def main() -> None:
    packet = set(DEV) | set(HELDOUT) | set(CORPUS)
    with (ROOT / "data/primaries.csv").open() as f:
        packet_titles = {norm_title(r["title"]): int(r["study_id"]) for r in csv.DictReader(f)
                         if int(r["study_id"]) in packet}
    merged: dict[str, dict] = {}
    per_source = {}
    for path in sorted(SEARCH.glob("*.json")):
        data = json.loads(path.read_text())
        source = data["source"]
        per_source[source] = {"hits": data.get("hits"), "records": len(data["records"]),
                              "queries": data.get("query") or list(data.get("queries", {}))}
        for r in data["records"]:
            doi, title = norm_doi(r.get("doi")), norm_title(r.get("title"))
            if not title:
                continue
            key = next((k for k, m in merged.items() if (doi and m["doi"] == doi) or m["key_title"] == title),
                       doi or title)
            m = merged.setdefault(key, {"doi": doi, "key_title": title, "title": r["title"], "dates": [],
                                        "sources": set()})
            m["doi"] = m["doi"] or doi
            m["sources"].add(source)
            if d := first_date(source, r):
                m["dates"].append(d)
    rows = []
    for m in merged.values():
        # The earliest dated record wins; a full date beats a year alone for the same year.
        dates = sorted(m["dates"], key=lambda d: (d[:4], -len(d), d))
        date = dates[0] if dates else None
        study = packet_titles.get(m["key_title"])
        status = "in_packet" if study else date_status(date)
        rows.append({"title": m["title"], "doi": m["doi"] or "", "first_date": date or "",
                     "date_rule": status, "packet_study": study or "",
                     "sources": ";".join(sorted(m["sources"]))})
    rows.sort(key=lambda r: (r["date_rule"], r["first_date"], r["title"]))
    with (SEARCH / "candidates.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(json.dumps({
        "per_source": per_source,
        "unique_records": len(rows),
        "date_rule": dict(Counter(r["date_rule"] for r in rows)),
        "to_screen": sum(r["date_rule"] in ("in", "unclear") for r in rows),
        "in_packet": sorted(r["packet_study"] for r in rows if r["packet_study"]),
    }, indent=1))


if __name__ == "__main__":
    main()
