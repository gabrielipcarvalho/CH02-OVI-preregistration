# Post-SLR search log (1 November 2026)

Run by the analyst (agent:claude-opus-5-5) at Gabriel's request. It follows
[SEARCH_PROTOCOL.md](SEARCH_PROTOCOL.md) (commit 5fe4197), with the deviations listed below.
- **Where the records are:** the exports and the merged candidate list are in
  `.research-private/postslr-2026-11/search/` and are never committed.
- **Scripts:**
  - `scripts/postslr_search.py` runs the API searches;
  - `scripts/postslr_candidates.py` merges the exports, removes duplicates and applies the date rule.
- **No screening has been done:** no record has been judged relevant or irrelevant.

## Searches run

All dates are from 1 Nov 2025. The run times are in each export.

| Source | Query | Hits | How |
|---|---|---:|---|
| arXiv | the SLR string (phrases) | 3 | public API |
| arXiv | recall: drowning, swimmer(s), lifeguard(s), rip current(s) | 135 | public API |
| PubMed | the SLR string | 39 | E-utilities. PubMed did not find "swimmer monitoring" or "swimmer distress" as phrases |
| PubMed | recall: the domain words in title or abstract, AND detection, monitoring, AI, ML, vision, sensor, camera or YOLO terms | 192 | E-utilities |
| OpenAlex (supplementary) | the SLR string, title and abstract | 127 | public API, no key |
| OpenAlex (supplementary) | recall, as for PubMed | 1,348 | public API, no key |
| SciSpace | "drowning detection" with deep learning / machine learning / artificial intelligence / computer vision | 4 × 100 shown | built-in browser, not signed in. Only records dated from Nov 2025, or undated, were kept: 45 unique |
| Google Scholar | — | not run | a bot-check page on the first request |

## After merging

| Step | Records |
|---|---:|
| Unique records (by DOI, else by normalised title) | 1,578 |
| Already in the packet (papers 5, 18, 23, 27, 53) | 5 |
| Outside the date rule (first dated record before 1 Nov 2025) | 18 |
| **To screen** (in the window, or the date is unclear) | **1,555** |
| …of which "drowning" is in the title | 126 |
| …of which the title mentions swimming, pools, aquatic topics or rip currents (and not drowning) | 343 |

- **A recall check:** the searches found both post-cutoff papers already in the packet: 27 (OpenAlex,
  dated 3 Nov 2025) and 53 (SciSpace). They also found three earlier packet papers:
  - 18 and 23, as undated SciSpace records;
  - 5, which OpenAlex dates to 2026 from its LNCS volume, although it was presented at ICIAP 2025.
  - **Why it matters:** database dates can mislead, so each included paper's own date is checked.
- **The date rule here uses database dates only.** At full-text screening each included paper is checked
  for an earlier public version (a preprint or a conference date), as the protocol requires.

## Deviations from SEARCH_PROTOCOL.md (dated 1 Nov 2026, before any screening)

1. **A recall query was added beside the SLR string in each API source.**
   - **arXiv:** its API returned no hits for any quoted phrase that day, even "drowning detection" with
     no date limit. So the SLR string cannot run there as written.
   - **Everywhere:** phrase-only strings miss papers that say "drowning" and "YOLO" but none of the SLR's
     phrases.
   - **The cost:** more records to screen, mostly from OpenAlex.
2. **OpenAlex was added** as a supplementary source. Without a key it allows only the first page with
   cursor paging, so page numbers were used.
   - Its response invited registering a key with the user's email. The analyst did not, because that
     creates an account and shares the email.
3. **Google Scholar was not searched.** The first request was met with a bot-check page, which the
   analyst may not complete.
4. **SciSpace was searched only partly:**
   - **The limit:** four free queries, then a sign-up wall. The analyst does not create accounts.
   - **The queries:** natural-language queries, not the Boolean string (SciSpace is relevance-ranked).
   - **How much was read:** the first 100 results of each query.
5. **Timing:** the search ran before the pre-registration's stage 1 was published.
   - **What protects the selection:** the screening criteria are fixed in commit 5fe4197, made before the
     search, and no screening has started.
   - **What it means for stage 1:** it should be published before screening begins.

## Still to do

- **Gabriel, if wanted:** Google Scholar and the remaining SciSpace queries, which need a person or a
  signed-in account. The SciSpace queries would be:
  - "swimmer monitoring deep learning";
  - "swimmer distress detection";
  - "aquatic safety artificial intelligence";
  - "aquatic emergency wearable sensor";
  - "water safety drowning".
- **Then:** citation tracking of the included papers, then screening.
