# Post-SLR full texts (1 November 2026)

Fetched by the analyst (agent:claude-opus-5-5) at Gabriel's request, for the 90 records left after title
and abstract screening: 52 include and 38 check.
- **Script:** `scripts/postslr_fulltext.py`.
- **Where the PDFs are:** `.research-private/postslr-2026-11/papers/<id>/paper.pdf`, never committed or
  released.
- **The record of every link tried:** `search/fulltext.json`. The list of what is still missing:
  `search/fulltext_needed.csv`.

## How

- **Sources of links:**
  - OpenAlex (best and other open-access locations, by DOI);
  - Semantic Scholar (openAccessPdf, and arXiv IDs);
  - the arXiv export;
  - then the publishers' documented direct PDF links (Springer and BMC) and Europe PMC.
- **What was kept:** a file only if it is a PDF under 60 MB.
- **The check:** every PDF's first two pages were matched against the record's title. All 28 match;
  S1515's title is split across lines in the PDF.
- **Not done:** where a publisher refused a scripted request (HTTP 403, or a landing page instead of the
  PDF), the analyst did not change the request to look like a browser, which would be getting round bot
  protection. Those papers are listed for Gabriel.

## Counts

| Outcome | Include | Check | All |
|---|---:|---:|---:|
| PDF fetched and verified | 21 | 7 | **28** |
| Open access, but the publisher blocks scripted download (MDPI, Elsevier, IEEE Access, Wiley, BMJ) | | | 15 |
| No open-access copy found | | | 44 |
| No DOI, so the record must be found first (S0070, S0089, S1549) | | | 3 |
| **Still needed** | 31 | 31 | **62** |

## Still to do

1. **Gabriel:** download the 62 listed in `fulltext_needed.csv`. Fifteen are open access and should open
   directly in a browser. The rest need library access. Each file goes to the `save_as` path in the list.
2. **Full-text screening of all 90:** this settles each check record, confirms each paper's own date, fixes
   the hazard-detector flags, and compares the possibly overlapping YOLO-NAS papers. It can start now on
   the 28 already here.

## Full-text screening: the first 28 (1 November 2026)

Screened by the analyst against the SLR criteria and Gabriel's three rulings. Each paper's date was
taken from the paper itself where it gives one, and each was checked for an earlier public version. Each
include carries a fixed hazard-detector flag (DEC-0010). The decisions, dates, flags and notes are in
`screening.csv` (`stage` = fulltext).

| Outcome | Papers |
|---|---:|
| **Included at full text** | **22** |
| Excluded at full text | 6 |

**Excluded, one reason each:**
- **Not in English:** S0236, whose body is in Chinese, and S0923, whose body is in Portuguese. Both have
  English abstracts.
- **Non-AI/ML:** S0178, an accelerometer threshold and an FFT peak; S1106, a rescue robot that tracks by
  colour.
- **Insufficient technical detail:** S0874 claims machine learning but describes no model, data or
  quantitative evaluation.
- **Not aquatic safety:** S0192 uses ML to estimate where to search for a drowned person in a river.
  This is response planning, not detection or monitoring. Kept out (Gabriel, 1 Nov 2026, "Keep it out").

**Among the 22 included:**
- **Hazard-detector papers (rip currents): 6.** S0235, S0403, S0794, S1183, S1515, S1540.
- **People detectors** (swimmers or people in or near water): 4. S0026, S0796, S1142, S1284. Under
  revision 3 their scope turns on whether drowning or distress, real or staged, is in the evaluation.
  S0796 targets distressed swimmers, so it may be in scope.
- **Records-based studies, by Gabriel's ruling: 2.** S0141, S0973.
- **Drowning or distress detection: 10.**

**Dates:**
- **All 22 fall in the window.** The earliest is S0026, 5 Nov 2025, from OpenAlex because the PDF gives
  no date.
- **S1537** prints 2024 received and online dates. They are a template error: the paper cites 25 works
  from 2025 and 6 from 2026. It is dated by its December 2026 issue.
- **S1540** was received in April 2025 but published on 29 Oct 2026, with no preprint found. Its earliest
  public version is therefore in the window.

**Answers to check questions:**
- **S0026:** its targets are passers-by, swimmers, and people about to enter the water.
- **S1515:** it benchmarks several detection models on its dataset.
- **S0178 and S1106:** no learned model.
- **S1142:** a people counter, kept as aquatic safety monitoring with a note.

**Still to screen:** the 62 papers in `fulltext_needed.csv` (31 include, 31 check), once their PDFs are
in place.

## Library retrieval (9–10 November 2026)

Gabriel's 12 manual downloads were moved in, then the rest were fetched in Gabriel's own Chrome
through the Griffith library proxy (`libraryproxy.griffith.edu.au`), with Gabriel signing in. Each PDF
was matched against its record's title or DOI before it was copied in, and its checksum was verified.
The one bot check (ScienceDirect security verification) was cleared in the browser, not worked around.

| Outcome | Papers | IDs |
|---|---:|---|
| PDF in place | **52** | all others in `fulltext_needed.csv` |
| No full text exists; record saved instead | 4 | S0070 (HAL notice + abstract, World Conference on Drowning Prevention 2025); S0625 (EGU26 conference abstract only); S1226 (Zenodo dataset, README only, no paper); S1549 (SciSpace title-only record, authors Barath and Gopinath, no venue, date or DOI) |
| Griffith has no SPIE access ("Get Access") | 4 | S0409, S0522, S0884, S1498 |
| Host unreachable on 10 Nov; retry | 2 | S0089 (UTFPR thesis repository), S0869 (IJIST journal site) |

**Full texts now in place: 80 of 90** (28 + 52).

**Notes for full-text screening:**
- **S0070, S0625, S1549:** each has an abstract or summary only. They will need a ruling on whether an
  abstract-only record can be judged.
- **S1226:** a dataset record, not a paper.
- **S0089:** a thesis (dissertation), in Portuguese going by the repository.

## Full-text screening: the remaining 52 (10 November 2026)

Screened by the analyst (agent:claude-opus-5-5) against the SLR criteria and Gabriel's rulings, in four
parallel groups working from one shared brief. The conference and online dates that decide the window
were checked against Crossref event records and the conference sites. Decisions, dates, flags and notes
are in `screening.csv` (`stage` = fulltext). **Checked and agreed by Gabriel, 10 Nov 2026.** The backups made before
writing are `decisions.backup-2026-11-10.json` and `decisions.backup-2026-11-10b.json`.

| Outcome | Papers |
|---|---:|
| **Included at full text** | **35** |
| Excluded at full text | 17 |

**Excluded, one reason each:**
- **Non-AI/ML (8):**
  - S0184: physics thresholds on FUNWAVE output;
  - S0351: reconstruction of a single fatal rip drowning, no ML;
  - S0592: threshold sensor fusion, with ML left as future work;
  - S0659: remote-controlled rescue buoy;
  - S0791: weighted sensor score against a threshold;
  - S1057: heart-rate and SpO2 thresholds;
  - S1208: analytical probability model;
  - S1289: sensor-material paper with a threshold alarm.
- **Insufficient technical detail (5):**
  - S0176: beach app with no model or test protocol;
  - S0276: CamTra, which names no detector, data or split;
  - S0290: the authors say no quantitative results were recorded;
  - S0825: qualitative results table only;
  - S1386: conceptual, nothing implemented.
- **Not aquatic safety (2):**
  - S0144: infrared detector where "drowned" refers to signal noise;
  - S0207: swimmer tracking for sport, under the "Keep them out" ruling.
- **Review (1):** S0317.
- **Before the window (1):** S0326 was presented at CoMeSySo 2025, held online 29–31 Oct 2025.

**Duplicate checks:**
- **The YOLO-NAS papers:** S0114 and S1537 come from one group but use a different method and dataset;
  S1537 cites S0114 as earlier work, so both stay. S0207 is from another group.
- **The Chuo rip-current chapters (APAC 2025):** S0246, S0247 and S0386 differ in first author, beach and
  analysis, so none is a duplicate.
- **The packet papers:** neither Drones paper is Ngo 2026. S0885 cites Ngo as its reference [1].

**Dates:** every one of the 35 falls in the window.
- **Conference first days, from Crossref:** ISMSIT 14 Nov 2025, ICICIS 25 Nov, ICIMCIS 3 Dec, IICSPI
  26 Dec.
- **APAC 2025:** held 4–7 Nov 2025.
- **S0467:** online 29 Jan 2026 (Crossref).

## Full-text totals (all 90)

- **Included: 57.**
  - **Hazard-detector (DEC-0010) flag: 14.** S0235, S0246, S0386, S0403, S0447, S0467, S0596, S0665,
    S0794, S0801, S1183, S1342, S1515 and S1540.
  - **People detectors: 15.** Under revision 3, these are outside the rubric's scope unless distress is
    in the evaluation.
  - **Records-based AI studies: 3.** S0141, S0589 and S0973.
- **Excluded at full text: 33.** This includes the 10 full texts that were not retrieved.

## Calls for Gabriel's check (settled 10 Nov 2026)

Gabriel agreed with all five as proposed: "I agree with your findings."


1. **S0276 (CamTra), excluded for insufficient technical detail.** It is on topic and reports some
   numbers, but never names its detector, data or split.
2. **S0246, included.** Its new contribution is an AR layer, and its AI evidence is a one-week
   cross-beach count comparison with no precision or recall.
3. **S0626, included as a people detector.** It detects pedestrians near riverbanks for warnings, but
   never shows that its images are of the waterside.
4. **S0207, excluded as sport.** It is a swimmer detector with no safety purpose, kept out under the
   "Keep them out" ruling. Under ruling 4 it would be included as a people detector instead.
5. **S0326, excluded as before the window.** This applies the conference-first-day rule to an online
   conference that ended on 31 Oct 2025.

## Deviation: pre-registration timing

**What the protocol required:** PREREGISTRATION_POSTSLR.md stage 1 was to be public before the
full-text decisions became final.

**What happened:** it was not. On 10 Nov 2026 the `CH02-OVI-preregistration` repository held only v1.0
(28 Oct 2026, for the held-out evaluation). The full-text decisions were made final on 10 Nov, before any
post-SLR release.

**What still holds:** screening was still blind to outcomes. No rater has seen these papers, and no
rubric score exists for them.

**What remains to do:** report this in the paper as a deviation.
