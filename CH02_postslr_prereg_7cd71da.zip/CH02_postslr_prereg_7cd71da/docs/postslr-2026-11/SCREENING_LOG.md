# Post-SLR screening log: titles and abstracts (1 November 2026)

**Status: provisional, for Gabriel's check.** Screened by the analyst (agent:claude-opus-5-5) at
Gabriel's request ("You screen, I check"), against the criteria in SEARCH_PROTOCOL.md.
- **Where the records are:** the full table, one row per record with decision, reason, stage and note, is
  `.research-private/postslr-2026-11/search/screening.csv`. It is never committed.
- **How it was built:** `scripts/postslr_screening.py`. The decisions are in `decisions.json` beside it.
- **Blind to outcomes:** no rater has seen any of these papers, and no rubric score exists for them.

## How it was done

1. **Abstracts:** gathered for 1,345 of the 1,555 records, from the arXiv export, PubMed (efetch) and
   OpenAlex (by DOI). Semantic Scholar filled in four more.
2. **Titles:** all 1,555 were read.
   - **Most went out by title:** 1,420 records, almost all clearly outside the topic. Examples are water
     quality, sports physiology and swimming performance, microswimmers, fish, forensic diatoms, and
     drowning used as a metaphor.
   - **Every title that could plausibly qualify had its abstract read.** That was about 130 records.
3. **Abstracts:** read against the criteria, giving one decision per record:
   - **include:** goes forward to full text;
   - **check:** uncertain, and goes forward to full text with a stated question;
   - **exclude:** with one reason.

## Counts

| Decision | Records |
|---|---:|
| **Include** (to full text) | **52** |
| **Check** (to full text, with a question) | **38** |
| Exclude | 1,465 |

| Exclusion reason | Records |
|---|---:|
| Not drowning detection or aquatic safety monitoring | 1,405 |
| Non-AI/ML approach (mostly IoT or wearables with sensor thresholds, and drowning-prevention studies) | 28 |
| Review without original data (one of them is the SLR itself) | 10 |
| Not empirical, or insufficient technical detail (proposals, a social-science case study) | 6 |
| Earliest public version before 1 Nov 2025 (SciSpace records dated 2014–2023 by their DOI) | 6 |
| Not a publication (dataset splits, software records, one retraction) | 5 |
| Not in English | 4 |
| Duplicate | 1 |

## Rules applied where the criteria needed reading

1. **"Aquatic safety monitoring":** read as AI/ML that detects or monitors people in or near water for
   their safety, or a drowning hazard. That covers:
   - drowning and distress detection;
   - swimmer or person-in-water detection for rescue;
   - rip currents.
2. **Not aquatic safety:**
   - swimming performance analytics (stroke counting, pose for coaching, heart rate for training);
   - water quality;
   - clinical or forensic analysis of drowning cases.

   **Swimming performance analytics stay out (Gabriel, 1 Nov 2026, "Keep them out").** This holds even
   though the SLR's own 65 include swimming-activity recognition (papers 59 and 82). Four papers carry a
   note recording the ruling: S0354, S0600, S0617, S0638.
   **Flood rescue is out too (Gabriel, 1 Nov 2026, "Keep it out").** S0038 detects people stranded in
   floodwater, which is disaster response, not a swimming or bathing setting.
3. **Non-AI/ML:** wearables and IoT devices whose detection is a sensor threshold or rule, with no
   learned model in the abstract. Where the abstract does not say, the record is marked check.
4. **Records-based AI studies: included (Gabriel, 1 Nov 2026, "Include them").** Three records apply ML
   or NLP to drowning records rather than to a detection system:
   - S0141: forecasting bathtub-drowning mortality;
   - S0589: NLP on media and police reports;
   - S0973: classifying Danish prehospital records.

   - **Why included:** the SLR's 65 include comparable studies, 75 (ML drowning-risk prediction) and 38
     (tide records). Including these keeps the new set comparable with the packet. The raters are likely
     to agree they are outside the rubric's scope.
   - **Not extended:** the ruling does not cover clinical or forensic ML on drowning cases (S0344, S0544,
     S0840, S1438). These diagnose or prognose individual patients or bodies, and the packet has nothing
     like them. They stay excluded under rule 2.

## What the includes look like (provisional)

- **Drowning or distress detection: about 30.**
  - Pool and open-water vision, mostly YOLO variants;
  - UAV drowning detection;
  - wearables with an ML model;
  - an underwater camera system;
  - a life jacket with embedded AI;
  - rescue platforms with detection (a buoy USV, a rescue board).
- **Records-based AI studies: 3** (S0141, S0589, S0973), by Gabriel's ruling.
- **Rip-current detectors: 9.**
  - S0235, S0403, S0447, S0596, S0665, S0794, S1183, S1342, S1540.
  - Under DEC-0010 they are hazard-detector papers, so the flag will be fixed at full text.
  - That is a far larger share than in the packet (2 of 65), so the pre-registered sensitivity
    analysis without hazard detectors matters more here.
- **Person-in-water detection for maritime search and rescue: about 7.** For example S0173, S1284 and
  S1319. Under revision 3, a people detector with no drowning or distress in its evaluation is outside
  the rubric's scope. Screening keeps them, as the protocol requires.
- **Possible overlap:** three YOLO-NAS open-water papers may come from one group (S0114, S0207, S1537).
  They will be compared at full text.

## Dates

- **The window:** every include and check record with a DOI was looked up in Semantic Scholar for an
  earlier version.
  - **Found:** none dated before 1 Nov 2025.
  - **arXiv-first:** two papers (S0794, S0796), both from April 2026.
- **Still to do at full text:** each paper's own date (received, published, conference) is confirmed
  from the paper, as for papers 5 and 53.

## What happens next

1. **Gabriel's check:**
   - the 52 includes;
   - the 38 checks, each with its question;
   - a sample of the exclusions;
   - no rulings left open.
2. **Full texts for the include and check records.** The analyst can fetch the open-access ones; the
   rest need library access. Full-text screening then settles each check, confirms dates, and fixes the
   hazard-detector flags.
3. **Citation tracking** of the final includes, as in the SLR. It also looks for the parent papers of
   two dataset records (S0119, S0525).
4. **The pre-registration's stage 1** should be published before the full-text decisions are final.
