# Post-SLR paper set: search, screening and preparation (DRAFT, 1 November 2026)

**Status: DRAFT for Gabriel. Not approved, not published, and no search has been run.** Provenance:
agent:claude-opus-5-5. Its companion is [PREREGISTRATION_POSTSLR.md](PREREGISTRATION_POSTSLR.md).

## Why

- **The gap it fills:** every paper in the 65-paper packet has been seen by at least one rubric version.
  v1.2 revision 3 was refined on the 42 corpus papers it was then run on (CORPUS3B), so its transfer is
  untested.
- **What it gives:** papers that no version of the rubric, the handbook or the pipeline has seen. That
  makes the comparison of v1.2 revision 3 against v1.0 a test on unseen papers.

## The sampling frame

- **Window:** publications whose earliest public version appeared on or after **1 November 2025**, the
  day after the SLR's final search (31 Oct 2025, `2-methods.tex` line 21), up to the search date.
  - **Earliest public version:** the first of a preprint posting, online-first publication, or the
    conference's first day. A paper with any public version before 1 Nov 2025 is outside the frame,
    because the SLR could have found it.
  - **Why this rule:** it gives one dated frame that a reader can check, rather than "what the SLR
    missed", which cannot be checked.
- **Already in the packet:** papers 27 (Hou 2025, MobiCom '25, 4–8 Nov 2025) and 53 (Ngo 2026, *Drones*,
  received 9 Jan 2026) fall inside the window. They are excluded, because they were rated in the
  held-out evaluation and the development loop.
- **Found incidentally:** papers from before the cutoff that the SLR missed are listed with a reason and
  not included.

## The search

The SLR did not record its per-database strings ("available from the corresponding author upon request",
`supplementary.tex` §S1). Its two descriptions differ: the main text and the supplement name different
terms. The search below uses the union of both, so it is at least as broad as either.

- **Databases:** the SLR's four: SciSpace, Google Scholar, arXiv and PubMed. Then backward and forward
  citation tracking of the included papers, as in the SLR.
- **String** (adapted only to each database's syntax, and recorded exactly as run):

  ```
  ("drowning detection" OR "swimmer monitoring" OR "aquatic safety" OR "water safety"
   OR "swimmer distress" OR "aquatic emergency")
  AND
  ("artificial intelligence" OR "machine learning" OR "deep learning" OR "computer vision"
   OR "wearable sensor")
  ```

- **Limits:** English. Publication date from 1 Nov 2025. No other filters.
- **What is saved for each database:** the exact string, the date and time run, the number of hits and
  the exported records (RIS or CSV), in `.research-private/postslr-2026-11/search/`.
- **Who runs it:** Gabriel, because library access and logged-in databases are his. The analyst can run
  the arXiv and PubMed queries through their public interfaces if Gabriel prefers.

## Screening

- **Criteria:** the SLR's main-text criteria (`2-methods.tex`, "Inclusion and Exclusion Criteria"),
  unchanged:
  - **Include:**
    1. AI/ML-based drowning detection or aquatic safety monitoring;
    2. empirical research with technical details;
    3. English;
    4. peer-reviewed publications, preprints or patents.
  - **Exclude:**
    1. non-AI/ML approaches;
    2. non-aquatic domains;
    3. insufficient technical detail;
    4. duplicate publications;
    5. reviews without original data.
  - **A difference within the SLR, to note in the paper:** its supplement lists peer-reviewed articles
    only. Its main text, used here, also admits preprints and patents.
- **The SLR's inclusion is not the rubric's scope.** Papers that meet the SLR criteria are included even
  when they may be outside the rubric's scope (for example people detectors). Scope is the raters'
  judgment, as it was for the 42 corpus papers.
- **Stages:**
  1. deduplicate and apply the date rule (mechanical; the analyst can do it from the exports);
  2. title and abstract;
  3. full text.

  Each exclusion is recorded with one reason, so the result can be shown as a PRISMA-style flow.
- **Who screens: Gabriel, decision needed.** The SLR's screening was the first author's.
  - **Recommended:** Gabriel screens, as in the SLR. That keeps the new set comparable with the 65.
  - **Alternative:** the analyst screens against the criteria, and Gabriel checks every decision.
  - **Either way:** screening happens before any rater sees a paper. No rubric score, pillar or OVI is
    looked at, because none exists yet.
- **Hazard-detector papers:** papers whose scope rests on D alone are flagged at full-text screening,
  under DEC-0010's definition, for the sensitivity analysis. The flag is fixed before the run.

## Preparation (as for the 65, unchanged)

1. **PDF:** the version of record where available, otherwise the preprint. Stored only in
   `.research-private/postslr-2026-11/papers/`, never committed or released.
2. **Conversion:** md-v1 (`scripts/convert_papers_markdown.py`), with the same toolchain versions
   recorded in a new manifest.
   - **Exclusion before rating:** a paper whose conversion recall falls below the review threshold
     (0.95) and cannot be fixed by the md-v1 rules is excluded, with the reason recorded.
3. **Figures:** described by claude-opus-5-5 with the frozen figure prompt (`scripts/describe_figures.py`),
   then frozen.
4. **Smoke run:** a D0 run (`D0_V4`) on the fictional fixture must pass before the first real request.

## Expected size, cost and time

- **Size:**
  - **Estimate:** the packet has 15 primaries from 2023 and 9 from 2024. It has 8 from 2025, a year
    the SLR covered only to October. A year of new publications should give about 10–25 eligible
    papers. This is an estimate, not a target.
  - **What counts:** the screening outcome, whatever it is.
- **Cost (ledger estimates):**
  - **Rating:** CORPUS3 cost US$39.01 for both arms on 42 papers, discussion included. That is about
    US$0.93 per paper, so about US$19 for 20 papers.
  - **Figure descriptions:** about US$10.5 was set aside for 623 figures on 28 Oct, under US$0.02 a
    figure. The packet averages about 10 figures to describe per paper, so 20 papers need about US$4.
  - **In all:** about US$25 for 20 papers, plus up to three re-requests of lost replies under v4.
- **Time:** about a week for 13 Nov.
  - Gabriel's steps:
    - the search (1–2 days);
    - screening (1 day);
    - PDFs (1 day).
  - Then the analyst's: conversion and figure descriptions, D0, the run (a few hours), and the report.
