# Post-SLR md-v1 conversion: review of flagged papers (10 November 2026)

Converted by the analyst (agent:claude-opus-5-5) with `scripts/postslr_convert.py`. This is the md-v1 core
and review rule of `convert_papers_markdown.py`, unchanged; only the input list differs.
- **Inputs:** the 57 full-text includes.
- **Manifest:** [MARKDOWN_MANIFEST.json](MARKDOWN_MANIFEST.json), hashes and counts only.
- **Private outputs:** `.research-private/postslr-2026-11/markdown-v1/study-<id>/`.
- **Study IDs:** 10000 plus the record number (S0021 → 10021), so they never collide with the packet's 1–82.

## Result

- **Flagged for review: 12 of 57**, by the same rule as the 65 (17 of 65 were flagged there).
- **Excluded: none.** All 12 were inspected, and none loses body text.
- **The protocol's rule:** exclude a paper whose recall is below 0.95 and cannot be fixed by the md-v1
  rules. It does not apply to any paper here, because the shortfall is extraction noise, not missing text.

| Flag | Papers | What the inspection found |
|---|---|---|
| Recall below 0.95 | S0403 (0.922), S0794 (0.941), S1301 (0.947), S1142 (0.949) | The "lost" tokens are hyphenation fragments of the reference text (`-tion`, `-ing`, `detec-`). md-v1 rejoins them. The rest is an arXiv margin stamp, equation layout and author superscripts. No body paragraph is missing. |
| Three or more unresolved runs | S1284 (29), S0199 (22), S0447 (11), S0764 (8), S0141 (6), S0403 (6), S0801 (4), S0220 (3), S0452 (3) | They come from running headers ("MANUSCRIPT ARTICLE" on an accelerated preview; "iScience Article"), the paper's own class label (`lifesavingappliances`) and place names written without spaces. None is body text glued together. |

This matches what was found for the 65 (WORKPLAN_RUBRIC_V1_2.md, A5; LOOP_DESIGN.md, "Fidelity"). No
input was hand-patched.

## Next

- **Figures to describe:** 519. They go to the frozen describer (`scripts/describe_figures.py`,
  figure-describe-v1, claude-opus-5-5).
- **After that:** D0, then the run.
