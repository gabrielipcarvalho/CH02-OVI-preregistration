# Measures for the full-corpus run (declared 29 October 2026, before any of its papers are scored)

Decided by Gabriel on 29 Oct 2026. Provenance: agent:claude-opus-5-5.

These measures apply to the scoring of the 42 papers not yet scored with the final procedure. Those
papers have not been exposed to any development or evaluation run, so declaring the measures now, before
the freeze, is prospective. The pre-registered held-out result (version 2) is unchanged and is still
reported with its own measures.

## Unit

A **panel** is one paper × one pillar × one execution, judged independently by the three AI raters in R0.

## Primary agreement measure: resolved panels

A panel is **resolved** when the three raters either:
- give the same score, each backed by a verified quotation or the absence marker; or
- all judge the pillar not applicable to the paper (`applicability_uncertain`, under Larry's D1: the
  paper assesses no drowning detection or response system).

A unanimous "not applicable" is an agreed scope judgment, so it counts as agreement. It does not produce
a pillar score.

Reported next to the primary measure:
- **Complete and agreeing** (three equal scores), the pre-registered primary. It stays comparable with
  the held-out evaluation.
- **Unresolved panels**, broken down as:
  - score disagreement;
  - not applicable against a score;
  - a failed judgment, by failure category.
- **Conditional agreement** (agreeing ÷ complete) and **repeat stability** across executions.

## OVI

- **Which papers get an OVI:** an OVI-Gate (minimum of the four pillars) is computed only for a profile
  with four scored pillars.
- **Out of scope:** a paper whose pillars are agreed not applicable is reported as outside the rubric's
  scope, not as incomplete. It receives no OVI.
- **Out-of-scope count:** reported separately, as a finding about the review corpus.

## Discussion

If discussion-v1 is adopted after the exploratory check (`results/DISC_V13.md`), it runs after R0 on
contested panels only.
- **R0 stays the reliability measure.**
- **The after-discussion figures are reported as a separate, dependent reconciliation stage.** They
  report movement towards the R0 majority, and never replace R0.

## Addendum: design and comparison (declared 30 October 2026, before freezing)

Gabriel chose design C on 30 Oct 2026, after the costing in `results/COSTING_42.md`. The text above
is unchanged. This addendum fixes the rubric versions, the design and the comparison before any of
the 42 papers is scored. Provenance: agent:claude-opus-5-5.

### Design

- **Papers:** the 42 corpus papers (`CORPUS` in `pipeline/study/final_phase.py`). None was exposed to a
  development, evaluation or exploratory run, and none was used to write rubric v1.1.
- **Arms:**
  - **CORPUS_V11, the refined package:** rubric v1.1 revision 2 (`rubric/rubric_v1_1.yaml`) with
    handbook H4.
  - **CORPUS_V10, the published package:** rubric v1.0 (`rubric/rubric.yaml`) with the handbook of
    the pre-registered EVAL_ORIGINAL run. The refined handbook C3 is not used, because its rules became
    v1.1 text.
- **Everything else is identical in both arms:** the models and settings (GLM at high reasoning), the
  md-page-v1.3 validator, final check v2, glm-repair-v2, quote-correction-v1 and unreadable-resample-v1.
  The independent-round prompts differ only in the rubric and handbook text
  (`tests/test_corpus_run.py`).
- **Executions:** 2 per arm, so 336 panels per arm (42 papers × 4 pillars × 2 executions).
- **Order:**
  1. one D0 smoke run (D0_CORPUS);
  2. the independent round of both arms in one seeded, interleaved schedule (`CORPUS`), so neither arm
     runs systematically earlier;
  3. discussion in the v1.1 arm only, execution 1 then execution 2. Each starts only if every provider
     still has its estimated discussion cost per execution plus one reservation (US$0.45) left:
     Anthropic US$1.63, OpenAI US$1.17, Z.AI US$1.04. An execution refused for headroom is reported as
     not discussed.
- **What the comparison can attribute:** it compares package with package. Rubric text and handbook
  change together, so a difference cannot be split between them.

### Comparison of the arms (independent round only)

- **Primary:** the difference in the proportion of resolved panels, v1.1 minus v1.0, with both
  executions pooled.
  - Panels are paired by paper × pillar × execution.
  - **Interval:** a 95% interval from a bootstrap that resamples papers (10,000 resamples, seed
    `corpus-run-20261030`), because panels of one paper are not independent.
  - **Expected:** v1.1 resolves more panels.
  - **Reading:** v1.1 is better on unseen papers if the interval's lower bound is above 0. If the
    interval includes 0, no difference is detected.
  - **Also reported:** the discordant pairs (resolved in one arm only), in each direction.
- **Secondary, with the same interval:** the difference in complete and agreeing panels, the
  pre-registered primary.
- **Descriptive only, without tests:**
  - both differences per pillar;
  - papers agreed out of scope in each arm;
  - failed judgments in each arm, by failure category;
  - how often the correction turn, the re-request and the adjacent-page rule fired in each arm.
- **Per arm:** all the measures declared above, including OVI and repeat stability across the two
  executions.

### Discussion

- **After-discussion figures for v1.1:** reported as a separate, dependent reconciliation stage, as
  declared above.
- **Not compared with v1.0:** the v1.0 arm is not discussed.

### If the run stops early

- **Rule:** if a budget stop ends the independent round, the comparison uses only paper-executions
  complete in both arms.
- **Reporting:** the stop and the missing paper-executions are reported.

All results are AI judgments (`human_confirmed=false`).

## Addendum: re-freeze after the stopped attempt (declared 30 October 2026, before re-freezing)

- **What happened:** the first freeze (schedule `CORPUS`; conditions `D0_CORPUS`, `CORPUS_V11`,
  `CORPUS_V10`) stopped at 15:23 after 72 of 504 independent-round requests. Anthropic answered HTTP
  529 (`overloaded_error`), which the transport did not then treat as temporary.
- **Fix:** HTTP 529 is now retried like the other temporary errors, within the same three attempts,
  after waits of 60 s and 120 s. Nothing else in the pipeline changed.
- **Re-freeze:** the same design under new names: `D0_CORPUS2`, `CORPUS2_V11`, `CORPUS2_V10`, and the
  interleaved schedule `CORPUS2` (order seed `corpus2-run-20261030`). Arms, papers, executions,
  rubrics, handbooks, models and settings are unchanged.
- **Measures:** unchanged, including the bootstrap seed `corpus-run-20261030`. The analysis uses only
  the `CORPUS2` runs.
- **The stopped attempt:** its 72 requests stay in the ledger. They are reported as a stopped attempt
  (count, cost, cause) and do not enter any result.
- **Budget:** the stopped attempt used about US$4.17, so less Sonnet headroom is left for discussion.
  The headroom check before each v1.1 discussion decides whether one or both executions are discussed.

## Addendum: CORPUS3, the complete experiment (declared 31 October 2026, before freezing)

Gabriel judged CORPUS2 a failed experiment for the final objective: its discussion stage never ran.
The rubric problems it exposed are fixed in v1.2 (DEC-0009), and the experiment is run again as
CORPUS3. Provenance: agent:claude-opus-5-5. The text above is unchanged.

### Design

- **Papers:** the same 42 corpus papers, 2 executions per arm, one interleaved schedule (`CORPUS3`,
  order seed `corpus3-run-20261031`).
- **Arms:**
  - **CORPUS3_V12, the refined package:** rubric v1.2 (`rubric/rubric_v1_2.yaml`) with procedure H5.
  - **CORPUS3_V10, the published package:** rubric v1.0 with the EVAL_ORIGINAL handbook, unchanged
    from CORPUS2.
- **Pipeline:** as in CORPUS2, with three changes:
  - the GLM read timeout is 600 s;
  - the re-request policy is `unreadable-resample-v2`;
  - no spending limits.
- **Discussion:** in both arms, after the independent round of both arms is complete.

### Status of the papers

- **For v1.2:** the papers are exposed. v1.2 was written from CORPUS2's results on them, so CORPUS3
  tests v1.2 on papers it was refined from, not on unseen papers.
- **CORPUS2:** reported unchanged, as the comparison of v1.1 against v1.0 on unseen papers.

### Measures

- **Primary:** as declared above. The paired difference in resolved panels (v1.2 minus v1.0) in the
  independent round, with executions pooled.
  - 95% paper bootstrap interval: 10,000 resamples, seed `corpus3-run-20261031`.
  - Discordant pairs in each direction.
- **Secondary, with the same interval:**
  - the difference in complete and agreeing panels;
  - the difference in resolved panels after discussion. This is a dependent reconciliation stage and
    never replaces the independent round.
- **Declared sub-analysis:** the primary difference computed separately for:
  - the 9 papers behind a v1.2 ruling (4, 11, 26, 41, 46, 50, 66, 81, and 61, considered and not
    changed);
  - the other 33 papers, which were seen but not used to write any ruling.
- **Descriptive only:**
  - **As before:** per pillar; out of scope; failures by category; mechanics; OVI; repeat stability.
  - **New:** v1.0's run-to-run variation between CORPUS2 and CORPUS3, the same package run twice.

### If the run stops early

- **Credit:** a provider running out of credit stops the run with its billing error.
- **Then:** the comparison uses only paper-executions complete in both arms, and the stop is
  reported.

### Amendment before freezing (31 October 2026, after CHECK_V12)

- **Rubric:** v1.2 is revision 2 (`RUBRIC_V1_2.md`, rows 16–18).
- **Re-request policy:** `unreadable-resample-v3` replaces v2. A reply the provider returned incomplete
  is also re-requested once, unchanged.
- **Measures:** unchanged.

### Amendment: CORPUS3B, the v1.2 arm under revision 3 (declared 31 October 2026, before freezing)

- **Why:** CORPUS3's P4 disagreements came mostly from one revision 2 sentence
  (`CORPUS3_P4_FINDINGS.md`). Gabriel accepted revision 3 (DEC-0009, addendum 2) and a re-run of the
  v1.2 arm.
- **Design:**
  - Arm `CORPUS3B_V12`: revision 3 (`rubric/rubric_v1_2_r3.yaml`) with H5.
  - The same 42 papers and 2 executions, with discussion per execution.
  - Pipeline, models and re-request policy (v3) as in CORPUS3. Only the rubric sentence differs.
- **The comparator:** CORPUS3's v1.0 arm, reused unchanged. Panels are paired by paper × pillar ×
  execution, as before.
- **Not interleaved:** the arms do not share one schedule. The re-run comes a few hours after the v1.0 arm,
  on the same pinned models. The v1.0 replication (CORPUS2 against CORPUS3: 267 and 263 resolved) bounds
  the run-to-run variation.
- **Measures:** as declared in the 31 Oct addendum, with `CORPUS3B_V12` in place of `CORPUS3_V12`:
  - **Primary:** the paired difference in resolved panels in the independent round, with the same
    bootstrap (10,000 resamples, seed `corpus3-run-20261031`) and the same reading.
  - **Secondary:** complete and agreeing panels; resolved panels after discussion.
  - **Declared sub-analysis:** the 9 ruled papers against the other 33, as before.
  - **Descriptive, new:**
    - the 5 papers behind revision 3 (35, 41, 48, 64, 67);
    - revision 2 (CORPUS3) against revision 3 (CORPUS3B) on the same panels: resolved, resolved on P4,
      and changed trios.
- **Reporting:**
  - CORPUS3B is reported as the complete-experiment result for v1.2 revision 3.
  - CORPUS3 is reported unchanged, as the run of revision 2.
  - All 42 papers are exposed for both.
- **If the run stops early:** as declared above. Only paper-executions complete in both arms are used,
  and the stop is reported.
