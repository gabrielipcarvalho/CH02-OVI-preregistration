# DEC-0009 — Rubric v1.2 rulings

`status: accepted` · `decided-by: Gabriel, 2026-10-31` · `raised: 2026-10-31`

## Context

- **The run:** CORPUS2 (30 Oct) compared v1.1 with the published v1.0 on the 42 corpus papers. Its
  independent round completed; its discussion stage did not run.
- **Gabriel's assessment (31 Oct):** a failed experiment for the final objective, to be run again.
  - The chapter's purpose is to refine the rubric.
  - So the rubric problems that run exposed are fixed before the complete experiment is run again.
- **The evidence:** `docs/final-phase-2026-10-28/CORPUS2_FINDINGS.md`. The change log is
  `docs/final-phase-2026-10-28/RUBRIC_V1_2.md`.

## Rulings (Gabriel, 31 Oct 2026, accepting the analyst's recommendations)

1. **Scope: detectors of people.**
   - A system evaluated only on detecting swimmers or people in or under the water is out of scope.
   - This includes a search-and-rescue detector evaluated on people not documented to be in distress.
   - Scope is decided once per publication, so P1–P3 are all assessed or all not applicable.
   - **Note:** this extends Larry's D1 and the 30 Oct boundary (DEC-0008 ruling 1). Larry is to be
     informed.
2. **P4: consent.**
   - Counts only when consent from the people the system monitors in use is part of the system as
     designed for use.
   - Consent from study participants to collect research data does not count.
   - This resolves v1.1's contradiction between the level-1 example and the privacy-mitigation test.
3. **P4: processing on the device.**
   - Uploading identifiable video or images when an event is detected does not count.
   - Processing non-imaging sensor data on the device, with none of it transmitted, counts.
4. **P1: systems without training data.** Evaluations at two distinct sites, with results reported for
   each, count as one cross-site evaluation.

## Consequences

- **v1.2 and H5:** v1.2 (`rubric/rubric_v1_2.yaml`) is applied with procedure H5, which adds the
  once-per-publication scope step.
- **Exposed papers:** the 42 corpus papers are now exposed for v1.2.
  - CORPUS2 is reported unchanged as the unseen-paper comparison of v1.1 against v1.0.
  - The v1.2 run is reported as a run on papers v1.2 was refined from.
- **Before the complete experiment:** the exploratory check CHECK_V12 (`WORKPLAN_RUBRIC_V1_2.md`).

## Addendum: revision 2 (Gabriel, 31 Oct 2026, after CHECK_V12)

5. **Staged drowning counts.** The people-detector exclusion applies only when the evaluation has no
   drowning, distress or casualty, real or staged.
   - This corrects the revision 1 wording ("not documented to be in distress"), which did not match
     ruling 1.
6. **Built systems evaluated in part.** A system built to detect drowning or to raise a drowning alert
   stays in scope when only some of its components are evaluated. Each pillar is scored on what is
   evaluated.
7. **Local-only systems.** A system description with no transmission component, whose only output is
   local, documents that nothing is transmitted.
8. **Pipeline.** A reply that used its whole output-token cap and returned no answer is re-requested
   once, under the content-blind re-request policy. The generation settings are unchanged.

## Addendum 2: revision 3 (Gabriel, 31 Oct 2026, after CORPUS3)

9. **Non-transmission needs a statement.** A publication documents that nothing is transmitted only when
   it states one of these:
   - the system as described has no communication component;
   - communication is left to future work.

   Its only output must also be local. A description that does not mention transmission does not
   document it.
   - This replaces revision 2's local-only sentence. That sentence turned silence into evidence on four
     camera papers (`CORPUS3_P4_FINDINGS.md`).
10. **Unchanged:**
    - the sensor-choice boundary (papers 50 and 82), left to discussion;
    - paper 26 (a rater error).
11. **Stopping rule:**
    - Revision 3 is the last revision made from the 42 corpus papers.
    - Disagreements after it are reported as residual, and left to discussion with no further wording.
12. **Re-run:**
    - After the check CHECK_V12C, the v1.2 arm is re-run under revision 3 (CORPUS3B).
    - It is compared against CORPUS3's v1.0 arm, which revision 3 does not touch.
    - CORPUS3 is reported unchanged, as the run of revision 2.

## Addendum 3: CORPUS3B despite J3 (Gabriel, 31 Oct 2026, after CHECK_V12C)

13. **The deviation:** CHECK_V12C met J1, J2 and J5, but not J3. Paper 23 had one gpt reading of 0
    (`results/CHECK_V12C.md`). The declared rule (`WORKPLAN_RUBRIC_V1_2.md`, §B3) was to stop and
    report.
    - **Gabriel's decision:** "Run CORPUS3B anyway".
    - **The run:** CORPUS3B runs as declared in §D and the CORPUS3B amendment of
      `CORPUS_RUN_MEASURES.md`, with no change to its design or measures.
    - **Reporting:** the J3 failure and this decision are reported with its results.
    - **The stopping rule (ruling 11) stands:** revision 3 stays the last revision.
