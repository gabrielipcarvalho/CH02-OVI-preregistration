# DEC-0010 — Hazard detectors in scope (D) and P2 for hazard detectors (N)

`status: accepted` · `decided-by: the analyst (agent:claude-opus-5-5), delegated by Gabriel, 2026-11-01` ·
`raised: 2026-10-28`

## Context

- **What was open:** DEC-0008 ruling 5 confirmed D (hazard detectors are in scope, Gabriel 28 Oct) and
  N (P2 "authentic events" for hazard detectors), but flagged both as awaiting Larry's agreement. No
  answer from Larry is recorded.
- **The delegation:** on 1 Nov Gabriel wrote "Do the ruling yourself". This record is that ruling. It
  replaces the wait for Larry; it does not record an answer from him.
- **Timing:** the ruling was written before the with/without sensitivity analysis was computed, so it
  does not depend on what that analysis shows.

## Rulings

1. **D is confirmed.** A system evaluated on detecting a drowning hazard is in scope (rubric v1.2
   revision 3, `scope`, unchanged).
2. **N is confirmed.** For a hazard detector, P2's "authentic distress events" means real field
   occurrences of the detected hazard, and "expert behavioural or clinical ground truth" means expert
   annotation or verification of them (v1.2 revision 3, P2 `definitions`, unchanged).
3. **The sensitivity analysis stays.** Every outcome is still reported with and without the
   hazard-detector papers (PREREGISTRATION.md, "Sensitivity"), so a reader who would rule D the other
   way can see its effect.

## Reasons

- **The corpus the rubric was published for includes them.** The SLR's inclusion criterion is
  "AI/ML-based drowning detection or aquatic safety monitoring" (`2-methods.tex`, line 27). Its
  primaries include two rip-current detectors (papers 60 and 61). Ruling D the other way would put
  published primaries outside the rubric built from them.
- **The other pillars apply to them as written.** P1 (generalisation), P3 (equity and accessibility)
  and P4 (governance) ask nothing that depends on whether the detected event is a drowning or a hazard.
- **N is what makes D coherent.** Without N, a hazard detector could never meet P2's "authentic
  distress events", so its P2 would be 0 by construction rather than by evidence. That contradicts
  the rubric's own rule that 0 means absent evidence.
- **The cost of being wrong is visible.** The sensitivity analysis bounds it, and if D were reversed
  the rubric text already says what follows: P1–P3 not applicable for these papers.

## The hazard-detector papers (fixed with this ruling, from the papers, not from any score)

A paper is a hazard-detector paper when the system it evaluates detects a drowning hazard and does not
detect drowning, distress, a casualty or a distress signal. These are the papers whose scope rests on D
alone.

| Paper | Set | Detected hazard |
|---|---|---|
| 60 | development | rip currents |
| 61 | corpus | rip currents |
| 72 | held-out | a person in a closed pool out of hours (unsupervised entry, DEC-0008 ruling 6) |
| 3 | corpus | a person or animal in an unattended pool out of hours (unsupervised entry) |
| 10 | corpus | a distracted parent or caregiver (inadequate supervision of children) |
| 79 | held-out | a person without a life jacket, with age-based risk |

**Considered and not included:**
- **63:** drone surveillance whose stated purpose includes detecting drowning. Under revision 3 it is
  either a drowning system or a people detector, never in scope through D alone.
- **75:** risk prediction from survey records. No detection system is evaluated, so it is outside scope
  whatever D says.
- **38:** tide and fatal-drowning records. No system is evaluated.

## Consequences

- RUBRIC_V1_1.md rows 1 and 4: the status "awaiting Larry" is closed by this record.
- **A correction to EVAL_RESULTS.md:** it says none of the 15 held-out papers is a hazard detector.
  Under the wording frozen for that evaluation (HANDBOOK_C3, "systems that detect a drowning hazard in
  order to prevent drowning"), papers 72 and 79 are hazard detectors. The pre-registered sensitivity
  analysis is recomputed in `results/HAZARD_SENSITIVITY.md`. The original sentence is left in place,
  with a pointer to the correction.
- Larry is still to be told of the scope rules (`NOTE_LARRY_SCOPE_2026-10-30.txt`); sending it is
  Gabriel's.
