# DEC-0011 — Re-request policy unreadable-resample-v4

`status: accepted` · `decided-by: Gabriel, 2026-11-01` · `raised: 2026-11-01`

## Context

- **The rule until now** (`unreadable-resample-v3`, DEC-0009 ruling 8):
  - a reply that cannot be read at all, that has format failures in some pillars, or that the provider
    returned incomplete, is re-requested **once**, unchanged;
  - a provider failure (network, HTTP 5xx or 529) gets three transport attempts and is then a process
    failure.
- **What it left in CORPUS3B:** 8 of its 9 failure panels came from two replies that showed nothing of the
  judgment:
  - Sonnet on paper 8: unreadable twice;
  - GLM on paper 46: unreadable, then cut off at the output cap.

  The ninth was an evidence failure.
- **The question:** Gabriel asked whether to keep prompting until a usable answer arrives. The analyst
  advised against an unbounded or content-dependent retry:
  - a score of 0 needs no quotation, so re-asking until evidence validates biases scores towards 0;
  - keeping only the replies that parse selects the data;
  - the lost coverage is itself a finding.

## Ruling (Gabriel, 1 Nov 2026: "I agree, do it")

1. **Up to three re-requests,** unchanged, for a failure that shows nothing of the judgment:
   - a reply with no readable pillar;
   - a reply the provider returned incomplete (no text, or the output cap reached);
   - a provider failure that outlasts the transport attempts (a quota or billing error is not retried).
2. **Unchanged:**
   - a reply with format failures in only some pillars still gets one re-request;
   - an evidence failure still gets one quote-correction turn with its judgment fixed;
   - generation settings are never changed for a re-request.
3. **Applies only to runs frozen under it:**
   - the next frozen experiment, with D0_V4 as its smoke run;
   - every run frozen earlier keeps its own policy;
   - the ledger refuses a second re-request for any run not frozen under v4.

## Notes

- **One extension past the wording agreed in chat:** a reply with no readable pillar is included, though
  the chat named "empty replies, cut-off replies, incomplete output and network errors".
  - **Why:** its trigger depends on nothing in the judgment, because nothing in it can be read.
  - **Which case:** Sonnet's paper 8 reply, earlier reported as empty, is exactly this.
  - **To reverse it:** drop `failure_status == "format_failure"` from `blind` in
    `pipeline/study/transport.py`.
- **Reporting:** every re-request stays in the ledger and is logged as an `unreadable_resample` event,
  numbered 1–3, so coverage can be reported both before and after re-requests.
- **Code:** `pipeline/study/records.py`, `pipeline/study/transport.py` and `pipeline/study/final_phase.py`.
  Tests: `tests/test_resample_v4.py`.
