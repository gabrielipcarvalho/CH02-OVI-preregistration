# Prospective measures — version 1

Provenance: agent:gpt-6; no study results. Accepted descriptive direction, exact operational
definitions delegated by Gabriel on 2026-09-28. Applies separately to each version/condition,
execution, paper batch, round and pillar. Never pool R0 with dependent deliberation or fresh
checks, or describe three repeated model calls as three independent human raters.

Let N=5 papers, K=4 pillars, R=3 raters per development execution. Requested R0 cells=20;
requested rater judgments=60. Evaluation uses 15 reserved papers split into three batches;
report both each batch and all evaluation papers with the same formulas. A missing denominator
is reported as NA with numerator and denominator, never as zero or perfect agreement.

| Measure | Numerator / denominator and reporting |
|---|---|
| Complete-panel coverage | Cells with all three valid numeric scored judgments / all requested paper×pillar cells. |
| Primary R0 exact agreement | Fully assessable cells with three identical numeric scores / fully assessable cells. Always adjacent to coverage and the unconditional agreeing-cells/requested-cells count. |
| Pairwise agreement | Equal numeric scores for a named model pair / cells where both have valid numeric scores. Report each pair's coverage separately; do not average unequal-denominator rates without specifying weights. |
| Pairwise absolute difference | Sum absolute ordinal score differences / pairwise-assessable cells; descriptive distance on numeric labels, not interval-scale construct validation. |
| Pillar marginals/floor | Counts for scores 0,1,2,3 and each null/failure status per model/pillar/round. Numeric zero proportion among numeric scores plus numeric/requested coverage. |
| Score change | Actual revision transitions with both endpoints numeric and different score / actual revision transitions with both endpoints numeric. Null→numeric and numeric→null separately over all actual paired transitions. |
| Substantive change | Actual paired transitions differing on the six-field signature / actual paired transitions with both records. Exclude carried-forward cells; report missing-transition coverage. |
| Evidence change | Actual paired transitions changing quote or locator / actual paired transitions with both records. This is not automatically an evidence correction. |
| Evidence correction | Changes confirmed under the audit taxonomy below / actual transitions with an auditable changed evidence claim. Also show confirmed/requested-audit counts and pending/unsupported cases. |
| Terminal outcomes | Counts by outcome and stop_reason / all requested paper×pillar cells. Include incomplete/resource-stopped, non-assessable and round-limited cases. |
| Fresh-check reproduction | Matching score/status outputs / usable returned target×check-replicate judgments; also matching / all requested target×replicate checks, failure counts and coverage. All-null matching reported separately from numeric reproduction. |
| Two-check confirmation | Targets with both usable checks matching revised score/status / all targets requiring two checks. Failure or one mismatch is not confirmation. Explanation agreement recorded separately. |
| Independent-repeat stability | For each model/cell, all three R0 executions numerically equal / model×cells assessable in all three; report requested coverage, score vectors and pairwise replicate differences. No pooling of check replicates into this measure. |
| OVI-Gate | Minimum for complete numeric four-pillar profiles only; distributions by model/execution, null-profile count, all tied bottleneck pillars. No mean endpoint or TRL optimisation. |
| Usage | Attempt/request counts, returned input/output tokens, reserved/estimated USD, wall time, retries and failures per provider/run/condition and cumulatively. Charges are estimates unless reconciled to billing. |

Evidence-audit taxonomy: (a) newly located source evidence, (b) corrected locator/extraction,
(c) changed interpretation of unchanged evidence, (d) unsupported or unverifiable assertion,
(e) pending. Category (a) or (b) is a confirmed correction only when the exact evidence is
locatable in the source and a documented audit explains the previous omission/error. Quote
substring matching alone does not establish criterion satisfaction. Researchers may inspect
source provenance and accept general instrument changes without assigning human reference
scores. An AI-generated audit retains its synthetic author identity. Report unaudited claims
as pending, not confirmed corrections.

For each controlled contrast report before/after counts and rates, paper/cell matched changes,
coverage changes and all three execution results (including their range). An agreement rise
with lower coverage is not unqualified improvement. Do not attribute simultaneous model,
prompt, extraction and paper changes to the rubric. Accepted-rule counts and residual ambiguity
categories describe instrument clarity; they are not a validated clarity scale.

Final evaluation: independent R0 only, three fresh executions, fixed 15-paper reservation and
frozen package. Describe transfer relative to development with explicit selection differences;
no causal or population-prevalence claim. No ICC, alpha, kappa significance tests, p-values or
confidence intervals in this v1 study. A future inferential extension requires a new prospective
sample/precision plan and dependence treatment before outcome inspection. Paper×pillar×rater
observations and repeated executions must never be treated as independent replication units.
