# CH02 final phase — 28 October 2026

Status: design APPROVED 28 Oct; inputs converted; validator qualified 72/72; D0 smoke passed (US$0.046).
Figure descriptions are complete (623/623, US$6.78). The refinement loop is complete (C0–C3): HANDBOOK_C3 is
frozen for the held-out evaluation. The pre-registration is approved and awaiting its public time-stamp;
the held-out evaluation has not been dispatched.

| File | What it is |
|---|---|
| [PREREGISTRATION.md](PREREGISTRATION.md) | Held-out evaluation pre-registration (approved 28 Oct): arms, papers, outcomes, analysis |
| [results/LOOP_SUMMARY.md](results/LOOP_SUMMARY.md) | Development cycles C0–C3 side by side, and the final-handbook selection |
| [CHANGESET_C1.md](CHANGESET_C1.md) · [C2](CHANGESET_C2.md) · [C3](CHANGESET_C3.md) | Evidence-linked changes, decisions and disclosed deviations per cycle |
| [CONTRIBUTION.md](CONTRIBUTION.md) | One-paragraph main contribution for Larry and Qinyi, with versions written in advance for each outcome |
| [LOOP_DESIGN.md](LOOP_DESIGN.md) | Develop → freeze → test-once design: paper sets, stop rules, budget, timetable (**PROPOSED until approved**) |
| [HANDBOOK_C0.txt](HANDBOOK_C0.txt) | Cycle-0 application handbook = SCOPE_v1 + CLARIFICATIONS_v1 (Larry's D1–D3) |
| [QUALIFICATION_MD.json](QUALIFICATION_MD.json) | md-page-v1 validator replay of the fixed 52 + 20 cases: 72/72 |
| [MARKDOWN_MANIFEST.json](MARKDOWN_MANIFEST.json) | md-v1 conversion of the 65 primaries: hashes, page/figure counts, fidelity, spacing repairs. No paper text |

Code: `pipeline/study/final_phase.py` (runner), `pipeline/study/evidence_md.py` (validator),
`scripts/qualify_evidence_md.py`, `pipeline/study/markdown_inputs.py`, `scripts/convert_papers_markdown.py`,
`scripts/describe_figures.py`, `tests/test_markdown_inputs.py`, `tests/test_evidence_md.py`.

Run order: `python -m pipeline.study.final_phase freeze-smoke | admit | smoke | freeze-dev --cycle k | dev --cycle k`;
held-out stage: `freeze-eval`, then `admit --smoke-run <D0 run>`, then `eval`. Reports: `scripts/final_cycle_report.py <condition>`.
Private outputs (copyright): `.research-private/markdown-v1/study-<id>/{paper.md, figures/, conversion.json}`.

Reproduce the conversion (writes only to new paths):

```bash
.venv/bin/python scripts/convert_papers_markdown.py --out /new/private/dir --public-manifest /new/manifest.json
```

Figure descriptions with `claude-opus-5-5`, which is not a rater (`--estimate` makes no calls):

```bash
.venv/bin/python scripts/describe_figures.py --estimate
.venv/bin/python scripts/describe_figures.py --execute --max-usd 15
.venv/bin/python scripts/describe_figures.py --render
```
