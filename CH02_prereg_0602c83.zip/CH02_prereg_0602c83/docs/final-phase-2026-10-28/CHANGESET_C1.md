# Cycle 0 results and proposed change set C1 — 28 October 2026

Provenance: analyst agent:claude-opus-5-5; `human_confirmed=false`. **Nothing here is applied until
Gabriel approves each item.** Source: [results/DEV_C0.json](results/DEV_C0.json) and the private cell
file `.research-private/final-phase-live-v1/DEV_C0_cells.json`. Development papers only.

## 1. Cycle 0 in numbers

| Measure | Value |
|---|---|
| Requests | 48/48 completed, 0 truncated, US$2.88 |
| Judgments (requested 192) | 133 numeric · 30 applicability null · 29 failed |
| Complete panels / requested | **27/64 (42.2 %)** — target 80 % |
| Agreeing / complete panels | **23/27 (85.2 %)** — target 85 % met |
| Complete and agreeing / requested (primary) | **23/64 (35.9 %)** |
| Evidence-validation failures / judgments | **4/192 (2.1 %)** — target 10 % met (October: 90/540 failed overall) |
| Same score in both executions | 53/56 complete model × paper × pillar tuples |
| Complete profiles | 23, all OVI-Gate 0 |

Failures by model:

| Model | Numeric | Null | Failed |
|---|---:|---:|---:|
| gpt-6.1-sol (switched) | 50 | 14 | **0** |
| claude-sonnet-5-5 (switched) | 51 | 11 | **2** (1 evidence, 1 format) |
| glm-5.3 (unchanged) | 32 | 5 | **27** (24 format, 3 evidence) |

Why the 37 incomplete panels are incomplete:
- **27 panels: a GLM failure.** The cause is 6 whole GLM responses that were not valid JSON. Each
  ended with a mismatched bracket (for example `"]}]}`), so all four pillars of each were lost. The
  existing format-recovery step cannot run, because it needs to parse the original response first.
- **8 panels: applicability disagreement or agreement.** 5 panels mixed null and numeric
  judgments; 3 panels were null from all three models.
- **2 panels: a Sonnet failure.**

## 2. Decision needed first: the model fallback rule

The rule was declared before the run. It says that cycle-0 coverage below 45 % means "the cheaper
models are unfit": revert to gpt-6-astra and claude-opus-4-8, then rerun cycle 0. Coverage was
42.2 %, so **the rule is triggered as written.**

**The data contradict the rule's premise:**
- The two switched models lost 0 and 2 of 64 judgments. In October, Opus 4.8 lost 36 of 180.
- The shortfall comes from GLM-5.3, which is unchanged, together with legitimate scope nulls.
- Reverting would cost more and would not touch either cause.

**Options:**
- **(a) Apply the rule as written.** Revert, rerun cycle 0 for about US$9, keep GLM's problem.
- **(b) Amend it, recommended.** Record a dated amendment:
  - the fallback criterion should have been failures attributable to the switched models, which was
    the stated intent;
  - by that criterion the switched models pass;
  - keep the panel.
  The deviation and both readings go into the paper's methods section.

## 3. Proposed changes for cycle 1 (one theme each)

| # | Theme | Evidence (cycle 0 cells) | Proposed change | Type |
|---|---|---|---|---|
| A | GLM JSON syntax | 6 GLM responses, 24 lost judgments across studies 38, 42, 83, 6, 53, 34 | Add `response_format: {"type": "json_object"}` to the GLM request. Z.AI documents this for glm-5.3; whether it works alongside thinking is undocumented, so a new D0 smoke must pass first. This changes format only, not science. It applies to every later cycle and to both evaluation arms. | Technical (generation config) |
| B | System-dependent pillars | Study 42 P1/P3: gpt and Sonnet return null (observer training is not a system), GLM scores 0 | Handbook: "When the publication assesses no drowning detection or response system, P1–P3 are system-dependent and must be `applicability_uncertain`; P4 may still be scored from governance evidence." | Handbook |
| C | Response systems are in scope | Study 77 P2: Sonnet null ("an SOS transmitter, not a drowning-behaviour detector"); gpt and GLM score it | Handbook: "Systems that detect or relay a distress signal (for example a wearable or acoustic SOS) are response systems and are in scope." | Handbook, per Larry's D1 |
| D | **Hazard detectors (rip currents)** | Study 60 P1, both executions: gpt 0, GLM 1, Sonnet null ("a rip-current detector, not a drowning-victim detector") | **This needs your or Larry's decision. I should not choose it.** Either "hazard-detection systems that aim to prevent drowning are in scope" or "out of scope: null". | Scope decision |
| E | P3 cost and LMIC | Study 77 P3, both executions: Sonnet 1, gpt and GLM 0. All cite only a US$28 hydrophone unit price. | Handbook worked example: "A component unit price is not a documented deployment cost. Level 0 applies when there is no LMIC-context consideration, whatever the hardware cost." This applies P3 level 0 as written. | Handbook |
| F | Edge processing as privacy mitigation | Study 6 P4, one execution: gpt 1 (hardware is *capable* of local inference); GLM and Sonnet 0 | Handbook: "Edge processing counts as a privacy mitigation only when the paper documents that video or personal data are processed on the device rather than transmitted or stored remotely; hardware capability alone does not." | Handbook |

**Not proposed:** the single disagreements on study 53 P2 (authentic events) and the Sonnet format
and evidence failures. Each was one cell with no repeated pattern.

## 4. A design issue to note, without changing the primary outcome

Because of Larry's D1, a null is a legitimate answer. The primary outcome counts only panels where all
three scores are numeric, so the 80 % coverage target may be unreachable on development papers that
are not systems, such as 38 and 42. The primary outcome stays as declared. I suggest adding a
**secondary** measure, *resolved panels* (complete and agreeing, or unanimously null), reported
alongside it and labelled as added after cycle 0.

## 5. Cost and next step

After approval: amend the design, freeze HANDBOOK_C1, run a new D0 smoke for the GLM change, then run
cycle 1 (48 requests, about US$3). Final-phase spend to date is about US$9.70 (descriptions US$6.78,
D0 US$0.05, cycle 0 US$2.88).

## 6. Decisions (28 October 2026)

- **Fallback rule:** option (b), amend and keep the panel. Recorded as Amendment 1 in LOOP_DESIGN.md.
- **Changes approved:** A, B, C, E and F, as proposed.
- **D, decided by Gabriel:** hazard detectors such as rip-current systems are in scope. For P2,
  "authentic events" means real field occurrences of the detected hazard. This is a scope
  interpretation of Larry's D1 and is pending his confirmation.
- **Secondary measure:** "resolved panels", added as Amendment 2 (post-hoc).
- The handbook is frozen as HANDBOOK_C1.txt.
