# CH02 main contribution — draft for Larry and Qinyi (28 October 2026)

Status: draft for Gabriel to edit and send. Authored with Claude (Opus 5.5); not yet agreed with
the supervisors. Nothing below claims a result the final evaluation has not produced.

## The one-paragraph statement (recommended)

Published appraisal rubrics are increasingly applied by large language models, but agreement
between model raters is usually reported without asking how many judgments actually survive and
whether their cited evidence exists. We contribute an auditable procedure for applying a
published research-maturity rubric — the four-pillar Operational Viability Index — with a panel
of three LLMs. Every score must be supported by a verified quotation, and every failure is
counted rather than dropped. We use it to answer one question: **can a prospectively refined
application protocol make LLM rubric judgments both more available and more consistent on papers
it has never seen?** The protocol is developed on eight papers, frozen and published, and then
compared once against the original protocol on fifteen untouched papers. Applied across the
drowning-detection literature, the procedure also gives a substantive answer: does any published
system document operational viability? So far, no complete profile has scored above zero.

## Why this is the story the data can carry

- The 7 Oct study already shows the central problem. Exact agreement looked high (82/99), but
  only 99 of 180 requested panels were complete, and evidence-validation failures dominated the
  missing ones. **Coverage, not agreement, is the bottleneck.** That is simple, general and
  useful beyond drowning detection.
- The quotation audit showed that part of the "failure" was our own text extraction. The md-v1
  inputs and the develop–freeze–test loop are the methodological answer, and the held-out
  comparison is the experiment that tests it.
- The substantive finding (OVI-Gate 0 in every complete profile from both AI panels so far, the
  August alpha and the October study) links straight back to the published SLR. It is the domain
  result readers will remember. The two panels share one model (Claude Opus 4.8), so they are not
  fully independent.

## Pre-written outcome versions (choose after the final evaluation, not before)

1. **Refinement helps on held-out papers.** Complete-and-agreeing panels per requested panel rise
   on the 15 untouched papers, with coverage not falling. Headline: *"A prospectively refined,
   evidence-verified protocol makes LLM application of a published rubric measurably more usable
   on unseen studies."*
2. **No held-out improvement.** Headline: *"Reported agreement among LLM raters overstates their
   usefulness: under evidence verification, coverage — not agreement — limits LLM application of
   a published rubric, and protocol refinement on development papers does not transfer."* This is
   still a publishable, honest methods result.
3. **Mixed** (coverage up, agreement down, or the reverse). Report both measures with their
   denominators; the headline is about the trade-off.

## What the paper does not claim

It does not validate the rubric against human experts. It does not estimate inferential
reliability (no κ/ICC/α significance), does not measure system safety, and does not show that a
rewritten rubric is better. Human reference validation is a separate, later study.

## Open points for the meeting

- Venue: ESwA (Elsevier) is the current target. Check Larry's email for the Q1 journal with the
  Griffith publishing agreement before formatting.
- Confirm that the substantive OVI finding belongs in this paper rather than the SLR follow-up.
- Data availability: frozen protocol plus judgments, quotations (short excerpts only), hashes and
  code on Zenodo with a DOI. Paper texts and figure images stay private (copyright).
