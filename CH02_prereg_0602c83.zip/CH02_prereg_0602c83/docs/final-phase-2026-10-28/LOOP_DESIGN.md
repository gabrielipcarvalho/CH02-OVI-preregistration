# CH02 final phase — develop, freeze, test once (design v1, 28 October 2026)

Status: **APPROVED by Gabriel on 28 October 2026 (in chat, with the model switch).** From now on, any change
is a dated, versioned amendment made before the final evaluation is dispatched. Authored with
Claude (Opus 5.5). One untracked pre-run check call (study 3 F3, ≈ US$0.01) confirmed the describer works.

## 1. Question and primary outcome

Does a prospectively refined application protocol make three-LLM rubric judgments more usable on
papers it has never seen?

- **Primary outcome.** Complete-and-agreeing panels divided by requested panels, on the held-out
  set, refined arm versus original arm.
  - A *panel* is one paper × pillar × execution.
  - *Complete* means all three models returned a numeric score whose quotation validates.
  - *Agreeing* means the three scores are identical.
- **Secondary outcomes.** These follow METRICS v1 (`docs/study-2026-09-28/METRICS.md`), always
  with their denominators:
  - coverage
  - conditional agreement
  - evidence, format, transport and process failure rates
  - within-model repeat stability across the three executions
  - OVI-Gate distribution of complete profiles
  - cost and attempts
- **No inferential statistics.** As in v1, results are descriptive with explicit denominators.
  Repeated executions are dependent, so they are never treated as independent replicates.

## 2. What is fixed and what may change

| Element | Status |
|---|---|
| Published rubric text (SHA-256 `df5d7b4b…f3`) | **Fixed.** Wording problems found during refinement are logged as *proposed v1.1 rubric amendments* for the paper's discussion. They are not applied in either evaluation arm, because changing the rubric would change what is being validated. |
| Application handbook and prompt instructions | **Refined in the loop.** Start point is HANDBOOK_v1 (Larry's D1 scope, D2 conjunction, D3 consent). |
| Inputs | **md-v1 for both arms** (see §5). Figure descriptions are frozen before cycle 0. |
| Models | **`gpt-6.1-sol` (OpenAI), `claude-sonnet-5-5` (Anthropic), `glm-5.3` (Z.AI)**, chosen by Gabriel on 28 Oct for cost. They replace gpt-6-astra and claude-opus-4-8 from the October study. All arms and cycles use the same three. Generation settings are fixed at freeze: Sonnet 5.5 at effort `medium` (it thinks by default, and thinking counts against the cap); gpt-6.1-sol reasoning effort set to the documented equivalent of the historical OpenAI setting, with the parameter name verified at freeze; GLM-5.3 at its historical settings. |
| Output cap | **16,000 tokens for all models.** On 21 Oct, adaptive/high truncated 11 of 15 responses at the 6,000-token cap. The cap is fixed now, before any new outcome is seen. |
| Retry policy | At most 2 transport retries and 1 format recovery. Never retry because of the scientific content of a response. |
| Evidence validator | `evidence_md` (to build, §6): the quotation must match the md-v1 source text exactly after the existing normalisation, inside the cited `[PDF PAGE n]` section. Generated figure descriptions are never quotable. |

## 3. Paper sets

- **Development (8):** 38, 42, 53, 77, 34 (C1–C5) and 60, 83, 6. These are already exposed, so
  they are used only for refinement.
- **Held-out evaluation (15), from the 41 primaries with a text layer, no recent direct use, and
  not in the October evaluation set.** Selected by SHA-256 order of `"ch2-final-heldout-20261028-v1:<id>"`:
  **14, 17, 18, 25, 27, 28, 31, 40, 47, 51, 59, 71, 72, 74, 79.**
  - Disclosure 1: the August alpha raters saw all of these.
  - Disclosure 2: during md-v1 conversion QA, short extraction fragments of paper 28 were viewed to
    diagnose glued words. No scoring-relevant reading took place.
  - Rule: **nobody opens held-out papers or their outputs until the final evaluation is dispatched.**
- The October 15-paper evaluation set stays retired. It is not reused.

## 4. The refinement loop (development papers only)

**Each cycle k (k = 0 is the baseline with HANDBOOK_v1):**
1. Run R0 for 8 papers × 3 models × 2 fresh executions = 48 requests.
2. Compute the §1 measures for the development set.
3. Classify every failure and disagreement using the existing audit taxonomy: model error,
   extraction/validator, ambiguity in the handbook, or ambiguity in the rubric wording.
4. **Analyst** (Claude Opus 5.5 in Claude Code) writes a change set. It is not a rater model, but it
   comes from the same vendor as the Anthropic rater; disclose this. Each change cites the
   specific cells and failure records that motivate it. One theme per change.
5. **Gabriel approves or rejects each change.** Larry and Qinyi are copied on the change log.
6. Freeze the handbook as v1.(k+1) and run the next cycle.

**Stop at the first of:**
- the cycle meets all development targets:
  - complete-panel coverage ≥ 80 % of requested
  - evidence-validation failures ≤ 10 % of judgments
  - conditional exact agreement ≥ 85 %
- three refinement cycles completed
- no evidence-linked change remains to propose
- the budget gate in §7 is reached.

**Model fallback rule (declared before any run):** if cycle 0 with the new models has complete-panel
coverage below 45 % of requested, which is clearly under the October baseline of 55 %, the cheaper
models are judged unfit. Before anything is frozen, the panel reverts to gpt-6-astra and
claude-opus-4-8 and cycle 0 is rerun. This is checked once, at cycle 0, and never later.

**Amendment 1, 28 Oct, after cycle 0 (approved by Gabriel; a disclosed deviation).**
- Cycle-0 coverage was 27/64 (42.2 %), so the rule above was triggered as written.
- The rule was meant to detect switched models that were unfit, but it measured the whole panel.
  The switched models lost 0/64 (gpt-6.1-sol) and 2/64 (claude-sonnet-5-5) judgments. The shortfall
  came from the unchanged glm-5.3 (27/64 lost to malformed JSON) and from legitimate scope nulls.
- Gabriel chose to restate the criterion as failures attributable to the switched models. Under that
  criterion they pass, and the panel is kept.
- The paper reports both readings. Evidence: `results/DEV_C0.json`, `CHANGESET_C1.md` §2.

**Amendment 2, 28 Oct, after cycle 0: a secondary measure only, labelled as post-hoc.**
- *Resolved panels:* complete and agreeing, or unanimously `applicability_uncertain`, divided by
  requested panels.
- It is reported next to the primary outcome, which is unchanged. The reason: under Larry's D1, a
  unanimous null is an agreed scope judgment, and the primary measure cannot count it.

The targets are stopping rules, not success criteria. Missing them is reported, not hidden. The
final handbook is the one from the last completed cycle, **or the best development cycle on the
primary outcome if a later cycle made it worse** (declared now, to avoid post-hoc choice).

## 5. Inputs: md-v1

- **Conversion:** `scripts/convert_papers_markdown.py` with pymupdf4llm 1.28.2.
  - Each page is marked `[PDF PAGE n]`.
  - Tables come out as Markdown.
  - Figures become numbered slots.
  - Words that the converter glued together are re-spaced, but only when a span of the same PDF's
    text layer matches exactly.
- **Fidelity:** recall against the old `pdftotext -layout` input is recorded per paper in
  `MARKDOWN_MANIFEST.json`.
  - Low-recall papers were inspected. Most of the "loss" is hidden "FOR PEER REVIEW" overlay text
    and publisher watermarks that polluted the old input.
  - Paper 12 has no text layer and is OCR-derived (bannered).
- **Figure descriptions:** `scripts/describe_figures.py` describes 623 captioned or large figures.
  - Model: `claude-opus-5-5` at effort `low`, which is not a rater. Sonnet 5.5 became a rater, so it
    cannot describe figures.
  - The prompt is fixed and covers visible content only, with no interpretation.
  - Every call goes into a hash-checked ledger with a spending cap.
  - Descriptions are frozen before cycle 0. They sit inside explicit blocks that raters are told
    are not the authors' text.
  - Gabriel spot-checks 20 random descriptions against their figures before the freeze. The sample is
    drawn only from papers outside the held-out 15, so the spot-check opens no held-out material.
- **Disclosure:** the October results used `pdftotext -layout` text without figures. Because md-v1
  is a different input condition, October and final-phase numbers are compared only descriptively.

## 6. Engineering before cycle 0 — status 28 Oct (done unless marked)

- **Runner:** `pipeline/study/final_phase.py`.
  - It has its own ledger in `.research-private/final-phase-live-v1/` and spending caps per provider.
  - The paper sets and model configuration are fixed in code, and cycles and arms are frozen
    append-only in FREEZE.json.
  - Transport now prices each model separately and allows the 16,000-token cap.
- **`md-page-v1` validator:** `pipeline/study/evidence_md.py`, wired into scoring and transport.
- **Qualification:** 72/72 (`QUALIFICATION_MD.json`). Disclosure: the first replay was 70/72. Both
  failures were real quotes that the converter had broken by joining line-split compounds ("low-cost"
  became "lowcost"). Matching now ignores hyphens between two letters, and only between letters;
  hyphens and minus signs next to digits are still literal. All 54 controls that should be rejected
  were rejected in both replays.
- **D0 smoke:** passed on 28 Oct (run `run-a36dff5c810e41d283b09eb7b4340f6a`).
  - 12/12 judgments, no failures.
  - Returned models were exactly gpt-6.1-sol, glm-5.3 and claude-sonnet-5-5, each with HTTP 200 and
    no truncation.
  - Cost US$0.046.
- **Figure descriptions: complete on 28 Oct.**
  - 623/623 succeeded on the first attempt: every stop reason was `end_turn` and every returned model
    was claude-opus-5-5.
  - Ledger cost US$6.78, plus the ≈ US$0.01 pre-run check call.
  - All 65 papers are rendered as `paper.described.md` with no pending slots. Median description
    length is 169 words.
  - An automated wording screen found 33/623 descriptions containing a listed evaluative word.
    Examples from non-held-out papers were transcriptions of text inside figures (axis labels such as
    "Robustness rank", a flowchart box reading "Deploy autonomous drones") or visual statements
    ("strongly saturated", "cannot be read reliably"). They were not interpretations. Descriptions
    are frozen and were not edited.
- **Spot-check passed:** Gabriel reviewed the 20-figure page (`.research-private/markdown-v1/SPOTCHECK.html`)
  on 28 Oct and judged the descriptions accurate and descriptive only. Its
  sample comes only from non-held-out papers: 75, 37, 10, 12, 64, 44, 70, 53, 77, 50, 81, 26, 46, 8,
  82, 13, 42, 33.

The original engineering list, kept for the record:


1. A md-v1 payload adapter in the study runner, alongside the legacy path.
2. An `evidence_md` validator.
3. Qualification of `evidence_md` against the existing 52 + 20 localisation cases, transferred to
   md-v1 page sections. It must pass before any paid call.
4. A D0 smoke run on the fictional fixture.
5. Freeze records, using the existing freeze/ledger machinery so every attempt is reserved before
   dispatch.

## 7. Budget (estimate from the measured md-v1 sizes)

**Size and price assumptions:**
- Input is about 18k tokens per request: median paper ≈ 9–10k tokens, plus figure descriptions,
  handbook, rubric and schema.
- Expected output is about 3k tokens. The worst case is the 16k cap.
- Prices, US$/M input/output: gpt-6.1-sol 2/10 (OpenAI pricing page, checked 28 Oct);
  claude-sonnet-5-5 2/10 and claude-opus-5-5 4/20 (Anthropic model table); GLM-5.3 1.4/4.4 (checked 21 Oct).

**Estimated cost:**

| Block | Requests | Expected | Output at cap |
|---|---:|---:|---:|
| Figure descriptions (Opus 5.5) | 623 | ≈ US$10 | ≈ US$30 |
| Development, 4 cycles | 192 | ≈ US$11 | ≈ US$31 |
| Final evaluation, 2 arms × 15 papers × 3 executions | 270 | ≈ US$15 | ≈ US$44 |
| Retries / format recovery (+30 %) | — | ≈ US$11 | — |
| **Total** | | **≈ US$47** | **≈ US$105** |

The US$105 figure is the bound if every response hits its cap, before retries. It is not an expectation.

**Expected spend by provider,** including retries: OpenAI ≈ US$13, Anthropic ≈ US$24 (raters ≈ US$13 plus
figures ≈ US$10.5), Z.AI ≈ US$8.

**Credit available,** as reported by Gabriel from the provider consoles on 28 Oct: OpenAI US$50.72,
Anthropic US$50.64, Z.AI US$38.19. Auto-reload is off on all three; on Anthropic it was switched off
after a payment failure. No new top-up was needed for this phase.

- **Budget gate:** stop and report if cumulative final-phase spend reaches **US$100**, or if any provider's
  recorded spend would leave less than US$5 of its reported credit.
- These are usage estimates, not invoices. Reimbursement depends on Larry's support and Leo's
  approval; keep the receipts.

## 8. Timetable (24 h, assuming credit and quick approvals)

| Step | Time |
|---|---|
| Approve design and contribution; build §6 adapter and validator, qualify, D0 smoke | 3–4 h |
| Describe figures and spot-check | 1 h (in parallel) |
| Cycle 0 plus up to 3 refinement cycles (run ≈ 45 min, analysis and approval ≈ 1 h each) | 6–8 h |
| Freeze; public pre-registration (OSF or Zenodo) of the frozen protocol; final evaluation | 3–4 h |
| Analysis, figures, results section | 2–3 h |

If approvals or credit slip, the loop pauses. No step is skipped to keep the clock.

## 9. Publication and data

- **Before dispatch:** publish the frozen protocol, handbook, prompts, schemas, code hash and the
  held-out list as a time-stamped pre-registration.
- **After analysis:** deposit the judgments, failure records, short quotations, md-v1 hashes,
  figure-description ledger and analysis code with a DOI (Zenodo).
- **Never deposited:** paper texts, figure images and provider account data.
