# Cycle 1 results and proposed change set C2 — 28 October 2026

Provenance: analyst agent:claude-opus-5-5; `human_confirmed=false`. **Nothing is applied until Gabriel
approves it.** Sources: [results/DEV_C1.json](results/DEV_C1.json), the private cell file
`DEV_C1_cells.json` and the raw responses in the final-phase ledger. Development papers only.

## 1. Cycle 1 compared with cycle 0

| Measure | C0 | C1 | Target |
|---|---:|---:|---:|
| **Primary: complete and agreeing / requested panels** | 23/64 (35.9 %) | **27/64 (42.2 %)** | — |
| Complete panels (coverage) | 27/64 (42.2 %) | **32/64 (50.0 %)** | 80 % |
| Agreeing / complete | 23/27 (85.2 %) | 27/32 (84.4 %) | 85 % |
| Evidence-validation failures / judgments | 4/192 (2.1 %) | 6/192 (3.1 %) | ≤ 10 % |
| Resolved panels, secondary (post-hoc) | 26/64 (40.6 %) | 29/64 (45.3 %) | — |
| Same score in both executions | 53/56 | 57/62 | — |
| Failed judgments: gpt / GLM / Sonnet | 0 / 27 / 2 | **0 / 30 / 0** | — |
| Complete profiles (all OVI-Gate 0) | 23 | 30 | — |
| Truncations · cost | 0 · US$2.88 | 0 · US$2.96 | — |

**What happened to GLM.**
- JSON mode (change A) fixed the syntax completely: 0 of 16 responses were unparseable, down from 6.
- But 5 GLM responses now include a **fifth, duplicated cell**. Their contents include "Duplicate
  placeholder" and "See above". The protocol rejects these as ambiguous pillar identity: 20 lost
  judgments.
- One further response broke the anonymous-defence rule, which forbids stating a score in the
  defence text: 4 lost judgments.

**GLM's 6 evidence failures, each traced to its source.**
- **3 genuine model errors.** On study 83 GLM spliced or paraphrased sentences: the quoted text is
  not contiguous in the paper. On study 53 P3 it wrote "search and rescue" where the paper has
  "search-and-rescue".
- **1 format artefact:** the duplicate placeholder cell.
- **2 checker false negatives caused by text conversion:**
  - *Study 42 P3.* The PDF font has no "×" glyph, so the paper text reads "1280 � 720". The model
    quoted "1280 × 720".
  - *Study 53 P2.* The converter placed a publisher DOI footer line in the middle of an abstract
    sentence, so a correct quote of that sentence cannot match.

## 2. Proposed changes for cycle 2

| # | Theme | Evidence | Proposed change | Type |
|---|---|---|---|---|
| G | Exactly one cell per pillar | 5 GLM responses, 20 judgments (studies 77, 38 ×2, 53, 60) | Handbook format line: "Return exactly four cells, one for each of P1–P4. Never repeat a pillar and never add placeholder or duplicate cells." | Format |
| H | Unreadable glyphs in the source | Study 42 P3 | The checker treats each "�" (U+FFFD, a glyph the PDF font could not map) in the source as matching any one non-space character in the quote. Nothing else is relaxed. Re-qualify on the 72 cases before use. | Technical (validator) |
| I | Publisher footer lines | Study 53 P2 | The checker ignores lines consisting only of a URL or DOI when matching. These are page furniture, not the authors' text, and become unquotable. Re-qualify on the 72 cases before use. | Technical (validator) |
| J | Edge processing with alert transmission | Study 6 P4, split in both executions (gpt 1/1, GLM 0/1, Sonnet 0/0); the paper processes video locally on a Raspberry Pi and sends only alerts to a cloud database | Handbook addition to F: "Local processing of video counts as edge processing even when alerts or event metadata are sent remotely. It does not count if video or images leave the device." | Handbook |

**Not proposed: single cells with no repeated pattern.**
- Study 60 P1 (0/1/1) and P2 (3/2/2) are rip-current panels. They are now scored by all three
  models, as clarification D intended.
- Study 83 P4: Sonnet gave 1 for an ethics approval alone. The handbook already rules this out.

## 3. Loop position

- **C1 meets one of three targets** (evidence failures). Conditional agreement is just under 85 %, and
  coverage is 50 % against 80 %.
- **Cycles remaining:** two refinement cycles (C2 and C3) remain under the design's cap of three.
- **What C2 could recover:** if G removes the duplicate cells, it could restore up to 20 GLM
  judgments. On the C1 pattern that would put coverage at about 60 %.
- **Spend:** final phase to date ≈ US$12.80. C2 would cost about US$3, plus a D0 smoke.

## 4. Decisions and implementation (28 October 2026)

- **Approved by Gabriel:** G, H, I and J.
- **Extension to I, made by the analyst and disclosed here.** The study-53 quote crosses from PDF
  page 1 to page 2. Between the two halves sit the DOI line, a running journal header and an "N of M"
  page counter. Removing URL/DOI-only lines, as approved, was not enough. Within the same "page
  furniture" theme, the validator also removes two further kinds of line:
  - lines repeated identically on three or more pages (running headers and footers);
  - "N of M" page counters.
  None of these lines is the authors' text.
- **Validator** renamed **md-page-v1.1**. Re-qualified 72/72 (`QUALIFICATION_MD_V1_1.json`).
- **Regression replay:** every quote accepted in cycles 0 and 1 is still accepted, 0 flips. The two
  traced false negatives (study 42 "×", study 53 abstract) now match. The genuine model splices
  (study 83) and inexact hyphenation (study 53 P3) are still rejected. Earlier cycles are **not**
  re-scored.
- **Handbook:** HANDBOOK_C2.txt adds G and J.
- **D0 smoke** `run-d1c8c326…` passed: 12/12 judgments, 0 failures.
- **Cycle 2** is frozen (`run-ee7e7cd0…`, `run-ec3679f7…`) and running.
