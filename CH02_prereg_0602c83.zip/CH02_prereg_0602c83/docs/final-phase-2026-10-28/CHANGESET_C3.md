# Cycle 2 results and proposed change set C3 (the last refinement cycle) — 28 October 2026

Provenance: analyst agent:claude-opus-5-5; `human_confirmed=false`. **Nothing is applied until Gabriel
approves it.** Sources: [results/DEV_C2.json](results/DEV_C2.json) and the private cell file. Development
papers only.

## 1. Three cycles side by side

| Measure | C0 | C1 | C2 | Target |
|---|---:|---:|---:|---:|
| **Primary: complete and agreeing / requested** | 23/64 (35.9 %) | 27/64 (42.2 %) | **31/64 (48.4 %)** | — |
| Coverage | 42.2 % | 50.0 % | **67.2 %** | 80 % |
| Agreeing / complete | 85.2 % | 84.4 % | **72.1 %** (31/43) | 85 % |
| Evidence failures / judgments | 2.1 % | 3.1 % | 3.6 % | ≤ 10 % |
| Resolved panels, secondary | 40.6 % | 45.3 % | **60.9 %** | — |
| Failed judgments: gpt / GLM / Sonnet | 0/27/2 | 0/30/0 | **0/10/3** | — |
| Same score in both executions | 53/56 | 57/62 | 63/70 | — |
| Cost | US$2.88 | US$2.96 | US$2.90 | — |

**Reading the table.**
- G removed GLM's duplicate cells, cutting GLM's lost judgments from 30 to 10. H and I recovered
  quotes that had been lost to text conversion.
- With 11 more panels complete, *conditional* agreement fell. The panels that had been missing were
  the harder ones, and they now come back with disagreements.
- The primary measure still rose, from 27 to 31.
- All 30 complete profiles remain OVI-Gate 0.

**Who disagrees.** Of the 11 disagreements where one model stands alone, Sonnet is the odd one out
7 times, gpt 3 times and GLM once. By pillar there are 5 on P4, 3 on P2, 2 on P1 and 2 on P3.

## 2. Proposed changes for cycle 3 (one theme each)

| # | Theme | Evidence | Proposed change | Type |
|---|---|---|---|---|
| K | **Ethics approval alone in P4** | Study 38 P4: gpt 0, GLM 1, Sonnet 1. Study 83 P4: Sonnet 1. | The rubric has a gap. Level 0 requires that *no* ethics framework is documented, while level 1 requires privacy mitigation or user acceptance, so a paper with ethics approval only fits neither level. The project's conservative-scoring rule (a score above 0 only when the criterion is unambiguously met) and Larry's D3 (ethics approval belongs to level 2) both point to: *"An ethics-approval statement alone does not meet level 1; score 0."* The gap is logged as a proposed v1.1 rubric amendment for the paper. **Needs your approval, as it settles a rubric gap.** | Handbook + rubric note |
| L | P3 as an explicit decision rule | Study 77 P3: Sonnet scores 1 in both executions after C1-E, while gpt and GLM score 0. | Restate it as a test: *"Level 0 applies if either (a) infrastructure costs over US$5,000 or (b) no LMIC-context consideration is documented. Level 1 needs all three: consumer hardware demonstrated, a documented total cost under US$5,000, and partial LMIC consideration."* This quotes the published criteria. | Handbook |
| M | P1 "cross-site" for camera and hazard systems | Study 60 P1 is split in both executions (0/1/0 and 0/1/1). | Use the published paragraph's strict reading: *"An external test set counts as cross-site only if the publication documents that it comes from a different physical location (pool, beach or open-water installation) than the training data. A different dataset, source or camera angle at an undocumented location is not a distinct site."* | Handbook |
| N | P2 levels for hazard detectors | Study 60 P2: 3/3/0 and 3/2/1. In one execution Sonnet rejected clarification D by citing the published definition of "authentic". | Make D usable level by level: *"For hazard detectors, read P2 with 'authentic distress events' as real field occurrences of the detected hazard and 'expert ground truth' as expert annotation or verification of those occurrences. The published paragraph's definition applies unchanged to systems that detect people."* D is still pending Larry's confirmation. | Handbook (extends D) |
| O | P4 edge processing as a decision rule | Study 6 P4: gpt 1, GLM and Sonnet 0. Sonnet's own reason says "processing runs locally". Study 53 P4 is split in both executions. | Strengthen F and J: *"If the publication states that video or image analysis runs on the device, P4 level 1's edge-processing example is met, whether or not the authors call it a privacy measure."* | Handbook |

**Not proposed:** study 53 P2 (one cell) and the 13 remaining failures. These are genuine quote
splices or inexact quotes, plus 5 GLM format failures with no new single cause.

## 3. After cycle 3

- **Last cycle.** C3 is the last refinement cycle the design allows.
- **Which handbook to freeze.** By the rule declared before cycle 0, the final evaluation freezes
  either C3's handbook or the best earlier development cycle on the primary outcome, if C3 does
  worse. At the moment that would be C2 at 31/64.
- **Then:**
  1. Write the frozen handbook and the original-arm prompt.
  2. Publish the pre-registration.
  3. Run the held-out evaluation: 2 arms × 15 papers × 3 executions, 270 requests, about
     US$17–25 at the observed request sizes.
- **Spend:** final phase to date ≈ US$15.80. C3 adds about US$3.

## 4. Rulings (28 October 2026)

Gabriel delegated the rulings on K–O to the analyst ("I approve your judgement here") and approved
running C3. The rulings below are the analyst's, made under that delegation. They are applied in
HANDBOOK_C3.txt.

- **K: score 0.** Ethics approval alone does not meet level 1.
  - Grounds: the project's conservative-scoring invariant, and Larry's D3, which places ethics
    approval at level 2.
  - The published rubric's level-0/level-1 gap is logged for the paper as **proposed v1.1 amendment
    R1**: level 0 should read "no privacy mitigation and no user-acceptance assessment documented",
    with ethics approval moved explicitly to level 2. The published rubric is unchanged.
- **L: adopted as proposed.** It restates the published P3 level-0 and level-1 criteria as a test.
- **M: adopted.** Added detail: a camera at the same facility is not a distinct site, as the published
  paragraph says.
- **N: adopted.** It applies only to hazard detectors. It extends clarification D, which still awaits
  Larry's confirmation.
  - If Larry rejects D, hazard-detector panels become scope nulls.
  - Sensitivity analysis for the paper: report the results with and without hazard-detector papers.
- **O: adopted, with a guard.** The publication itself must state that analysis runs on the device
  and that video is not transmitted. Hardware capability alone still does not count (F).
