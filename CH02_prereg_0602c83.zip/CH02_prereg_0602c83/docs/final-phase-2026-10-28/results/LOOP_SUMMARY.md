# Refinement loop summary — development papers, 28 October 2026

Provenance: agent:claude-opus-5-5; `human_confirmed=false`. Eight development papers (38, 42, 53, 77,
34, 60, 83, 6). Each cycle ran 3 models × 8 papers × 2 fresh executions, R0 only: 48 requests,
192 requested judgments and 64 requested panels. These are descriptive counts. Panels and executions
are dependent, so no inferential statistics are given.

| Measure | C0 | C1 | C2 | **C3** | Target |
|---|---:|---:|---:|---:|---:|
| **Primary: complete and agreeing / requested panels** | 23 (35.9 %) | 27 (42.2 %) | 31 (48.4 %) | **36 (56.2 %)** | — |
| Complete panels (coverage) | 27 (42.2 %) | 32 (50.0 %) | 43 (67.2 %) | 42 (65.6 %) | 80 % — not met |
| Agreeing / complete | 85.2 % | 84.4 % | 72.1 % | **85.7 %** | 85 % — met |
| Evidence-validation failures / judgments | 2.1 % | 3.1 % | 3.6 % | 3.1 % | ≤ 10 % — met |
| Resolved panels, secondary (post-hoc) | 40.6 % | 45.3 % | 60.9 % | **68.8 %** | — |
| Failed judgments: gpt / GLM / Sonnet | 0/27/2 | 0/30/0 | 0/10/3 | 0/13/1 | — |
| Same score in both executions | 53/56 | 57/62 | 63/70 | 67/69 | — |
| Complete profiles: OVI-Gate > 0 | 0/23 | 0/30 | 0/30 | 0/31 | — |
| Truncated responses · cost | 0 · US$2.88 | 0 · US$2.96 | 0 · US$2.90 | 0 · US$2.94 | — |

## What each cycle changed

- **C1**
  - *Technical:* GLM JSON mode (A).
  - *Handbook:* system-dependent pillars (B), response systems (C), hazard detectors in scope (D,
    Gabriel's decision pending Larry), P3 cost and LMIC (E), edge processing (F).
  - *Design:* fallback rule amended (Amendment 1); resolved-panels secondary added (Amendment 2).
- **C2**
  - *Format:* exactly four cells (G).
  - *Validator v1.1:* unmapped-glyph matching (H) and page furniture (I, plus the analyst's
    extension). Re-qualified 72/72 with 0 regression flips.
  - *Handbook:* edge processing with alerts (J).
- **C3**
  - *Handbook, rulings delegated to the analyst:* ethics approval alone scores 0 (K, with proposed
    rubric amendment R1); P3 test (L); strict cross-site (M); P2 for hazard detectors (N); edge
    processing as a decision rule (O).

## Selection, applying the rule declared before cycle 0

The final handbook is the last cycle's, unless an earlier cycle scored higher on the primary outcome.
C3 has the highest primary outcome (36/64), so **HANDBOOK_C3.txt is frozen for the final evaluation**.
The loop stopped after the third refinement cycle, as the design caps it. The coverage target was not
met, and that is reported here, not hidden.

## Interpretation limits

- **Development results are not evidence of benefit.** These eight papers were used to write the
  changes, so the improvement over C0 cannot be read as one. Only the held-out comparison can test
  whether the refinement transfers.
- **Missingness is now mostly GLM.** The remaining failed judgments are mostly GLM's (13/14 in C3).
  gpt-6.1-sol lost none in any cycle.
- **OVI-Gate is 0 everywhere.** It is 0 in every complete profile in every cycle, consistent with the
  August alpha and the October study.
