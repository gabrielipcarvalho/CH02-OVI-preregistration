"""Descriptive reports regenerated from immutable CSV snapshots; dependent populations stay separate."""

from __future__ import annotations

import csv
import html
import io
import json
from itertools import combinations
from pathlib import Path

from pipeline.study.records import PILLARS, RATERS, Records, StudyError, canonical, digest
from pipeline.study.workflow import states

FIELDS = (
    "run_id",
    "population",
    "condition",
    "execution",
    "study",
    "rater",
    "pillar",
    "round",
    "kind",
    "replicate",
    "carried",
    "request_id",
    "status",
    "score",
    "quote",
    "locator",
    "reason",
    "alternative",
    "confidence",
    "action",
    "change_reason",
    "agent",
    "human_confirmed",
    "evidence_check",
)


def ratio(n: int, d: int) -> dict:
    """Zero denominators are NA, not zero agreement or perfect agreement."""
    return {"numerator": n, "denominator": d, "value": n / d if d else None}


def csv_snapshot(directory: Path, name: str, rows: list[dict], fields: tuple | list) -> Path:
    """Content-addressed CSV snapshots never overwrite a populated earlier export."""
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    value = buffer.getvalue()
    path = directory / f"{name}-{digest(value)[:16]}.csv"
    directory.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text() != value:
        raise StudyError("CSV snapshot identity collision")
    if not path.exists():
        path.write_text(value)
    return path


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def flattened(store: Records, run_id: str) -> tuple[dict, list[dict], list[dict], list[dict], list[dict]]:
    """Actual responses, carries, requested checks and failures retain distinct provenance."""
    exported = store.export(run_id)
    m = exported["manifest"]
    observations = []
    for j in exported["judgments"]:
        c = j["payload"]
        row = {field: c.get(field, "") for field in FIELDS}
        row.update(
            run_id=run_id,
            population=m["population"],
            condition=m["condition"],
            execution=m["execution"],
            study=j["study"],
            rater=j["rater"],
            round=j["round"],
            kind=j["kind"],
            replicate=j["replicate"],
            carried=0,
            request_id=j["request_id"],
            agent=j["provenance"]["rater"],
            human_confirmed=0,
            score="" if c["score"] is None else c["score"],
            evidence_check=canonical(c.get("evidence_check", {})),
        )
        observations.append(row)
    for e in exported["events"]:
        if e["kind"] != "carry":
            continue
        carried = e["payload"]
        c = carried["cell"]
        r = carried["rater"]
        row = {field: c.get(field, "") for field in FIELDS}
        row.update(
            run_id=run_id,
            population=m["population"],
            condition=m["condition"],
            execution=m["execution"],
            study=carried["study"],
            rater=r,
            round=carried["round"],
            kind="rating",
            replicate=0,
            carried=1,
            request_id=carried["source_request_id"],
            agent="agent:" + m["models"][r]["model"],
            human_confirmed=0,
            score="" if c["score"] is None else c["score"],
            evidence_check=canonical(c.get("evidence_check", {})),
        )
        observations.append(row)
    observations.sort(
        key=lambda r: (r["study"], r["round"], r["kind"], r["rater"], r["replicate"], r["pillar"])
    )
    requested = [
        {
            "request_id": q["id"],
            "study": q["study"],
            "rater": q["rater"],
            "round": q["round"],
            "kind": q["kind"],
            "replicate": q["replicate"],
            "pending": canonical(q["context"]["pending"]),
            "check_targets": canonical(q["context"].get("check_targets", [])),
            "original_request_id": q["context"].get("original_request_id", ""),
        }
        for q in exported["requests"]
    ]
    pending_by_request = {q["id"]: q["context"]["pending"] for q in exported["requests"]}
    failures = [
        {
            "request_id": r["request_id"],
            "study": r["study"],
            "rater": r["rater"],
            "round": r["round"],
            "kind": r["kind"],
            "replicate": r["replicate"],
            "status": r["payload"]["status"],
            "reason": r["payload"]["reason"],
            "failed_pillars": canonical(
                r["payload"].get("failed_pillars", pending_by_request[r["request_id"]])
            ),
            "pillar_failures": canonical(r["payload"].get("pillar_failures", {})),
        }
        for r in exported["dispositions"]
    ]
    outcomes = [
        {"study": p["study_id"], "pillar": pillar, **value}
        for p in m["papers"]
        for pillar, value in states(store, run_id, p["study_id"]).items()
    ]
    if m["population"] == "final_evaluation":
        for o in outcomes:
            if o["complete"]:
                o["outcome"] = (
                    "non_assessable"
                    if not o["assessable"]
                    else "independent_agreement"
                    if o["numeric_agreement"]
                    else "independent_disagreement"
                )
                o["stop_reason"] = "initial_only"
                o["terminal"] = True
    completed = {c["attempt_id"]: c for c in exported["completions"]}
    requests = {q["id"]: q for q in exported["requests"]}
    attempts = []
    for a in exported["attempts"]:
        completion = completed.get(a["id"])
        result = completion["result"] if completion else {}
        q = requests[a["request_id"]]
        cfg = m["models"][q["rater"]]
        attempts.append(
            {
                "attempt_id": a["id"],
                "request_id": a["request_id"],
                "provider": cfg["provider"],
                "rater": q["rater"],
                "stage": a["stage"],
                "transport": a["transport"],
                "reserved_usd": a["reserved"],
                "charged_or_reserved_usd": completion["effective_charge"] if completion else a["reserved"],
                "original_charge_or_reservation_usd": completion["charged"] if completion else a["reserved"],
                "reconciliation_id": completion["reconciliation_id"] if completion else "",
                "status": result.get("status", "unknown"),
                "input_tokens": result.get("input_tokens", ""),
                "output_tokens": result.get("output_tokens", ""),
                "model_returned": result.get("model_returned", ""),
            }
        )
    return m, observations, requested, failures, outcomes, attempts


def agreement(rows: list[dict], paper_ids: list[int], round_n: int) -> dict:
    """All-three and pairwise agreement have their own assessable and requested denominators."""
    index = {
        (int(r["study"]), r["rater"], r["pillar"]): r
        for r in rows
        if r["kind"] == "rating" and int(r["round"]) == round_n
    }
    requested = len(paper_ids) * 4
    complete = agreed = 0
    pairs = {a + "|" + b: {"valid": 0, "equal": 0, "difference": 0} for a, b in combinations(RATERS, 2)}
    marginals = {
        r: {
            p: {
                "0": 0,
                "1": 0,
                "2": 0,
                "3": 0,
                "unable_to_assess": 0,
                "applicability_uncertain": 0,
                "missing": 0,
            }
            for p in PILLARS
        }
        for r in RATERS
    }
    for sid in paper_ids:
        for p in PILLARS:
            cells = [index.get((sid, r, p)) for r in RATERS]
            valid = [c is not None and c["status"] == "scored" for c in cells]
            if all(valid):
                complete += 1
                agreed += len({int(c["score"]) for c in cells}) == 1
            for r, c in zip(RATERS, cells, strict=True):
                label = c["score"] if c and c["status"] == "scored" else c["status"] if c else "missing"
                if label not in marginals[r][p]:
                    raise StudyError("Unknown CSV judgment/status")
                marginals[r][p][label] += 1
            for a, b in combinations(RATERS, 2):
                ca = index.get((sid, a, p))
                cb = index.get((sid, b, p))
                pair = pairs[a + "|" + b]
                if ca and cb and ca["status"] == cb["status"] == "scored":
                    pair["valid"] += 1
                    pair["equal"] += int(ca["score"]) == int(cb["score"])
                    pair["difference"] += abs(int(ca["score"]) - int(cb["score"]))
    return {
        "requested_cells": requested,
        "complete_panel_coverage": ratio(complete, requested),
        "exact_agreement": ratio(agreed, complete),
        "unconditional_agreeing_cells": ratio(agreed, requested),
        "pairs": {
            pair: {
                "agreement": ratio(v["equal"], v["valid"]),
                "coverage": ratio(v["valid"], requested),
                "absolute_difference": ratio(v["difference"], v["valid"]),
            }
            for pair, v in pairs.items()
        },
        "pillar_marginals": marginals,
    }


def analyse(
    manifest: dict,
    observations: list[dict],
    requested: list[dict],
    failures: list[dict],
    outcomes: list[dict],
) -> dict:
    """Implement prospective diagnostics without pooling rounds/checks/executions as independent data."""
    papers = [p["study_id"] for p in manifest["papers"]]
    rounds = sorted({int(r["round"]) for r in observations if r["kind"] == "rating"} | {0})
    ratings = {
        (int(r["study"]), r["rater"], r["pillar"], int(r["round"])): r
        for r in observations
        if r["kind"] == "rating"
    }
    transitions = []
    for key, now in ratings.items():
        if key[3] == 0 or int(now["carried"]):
            continue
        old = ratings.get((*key[:3], key[3] - 1))
        if old is None:
            continue
        numeric = now["status"] == old["status"] == "scored"
        changed = any(
            now[k] != old[k] for k in ("status", "score", "quote", "locator", "reason", "alternative")
        )
        transitions.append(
            {
                "numeric": numeric,
                "score_changed": numeric and now["score"] != old["score"],
                "status_changed": now["status"] != old["status"],
                "substantive_changed": changed,
                "evidence_changed": now["quote"] != old["quote"] or now["locator"] != old["locator"],
            }
        )
    checks = {(r["request_id"], r["pillar"]): r for r in observations if r["kind"] == "check"}
    base_requests = {q["request_id"]: q for q in requested}
    check_attempts = []
    groups = {}
    for q in requested:
        if q["kind"] != "check":
            continue
        targets = json.loads(q["check_targets"])
        original = base_requests[q["original_request_id"]]
        for p in targets:
            target = ratings.get((int(original["study"]), original["rater"], p, int(original["round"])))
            if target is None:
                raise StudyError("Check target absent from canonical ratings")
            actual = checks.get((q["request_id"], p))
            usable = actual is not None
            match = usable and all(actual[k] == target[k] for k in ("score", "status"))
            group = (int(q["study"]), q["rater"], int(q["round"]), p)
            groups.setdefault(group, {})[int(q["replicate"])] = (usable, match)
            check_attempts.append(
                {
                    "study": group[0],
                    "rater": group[1],
                    "round": group[2],
                    "pillar": p,
                    "replicate": int(q["replicate"]),
                    "usable": usable,
                    "match": match,
                    "numeric": usable and actual["status"] == "scored",
                    "actual_score": actual["score"] if actual else None,
                    "target_score": target["score"],
                    "actual_status": actual["status"] if actual else None,
                }
            )
    requested_checks = len(check_attempts)
    usable = sum(c["usable"] for c in check_attempts)
    matching = sum(c["match"] for c in check_attempts)
    confirmation = sum(
        set(g) == {1, 2} and all(use and match for use, match in g.values()) for g in groups.values()
    )
    terminal = {}
    stops = {}
    for row in outcomes:
        terminal[row["outcome"]] = terminal.get(row["outcome"], 0) + 1
        stops[str(row["stop_reason"])] = stops.get(str(row["stop_reason"]), 0) + 1
    profiles = []
    for round_n in rounds:
        for sid in papers:
            for r in RATERS:
                cells = [ratings.get((sid, r, p, round_n)) for p in PILLARS]
                numeric = all(c and c["status"] == "scored" for c in cells)
                values = [int(c["score"]) for c in cells] if numeric else []
                profiles.append(
                    {
                        "study": sid,
                        "rater": r,
                        "round": round_n,
                        "ovi_gate": min(values) if values else None,
                        "bottlenecks": [p for p, v in zip(PILLARS, values, strict=False) if v == min(values)]
                        if values
                        else [],
                        "profile_complete": numeric,
                    }
                )
    numeric_transitions = sum(t["numeric"] for t in transitions)
    return {
        "provenance": "agent:gpt-6",
        "population": manifest["population"],
        "condition": manifest["condition"],
        "execution": manifest["execution"],
        "requested_initial_judgments": len(papers) * 12,
        "papers": papers,
        "rounds": {str(n): agreement(observations, papers, n) for n in rounds},
        "transitions": {
            "numeric_pairs": numeric_transitions,
            "actual_pairs": len(transitions),
            "score_change": ratio(sum(t["score_changed"] for t in transitions), numeric_transitions),
            "status_change": ratio(sum(t["status_changed"] for t in transitions), len(transitions)),
            "substantive_change": ratio(sum(t["substantive_changed"] for t in transitions), len(transitions)),
            "evidence_change": ratio(sum(t["evidence_changed"] for t in transitions), len(transitions)),
            "confirmed_evidence_corrections": None,
            "correction_audit": "pending; changes are not corrections",
        },
        "fresh_checks": {
            "reproduction_usable": ratio(matching, usable),
            "reproduction_requested": ratio(matching, requested_checks),
            "coverage": ratio(usable, requested_checks),
            "two_check_confirmation": ratio(confirmation, len(groups)),
            "numeric_matching": sum(c["numeric"] and c["match"] for c in check_attempts),
            "null_matching": sum(c["usable"] and not c["numeric"] and c["match"] for c in check_attempts),
            "outcomes": check_attempts,
        },
        "terminal_outcomes": terminal,
        "stop_reasons": stops,
        "process_failures": failures,
        "ovi_profiles": profiles,
        "observations": observations,
        "claim_limits": "AI consistency; no human reference, inferential reliability or correctness claim",
    }


def report_run(store: Records, run_id: str, directory: Path) -> tuple[dict, dict]:
    """Write and re-read the canonical CSV evidence before computing any aggregate."""
    m, rows, requested, failures, outcomes, attempts = flattened(store, run_id)
    sources = {}
    definitions = [
        ("observations", rows, FIELDS),
        (
            "requests",
            requested,
            (
                "request_id",
                "study",
                "rater",
                "round",
                "kind",
                "replicate",
                "pending",
                "check_targets",
                "original_request_id",
            ),
        ),
        (
            "failures",
            failures,
            (
                "request_id",
                "study",
                "rater",
                "round",
                "kind",
                "replicate",
                "status",
                "reason",
                "failed_pillars",
                "pillar_failures",
            ),
        ),
        (
            "outcomes",
            outcomes,
            (
                "study",
                "pillar",
                "outcome",
                "complete",
                "assessable",
                "numeric_agreement",
                "substantive_stable",
                "numeric_stable",
                "instability",
                "stop_reason",
                "terminal",
                "round",
            ),
        ),
    ]
    definitions.append(
        (
            "attempts",
            attempts,
            (
                "attempt_id",
                "request_id",
                "provider",
                "rater",
                "stage",
                "transport",
                "reserved_usd",
                "charged_or_reserved_usd",
                "original_charge_or_reservation_usd",
                "reconciliation_id",
                "status",
                "input_tokens",
                "output_tokens",
                "model_returned",
            ),
        )
    )
    datasets = {}
    for name, data, fields in definitions:
        path = csv_snapshot(directory, f"study_{run_id}_{name}", data, fields)
        sources[name] = {"path": str(path), "sha256": digest(path.read_bytes())}
        datasets[name] = read_csv(path)
    report = analyse(
        m, datasets["observations"], datasets["requests"], datasets["failures"], datasets["outcomes"]
    )
    report["configuration_hash"] = digest(
        canonical(
            {
                "models": m["models"],
                "versions": m["versions"],
                "papers": m["papers"],
                "code_files": m["code"].get("files", {}),
                "environment": {k: m["code"].get(k) for k in ("python", "packages", "parser")},
            }
        )
    )
    report["source_csvs"] = sources
    report["run_id"] = run_id
    costs = datasets["attempts"]
    report["usage"] = {
        "provenance": "agent:gpt-6",
        "attempts": len(costs),
        "spent_or_reserved_usd": sum(float(a["charged_or_reserved_usd"]) for a in costs),
        "by_provider": {
            provider: {
                "attempts": sum(a["provider"] == provider for a in costs),
                "usd": sum(float(a["charged_or_reserved_usd"]) for a in costs if a["provider"] == provider),
            }
            for provider in sorted({a["provider"] for a in costs})
        },
    }
    report["programme_usage"] = store.usage()
    return report, sources


def html_report(report: dict) -> str:
    """Local interactive coordinator report escapes every scientific string before display."""
    title = f"CH02 {report['condition']} · execution {report['execution']} · {report['population']}"
    data = canonical(report).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    return (
        """<!doctype html><html lang="en"><meta charset="utf-8"><title>CH02 experiment report</title>
<style>body{font:16px system-ui;max-width:1200px;margin:40px auto;padding:20px;color:#172536}
h1{font-size:30px}table{border-collapse:collapse;width:100%}
td,th{padding:12px;border-bottom:1px solid #ccd5dd;
text-align:left;vertical-align:top}select{font:inherit;padding:8px}pre{white-space:pre-wrap;background:#eef2f5;
padding:18px}blockquote{border-left:3px solid #317383;padding-left:14px}small{color:#536474}</style>
<h1>"""
        + html.escape(title)
        + """</h1><p>Agent-produced research records; human_confirmed=false.
Round 0 is independent. Later rounds share evidence. Quote matching is not semantic validation.</p>
<label>Show round <select id="round"></select></label><div id="summary"></div><div id="grid"></div>
<h2>Changes, checks, outcomes and failures</h2><p id="outcomes"></p>
<details><summary>Full diagnostics and CSV lineage</summary><pre id="diagnostics"></pre></details>
<h2>Exact evidence and explanations</h2><div id="evidence"></div>
<script type="application/json" id="data">"""
        + data
        + """</script><script>
const d=JSON.parse(document.getElementById('data').textContent),sel=document.getElementById('round');
for(const n of Object.keys(d.rounds)){const o=document.createElement('option');
o.value=n;o.textContent=n==='0'?
'0 · independent':n+' · deliberation';sel.append(o)}
function cell(tag,text){const e=document.createElement(tag);e.textContent=text;return e}
function rate(v){return v.value===null?'NA (0 denominator)':
(100*v.value).toFixed(1)+'% ('+v.numerator+'/'+v.denominator+')'}
function draw(){const n=Number(sel.value),
rows=d.observations.filter(r=>r.kind==='rating'&&Number(r.round)===n),
s=d.rounds[String(n)],summary=document.getElementById('summary');summary.replaceChildren();
summary.append(cell('p','All-three exact agreement: '+rate(s.exact_agreement)+
'; complete-panel coverage: '+rate(s.complete_panel_coverage)));
const grid=document.getElementById('grid');grid.replaceChildren();const table=document.createElement('table'),
head=document.createElement('tr');
for(const t of ['Paper','Pillar','r1','r2','r3'])head.append(cell('th',t));table.append(head);
const studies=[...new Set(d.ovi_profiles.map(r=>r.study))];
for(const sid of studies)for(const p of ['P1','P2','P3','P4']){
const tr=document.createElement('tr');tr.append(cell('td',sid),cell('td',p));for(const r of ['r1','r2','r3']){
const c=rows.find(x=>Number(x.study)===sid&&x.rater===r&&x.pillar===p);tr.append(cell('td',c?
(c.status==='scored'?c.score:c.status)+(Number(c.carried)?' · carried':''):'No response'))}
table.append(tr)}grid.append(table);
document.getElementById('outcomes').textContent='Outcomes: '+JSON.stringify(d.terminal_outcomes)+
'; process failures: '+d.process_failures.length+'; two-check confirmation: '+
rate(d.fresh_checks.two_check_confirmation);
document.getElementById('diagnostics').textContent=JSON.stringify({transitions:d.transitions,
fresh_checks:d.fresh_checks,terminal_outcomes:d.terminal_outcomes,stop_reasons:d.stop_reasons,
process_failures:d.process_failures,usage:d.usage,source_csvs:d.source_csvs},null,2);
const evidence=document.getElementById('evidence');evidence.replaceChildren();for(const r of rows){
const a=document.createElement('details');
a.append(cell('summary',r.study+' / '+r.pillar+' / '+r.rater+' / '+r.agent));
a.append(cell('blockquote',r.quote),cell('small',r.locator),cell('p',r.reason),
cell('p','Alternative: '+r.alternative));
evidence.append(a)}}sel.addEventListener('change',draw);draw();</script></html>"""
    )


def compare_executions(reports: list[dict], expected_executions=(1, 2, 3)) -> dict:
    """Three-execution diagnostics retain missing executions and require the same condition/population."""
    if not reports:
        return {"provenance": "agent:gpt-6", "status": "no_executions", "complete": False}
    if len({r["population"] for r in reports}) != 1 or len({r["condition"] for r in reports}) != 1:
        raise StudyError("Do not pool different populations or conditions")
    by_execution = {int(r["execution"]): r for r in reports}
    if len(by_execution) != len(reports):
        raise StudyError("Duplicate execution/version requires a separate comparison block")
    if len({r["configuration_hash"] for r in reports}) != 1:
        raise StudyError("Repeat configurations differ; use a separate comparison block")
    paper_sets = [set(r["papers"]) for r in reports]
    if any(s != paper_sets[0] for s in paper_sets):
        raise StudyError("Repeat comparison paper sets differ")
    papers = sorted(paper_sets[0])
    requested = len(papers) * 12
    valid = equal = 0
    vectors = []
    indexes = {
        e: {
            (int(row["study"]), row["rater"], row["pillar"]): row
            for row in r["observations"]
            if row["kind"] == "rating" and int(row["round"]) == 0
        }
        for e, r in by_execution.items()
    }
    for sid in papers:
        for rater in RATERS:
            for p in PILLARS:
                rows = [indexes.get(e, {}).get((sid, rater, p)) for e in expected_executions]
                numeric = all(row and row["status"] == "scored" for row in rows)
                values = [int(row["score"]) if row and row["status"] == "scored" else None for row in rows]
                valid += numeric
                equal += numeric and len(set(values)) == 1
                vectors.append(
                    {"study": sid, "rater": rater, "pillar": p, "scores": values, "complete": numeric}
                )
    return {
        "provenance": "agent:gpt-6",
        "population": reports[0]["population"],
        "condition": reports[0]["condition"],
        "expected_executions": list(expected_executions),
        "present_executions": sorted(by_execution),
        "complete": set(by_execution) == set(expected_executions),
        "requested_model_cells": requested,
        "three_execution_coverage": ratio(valid, requested),
        "three_execution_equal_scores": ratio(equal, valid),
        "vectors": vectors,
        "sources": {str(e): r["source_csvs"] for e, r in by_execution.items()},
    }
