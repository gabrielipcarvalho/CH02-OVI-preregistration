"""Physical-page block extraction and explicit localisation; no semantic grading or legacy rewriting."""

from __future__ import annotations

import json
import re
import subprocess
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path

from pipeline.study.evidence_v2 import contains
from pipeline.study.records import StudyError

VERSION = "physical-block-v3"
INSTRUCTION = """Quote one contiguous source passage and identify its physical PDF page.
Use 'PDF page N' or 'PDF p.N'; section names may precede the page.
Label printed/journal pagination separately. Put contextual references after '; context:'.
Do not splice quotations with ellipses. Source localisation does not establish criterion adequacy."""
NS = "{http://www.w3.org/1999/xhtml}"


def extract_blocks(pdf: bytes) -> str:
    """Freeze in-page word blocks, preserving columns/line hyphens; reject malformed geometry."""
    with tempfile.TemporaryDirectory(prefix="ch2-bbox-") as folder:
        p = Path(folder) / "source.pdf"
        p.write_bytes(pdf)
        result = subprocess.run(
            ["pdftotext", "-bbox-layout", str(p), "-"], check=True, capture_output=True, timeout=60
        )
    xml = result.stdout.decode("utf-8")
    invalid = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
    replacements = len(invalid.findall(xml))
    root = ET.fromstring(invalid.sub("\ufffd", xml))
    pages = {}
    for number, page in enumerate(root.iter(NS + "page"), 1):
        width, height = float(page.attrib["width"]), float(page.attrib["height"])
        blocks = []
        for block in page.iter(NS + "block"):
            lines = []
            for line in block.iter(NS + "line"):
                words = []
                for word in line.iter(NS + "word"):
                    x0, y0, x1, y1 = (float(word.attrib[k]) for k in ["xMin", "yMin", "xMax", "yMax"])
                    if 0 <= x0 <= x1 <= width and 0 <= y0 <= y1 <= height:
                        words.append(word.text or "")
                if words:
                    lines.append(" ".join(words))
            if lines:
                blocks.append("\n".join(lines))
        pages[str(number)] = blocks
    if not pages:
        raise StudyError("No physical PDF pages extracted")
    return json.dumps(
        {"version": VERSION, "pages": pages, "unmapped_control_characters": replacements},
        sort_keys=True,
        ensure_ascii=False,
    )


def source_text(blocks_json: str) -> str:
    """Expose the same bounded block extraction to every assessor; no scores or study metadata."""
    value = json.loads(blocks_json)
    return "\n\n".join(
        "[PDF PAGE " + n + "]\n" + "\n\n".join(blocks)
        for n, blocks in sorted(value["pages"].items(), key=lambda x: int(x[0]))
    )


def anchor_page(locator: str) -> int:
    """Accept physical anchors anywhere; printed labels/context never become extra evidence pages."""
    anchor = locator.split("; context:", 1)[0]
    anchor = re.sub(r"\b(?:printed|journal|publication)\s+(?:page|p\.)\s*\d+", "", anchor, flags=re.I)
    # A range is ambiguous for the one-contiguous-passage contract; do not silently choose one end.
    if re.search(r"\b(?:pages?|p\.)\s*\d+\s*[-–,]\s*\d+", anchor, re.I):
        raise StudyError("Ambiguous claimed PDF page range; review required")
    matches = re.findall(r"\b(?:PDF\s+)?(?:page|p\.)\s*([1-9]\d*)\b", anchor, re.I)
    if len(set(matches)) != 1:
        raise StudyError("Ambiguous or missing claimed PDF page; review required")
    return int(matches[0])


def typographic(text: str) -> str:
    """Equate typographic apostrophes/quotes only; scientific signs and quantities remain literal."""
    return text.translate(str.maketrans({"’": "'", "‘": "'", "“": '"', "”": '"'}))


def variants(text: str) -> tuple[str, ...]:
    """Preserve scientific unit case, quantities and signs; vary only alphabetic line-end hyphens."""
    text = unicodedata.normalize("NFKC", text)
    text = text.translate(str.maketrans({"\u2010": "-", "\u2011": "-", "\u2212": "-"}))
    pattern = r"(?<=[^\W\d_])[-\u00ad]\s*\n\s*(?=[^\W\d_])"
    return tuple(dict.fromkeys(" ".join(re.sub(pattern, v, text).split()) for v in ("-", "")))


def evidence_check_v3(cell: dict, blocks_json: str) -> dict:
    """Match contiguous words within an in-page block; never use raw stream or fuzzy evidence."""
    base = {"validator_version": VERSION, "semantic_validity": False}
    if cell["quote"] == "NO_DOCUMENTED_EVIDENCE":
        return {**base, "status": "absence_not_verified"}
    if not cell["quote"].strip():
        if cell["status"] == "scored":
            raise StudyError("Scored evidence is empty")
        return {**base, "status": "not_assessable"}
    page = anchor_page(cell["locator"])
    value = json.loads(blocks_json)
    if value["version"] != VERSION:
        raise StudyError("Frozen block extraction version mismatch")
    quotation = typographic(cell["quote"])
    needles = variants(quotation)
    # Sentence-initial article capitalisation is typographic; preserve unit/variable case elsewhere.
    if quotation.startswith("The "):
        needles += variants("the " + quotation[4:])
    elif quotation.startswith("the "):
        needles += variants("The " + quotation[4:])
    for index, block in enumerate(value["pages"].get(str(page), [])):
        if any(contains(needle, haystack) for needle in needles for haystack in variants(typographic(block))):
            return {
                **base,
                "status": "text_match",
                "method": "bounded_pdf_block",
                "pages": [page],
                "block": index,
                "locator_page_verified": True,
            }
    raise StudyError("Quote not locatable on claimed PDF page in bounded blocks; original preserved")
