"""Synchronous per-paper rounds, whole-batch R0 barrier and two exact-request fresh checks."""

from __future__ import annotations

import json
import random

from pipeline.calibration.store import SUBSTANTIVE
from pipeline.study.records import PILLARS, RATERS, Records, StudyError, canonical, digest, stamp
from pipeline.study.scoring import build_prompt, defence_violations, payload_for
from pipeline.study.transport import Dispatcher


def effective_round(store: Records, run_id: str, study: int, round_n: int) -> dict:
    """Combine actual submissions with explicitly labelled carries; a carry is not a new model response."""
    with store.db() as db:
        rows = db.execute(
            "SELECT j.payload,q.rater,q.id FROM judgments j JOIN requests q ON q.id=j.request_id "
            "WHERE q.run_id=? AND q.study=? AND q.round=? AND q.kind=?",
            (run_id, study, round_n, "rating"),
        ).fetchall()
        carries = db.execute(
            "SELECT payload FROM events WHERE run_id=? AND kind='carry'", (run_id,)
        ).fetchall()
    result = {
        (r["rater"], json.loads(r["payload"])["pillar"]): {
            "cell": json.loads(r["payload"]),
            "request_id": r["id"],
            "carried": False,
        }
        for r in rows
    }
    for row in carries:
        c = json.loads(row[0])
        if c["study"] == study and c["round"] == round_n:
            key = (c["rater"], c["pillar"])
            if key in result:
                raise StudyError("Carry conflicts with a fresh scientific response")
            result[key] = {"cell": c["cell"], "request_id": c["source_request_id"], "carried": True}
    return result


def batch_initial_complete(store: Records, run_id: str) -> bool:
    """Every expected initial rater×paper request must have four locked cells or explicit failure."""
    m = store.manifest(run_id)
    with store.db() as db:
        for paper in m["papers"]:
            for rater in RATERS:
                row = db.execute(
                    "SELECT id FROM requests WHERE run_id=? AND study=? AND rater=? "
                    "AND round=0 AND kind='rating'",
                    (run_id, paper["study_id"], rater),
                ).fetchone()
                if row is None:
                    return False
                disposition = db.execute(
                    "SELECT payload FROM dispositions WHERE request_id=?", tuple(row)
                ).fetchone()
                saved = {
                    r[0] for r in db.execute("SELECT pillar FROM judgments WHERE request_id=?", tuple(row))
                }
                failed = (
                    set(json.loads(disposition[0]).get("failed_pillars", PILLARS)) if disposition else set()
                )
                if saved & failed or saved | failed != set(PILLARS):
                    return False
    return True


def current_round(store: Records, run_id: str, study: int) -> int:
    with store.db() as db:
        n = db.execute(
            "SELECT coalesce(max(round),0) FROM packets WHERE run_id=? AND study=?", (run_id, study)
        ).fetchone()[0]
    return n


def failed_cells(store: Records, run_id: str, study: int, n: int) -> dict:
    """Propagate exact original failure status and request provenance, never invent a new judgment."""
    with store.db() as db:
        failures = db.execute(
            "SELECT q.id,q.rater,q.context,d.payload FROM dispositions d JOIN requests q "
            "ON q.id=d.request_id WHERE q.run_id=? AND q.study=? AND q.round=? "
            "AND q.kind='rating'",
            (run_id, study, n),
        ).fetchall()
    failed = {
        (r["rater"], p): {"failure": json.loads(r["payload"]), "source_request_id": r["id"]}
        for r in failures
        for p in json.loads(r["payload"]).get("failed_pillars", json.loads(r["context"])["pending"])
    }
    with store.db() as db:
        carried_failures = db.execute(
            "SELECT payload FROM events WHERE run_id=? AND kind='carry_failure'", (run_id,)
        ).fetchall()
    for row in carried_failures:
        c = json.loads(row[0])
        if c["study"] == study and c["round"] == n:
            failed[c["rater"], c["pillar"]] = {
                "failure": c["failure"],
                "source_request_id": c["source_request_id"],
            }
    return failed


def states(store: Records, run_id: str, study: int, round_n: int | None = None) -> dict:
    """Outcome and stop reason stay separate; matching nulls and process failures never count as agreement."""
    n = current_round(store, run_id, study) if round_n is None else round_n
    history = {t: effective_round(store, run_id, study, t) for t in range(max(0, n - 2), n + 1)}
    failed = {key: value["failure"] for key, value in failed_cells(store, run_id, study, n).items()}
    output = {}
    for p in PILLARS:
        complete = all((r, p) in history[n] for r in RATERS)
        stops = [failed[(r, p)] for r in RATERS if (r, p) in failed and (r, p) not in history[n]]
        numeric = False
        stable = False
        numeric_stable = False
        if complete:
            cells = [history[n][r, p]["cell"] for r in RATERS]
            assessable = all(c["status"] == "scored" for c in cells)
            numeric = assessable and len({c["score"] for c in cells}) == 1

            def unchanged(fields, p=p):
                return n >= 2 and all(
                    all((r, p) in history[t] for t in range(n - 2, n + 1))
                    and len({tuple(history[t][r, p]["cell"][k] for k in fields) for t in range(n - 2, n + 1)})
                    == 1
                    for r in RATERS
                )

            stable = unchanged(SUBSTANTIVE)
            numeric_stable = unchanged(("status", "score"))
            withheld = any(c.get("defence_check", {}).get("status") == "withheld" for c in cells)
            reason = (
                "defence_failure"
                if withheld
                else "stability"
                if stable
                else "round_limit"
                if n >= 4
                else None
            )
            outcome = (
                "incomplete_deliberation"
                if withheld
                else "non_assessable"
                if not assessable
                else "stable_agreement"
                if stable and numeric
                else "stable_disagreement"
                if stable
                else "unstable"
                if n >= 4
                else "agreement_under_review"
                if numeric
                else "contested"
            )
        else:
            assessable = False
            reason = (
                ("resource_stop" if any(c["status"] == "resource_stop" for c in stops) else "process_failure")
                if stops
                else None
            )
            outcome = "incomplete" if stops else "awaiting"
        output[p] = {
            "outcome": outcome,
            "complete": complete,
            "assessable": assessable,
            "numeric_agreement": numeric,
            "substantive_stable": stable,
            "numeric_stable": numeric_stable,
            "instability": complete and n >= 4 and not stable,
            "stop_reason": reason,
            "terminal": reason is not None,
            "round": n,
        }
    return output


def check_targets(store: Records, run_id: str, study: int, n: int, rater: str) -> list[str]:
    """Any substantive change to a previously contested cell triggers two checks."""
    if not n:
        return []
    prior = effective_round(store, run_id, study, n - 1)
    now = effective_round(store, run_id, study, n)
    targets = []
    for p in PILLARS:
        if (rater, p) not in now or now[rater, p]["carried"] or (rater, p) not in prior:
            continue
        if not all((r, p) in prior for r in RATERS):
            continue
        contested = len({(prior[r, p]["cell"]["status"], prior[r, p]["cell"]["score"]) for r in RATERS}) > 1
        changed = any(now[rater, p]["cell"][k] != prior[rater, p]["cell"][k] for k in SUBSTANTIVE)
        if contested and changed:
            targets.append(p)
    return targets


def run_checks(store: Records, run_id: str, study: int, n: int, dispatcher: Dispatcher) -> None:
    """Two independently identified requests replay exact original revision payload without desired scores."""
    current = effective_round(store, run_id, study, n)
    prior = effective_round(store, run_id, study, n - 1) if n else {}
    for rater in RATERS:
        targets = check_targets(store, run_id, study, n, rater)
        if not targets:
            continue
        original_id = current[rater, targets[0]]["request_id"]
        with store.db() as db:
            row = db.execute("SELECT * FROM requests WHERE id=?", (original_id,)).fetchone()
        payload = json.loads(row["payload"])
        context = json.loads(row["context"])
        context.update(
            check_targets=targets,
            original_request_id=original_id,
            exact_payload_hash=digest(canonical(payload)),
        )
        previous = {p: prior[rater, p]["cell"] for p in PILLARS if (rater, p) in prior}
        for replicate in (1, 2):
            q = store.request(run_id, study, rater, n, "check", replicate, payload, context)
            dispatcher.execute(q, previous=previous)


def checks_complete(store: Records, run_id: str, study: int, n: int) -> bool:
    with store.db() as db:
        for r in RATERS:
            if not check_targets(store, run_id, study, n, r):
                continue
            for rep in (1, 2):
                q = db.execute(
                    "SELECT id FROM requests WHERE run_id=? AND study=? AND rater=? AND round=? "
                    "AND kind='check' AND replicate=?",
                    (run_id, study, r, n, rep),
                ).fetchone()
                if q is None:
                    return False
                if (
                    not db.execute("SELECT 1 FROM dispositions WHERE request_id=?", tuple(q)).fetchone()
                    and not db.execute("SELECT 1 FROM judgments WHERE request_id=?", tuple(q)).fetchone()
                ):
                    return False
    return True


def release(store: Records, run_id: str, study: int) -> int:
    """Release all recipient snapshots atomically only after batch/round completion and required checks."""
    if not batch_initial_complete(store, run_id):
        raise StudyError("Whole execution R0 batch incomplete")
    n = current_round(store, run_id, study)
    status = states(store, run_id, study, n)
    if not all(s["complete"] or s["terminal"] for s in status.values()):
        raise StudyError("Current paper round incomplete/process-stopped")
    if n >= 4 or all(s["terminal"] for s in status.values()):
        raise StudyError("Paper reached stopping state")
    if not checks_complete(store, run_id, study, n):
        raise StudyError("Two required fresh checks not dispositioned")
    records = effective_round(store, run_id, study, n)
    failure_records = failed_cells(store, run_id, study, n)
    m = store.manifest(run_id)
    packets = {}
    for recipient in RATERS:
        packet = {}
        for p in PILLARS:
            if status[p]["terminal"]:
                packet[p] = []
                continue
            unique = {}
            for peer in RATERS:
                if peer == recipient:
                    continue
                cell = records[peer, p]["cell"]
                if defence_violations(cell):
                    raise StudyError("Prohibited peer defence cannot be released")
                argument = {**cell["anonymous_defence"], "status": cell["status"]}
                unique[canonical(argument)] = argument
            arguments = list(unique.values())
            seed = digest(canonical([m["seed"], run_id, study, n + 1, recipient, p]))
            random.Random(seed).shuffle(arguments)
            packet[p] = [{"label": f"Argument {i}", **a} for i, a in enumerate(arguments, 1)]
        packets[recipient] = packet
    with store.db() as db:
        db.execute("BEGIN IMMEDIATE")
        if db.execute(
            "SELECT 1 FROM packets WHERE run_id=? AND study=? AND round=?", (run_id, study, n + 1)
        ).fetchone():
            raise StudyError("Round already released; resume it")
        for r in RATERS:
            db.execute(
                "INSERT INTO packets VALUES(?,?,?,?,?,?)",
                (run_id, study, n + 1, r, canonical(packets[r]), stamp()),
            )
        for p, state in status.items():
            if not state["terminal"]:
                continue
            for r in RATERS:
                if (r, p) not in records:
                    failure = failure_records[r, p]
                    db.execute(
                        "INSERT INTO events(run_id,kind,payload,created) VALUES(?,?,?,?)",
                        (
                            run_id,
                            "carry_failure",
                            canonical(
                                {
                                    "study": study,
                                    "round": n + 1,
                                    "rater": r,
                                    "pillar": p,
                                    **failure,
                                    "source_round": n,
                                }
                            ),
                            stamp(),
                        ),
                    )
                    continue
                entry = records[r, p]
                carry = {
                    "study": study,
                    "round": n + 1,
                    "rater": r,
                    "pillar": p,
                    "cell": entry["cell"],
                    "source_request_id": entry["request_id"],
                    "carried_forward": True,
                }
                db.execute(
                    "INSERT INTO events(run_id,kind,payload,created) VALUES(?,?,?,?)",
                    (run_id, "carry", canonical(carry), stamp()),
                )
    return n + 1


def execute_run(store: Records, run_id: str, dispatcher: Dispatcher) -> dict:
    """Resume initial/revision/check requests idempotently; never collect genuine data without admission."""
    from pipeline.study.cli import check_admission, initial_round

    m = store.manifest(run_id)
    check_admission(m["population"])
    initial_round(store, run_id, dispatcher)
    if not batch_initial_complete(store, run_id):
        raise StudyError("Initial batch incomplete")
    if m["population"] == "final_evaluation":
        return {"run_id": run_id, "status": "independent_initial_dispositioned", "usage": store.usage()}
    results = {}
    for paper in m["papers"]:
        sid = paper["study_id"]
        while True:
            n = current_round(store, run_id, sid)
            if n:
                records = effective_round(store, run_id, sid, n)
                previous = effective_round(store, run_id, sid, n - 1)
                for rater in RATERS:
                    status_now = states(store, run_id, sid, n)
                    pending = [
                        p for p in PILLARS if (rater, p) not in records and not status_now[p]["terminal"]
                    ]
                    if not pending:
                        continue
                    with store.db() as db:
                        packet = json.loads(
                            db.execute(
                                "SELECT payload FROM packets WHERE run_id=? AND study=? "
                                "AND round=? AND rater=?",
                                (run_id, sid, n, rater),
                            ).fetchone()[0]
                        )
                    own = {p: previous[rater, p]["cell"] for p in PILLARS if (rater, p) in previous}
                    prompt, context = build_prompt(store, run_id, sid, pending, own, packet)
                    q = store.request(
                        run_id, sid, rater, n, "rating", 0, payload_for(m["models"][rater], prompt), context
                    )
                    dispatcher.execute(q, previous=own)
                run_checks(store, run_id, sid, n, dispatcher)
            status = states(store, run_id, sid, n)
            if all(s["terminal"] for s in status.values()):
                results[str(sid)] = status
                break
            if any(not s["complete"] and not s["terminal"] for s in status.values()):
                raise StudyError("Round awaiting undispositioned requests")
            release(store, run_id, sid)
    with store.db() as db:
        if not db.execute(
            "SELECT 1 FROM events WHERE run_id=? AND kind='execution_dispositioned'", (run_id,)
        ).fetchone():
            db.execute(
                "INSERT INTO events(run_id,kind,payload,created) VALUES(?,?,?,?)",
                (run_id, "execution_dispositioned", canonical({"outcomes": results}), stamp()),
            )
    return {
        "run_id": run_id,
        "status": "execution_dispositioned",
        "outcomes": results,
        "usage": store.usage(),
    }
