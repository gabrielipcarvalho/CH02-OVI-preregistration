"""Read-only failure accounting; preserve eligibility and distinguish requests from lost judgments."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import sqlite3
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

PILLARS = ("P1", "P2", "P3", "P4")
RATERS = ("r1", "r2", "r3")
LABELS = {"P1": "paper_swap_A", "P2": "paper_swap_B", "P3": "paper_swap_C"}
PROVENANCE = {"provenance": "agent:gpt-6", "human_confirmed": False}


def reason_tags(reason: str) -> tuple[str, ...]:
    """Classify explicit saved reasons only; allow mixed labels rather than hiding secondary failures."""
    tests = {
        "quote_unlocatable": "not locatable" in reason,
        "quote_wrong_page": "claimed PDF page" in reason,
        "resource_stop": "budget stop" in reason,
        "process_gate": "acceptance receipt absent" in reason,
        "transport_error": "HTTP " in reason or "Timeout" in reason or "Connection" in reason,
        "json_format": any(s in reason for s in ("Expecting ", "Unterminated ", "Extra data")),
        "response_contract": any(
            s in reason
            for s in ("Defence must preserve", "required property", "not of type", "Missing scientific field")
        ),
        "ambiguous_pillar_identity": "Ambiguous raw pillar identity" in reason,
    }
    return tuple(k for k, present in tests.items() if present) or ("other_unresolved",)


def broad_category(tags: tuple[str, ...] | list[str]) -> str:
    """Use a declared primary-category precedence while keeping all tags in the source row."""
    if set(tags) & {"quote_unlocatable", "quote_wrong_page"}:
        return "evidence_validation"
    if set(tags) & {"resource_stop", "process_gate"}:
        return "resource_process"
    if "ambiguous_pillar_identity" in tags:
        return "ambiguous_identity"
    if "response_contract" in tags:
        return "response_contract"
    if "transport_error" in tags:
        return "transport"
    if "json_format" in tags:
        return "json_format"
    return "other_unresolved"


def failed_pillars(payload: dict, pending: list[str]) -> list[str]:
    """Expand only declared affected pillars or the legacy request-wide fallback; reject bad joins."""
    result = payload.get("failed_pillars", pending)
    if not result or len(result) != len(set(result)) or not set(result) <= set(pending):
        raise ValueError("Invalid affected-pillar set")
    return sorted(result)


def ratio(n: int, d: int) -> float | None:
    return n / d if d else None


def read_ledger(path: Path) -> dict:
    """Open the fixed ledger read-only; never instantiate the writable/migrating production store."""
    if not path.is_file():
        raise ValueError("Ledger missing")
    output = {}
    with sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True) as db:
        db.row_factory = sqlite3.Row
        for table in (
            "runs",
            "requests",
            "attempts",
            "completions",
            "judgments",
            "dispositions",
            "events",
            "charge_reconciliations",
        ):
            output[table] = []
            for raw in db.execute(f"SELECT * FROM {table} ORDER BY rowid"):
                row = dict(raw)
                for key in ("manifest", "payload", "context", "result", "provenance"):
                    if key in row:
                        row[key] = json.loads(row[key])
                output[table].append(row)
        # Every frozen asset must match its content address, not merely be present.
        for row in db.execute("SELECT hash,payload FROM assets"):
            if hashlib.sha256(bytes(row["payload"])).hexdigest() != row["hash"]:
                raise ValueError("Frozen asset hash mismatch")
    return output


def inventory(ledger: dict, cohorts: dict[str, list[str]]) -> dict:
    """Build explicit request, failure and effective-cell populations without changing observations."""
    runs = {r["id"]: r["manifest"] for r in ledger["runs"]}
    requests = {r["id"]: r for r in ledger["requests"]}
    dispositions = {r["request_id"]: r["payload"] for r in ledger["dispositions"]}
    attempts = Counter(r["request_id"] for r in ledger["attempts"])
    judgments = {}
    for row in ledger["judgments"]:
        key = (row["request_id"], row["pillar"])
        if key in judgments:
            raise ValueError("Duplicate authoritative judgment")
        judgments[key] = row["payload"]
    group = {}
    for name, ids in cohorts.items():
        for id_ in ids:
            if id_ not in runs or id_ in group:
                raise ValueError("Missing/overlapping cohort run")
            group[id_] = name
    request_rows, failure_rows, failure_cells = [], [], []
    failure_lookup = {}
    for qid, q in requests.items():
        m = runs[q["run_id"]]
        meta = dict(
            run_id=q["run_id"],
            cohort=group.get(q["run_id"], "other_recorded_run"),
            population=m["population"],
            condition_original=m["condition"],
            condition=LABELS.get(m["condition"], m["condition"]),
            execution=m["execution"],
            study=q["study"],
            rater=q["rater"],
            model=m["models"][q["rater"]]["model"],
            round=q["round"],
            kind=q["kind"],
            replicate=q["replicate"],
            request_id=qid,
        )
        pending = q["context"]["pending"]
        if len(pending) != len(set(pending)) or not set(pending) <= set(PILLARS):
            raise ValueError("Invalid pending-pillar set")
        saved = [p for p in pending if (qid, p) in judgments]
        disposition = dispositions.get(qid)
        failed = failed_pillars(disposition, pending) if disposition else []
        if set(saved) & set(failed):
            raise ValueError("A pillar cannot be both saved and failed")
        tags = reason_tags(disposition["reason"]) if disposition else ()
        row = {
            **meta,
            "pending_pillars": json.dumps(pending),
            "saved_pillars": len(saved),
            "failed_pillars": len(failed),
            "attempts": attempts[qid],
            "has_failure": int(bool(disposition)),
            "partial_response": int(bool(saved) and bool(failed)),
            "fully_unusable_response": int(bool(failed) and not saved),
            "primary_category": broad_category(tags) if tags else "",
            "tags": json.dumps(tags),
            **PROVENANCE,
        }
        request_rows.append(row)
        if disposition:
            failure_rows.append(
                {
                    **row,
                    "affected_pillars": json.dumps(failed),
                    "reason_sha256": hashlib.sha256(disposition["reason"].encode()).hexdigest(),
                }
            )
            details = disposition.get("pillar_failures", {})
            for pillar in failed:
                detail = details.get(pillar)
                if isinstance(detail, dict):
                    detail = detail["reason"]
                if detail is not None and not isinstance(detail, str):
                    raise ValueError("Unexpected per-pillar reason type")
                reason = detail if detail is not None else disposition["reason"]
                ct = reason_tags(reason)
                cell = {
                    **meta,
                    "pillar": pillar,
                    "primary_category": broad_category(ct),
                    "tags": json.dumps(ct),
                    "reason_attribution": "pillar_explicit" if detail else "request_inherited",
                    "reason_sha256": hashlib.sha256(reason.encode()).hexdigest(),
                    **PROVENANCE,
                }
                failure_cells.append(cell)
                failure_lookup[qid, pillar] = cell
    qindex = {
        (q["run_id"], q["study"], q["rater"], q["round"], q["kind"], q["replicate"]): q
        for q in requests.values()
    }
    carries = {}
    for e in ledger["events"]:
        if e["kind"] == "carry":
            x = e["payload"]
            key = (e["run_id"], x["study"], x["rater"], x["round"], x["pillar"])
            if key in carries:
                raise ValueError("Duplicate carry")
            carries[key] = x
    cell_rows = []
    for rid, m in runs.items():
        for paper in m["papers"]:
            study = paper["study_id"]
            frames = {(0, "rating", 0)}
            frames.update(
                (q["round"], q["kind"], q["replicate"])
                for q in requests.values()
                if q["run_id"] == rid and q["study"] == study
            )
            for n, kind, replicate in sorted(frames):
                for rater in RATERS:
                    q = qindex.get((rid, study, rater, n, kind, replicate))
                    # Fresh-check denominators are scheduled target judgments, not full three-rater panels.
                    if kind != "rating" and q is None:
                        continue
                    pillars = (
                        q["context"].get("check_targets", q["context"]["pending"])
                        if kind != "rating"
                        else PILLARS
                    )
                    for pillar in pillars:
                        carry = carries.get((rid, study, rater, n, pillar)) if kind == "rating" else None
                        saved = judgments.get((q["id"], pillar)) if q else None
                        if saved and carry:
                            raise ValueError("Carry conflicts with actual response")
                        failure = failure_lookup.get((q["id"], pillar)) if q else None
                        value = saved or (carry["cell"] if carry else None)
                        status = (
                            value["status"] if value else "validation_failure" if failure else "not_returned"
                        )
                        if status == "scored" and (
                            type(value["score"]) is not int or value["score"] not in range(4)
                        ):
                            raise ValueError("Invalid preserved scored value")
                        cell_rows.append(
                            {
                                "run_id": rid,
                                "cohort": group.get(rid, "other_recorded_run"),
                                "population": m["population"],
                                "condition_original": m["condition"],
                                "condition": LABELS.get(m["condition"], m["condition"]),
                                "execution": m["execution"],
                                "study": study,
                                "rater": rater,
                                "model": m["models"][rater]["model"],
                                "pillar": pillar,
                                "round": n,
                                "kind": kind,
                                "replicate": replicate,
                                "status": status,
                                "score": value["score"] if value else None,
                                "carried": int(bool(carry)),
                                "request_id": q["id"] if q and not carry else "",
                                "source_request_id": carry["source_request_id"]
                                if carry
                                else q["id"]
                                if q
                                else "",
                                "dispatched": int(
                                    bool(
                                        q
                                        and not carry
                                        and pillar in q["context"]["pending"]
                                        and attempts[q["id"]]
                                    )
                                ),
                                "tags": failure["tags"] if failure else "[]",
                                "reason_attribution": failure["reason_attribution"] if failure else "",
                                **PROVENANCE,
                            }
                        )
    return {
        "requests": request_rows,
        "failures": failure_rows,
        "failed_judgments": failure_cells,
        "cells": cell_rows,
    }


def panel_rows(cells: list[dict]) -> tuple[list[dict], list[dict]]:
    """All-three and pairwise denominators remain requested panel instances; never fill a missing score."""
    groups = defaultdict(dict)
    for row in cells:
        if row["kind"] != "rating":
            continue
        key = (row["run_id"], row["study"], row["pillar"], row["round"])
        if row["rater"] in groups[key]:
            raise ValueError("Duplicate panel member")
        groups[key][row["rater"]] = row
    panels, pairs = [], []
    for rows in groups.values():
        if set(rows) != set(RATERS):
            raise ValueError("Panel lacks requested-rater denominator")
        first = rows["r1"]
        meta = {
            k: first[k]
            for k in (
                "run_id",
                "cohort",
                "population",
                "condition",
                "condition_original",
                "execution",
                "study",
                "pillar",
                "round",
            )
        }
        complete = all(r["status"] == "scored" for r in rows.values())
        invalid = [r for r in rows.values() if r["status"] != "scored"]
        evidence = any(
            set(json.loads(r["tags"])) & {"quote_unlocatable", "quote_wrong_page"} for r in invalid
        )
        categories = sorted(
            {t for r in invalid for t in json.loads(r["tags"])}
            | {r["status"] for r in invalid if r["status"] != "validation_failure"}
        )
        panels.append(
            {
                **meta,
                "complete_numeric": int(complete),
                "agrees": int(complete and len({r["score"] for r in rows.values()}) == 1),
                "evidence_affected": int(evidence),
                "blocking_categories": json.dumps(categories),
                "has_carried": int(any(r["carried"] for r in rows.values())),
                **PROVENANCE,
            }
        )
        for a, b in combinations(RATERS, 2):
            valid = rows[a]["status"] == rows[b]["status"] == "scored"
            pairs.append(
                {
                    **meta,
                    "pair": a + "|" + b,
                    "both_numeric": int(valid),
                    "agrees": int(valid and rows[a]["score"] == rows[b]["score"]),
                    **PROVENANCE,
                }
            )
    return panels, pairs


def aggregate(rows: list[dict], dimensions: tuple[str, ...], measures: tuple[str, ...]) -> list[dict]:
    """Aggregate only explicit rows and preserve grouping dimensions for dependent populations."""
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[k] for k in dimensions)].append(row)
    result = []
    for key, values in sorted(groups.items(), key=lambda x: str(x[0])):
        out = dict(zip(dimensions, key, strict=True))
        out["denominator"] = len(values)
        for name in measures:
            out[name] = sum(int(r[name]) for r in values)
            out[name + "_rate"] = ratio(out[name], len(values))
        result.append({**out, **PROVENANCE})
    return result


def snapshot_csv(directory: Path, name: str, rows: list[dict]) -> dict:
    """Never overwrite differing existing data; source-linked analyses get content-addressed filenames."""
    if not rows:
        raise ValueError("Refuse an empty undefined-schema export")
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    content = buffer.getvalue().encode()
    digest = hashlib.sha256(content).hexdigest()
    path = directory / f"{name}-{digest[:16]}.csv"
    directory.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != content:
        raise ValueError("Content-address collision")
    if not path.exists():
        path.write_bytes(content)
    return {"path": str(path), "sha256": digest, "rows": len(rows)}
