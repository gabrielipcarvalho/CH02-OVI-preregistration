"""Create/status/run/resume/export frozen study executions; genuine calls require acceptance evidence."""

from __future__ import annotations

import argparse
import copy
import json
import os
import shutil
import sqlite3
from pathlib import Path

from pipeline.calibration import sources
from pipeline.study.records import PILLARS, RATERS, Records, StudyError, canonical, digest
from pipeline.study.scoring import build_prompt, freeze_run, implementation_provenance, payload_for
from pipeline.study.transport import Dispatcher

ROOT = Path(__file__).resolve().parents[2]
PRIVATE = ROOT / ".research-private/programme-v1"
DOCS = ROOT / "docs/study-2026-09-28"


def programme() -> Records:
    """One production ledger, with verified prior D0 attempts imported exactly once."""
    os.umask(0o077)
    store = Records(PRIVATE / "programme.sqlite3")
    store.programme({"cap_usd": 100, "final_reserve_usd": 25, "smoke_cap_usd": 3})
    prior = ROOT / ".research-private/backups/smoke-2026-09-28/smoke.sqlite3"
    proof = json.loads((DOCS / "SMOKE_CALL_MANIFEST.json").read_text())
    if not prior.is_file() or digest(prior.read_bytes()) != proof["database_sha256"]:
        raise StudyError("Missing/changed preparation spend evidence; never reset prior charges")
    with sqlite3.connect(f"{prior.as_uri()}?mode=ro", uri=True) as db:
        rows = db.execute("SELECT id,reserved,payload FROM calls ORDER BY created").fetchall()
    for identity, amount, value in rows:
        store.import_spend(
            "preparation:" + identity,
            amount,
            "synthetic_fixture",
            {"source_sha256": proof["database_sha256"], "call_sha256": digest(value)},
        )
    return store


def specification_hashes() -> dict:
    """Bind admission to accepted scientific inputs/settings as well as implementation code."""
    names = [
        "docs/study-2026-09-28/experiment-matrix.json",
        "docs/study-2026-09-28/INPUT_MANIFEST.json",
        "docs/study-2026-09-28/PROTOCOL.md",
        "docs/study-2026-09-28/METRICS.md",
        "docs/study-2026-09-28/judgment.schema.json",
        "rubric/rubric.yaml",
        "calibration/protocol-ai-only-v1.md",
    ]
    return {name: digest((ROOT / name).read_bytes()) for name in names}


def evaluation_freeze() -> dict:
    """Select a hash-bound versioned recovery freeze without modifying the original freeze."""
    activation = PRIVATE / "EVALUATION_ACTIVATION.json"
    path = PRIVATE / "FINAL_FREEZE.json"
    if activation.exists():
        value = json.loads(activation.read_text())
        path = (PRIVATE / value["freeze_path"]).resolve()
        if (
            value.get("accepted") is not True
            or not path.is_relative_to(PRIVATE.resolve())
            or not path.is_file()
            or digest(path.read_bytes()) != value["freeze_sha256"]
        ):
            raise StudyError("Versioned evaluation activation invalid or drifted")
    if not path.is_file():
        raise StudyError("GAB-56 final freeze absent; evaluation refused")
    return json.loads(path.read_text())


def check_admission(population: str) -> None:
    """No genuine request before full workflow acceptance; no evaluation before a final freeze."""
    if population == "synthetic_fixture":
        return
    receipt = PRIVATE / "ACCEPTANCE_RECEIPT.json"
    if not receipt.exists():
        raise StudyError("GAB-70 acceptance receipt absent; genuine collection refused")
    value = json.loads(receipt.read_text())
    if value.get("all_required_passed") is not True:
        raise StudyError("GAB-70 required checks have not passed")
    if value.get("specification_hashes") != specification_hashes():
        raise StudyError("Scientific settings or inputs changed since acceptance")
    if value["code_files"] != implementation_provenance()["files"]:
        raise StudyError("Implementation changed since acceptance; retest before collection")
    if population == "final_evaluation":
        freeze = evaluation_freeze()
        if freeze.get("accepted") is not True or freeze["code_files"] != value["code_files"]:
            raise StudyError("Final evaluation freeze invalid or drifted")


def create(population: str, condition: str, execution: int) -> str:
    """Create concrete manifests from accepted splits/settings; never dispatch a candidate template."""
    check_admission(population)
    matrix = json.loads((DOCS / "experiment-matrix.json").read_text())
    manifest = json.loads((DOCS / "INPUT_MANIFEST.json").read_text())
    models = copy.deepcopy(matrix["models"])
    if population == "synthetic_fixture":
        if condition != "D0":
            raise StudyError("Synthetic live fixture must be D0")
        packet = PRIVATE / "fixtures/D0"
        if not packet.exists():
            packet.mkdir(parents=True)
            shutil.copyfile(ROOT / "calibration/fixtures/D0.pdf", packet / "paper.pdf")
            (packet / "paper.txt").write_text(sources.paper_text(0))
            shutil.copyfile(ROOT / "rubric/rubric.yaml", packet / "rubric.yaml")
            shutil.copyfile(ROOT / "calibration/protocol-ai-only-v1.md", packet / "protocol.md")
        paths = {0: packet}
        expected = None
    elif population == "development":
        conditions = {c["id"]: c for c in matrix["conditions"]}
        if condition not in conditions:
            raise StudyError("Unaccepted/placeholder condition refused")
        selected = conditions[condition]
        if selected["instrument"] != "v1":
            raise StudyError("No accepted candidate instrument")
        ids = selected["papers"]
        if not set(ids) <= set(manifest["development"]):
            raise StudyError("Reserved paper in development")
        rows = {r["study_id"]: r for r in manifest["papers"]}
        paths = {i: ROOT / rows[i]["packet"] for i in ids}
        expected = {i: rows[i]["files"] for i in ids}
        for r, settings in selected.get("settings_override", {}).items():
            models[r]["generation"] = settings
    else:
        # The final freeze owns extracted evaluation inputs; no opportunistic replacement is allowed.
        freeze = evaluation_freeze()
        if condition not in ("E1", "E2", "E3"):
            raise StudyError("Unknown fixed evaluation batch")
        ids = manifest["evaluation_batches"][int(condition[1]) - 1]
        paths = {i: ROOT / freeze["papers"][str(i)]["packet"] for i in ids}
        expected = {i: freeze["papers"][str(i)]["files"] for i in ids}
    schema = json.loads((DOCS / "judgment.schema.json").read_text())
    return freeze_run(
        programme(),
        population=population,
        condition=condition,
        execution=execution,
        packet_paths=paths,
        models=models,
        limits=matrix["request_limits"],
        seed=manifest["seed"],
        schema=schema,
        code=implementation_provenance(),
        expected_hashes=expected,
    )


def initial_round(store: Records, run_id: str, dispatcher: Dispatcher) -> dict:
    """Lock/disposition every initial request; never release other ratings during R0."""
    manifest = store.manifest(run_id)
    check_admission(manifest["population"])
    results = []
    for paper in manifest["papers"]:
        sid = paper["study_id"]
        for rater in RATERS:
            prompt, context = build_prompt(store, run_id, sid, list(PILLARS))
            payload = payload_for(manifest["models"][rater], prompt)
            q = store.request(run_id, sid, rater, 0, "rating", 0, payload, context)
            result = dispatcher.execute(q)
            results.append({"study": sid, "rater": rater, "status": result["status"]})
            print(
                canonical({"run_id": run_id, "round": 0, **results[-1], "usage": store.usage()}), flush=True
            )
    return {"round": 0, "requests": results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    create_cmd = sub.add_parser("create")
    create_cmd.add_argument(
        "--population", choices=["synthetic_fixture", "development", "final_evaluation"], required=True
    )
    create_cmd.add_argument("--condition", required=True)
    create_cmd.add_argument("--execution", type=int, choices=[1, 2, 3], required=True)
    for name in ("status", "run", "resume", "export", "report"):
        command = sub.add_parser(name)
        command.add_argument("run_id", nargs="?" if name == "status" else None)
        if name in ("run", "resume"):
            command.add_argument(
                "--initial-only", action="store_true", help="Collect/disposition R0; no peer release"
            )
    args = parser.parse_args()
    if args.command == "create":
        print(create(args.population, args.condition, args.execution))
        return
    store = programme()
    if args.command == "status":
        if args.run_id:
            export = store.export(args.run_id)
            print(
                canonical(
                    {
                        "run_id": args.run_id,
                        "manifest": export["manifest"],
                        "judgments": len(export["judgments"]),
                        "dispositions": export["dispositions"],
                        "events": export["events"],
                        "usage": store.usage(),
                    }
                )
            )
        else:
            with store.db() as db:
                runs = [dict(r) for r in db.execute("SELECT id,created FROM runs ORDER BY created")]
            print(canonical({"runs": runs, "usage": store.usage()}))
    elif args.command == "report":
        from pipeline.study.reports import html_report, report_run

        m = store.manifest(args.run_id)
        csv_dir = PRIVATE / "reports/data" if m["population"] == "synthetic_fixture" else ROOT / "data"
        report, sources = report_run(store, args.run_id, csv_dir)
        target = PRIVATE / "reports" / args.run_id
        target.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
        identity = digest(serialized)[:16]
        (target / f"report-{identity}.json").write_text(serialized)
        (target / f"report-{identity}.html").write_text(html_report(report))
        print(target / f"report-{identity}.html")
    elif args.command == "export":
        output = store.export(args.run_id)
        target = PRIVATE / "exports" / args.run_id
        target.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps(output, indent=2, ensure_ascii=False) + "\n"
        (target / f"records-{digest(serialized)}.json").write_text(serialized)
        print(target)
    else:
        check_admission(store.manifest(args.run_id)["population"])
        # Full bounded round orchestration is integrated in GAB-66/67; a missing module is a hard stop.
        if args.initial_only:
            print(canonical(initial_round(store, args.run_id, Dispatcher(store))))
        else:
            from pipeline.study.workflow import execute_run

            print(canonical(execute_run(store, args.run_id, Dispatcher(store))))


if __name__ == "__main__":
    main()
