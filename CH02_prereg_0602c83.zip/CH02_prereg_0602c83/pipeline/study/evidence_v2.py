"""Opt-in conservative quote localisation; never establish semantic validity or rescore history."""
from __future__ import annotations

import re
import unicodedata

from pipeline.study.records import StudyError

VERSION = "physical-anchor-v2"
INSTRUCTION = """Evidence localisation v2: use one contiguous exact quotation from one physical PDF page.
Start locator with 'PDF page N'. Put optional non-evidentiary page context after '; context:'.
Label printed/journal pagination separately. Do not splice quotations with ellipses.
Source location is not proof of criterion satisfaction. Preserve applicability nulls."""


def normalise(text: str) -> str:
    """Fold typography and whitespace only; retain signs, decimal points and punctuation."""
    text = unicodedata.normalize("NFKC", text).casefold()
    text = text.translate(str.maketrans({"\u2010": "-", "\u2011": "-", "\u2212": "-"}))
    return " ".join(text.split())


def variants(text: str) -> tuple[str, ...]:
    """Only source line-end alphabetic hyphens admit joined and retained-hyphen readings."""
    pattern = r"(?<=[^\W\d_])[-\u00ad]\s*\n\s*(?=[^\W\d_])"
    return tuple(dict.fromkeys(normalise(re.sub(pattern, v, text)) for v in ("-", "")))


def contains(needle: str, source: str) -> bool:
    """Reject substring matches inside words, signed quantities, decimals and percentages."""
    for match in re.finditer(re.escape(needle), source):
        before = source[match.start()-1:match.start()] if match.start() else ""
        after = source[match.end():match.end()+1]
        if before and (before.isalnum() or before == "_") and needle[0].isalnum():
            continue
        if after and (after.isalnum() or after == "_") and needle[-1].isalnum():
            continue
        if needle[0].isdigit() and before and before in "+-.$€£":
            continue
        if needle[-1].isdigit() and after and after in ".%":
            continue
        return True
    return False


def pages(text: str) -> dict[int, str]:
    """Reject ambiguous duplicate physical-page boundaries rather than overwrite them."""
    parts = re.split(r"\[PDF PAGE (\d+)\]", text)
    ids = [int(parts[i]) for i in range(1, len(parts), 2)]
    if not ids or len(ids) != len(set(ids)) or any(n < 1 for n in ids):
        raise StudyError("Invalid physical page boundaries")
    return {int(parts[i]): parts[i + 1] for i in range(1, len(parts), 2)}


def evidence_check_v2(cell: dict, text: str, reading_order: str | None = None,
                      content_order: str | None = None) -> dict:
    """Require an explicit physical anchor and contiguous punctuation-preserving match."""
    base = {"validator_version": VERSION, "semantic_validity": False}
    quote = cell["quote"]
    if quote == "NO_DOCUMENTED_EVIDENCE":
        return {**base, "status": "absence_not_verified"}
    if not quote.strip():
        if cell["status"] == "scored":
            raise StudyError("Scored evidence is empty")
        return {**base, "status": "not_assessable"}
    anchor, _, context = cell["locator"].partition("; context:")
    match = re.match(r"^PDF page ([1-9][0-9]*)(?=$|[ ,;.(])", anchor)
    remainder = anchor[match.end():] if match else ""
    remainder = re.sub(r"\b(?:printed|journal|publication) page [0-9]+", "", remainder, flags=re.I)
    if not match or re.search(r"\b(?:PDF\s+)?(?:page|p\.)\s*\d+", remainder, re.I):
        raise StudyError("Quotation requires one unambiguous physical PDF page anchor")
    page = int(match.group(1))
    needle = normalise(quote)
    sources = [("common_layout", text), ("frozen_pdf_reading_order", reading_order)]
    for method, source in sources:
        if source is None:
            continue
        source_pages = pages(source)
        if page in source_pages and any(contains(needle, value) for value in variants(source_pages[page])):
            return {**base, "status": "text_match", "method": method, "pages": [page],
                    "locator_page_verified": True, "context_unverified": context}
    # Raw extraction can place invisible/adjacent-page text on the wrong page; diagnostic only.
    raw_match = False
    if content_order is not None:
        raw_pages = pages(content_order)
        raw_match = page in raw_pages and any(contains(needle, v) for v in variants(raw_pages[page]))
    if raw_match:
        raise StudyError("Quote not locatable on claimed PDF page except raw extraction; review required")
    raise StudyError("Quote not locatable on the claimed PDF page under v2; original preserved")
