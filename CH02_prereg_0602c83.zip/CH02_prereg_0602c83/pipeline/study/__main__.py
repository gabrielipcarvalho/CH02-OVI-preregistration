"""Command entry point for the isolated, versioned research runner."""

from pipeline.study.cli import main

main()
