"""Append-only programme records; changed inputs always create a different frozen run."""

from __future__ import annotations

import base64
import hashlib
import json
import math
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

POPULATIONS = {"synthetic_fixture", "development", "final_evaluation"}
RATERS = ("r1", "r2", "r3")
PILLARS = ("P1", "P2", "P3", "P4")
PACKET_FILES = {"paper.pdf", "paper.txt", "rubric.yaml", "protocol.md"}


class StudyError(ValueError):
    """Refuse an invalid research transition before changing scientific records."""


class BudgetStop(StudyError):
    """The next reserved attempt cannot fit the accepted shared envelope."""


def stamp() -> str:
    return datetime.now(UTC).isoformat()


def canonical(value) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(value: bytes | str) -> str:
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def frozen_packet(path: Path, *, allow_unusable: bool = False) -> tuple[dict, dict]:
    """Reject symlinks/extra metadata and preserve exact allowed file bytes as content-addressed assets."""
    if path.is_symlink() or {p.name for p in path.iterdir()} != PACKET_FILES:
        raise StudyError("Packet is not exactly PDF, extracted text, rubric and protocol")
    assets, refs = {}, {}
    for name in sorted(PACKET_FILES):
        p = path / name
        if p.is_symlink() or not p.is_file():
            raise StudyError("Packet contains a non-regular file")
        data = p.read_bytes()
        if name == "paper.pdf" and not data.startswith(b"%PDF-"):
            raise StudyError("Packet PDF magic invalid")
        if name != "paper.pdf":
            data.decode("utf-8")
        refs[name] = digest(data)
        assets[refs[name]] = data
    text = assets[refs["paper.txt"]].decode()
    if not allow_unusable and (len(text.strip()) < 200 or "[PDF PAGE 1]" not in text):
        raise StudyError("Unusable page-aware text; never convert access failure to zero")
    return refs, assets


class Records:
    """One shared ledger owns all prospective calls and immutable records across runs."""

    def __init__(self, path: Path, *, upgrade_backup: Path | None = None):
        self.path = Path(path).resolve()
        from pipeline.config import SLR_ROOT

        if self.path.is_relative_to(SLR_ROOT.resolve()):
            raise StudyError("Research store must be outside the read-only SLR tree")
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self.path.exists():
            with sqlite3.connect(f"{self.path.as_uri()}?mode=ro", uri=True) as existing:
                names = {r[0] for r in existing.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                populated_legacy = (
                    "attempts" in names
                    and "charge_reconciliations" not in names
                    and existing.execute("SELECT count(*) FROM attempts").fetchone()[0] > 0
                )
            if populated_legacy and (
                upgrade_backup is None
                or Path(upgrade_backup).resolve() == self.path
                or not Path(upgrade_backup).is_file()
                or self.logical_fingerprint(self.path) != self.logical_fingerprint(Path(upgrade_backup))
            ):
                raise StudyError(
                    "Populated legacy store requires a verified consistent restore before migration"
                )
        with self.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS programme(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS imports(id TEXT PRIMARY KEY, amount REAL NOT NULL,
                    population TEXT NOT NULL, evidence TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS assets(hash TEXT PRIMARY KEY, payload BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, manifest TEXT NOT NULL,
                    created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL REFERENCES runs(id),
                    study INTEGER NOT NULL, rater TEXT NOT NULL, round INTEGER NOT NULL, kind TEXT NOT NULL,
                    replicate INTEGER NOT NULL, payload TEXT NOT NULL, context TEXT NOT NULL,
                    created TEXT NOT NULL,
                    UNIQUE(run_id,study,rater,round,kind,replicate));
                CREATE TABLE IF NOT EXISTS attempts(id TEXT PRIMARY KEY,
                    request_id TEXT NOT NULL REFERENCES requests(id), stage INTEGER NOT NULL,
                    transport INTEGER NOT NULL, reserved REAL NOT NULL, payload TEXT NOT NULL,
                    created TEXT NOT NULL,
                    UNIQUE(request_id,stage,transport));
                CREATE TABLE IF NOT EXISTS completions(attempt_id TEXT PRIMARY KEY REFERENCES attempts(id),
                    charged REAL NOT NULL, result TEXT NOT NULL, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS charge_reconciliations(
                    sequence INTEGER PRIMARY KEY, identity TEXT NOT NULL UNIQUE,
                    attempt_id TEXT NOT NULL REFERENCES attempts(id), prior_amount REAL NOT NULL,
                    amount REAL NOT NULL, evidence_hash TEXT NOT NULL REFERENCES assets(hash),
                    basis TEXT NOT NULL, source_reference TEXT NOT NULL,
                    verifier TEXT NOT NULL, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS judgments(request_id TEXT REFERENCES requests(id),
                    pillar TEXT NOT NULL,
                    payload TEXT NOT NULL, provenance TEXT NOT NULL, PRIMARY KEY(request_id,pillar));
                CREATE TABLE IF NOT EXISTS dispositions(request_id TEXT PRIMARY KEY REFERENCES requests(id),
                    payload TEXT NOT NULL, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS packets(run_id TEXT REFERENCES runs(id), study INTEGER NOT NULL,
                    round INTEGER NOT NULL, rater TEXT NOT NULL, payload TEXT NOT NULL,
                    created TEXT NOT NULL,
                    PRIMARY KEY(run_id,study,round,rater));
                CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, run_id TEXT REFERENCES runs(id),
                    kind TEXT NOT NULL, payload TEXT NOT NULL, created TEXT NOT NULL);
            """)
            for table in (
                "programme",
                "imports",
                "assets",
                "runs",
                "requests",
                "attempts",
                "completions",
                "charge_reconciliations",
                "judgments",
                "dispositions",
                "packets",
                "events",
            ):
                for operation in ("UPDATE", "DELETE"):
                    db.execute(f"""CREATE TRIGGER IF NOT EXISTS immutable_{table}_{operation}
                        BEFORE {operation} ON {table}
                        BEGIN SELECT RAISE(ABORT,'Research records immutable'); END""")
        self.path.chmod(0o600)

    @staticmethod
    def logical_fingerprint(path: Path, *, original_records_only: bool = False) -> str:
        """Verify SQLite integrity and every original schema/row without exposing source content."""
        rows = []
        with sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro", uri=True) as db:
            if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise StudyError("Backup restore integrity failed")
            schema = db.execute(
                "SELECT type,name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name"
            ).fetchall()
            if original_records_only:
                schema = [
                    r
                    for r in schema
                    if r[1] != "charge_reconciliations"
                    and not r[1].startswith("immutable_charge_reconciliations_")
                ]
            rows.append(schema)
            for kind, name, _ in schema:
                if kind != "table":
                    continue
                quoted = '"' + name.replace('"', '""') + '"'
                for row in db.execute("SELECT * FROM " + quoted + " ORDER BY rowid"):
                    rows.append([{"blob_sha256": digest(v)} if isinstance(v, bytes) else v for v in row])
        return digest(canonical(rows))

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA foreign_keys=ON")
            with db:
                yield db
        finally:
            db.close()

    def programme(self, config: dict | None = None) -> dict:
        """Freeze budget settings once; reject a reset or conflicting ceiling."""
        if config is not None:
            if config["cap_usd"] != 100 or config["final_reserve_usd"] != 25 or config["smoke_cap_usd"] != 3:
                raise StudyError("Unapproved programme envelope")
            value = canonical(config)
            with self.db() as db:
                db.execute("INSERT OR IGNORE INTO programme VALUES(?,?)", ("ch2-v1", value))
                actual = db.execute("SELECT payload FROM programme WHERE id=?", ("ch2-v1",)).fetchone()[0]
                if actual != value:
                    raise StudyError("Cannot reset or change the shared programme ledger")
        with self.db() as db:
            row = db.execute("SELECT payload FROM programme WHERE id=?", ("ch2-v1",)).fetchone()
        if row is None:
            raise StudyError("Programme ledger is not initialised")
        return json.loads(row[0])

    def import_spend(self, identity: str, amount: float, population: str, evidence: dict) -> None:
        """Import verified preparation attempts exactly once, never silently waive prior costs."""
        if amount < 0 or population not in POPULATIONS:
            raise StudyError("Invalid historical prospective charge")
        value = canonical(evidence)
        with self.db() as db:
            db.execute("INSERT OR IGNORE INTO imports VALUES(?,?,?,?)", (identity, amount, population, value))
            row = db.execute("SELECT * FROM imports WHERE id=?", (identity,)).fetchone()
            if (row["amount"], row["population"], row["evidence"]) != (amount, population, value):
                raise StudyError("Conflicting historical-spend import")

    def usage(self, db=None) -> dict:
        """Unknown attempts retain reservations; complete attempts use documented charges."""
        if db is None:
            with self.db() as connection:
                return self.usage(connection)
        charges = db.execute("""SELECT json_extract(r.manifest,'$.population') population,
            coalesce((SELECT z.amount FROM charge_reconciliations z
                WHERE z.attempt_id=a.id ORDER BY z.sequence DESC LIMIT 1),c.charged,a.reserved) amount
            FROM attempts a
            JOIN requests q ON q.id=a.request_id JOIN runs r ON r.id=q.run_id
            LEFT JOIN completions c ON c.attempt_id=a.id
            UNION ALL SELECT population,amount FROM imports""").fetchall()
        totals = {p: sum(row["amount"] for row in charges if row["population"] == p) for p in POPULATIONS}
        return {
            "provenance": "agent:gpt-6",
            "by_population": totals,
            "spent_or_reserved_usd": sum(totals.values()),
            "attempts": db.execute("SELECT count(*) FROM attempts").fetchone()[0],
        }

    def create_run(self, manifest: dict, assets: dict[str, bytes]) -> str:
        """Freeze complete input provenance; IDs bind population, papers and all configurations."""
        required = {
            "population",
            "condition",
            "execution",
            "papers",
            "models",
            "versions",
            "code",
            "seed",
            "limits",
        }
        if not required <= set(manifest) or manifest["population"] not in POPULATIONS:
            raise StudyError("Incomplete run manifest or invalid population")
        ids = [p["study_id"] for p in manifest["papers"]]
        if not ids or len(ids) != len(set(ids)) or set(manifest["models"]) != set(RATERS):
            raise StudyError("Duplicate/missing paper IDs or model slots")
        if manifest["population"] != "synthetic_fixture" and (not self.paper_count_ok(manifest) or 0 in ids):
            raise StudyError("Genuine executions require the declared real-paper set, never D0")
        if manifest["population"] == "synthetic_fixture" and any(i != 0 for i in ids):
            raise StudyError("Synthetic live smoke uses D0 only")
        if type(manifest["execution"]) is not int or manifest["execution"] not in (1, 2, 3):
            raise StudyError("Independent execution must be 1, 2 or 3")
        for paper in manifest["papers"]:
            if set(paper["files"]) != PACKET_FILES:
                raise StudyError("Run input allowlist mismatch")
            for ref in paper["files"].values():
                if ref not in assets or digest(assets[ref]) != ref:
                    raise StudyError("Frozen asset hash mismatch")
        for ref, data in assets.items():
            if digest(data) != ref:
                raise StudyError("Asset hash mismatch")
        value = canonical(manifest)
        run_id = "run-" + digest(value)[:32]
        with self.db() as db:
            for ref, data in assets.items():
                db.execute("INSERT OR IGNORE INTO assets VALUES(?,?)", (ref, data))
                if bytes(db.execute("SELECT payload FROM assets WHERE hash=?", (ref,)).fetchone()[0]) != data:
                    raise StudyError("Content-addressed asset collision")
            db.execute("INSERT OR IGNORE INTO runs VALUES(?,?,?)", (run_id, value, stamp()))
        return run_id

    def paper_count_ok(self, manifest: dict) -> bool:
        """Historical design: five real papers per genuine execution; later phases declare their own."""
        return len(manifest["papers"]) == 5

    def manifest(self, run_id: str) -> dict:
        with self.db() as db:
            row = db.execute("SELECT manifest FROM runs WHERE id=?", (run_id,)).fetchone()
        if row is None:
            raise StudyError("Unknown frozen run")
        return json.loads(row[0])

    def asset(self, ref: str) -> bytes:
        with self.db() as db:
            row = db.execute("SELECT payload FROM assets WHERE hash=?", (ref,)).fetchone()
        if row is None or digest(bytes(row[0])) != ref:
            raise StudyError("Missing or corrupted frozen asset")
        return bytes(row[0])

    def request(
        self,
        run_id: str,
        study: int,
        rater: str,
        round_n: int,
        kind: str,
        replicate: int,
        payload: dict,
        context: dict,
    ) -> str:
        """Idempotent request identity; reject changed context and invalid check identities."""
        manifest = self.manifest(run_id)
        if study not in [p["study_id"] for p in manifest["papers"]] or rater not in RATERS:
            raise StudyError("Request outside frozen run")
        if type(round_n) is not int or round_n not in range(5):
            raise StudyError("Invalid round")
        if kind not in ("rating", "check") or replicate not in ((0,) if kind == "rating" else (1, 2)):
            raise StudyError("Invalid request kind/check replicate")
        if kind == "check" and not round_n:
            raise StudyError("Fresh checks require a revision")
        identity = digest(canonical([run_id, study, rater, round_n, kind, replicate]))
        value, ctx = canonical(payload), canonical(context)
        with self.db() as db:
            db.execute(
                "INSERT OR IGNORE INTO requests VALUES(?,?,?,?,?,?,?,?,?,?)",
                (identity, run_id, study, rater, round_n, kind, replicate, value, ctx, stamp()),
            )
            actual = db.execute("SELECT payload,context FROM requests WHERE id=?", (identity,)).fetchone()
            if tuple(actual) != (value, ctx):
                raise StudyError("Frozen request changed on resume")
        return identity

    def additional_budget_guard(self, db, request_id: str, amount: float) -> None:
        """Extension hook runs inside the shared reservation transaction; legacy policy is unchanged."""

    def reserve(self, request_id: str, stage: int, transport: int, amount: float, payload: dict) -> str:
        """Reserve atomically across all runs/providers before any network dispatch."""
        if stage not in (0, 1) or transport not in (0, 1, 2) or not amount > 0:
            raise StudyError("Invalid attempt/charge")
        config = self.programme()
        identity = digest(canonical([request_id, stage, transport]))
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM attempts WHERE id=?", (identity,)).fetchone():
                raise StudyError("Attempt already recorded; never redispatch an unknown/completed attempt")
            row = db.execute("SELECT run_id FROM requests WHERE id=?", (request_id,)).fetchone()
            if row is None:
                raise StudyError("Unknown request")
            population = json.loads(
                db.execute("SELECT manifest FROM runs WHERE id=?", tuple(row)).fetchone()[0]
            )["population"]
            usage = self.usage(db)
            new = usage["spent_or_reserved_usd"] + amount
            nonfinal = usage["by_population"]["development"] + usage["by_population"]["synthetic_fixture"]
            if new > config["cap_usd"] or (
                population != "final_evaluation"
                and nonfinal + amount > config["cap_usd"] - config["final_reserve_usd"]
            ):
                raise BudgetStop("Shared programme/final-reserve budget stop")
            if (
                population == "synthetic_fixture"
                and usage["by_population"][population] + amount > config["smoke_cap_usd"]
            ):
                raise BudgetStop("Cumulative D0 allowance exhausted")
            self.additional_budget_guard(db, request_id, amount)
            db.execute(
                "INSERT INTO attempts VALUES(?,?,?,?,?,?,?)",
                (identity, request_id, stage, transport, amount, canonical(payload), stamp()),
            )
        return identity

    def complete(self, attempt_id: str, charged: float, result: dict) -> None:
        """Append one completion; do not overwrite requests, reservations or prior failures."""
        if charged < 0:
            raise StudyError("Negative charge")
        with self.db() as db:
            db.execute(
                "INSERT INTO completions VALUES(?,?,?,?)", (attempt_id, charged, canonical(result), stamp())
            )

    def reconcile_charge(
        self,
        attempt_id: str,
        amount: float,
        *,
        expected_prior: float,
        evidence: bytes,
        basis: str,
        source_reference: str,
        verifier: str,
    ) -> str:
        """Append evidenced accounting; refuse stale/double refunds without changing original records."""
        if (
            type(amount) not in (float, int)
            or not math.isfinite(amount)
            or amount < 0
            or type(expected_prior) not in (float, int)
            or not math.isfinite(expected_prior)
        ):
            raise StudyError("Invalid reconciled amount")
        if basis not in ("provider_invoice", "billing_export", "provider_policy_and_recorded_rejection"):
            raise StudyError("Unverified reconciliation basis")
        if (
            not isinstance(evidence, bytes)
            or not evidence
            or not source_reference.strip()
            or not verifier.strip()
        ):
            raise StudyError("Reconciliation requires preserved source evidence and an identified verifier")
        proof = json.loads(evidence)
        if (
            not isinstance(proof, dict)
            or type(proof.get("amount_usd")) not in (int, float)
            or proof.get("attempt_id") != attempt_id
            or proof.get("amount_usd") != amount
            or proof.get("verified") is not True
        ):
            raise StudyError("Evidence does not verify this attempt/amount")
        ref = digest(evidence)
        identity = digest(
            canonical([attempt_id, expected_prior, amount, ref, basis, source_reference, verifier])
        )
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM charge_reconciliations WHERE identity=?", (identity,)).fetchone():
                return identity
            completed = db.execute("SELECT * FROM completions WHERE attempt_id=?", (attempt_id,)).fetchone()
            if completed is None or proof.get("completion_sha256") != digest(completed["result"]):
                raise StudyError("Missing completion or evidence for a different original response")
            response = json.loads(completed["result"])
            if proof.get("provider") != response.get("provider"):
                raise StudyError("Evidence provider differs from the completed request")
            if basis == "provider_policy_and_recorded_rejection":
                status = response.get("http_status")
                if amount != 0 or type(status) is not int or not 400 <= status <= 599:
                    raise StudyError("Policy reconciliation applies only to received rejected requests")
                if not response.get("response_sha256"):
                    raise StudyError("A timeout or missing response cannot establish an uncharged rejection")
                if response.get("provider") == "anthropic":
                    if (
                        source_reference
                        != "https://support.claude.com/en/articles/8977456-how-do-i-pay-for-my-claude-api-usage"
                    ):
                        raise StudyError("Require the exact failed-request billing policy reference")
                elif response.get("provider") == "openai":
                    try:
                        body = json.loads(
                            base64.b64decode(response["observable_response_base64"], validate=True)
                        )
                    except ValueError, KeyError:
                        raise StudyError("Unknown OpenAI error body must retain its reservation") from None
                    error = body.get("error", {}) if isinstance(body, dict) else {}
                    if (
                        not isinstance(error, dict)
                        or error.get("code") != "credit_balance_exhausted"
                        or source_reference != "https://developers.openai.com/api/docs/guides/error-codes"
                    ):
                        raise StudyError("Only a preserved explicit exhausted-credit rejection qualifies")
                else:
                    raise StudyError("No accepted rejection-billing policy for this provider")
            prior = db.execute(
                "SELECT amount FROM charge_reconciliations WHERE attempt_id=? ORDER BY sequence DESC LIMIT 1",
                (attempt_id,),
            ).fetchone()
            actual = prior["amount"] if prior else completed["charged"]
            if actual != expected_prior:
                raise StudyError(
                    "Stale reconciliation: another decision already changed the effective amount"
                )
            db.execute("INSERT OR IGNORE INTO assets VALUES(?,?)", (ref, evidence))
            if bytes(db.execute("SELECT payload FROM assets WHERE hash=?", (ref,)).fetchone()[0]) != evidence:
                raise StudyError("Preserved financial evidence changed")
            db.execute(
                "INSERT INTO charge_reconciliations(identity,attempt_id,prior_amount,amount,evidence_hash,"
                "basis,source_reference,verifier,created) VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    identity,
                    attempt_id,
                    expected_prior,
                    amount,
                    ref,
                    basis,
                    source_reference,
                    verifier,
                    stamp(),
                ),
            )
        return identity

    def disposition(self, request_id: str, status: str, reason: str, *, pillars=None, details=None) -> None:
        """Persist process failures separately from any model's scientific score."""
        if status not in (
            "process_failure",
            "resource_stop",
            "model_change",
            "evidence_failure",
            "format_failure",
        ):
            raise StudyError("Unknown failure disposition")
        payload = {"status": status, "reason": reason, "score": None}
        if pillars is not None:
            if not pillars or len(set(pillars)) != len(pillars) or not set(pillars) <= set(PILLARS):
                raise StudyError("Invalid failed-pillar disposition")
            payload.update(failed_pillars=sorted(pillars), pillar_failures=details or {})
        with self.db() as db:
            db.execute(
                "INSERT INTO dispositions VALUES(?,?,?)",
                (request_id, canonical(payload), stamp()),
            )

    def event(self, run_id: str, kind: str, payload: dict) -> None:
        with self.db() as db:
            db.execute(
                "INSERT INTO events(run_id,kind,payload,created) VALUES(?,?,?,?)",
                (run_id, kind, canonical(payload), stamp()),
            )

    def export(self, run_id: str) -> dict:
        """Export exact frozen inputs/requests/attempts without a UI dependency."""
        manifest = self.manifest(run_id)
        with self.db() as db:
            queries = {
                "requests": ("SELECT * FROM requests WHERE run_id=? ORDER BY created", (run_id,)),
                "attempts": (
                    "SELECT a.* FROM attempts a JOIN requests q ON q.id=a.request_id WHERE q.run_id=? "
                    "ORDER BY a.created",
                    (run_id,),
                ),
                "completions": (
                    "SELECT c.*,coalesce((SELECT z.amount FROM charge_reconciliations z "
                    "WHERE z.attempt_id=c.attempt_id ORDER BY z.sequence DESC LIMIT 1),c.charged) "
                    "effective_charge,(SELECT z.identity FROM charge_reconciliations z "
                    "WHERE z.attempt_id=c.attempt_id ORDER BY z.sequence DESC LIMIT 1) "
                    "reconciliation_id FROM completions c JOIN attempts a ON a.id=c.attempt_id "
                    "JOIN requests q ON q.id=a.request_id WHERE q.run_id=? ORDER BY c.created",
                    (run_id,),
                ),
                "judgments": (
                    "SELECT j.*,q.study,q.rater,q.round,q.kind,q.replicate FROM judgments j "
                    "JOIN requests q ON q.id=j.request_id WHERE q.run_id=? ORDER BY q.created,j.pillar",
                    (run_id,),
                ),
                "dispositions": (
                    "SELECT d.*,q.study,q.rater,q.round,q.kind,q.replicate FROM dispositions d "
                    "JOIN requests q ON q.id=d.request_id WHERE q.run_id=?",
                    (run_id,),
                ),
                "packets": ("SELECT * FROM packets WHERE run_id=? ORDER BY study,round,rater", (run_id,)),
                "events": ("SELECT * FROM events WHERE run_id=? ORDER BY id", (run_id,)),
                "charge_reconciliations": (
                    "SELECT z.* FROM charge_reconciliations z JOIN attempts a ON a.id=z.attempt_id "
                    "JOIN requests q ON q.id=a.request_id WHERE q.run_id=? ORDER BY z.sequence",
                    (run_id,),
                ),
            }
            output = {
                name: [dict(row) for row in db.execute(sql, args)] for name, (sql, args) in queries.items()
            }
        for rows in output.values():
            for row in rows:
                for key in ("payload", "context", "result", "provenance"):
                    if key in row:
                        row[key] = json.loads(row[key])
        return {
            "provenance": "agent:gpt-6",
            "manifest": manifest,
            "run_id": run_id,
            **output,
            "usage": self.usage(),
        }
