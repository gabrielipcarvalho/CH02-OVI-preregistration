"""Frozen input projection and evidence/schema guards; no provider call or global outcome access."""

from __future__ import annotations

import copy
import importlib.metadata
import json
import re
import subprocess
import tempfile
from pathlib import Path

from jsonschema import Draft202012Validator, ValidationError

from pipeline.calibration.sources import norm
from pipeline.calibration.store import SUBSTANTIVE, PanelError, validate_cell
from pipeline.study.evidence_md import INSTRUCTION as INSTRUCTION_MD
from pipeline.study.evidence_md import VERSION as VERSION_MD
from pipeline.study.evidence_md import evidence_check_md
from pipeline.study.evidence_v2 import INSTRUCTION, VERSION, evidence_check_v2
from pipeline.study.evidence_v3 import INSTRUCTION as INSTRUCTION3
from pipeline.study.evidence_v3 import VERSION as VERSION3
from pipeline.study.evidence_v3 import evidence_check_v3, extract_blocks
from pipeline.study.records import PILLARS, Records, StudyError, canonical, digest, frozen_packet

ROOT = Path(__file__).resolve().parents[2]
PROMPT_VERSION = "ai-study-v1-format3"
FORMAT_INSTRUCTION = """Return ONLY one JSON object {"cells":[...]}.
Use exactly the requested pillar codes P1/P2/P3/P4, never full pillar names or top-level pillar maps.
Every cell has: pillar,status,score,quote,locator,reason,alternative,confidence,action,change_reason,
anonymous_defence. Every textual field is a JSON string (use "" for an empty optional field), never null.
Only score may be null, and only for unable_to_assess or applicability_uncertain.
anonymous_defence is an object with exactly quote,locator,reason,alternative strings.
Its quote and locator must be identical to the cell's original source quote and locator.
Defence reason/alternative omit numeric advocated scores, model names and self-identification.
No vote tallies.
Preserve all legitimate scientific numbers in source quotes. Do not omit or truncate requested cells.
Your source quote must be exact and its PDF page/section/table/figure locator must be specific.
NO_DOCUMENTED_EVIDENCE means documented-evidence absence with score zero.
Inaccessible decisive evidence is null.
Concise observable justifications only, no private reasoning transcript.
For a retain, preserve every preceding substantive field exactly and provide a separate change_reason."""

ADVOCATED = re.compile(
    r"\b(?:score|rating|level)\s*(?:(?:of|is|at|equals|should be|=|:)\s*)?[0-3]\b"
    r"(?!\s*(?:m\b|cm\b|mm\b|metre|meter))|\bP[1-4]\s*[=:]\s*[0-3]\b",
    re.I,
)
IDENTITY = re.compile(
    r"\b(?:gpt[- ]?6\w*|glm[- ]?5\w*|claude|openai|anthropic|z\.?ai|r[123]|rater\s*[123])\b", re.I
)
TALLY = re.compile(
    r"\bmajority\s+(?:vote|agrees|chose|decision|of\s+(?:raters|models|reviewers))\b|\b(?:two|three|both|all|2|3)\s+(?:models|raters|reviewers)\s+"
    r"(?:agree|chose|voted|scored)|\b\d\s*(?:of|/)\s*\d\s+raters",
    re.I,
)


def defence_violations(cell: dict) -> list[str]:
    """Guard presentation fields only; legitimate numbers in exact source quotes remain intact."""
    d = cell["anonymous_defence"]
    text = d["reason"] + "\n" + d["alternative"]
    return [
        label
        for label, pattern in [("advocated_score", ADVOCATED), ("identity", IDENTITY), ("tally", TALLY)]
        if pattern.search(text)
    ]


def projected_schema(schema: dict, pending: list[str]) -> dict:
    """Freeze a pending-pillar projection; duplicates, unexpected fields and boolean scores fail."""
    if not pending or len(pending) != len(set(pending)) or not set(pending) <= set(PILLARS):
        raise StudyError("Invalid pending-pillar projection")
    result = copy.deepcopy(schema)
    cells = result["properties"]["cells"]
    cells["minItems"] = cells["maxItems"] = len(pending)
    cells["items"]["properties"]["pillar"]["enum"] = list(pending)
    cells["allOf"] = [
        {"contains": {"properties": {"pillar": {"const": p}}, "required": ["pillar"]}} for p in pending
    ]
    Draft202012Validator.check_schema(result)
    return result


def source_pages(text: str) -> dict[int, str]:
    parts = re.split(r"\[PDF PAGE (\d+)\]", text)
    return {int(parts[i]): parts[i + 1] for i in range(1, len(parts) - 1, 2)}


def evidence_check(
    cell: dict, text: str, reading_order: str | None = None, content_order: str | None = None
) -> dict:
    """Require locatable quotes and truthful page claims; matching never proves criterion adequacy."""
    if cell["quote"] == "NO_DOCUMENTED_EVIDENCE":
        return {"status": "absence_not_verified", "semantic_validity": False}
    if not cell["quote"].strip():
        if cell["status"] == "scored":
            raise StudyError("Scored evidence is empty")
        return {"status": "not_assessable", "semantic_validity": False}
    needle = norm(cell["quote"])
    pages = source_pages(text)
    matches = [n for n, value in pages.items() if needle and needle in norm(value)]
    method = "common_layout"
    for alternate, candidate_method in (
        (reading_order, "frozen_pdf_reading_order"),
        (content_order, "frozen_pdf_content_order"),
    ):
        if not matches and alternate is not None:
            other = source_pages(alternate)
            matches = [n for n, value in other.items() if needle and needle in norm(value)]
            method = candidate_method
    if not matches:
        raise StudyError("Quote not locatable in frozen source; original response preserved")
    claimed = []
    for match in re.finditer(r"\b(?:PDF\s+)?(?:page|p\.)\s*(\d+)\b", cell["locator"], re.I):
        prefix = cell["locator"][: match.start()]
        if re.search(r"\b(?:printed|journal|publication)\s*$", prefix, re.I):
            continue  # These labels are not physical PDF page claims; retain them unverified.
        claimed.append(match.group(1))
    if claimed and not all(int(n) in matches for n in claimed):
        raise StudyError("Quotation does not occur on the claimed PDF page")
    return {
        "status": "text_match",
        "method": method,
        "pages": matches,
        "locator_page_verified": bool(claimed),
        "semantic_validity": False,
    }


def validate_response(
    text: str,
    schema: dict,
    pending: list[str],
    paper_text: str,
    previous: dict | None = None,
    *,
    require_defence: bool = True,
    reading_order: str | None = None,
    content_order: str | None = None,
    validator_version: str = "legacy-v1",
    physical_blocks: str | None = None,
) -> list[dict]:
    """Reject the full response atomically on schema/evidence/defence failure; never floor an error."""
    if validator_version not in ("legacy-v1", VERSION, VERSION3, VERSION_MD):
        raise StudyError("Unknown evidence validator version")
    clean = text.strip()
    if "```" in clean:
        blocks = re.findall(r"```(?:json)?\s*\n(.*?)\n```", clean, flags=re.S)
        if len(blocks) != 1 or clean.count("```") != 2:
            raise StudyError("Ambiguous JSON response blocks")
        clean = blocks[0]
    value = json.loads(clean)
    if not isinstance(value, dict):
        raise StudyError("Response must be one JSON object")
    auxiliary = {key: value.pop(key) for key in ("headline_metric", "headline_metrics") if key in value}
    Draft202012Validator(projected_schema(schema, pending)).validate(value)
    cells = value["cells"]
    result = []
    for raw in cells:
        cell = copy.deepcopy(raw)
        try:
            checked = validate_cell(cell)
        except PanelError as exc:
            raise StudyError(str(exc)) from exc
        if cell["status"] == "scored" and type(cell["score"]) is not int:
            raise StudyError("Integer scores required; boolean/float scores invalid")
        # Do not silently rewrite scientific fields while applying the legacy conservative guard.
        for field in SUBSTANTIVE:
            if checked[field] != cell[field]:
                raise StudyError("Noncanonical scientific field requires format recovery")
        if previous is None and cell["action"] != "initial":
            raise StudyError("R0 action must be initial")
        if previous is not None:
            if cell["action"] not in ("retain", "revise") or not cell["change_reason"].strip():
                raise StudyError("Revision requires retain/revise and change_reason")
            prior = previous[cell["pillar"]]
            if cell["action"] == "retain" and any(cell[k] != prior[k] for k in SUBSTANTIVE):
                # Store original reported action alongside the operational correction, never erase changes.
                cell["reported_action"] = "retain"
                cell["action"] = "revise"
        d = cell["anonymous_defence"]
        if d["quote"] != cell["quote"] or d["locator"] != cell["locator"]:
            raise StudyError("Defence must preserve the original exact quote/locator")
        flags = defence_violations(cell)
        if flags and require_defence:
            raise StudyError("Defence presentation prohibited: " + ",".join(flags))
        if auxiliary:
            cell["auxiliary_metric"] = {"raw_json": json.dumps(auxiliary), "used_for_pillar_scoring": False}
        if validator_version == VERSION3:
            if physical_blocks is None:
                raise StudyError("Missing frozen physical block extraction")
            cell["evidence_check"] = evidence_check_v3(cell, physical_blocks)
        elif validator_version == VERSION_MD:
            # The frozen md-v1 model input is itself the validation source.
            cell["evidence_check"] = evidence_check_md(cell, paper_text)
        else:
            checker = evidence_check_v2 if validator_version == VERSION else evidence_check
            cell["evidence_check"] = checker(cell, paper_text, reading_order, content_order)
        cell["defence_check"] = {
            "status": "withheld" if flags else "checked",
            "violations": flags,
            "residual_stylistic_identity_possible": True,
        }
        result.append(cell)
    return result


def validate_individual_cells(
    text: str, schema: dict, pending: list[str], paper_text: str, previous: dict | None = None, **validation
) -> tuple[list, dict]:
    """Only an unambiguous complete pillar array may preserve independently validated cells."""
    clean = text.strip()
    if "```" in clean:
        blocks = re.findall(r"```(?:json)?\s*\n(.*?)\n```", clean, flags=re.S)
        if len(blocks) != 1 or clean.count("```") != 2:
            raise StudyError("Ambiguous JSON response blocks")
        clean = blocks[0]
    value = json.loads(clean)
    if not isinstance(value, dict) or "cells" not in value:
        raise StudyError("No unambiguous complete pillar array")
    if set(value) - {"cells", "headline_metric", "headline_metrics"}:
        raise StudyError("Unexpected root fields")
    raw_cells = value["cells"]
    if (
        not isinstance(raw_cells, list)
        or len(raw_cells) != len(pending)
        or any(not isinstance(c, dict) for c in raw_cells)
        or sorted(str(c.get("pillar")) for c in raw_cells) != sorted(pending)
    ):
        raise StudyError("Duplicate/missing/ambiguous pillars; no partial persistence")
    auxiliary = {k: v for k, v in value.items() if k != "cells"}
    valid, failures = [], {}
    for raw in raw_cells:
        pillar = raw["pillar"]
        try:
            valid.extend(
                validate_response(
                    canonical({"cells": [raw], **auxiliary}),
                    schema,
                    [pillar],
                    paper_text,
                    previous,
                    require_defence=False,
                    **validation,
                )
            )
        except (ValueError, KeyError, TypeError, ValidationError) as exc:
            evidence = any(label in str(exc) for label in ("Quote not locatable", "claimed PDF page"))
            failures[pillar] = {
                "status": "evidence_failure" if evidence else "format_failure",
                "reason": str(exc),
            }
    return valid, failures


def payload_for(config: dict, prompt: str) -> dict:
    """Retain exact frozen provider settings and fresh context; no tools, threads or hidden peers."""
    request = copy.deepcopy(config["generation"])
    if config["provider"] == "openai":
        request["input"] = prompt
    else:
        request["messages"] = [{"role": "user", "content": prompt}]
    return request


def build_prompt(
    store: Records, run_id: str, study: int, pending: list[str], previous=None, packet=None
) -> tuple[str, dict]:
    """Project only permitted frozen assets; coordinator manifests/outcomes never enter context."""
    m = store.manifest(run_id)
    paper = next(p for p in m["papers"] if p["study_id"] == study)
    schema = json.loads(store.asset(m["versions"]["schema"]).decode())
    section = [
        store.asset(m["versions"]["prompt_template"]).decode(),
        "REQUESTED PILLARS: " + ",".join(pending),
        "FROZEN RUBRIC\n" + store.asset(paper["files"]["rubric.yaml"]).decode(),
        "COMMON PROCEDURE\n" + store.asset(paper["files"]["protocol.md"]).decode(),
        "COMPLETE PAPER TEXT\n" + store.asset(paper["files"]["paper.txt"]).decode(),
        "RESPONSE SCHEMA\n" + canonical(projected_schema(schema, pending)),
    ]
    if previous is not None:
        # Stored audit/provenance fields are excluded even from the model's own prior projection.
        own = [
            {
                k: c[k]
                for k in (
                    *SUBSTANTIVE,
                    "pillar",
                    "confidence",
                    "action",
                    "change_reason",
                    "anonymous_defence",
                )
            }
            for c in previous.values()
            if c["pillar"] in pending
        ]
        section += [
            "OWN PRECEDING JUDGMENTS\n" + canonical(own),
            "ANONYMOUS PEER SNAPSHOT\n" + canonical(packet),
            "This is a revision. Return retain or revise with a nonempty evidence-based change_reason.",
        ]
    else:
        section.append("This is independent Round 0. Return action initial.")
    prompt = "\n\n".join(section)
    return prompt, {
        "pending": pending,
        "prompt_hash": digest(prompt),
        "prompt_version": PROMPT_VERSION,
        "complete_prompt_bytes": len(prompt.encode()),
        "paper_text_hash": paper["files"]["paper.txt"],
        "schema_hash": m["versions"]["schema"],
    }


def implementation_provenance(root: Path = ROOT) -> dict:
    """Record exact code bytes/environment without reading secret or withheld research material."""
    paths = list((root / "pipeline/study").glob("*.py")) + [
        root / "pipeline/calibration/providers.py",
        root / "pipeline/calibration/sources.py",
        root / "pipeline/calibration/store.py",
        root / "pipeline/schema.py",
    ]
    return {
        "revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root).decode().strip(),
        "files": {str(p.relative_to(root)): digest(p.read_bytes()) for p in sorted(paths)},
        "source_text": {str(p.relative_to(root)): p.read_text() for p in sorted(paths)},
        "python": __import__("sys").version,
        "sqlite": __import__("sqlite3").sqlite_version,
        "packages": {name: importlib.metadata.version(name) for name in ("jsonschema", "httpx", "PyYAML")},
        "parser": subprocess.check_output(["pdftotext", "-v"], stderr=subprocess.STDOUT)
        .decode()
        .splitlines()[0],
    }


def reading_order_text(pdf: bytes, *, raw: bool = False) -> str | None:
    """Derive validation-only text from the frozen PDF; never change common model input or a quotation."""
    with tempfile.TemporaryDirectory(prefix="ch2-frozen-reading-order-") as directory:
        path = Path(directory) / "paper.pdf"
        path.write_bytes(pdf)
        flags = ["-raw"] if raw else []
        result = subprocess.run(["pdftotext", *flags, str(path), "-"], capture_output=True, timeout=60)
    if result.returncode:
        return None
    pages = result.stdout.decode("utf-8").split("\f")
    if not pages[-1].strip():
        pages.pop()
    return "\n\n".join(f"[PDF PAGE {n}]\n{text}" for n, text in enumerate(pages, 1))


def freeze_run(
    store: Records,
    *,
    population: str,
    condition: str,
    execution: int,
    packet_paths: dict[int, Path],
    models: dict,
    limits: dict,
    seed: str,
    schema: dict,
    code: dict,
    expected_hashes: dict[int, dict] | None = None,
    validator_version: str = "legacy-v1",
) -> str:
    """Freeze exact assets, schema, prompt template and execution settings before request dispatch."""
    if validator_version not in ("legacy-v1", VERSION, VERSION3, VERSION_MD):
        raise StudyError("Unknown evidence validator version")
    instruction = FORMAT_INSTRUCTION + ("\n" + INSTRUCTION if validator_version == VERSION else "")
    if validator_version == VERSION3:
        instruction = FORMAT_INSTRUCTION + "\n" + INSTRUCTION3
    if validator_version == VERSION_MD:
        instruction = FORMAT_INSTRUCTION + "\n" + INSTRUCTION_MD
    papers = []
    assets = {}
    for sid, path in packet_paths.items():
        refs, data = frozen_packet(path, allow_unusable=population == "final_evaluation")
        if expected_hashes is not None and refs != expected_hashes[sid]:
            raise StudyError("Prepared packet drift")
        paper = {
            "study_id": sid,
            "files": refs,
            "quote_validation": "common_layout+same_PDF_reading_and_content_order",
        }
        if validator_version == VERSION3:
            blocks = extract_blocks(data[refs["paper.pdf"]])
            assets[digest(blocks)] = blocks.encode()
            paper["physical_blocks"] = digest(blocks)
        common = data[refs["paper.txt"]].decode()
        if len(common.strip()) < 200 or "[PDF PAGE 1]" not in common:
            paper["input_failure"] = "Unusable page-aware common text; no source absence/zero inferred"
        for key, raw in (("reading_order_text", False), ("content_order_text", True)):
            alternate = reading_order_text(data[refs["paper.pdf"]], raw=raw)
            if alternate is not None:
                ref = digest(alternate)
                assets[ref] = alternate.encode()
                paper[key] = ref
        papers.append(paper)
        assets.update(data)
    schema = copy.deepcopy(schema)
    schema.pop("description", None)
    for value in (canonical(schema), instruction):
        assets[digest(value)] = value.encode()
    versions = {
        "schema": digest(canonical(schema)),
        "prompt_template": digest(instruction),
        "procedure_version": "ai-only-v1",
        "prompt_version": PROMPT_VERSION,
    }
    if validator_version != "legacy-v1":
        versions["evidence_validator"] = validator_version
    if validator_version == VERSION3:
        versions["procedure_version"] = "scope-v1-physical-block-v3"
        versions["prompt_version"] = PROMPT_VERSION + "+" + VERSION3
    if validator_version == VERSION_MD:
        versions["procedure_version"] = "final-phase-md-v1"
        versions["prompt_version"] = PROMPT_VERSION + "+" + VERSION_MD
    code = copy.deepcopy(code)
    source_text = code.pop("source_text", {})
    for name, text in source_text.items():
        ref = digest(text)
        if code["files"][name] != ref:
            raise StudyError("Code source changed during freeze")
        assets[ref] = text.encode()
    if code.get("files") and set(source_text) != set(code["files"]):
        raise StudyError("Code provenance requires preserved exact source text")
    manifest = {
        "provenance": "agent:gpt-6",
        "population": population,
        "condition": condition,
        "execution": execution,
        "papers": papers,
        "models": models,
        "versions": versions,
        "code": code,
        "seed": seed,
        "limits": limits,
    }
    return store.create_run(manifest, assets)


def save_judgments(store: Records, request_id: str, cells: list[dict], attempt_id: str, model: str) -> None:
    """Persist already validated scientific judgments atomically with synthetic model provenance."""
    with store.db() as db:
        row = db.execute("SELECT run_id,rater FROM requests WHERE id=?", (request_id,)).fetchone()
        if row is None:
            raise StudyError("Unknown request")
        m = store.manifest(row["run_id"])
        if m["models"][row["rater"]]["model"] != model:
            raise StudyError("Provider model changed")
        completion = db.execute(
            "SELECT c.result FROM completions c JOIN attempts a ON a.id=c.attempt_id "
            "WHERE c.attempt_id=? AND a.request_id=?",
            (attempt_id, request_id),
        ).fetchone()
        if completion is None:
            raise StudyError("No preserved provider completion for this request")
        result = json.loads(completion[0])
        if result.get("model_returned") != model or result.get("status") != "succeeded":
            raise StudyError("Scientific record must match a successful returned model")
        for cell in cells:
            provenance = {
                "rater": "agent:" + model,
                "human_confirmed": False,
                "population": m["population"],
                "attempt_id": attempt_id,
                "run_id": row["run_id"],
            }
            db.execute(
                "INSERT INTO judgments VALUES(?,?,?,?)",
                (request_id, cell["pillar"], canonical(cell), canonical(provenance)),
            )
