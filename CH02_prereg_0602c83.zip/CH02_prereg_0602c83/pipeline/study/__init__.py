"""Versioned AI-only research execution, separate from historical calibration populations."""
