"""Final phase (approved 28 Oct 2026): md-v1 inputs, cost-reduced panel, develop → freeze → test once.

A separate append-only ledger; the October programme and next-phase ledgers are never written.
Design: docs/final-phase-2026-10-28/LOOP_DESIGN.md.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import tempfile
from pathlib import Path

from pipeline.study.evidence_md import VERSION as VERSION_MD
from pipeline.study.markdown_inputs import convert
from pipeline.study.phase import PhaseRecords
from pipeline.study.records import PILLARS, BudgetStop, StudyError, canonical, digest
from pipeline.study.scoring import ROOT, build_prompt, freeze_run, implementation_provenance, payload_for

PHASE = "final-phase-md-v1"
DEV = (38, 42, 53, 77, 34, 60, 83, 6)
HELDOUT = (14, 17, 18, 25, 27, 28, 31, 40, 47, 51, 59, 71, 72, 74, 79)
OUTPUT_CAP = 16000
MODELS = {
    "r1": {
        "provider": "openai",
        "model": "gpt-6.1-sol",
        "generation": {
            "model": "gpt-6.1-sol",
            "max_output_tokens": OUTPUT_CAP,
            "reasoning": {"effort": "low"},
            "store": False,
        },
        "rate_usd_per_million": [2, 10],
    },
    "r2": {
        "provider": "zai",
        "model": "glm-5.3",
        "generation": {
            "model": "glm-5.3",
            "max_tokens": OUTPUT_CAP,
            "reasoning_effort": "low",
            "thinking": {"type": "enabled"},
            # Change C1-A (28 Oct): provider-enforced JSON syntax; cycle 0 lost 6/16 responses to brackets.
            "response_format": {"type": "json_object"},
        },
        "rate_usd_per_million": [1.4, 4.4],
    },
    "r3": {
        "provider": "anthropic",
        "model": "claude-sonnet-5-5",
        # Thinking is on by default and counts against max_tokens; effort is fixed, never tuned mid-study.
        "generation": {
            "model": "claude-sonnet-5-5",
            "max_tokens": OUTPUT_CAP,
            "output_config": {"effort": "medium"},
        },
        "rate_usd_per_million": [2, 10],
    },
}
POLICY = {
    "phase": PHASE,
    "cap_usd": 100,
    "final_reserve_usd": 25,
    "smoke_cap_usd": 3,
    "authorisation": "user:final-phase-2026-10-28-existing-credit-only",
    # Gabriel's console balances on 28 Oct less a US$5 margin;
    # Anthropic is also reduced by ≈US$10.5 for the figure descriptions.
    "provider_limit_usd": {"openai": 45.72, "anthropic": 35.0, "zai": 33.19},
}


def location() -> Path:
    return ROOT / ".research-private/final-phase-live-v1"


def population_of(condition: str) -> str:
    if condition == "D0" or condition.startswith("D0_C"):
        return "synthetic_fixture"
    if condition.startswith("DEV_C"):
        return "development"
    if condition in ("EVAL_ORIGINAL", "EVAL_REFINED"):
        return "final_evaluation"
    raise StudyError("Unknown final-phase condition")


class FinalRecords(PhaseRecords):
    """Final-phase store: own policy, declared paper sets, independent R0 by all three raters only."""

    PHASE_ID = PHASE

    def programme(self, config: dict | None = None) -> dict:
        if config is not None:
            limits = config.get("provider_limit_usd", {})
            if {k: v for k, v in config.items() if k != "provider_limit_usd"} != {
                k: v for k, v in POLICY.items() if k != "provider_limit_usd"
            } or set(limits) != {"openai", "anthropic", "zai"} or any(
                type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in limits.values()
            ):
                raise StudyError("Final phase requires the approved allowance and provider spending caps")
            value = canonical(config)
            with self.db() as db:
                db.execute("INSERT OR IGNORE INTO programme VALUES(?,?)", (PHASE, value))
                if db.execute("SELECT payload FROM programme WHERE id=?", (PHASE,)).fetchone()[0] != value:
                    raise StudyError("Cannot reset final-phase spending or credit limits")
        with self.db() as db:
            row = db.execute("SELECT payload FROM programme WHERE id=?", (PHASE,)).fetchone()
        if row is None:
            raise StudyError("Final-phase allowance not initialised")
        return json.loads(row[0])

    def paper_count_ok(self, manifest: dict) -> bool:
        ids = {p["study_id"] for p in manifest["papers"]}
        return ids == set(DEV if manifest["population"] == "development" else HELDOUT)

    def create_run(self, manifest: dict, assets: dict[str, bytes]) -> str:
        value = json.loads(canonical(manifest))
        if value["versions"].get("evidence_validator") != VERSION_MD:
            raise StudyError("Final phase requires the qualified md-page-v1 validator")
        if value["population"] != population_of(value["condition"]):
            raise StudyError("Condition/population mismatch; no substitution")
        if value["models"] != json.loads(canonical(MODELS)):
            raise StudyError("Final phase uses only the approved model configuration")
        value["study_phase"] = PHASE
        value["active_raters"] = ["r1", "r2", "r3"]
        return super(PhaseRecords, self).create_run(value, assets)

    def admission(self, manifest: dict) -> None:
        check_final_admission(self, manifest)


def check_final_admission(store: FinalRecords, manifest: dict) -> None:
    """Central store, unchanged policy and code, frozen run, recorded billing state, and a clean D0 first."""
    if store.path != (location() / "programme.sqlite3").resolve() or manifest.get("study_phase") != PHASE:
        raise StudyError("Final phase cannot use an isolated or historical ledger")
    receipt = location() / "ADMISSION.json"
    value = json.loads(receipt.read_text()) if receipt.exists() else {}
    if (
        value.get("qualification_passed") is not True
        or value.get("policy") != store.programme()
        or value.get("code_files") != implementation_provenance()["files"]
        or manifest["code"]["files"] != value["code_files"]
        or value.get("automatic_topups_disabled") is not True
    ):
        raise StudyError("Final-phase qualification, policy, billing record or frozen code drifted")
    run_id = "run-" + digest(canonical(manifest))[:32]
    if run_id not in value.get("allowed_runs", []):
        raise StudyError("Run is not in the final-phase freeze")
    if manifest["population"] != "synthetic_fixture":
        smoke = value.get("smoke_run")
        exported = store.export(smoke) if smoke else None
        if not exported or len(exported["judgments"]) != 12 or exported["dispositions"]:
            raise StudyError("D0 smoke has not passed for all three raters")


def write_once(path: Path, data: bytes) -> None:
    if path.exists():
        if path.read_bytes() != data:
            raise StudyError("Frozen packet drift: " + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def procedure(handbook: Path) -> bytes:
    """AI-only rater protocol plus the cycle's handbook text (cycle 0: SCOPE_v1 + CLARIFICATIONS_v1)."""
    base = (ROOT / "calibration/protocol-ai-only-v1.md").read_text()
    return (base + "\n\n" + handbook.read_text()).encode()


def packet(condition: str, sid: int, handbook: Path) -> Path:
    """Exactly the four allowed files; the md-v1 text (with frozen figure descriptions) is the paper text."""
    target = location() / "packets" / condition / str(sid)
    rubric = (ROOT / "rubric/rubric.yaml").read_bytes()
    if sid == 0:
        pdf = (ROOT / "calibration/fixtures/D0.pdf").read_bytes()
        with tempfile.TemporaryDirectory() as folder:
            md = convert(ROOT / "calibration/fixtures/D0.pdf", Path(folder) / "figures")["markdown"]
    else:
        folder = ROOT / ".research-private/markdown-v1" / f"study-{sid}"
        conversion = json.loads((folder / "conversion.json").read_text())
        pdf = next((ROOT / "reviewer_packet/papers").glob(f"{sid}.*.pdf")).read_bytes()
        if digest(pdf) != conversion["pdf_sha256"]:
            raise StudyError(f"Study {sid} PDF differs from the md-v1 conversion source")
        described = folder / "paper.described.md"
        pending = any(f["to_describe"] for f in conversion["figures"])
        if pending and not described.exists():
            raise StudyError(f"Study {sid} figure descriptions are not frozen yet")
        md = (described if pending else folder / "paper.md").read_text()
    for name, data in {
        "paper.pdf": pdf,
        "paper.txt": md.encode(),
        "rubric.yaml": rubric,
        "protocol.md": procedure(handbook),
    }.items():
        write_once(target / name, data)
    return target


def freeze(condition: str, papers: tuple[int, ...], executions: tuple[int, ...], handbook: Path) -> list[str]:
    """Freeze runs and their randomised request schedule; append to FREEZE.json without rewriting it."""
    store = FinalRecords(location() / "programme.sqlite3")
    store.programme(POLICY)
    paths = {sid: packet(condition, sid, handbook) for sid in papers}
    code = implementation_provenance()
    runs = []
    for execution in executions:
        runs.append(
            freeze_run(
                store,
                population=population_of(condition),
                condition=condition,
                execution=execution,
                packet_paths=paths,
                models=MODELS,
                limits={"max_prompt_utf8_bytes": 320000},
                seed="final-phase-20261028",
                schema=json.loads((ROOT / "docs/study-2026-09-28/judgment.schema.json").read_text()),
                code=code,
                validator_version=VERSION_MD,
            )
        )
    rng = random.Random(digest(canonical([condition, runs])))
    schedule = []
    for run in runs:
        order = [(sid, r) for sid in papers for r in ("r1", "r2", "r3")]
        rng.shuffle(order)
        for sid, rater in order:
            m = store.manifest(run)
            prompt, _ = build_prompt(store, run, sid, list(PILLARS))
            schedule.append({
                "run_id": run, "study": sid, "rater": rater,
                "payload_sha256": digest(canonical(payload_for(m["models"][rater], prompt))),
            })
    path = location() / "FREEZE.json"
    frozen = json.loads(path.read_text()) if path.exists() else {"phase": PHASE, "conditions": {}}
    entry = {"runs": runs, "schedule": schedule, "handbook_sha256": digest(handbook.read_bytes())}
    if condition in frozen["conditions"] and frozen["conditions"][condition] != entry:
        raise StudyError("Condition already frozen with different inputs")
    frozen["conditions"][condition] = entry
    path.write_text(json.dumps(frozen, indent=2) + "\n")
    return runs


def admit(smoke_run: str | None = None) -> dict:
    """Record the admission receipt from verifiable facts only; the D0 run is added once it has passed."""
    qualification = json.loads((ROOT / "docs/final-phase-2026-10-28/QUALIFICATION_MD.json").read_text())
    frozen = json.loads((location() / "FREEZE.json").read_text())
    store = FinalRecords(location() / "programme.sqlite3")
    receipt = {
        "phase": PHASE,
        "qualification_passed": qualification["passed"] == qualification["total"] == 72,
        "policy": store.programme(),
        "code_files": implementation_provenance()["files"],
        "allowed_runs": sorted(r for c in frozen["conditions"].values() for r in c["runs"]),
        "automatic_topups_disabled": True,
        "billing_evidence": "Gabriel pasted OpenAI, Anthropic and Z.AI console pages on 28 Oct 2026: "
        "auto-reload/auto-recharge OFF on all three; balances US$50.72, US$50.64, US$38.19.",
    }
    if smoke_run:
        exported = store.export(smoke_run)
        if len(exported["judgments"]) != 12 or exported["dispositions"]:
            raise StudyError("Refusing to record a D0 run that did not pass cleanly")
        receipt["smoke_run"] = smoke_run
    (location() / "ADMISSION.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


EVAL_HANDBOOKS = {
    "EVAL_ORIGINAL": "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt",
    "EVAL_REFINED": "docs/final-phase-2026-10-28/HANDBOOK_C3.txt",
}


def interleave(rows: list[dict], seed: str) -> list[dict]:
    """One seeded order across both arms, so neither arm systematically runs first or later."""
    order = list(rows)
    random.Random(seed).shuffle(order)
    return order


def freeze_eval() -> dict:
    """Freeze both held-out arms (3 executions each) and one interleaved dispatch schedule "EVAL"."""
    for condition, handbook in EVAL_HANDBOOKS.items():
        freeze(condition, HELDOUT, (1, 2, 3), ROOT / handbook)
    path = location() / "FREEZE.json"
    frozen = json.loads(path.read_text())
    arms = [frozen["conditions"][c] for c in EVAL_HANDBOOKS]
    entry = {
        "runs": [r for arm in arms for r in arm["runs"]],
        "schedule": interleave([row for arm in arms for row in arm["schedule"]], "final-eval-20261028"),
        "handbook_sha256": {c: frozen["conditions"][c]["handbook_sha256"] for c in EVAL_HANDBOOKS},
    }
    if "EVAL" in frozen["conditions"] and frozen["conditions"]["EVAL"] != entry:
        raise StudyError("Evaluation schedule already frozen with different inputs")
    frozen["conditions"]["EVAL"] = entry
    path.write_text(json.dumps(frozen, indent=2) + "\n")
    return entry


def run_condition(condition: str, *, dispatcher=None) -> dict:
    """Dispatch a frozen schedule in order; stop on billing, identity or provider configuration errors."""
    from pipeline.study.transport import Dispatcher

    frozen = json.loads((location() / "FREEZE.json").read_text())["conditions"][condition]
    store = FinalRecords(location() / "programme.sqlite3")
    dispatcher = dispatcher or Dispatcher(store)
    statuses = []
    for row in frozen["schedule"]:
        m = store.manifest(row["run_id"])
        store.admission(m)
        prompt, context = build_prompt(store, row["run_id"], row["study"], list(PILLARS))
        payload = payload_for(m["models"][row["rater"]], prompt)
        if digest(canonical(payload)) != row["payload_sha256"]:
            raise StudyError("Frozen request changed")
        q = store.request(row["run_id"], row["study"], row["rater"], 0, "rating", 0, payload, context)
        try:
            result = dispatcher.execute(q)
        except BudgetStop as stop:
            return {"condition": condition, "stopped": str(stop), "dispositioned": len(statuses)}
        statuses.append(result["status"])
        print(canonical({**row, "request_id": q, "status": result["status"]}), flush=True)
        exported = store.export(row["run_id"])
        attempts = {a["id"] for a in exported["attempts"] if a["request_id"] == q}
        done = [c["result"] for c in exported["completions"] if c["attempt_id"] in attempts]
        failed_http = done and done[-1].get("http_status") not in (None, 200)
        if any(c.get("model_change") for c in done) or failed_http:
            raise StudyError("Provider/configuration/credit error preserved; stopped without top-up")
    return {"condition": condition, "dispositioned": len(statuses), "statuses": statuses}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    actions = ["freeze-smoke", "admit", "smoke", "freeze-dev", "dev", "freeze-eval", "eval"]
    ap.add_argument("action", choices=actions)
    ap.add_argument("--smoke-run")
    ap.add_argument("--cycle", type=int, default=0)
    ap.add_argument("--handbook", type=Path, default=ROOT / "docs/final-phase-2026-10-28/HANDBOOK_C0.txt")
    a = ap.parse_args()
    if a.action == "freeze-smoke":
        # Each model-configuration change needs its own D0; cycle 0 keeps the original "D0" label.
        print(freeze("D0" if a.cycle == 0 else f"D0_C{a.cycle}", (0,), (1,), a.handbook))
    elif a.action == "admit":
        print(json.dumps(admit(a.smoke_run), indent=1)[:600])
    elif a.action == "smoke":
        print(canonical(run_condition("D0")))
    elif a.action == "freeze-eval":
        entry = freeze_eval()
        print(json.dumps({"runs": entry["runs"], "requests": len(entry["schedule"])}))
    elif a.action == "eval":
        print(canonical(run_condition("EVAL")))
    elif a.action == "freeze-dev":
        print(freeze(f"DEV_C{a.cycle}", DEV, (1, 2), a.handbook))
    else:
        print(canonical(run_condition(f"DEV_C{a.cycle}")))


if __name__ == "__main__":
    main()
