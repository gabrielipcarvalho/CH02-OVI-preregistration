"""Prepare and run the authorised independent-R0 comparisons with immutable inputs and no top-ups."""

from __future__ import annotations

import argparse
import copy
import json
import random
import sqlite3
from pathlib import Path

from pipeline.study.evidence_v3 import VERSION, extract_blocks, source_text
from pipeline.study.phase import CONDITIONS, PhaseRecords, check_phase_admission
from pipeline.study.records import PILLARS, StudyError, canonical, digest
from pipeline.study.scoring import ROOT, build_prompt, freeze_run, implementation_provenance, payload_for
from pipeline.study.transport import Dispatcher, central_live_ledger


def location() -> Path:
    return central_live_ledger(ROOT).parents[2] / ".research-private/next-phase-live-v1"


def write_once(path: Path, value: bytes) -> None:
    """Resume only byte-identical prepared inputs; never replace a changed freeze."""
    if path.exists():
        if path.read_bytes() != value:
            raise StudyError("Frozen file drift: " + path.name)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)


def prepare() -> dict:
    """Create no network traffic; derive only agreed development/D0 inputs from preserved assets."""
    target = location()
    target.mkdir(parents=True, exist_ok=True)
    original_root = target.parents[1]
    dbpath = original_root / ".research-private/meeting-2026-10-15/source-ledger.sqlite3"
    source = sqlite3.connect(f"{dbpath.as_uri()}?mode=ro", uri=True)
    manifest = json.loads(
        source.execute(
            "SELECT manifest FROM runs WHERE id=?", ("run-49a691373bcdd50354a9ca1a023663a1",)
        ).fetchone()[0]
    )

    def asset(ref):
        value = bytes(source.execute("SELECT payload FROM assets WHERE hash=?", (ref,)).fetchone()[0])
        if digest(value) != ref:
            raise StudyError("Source asset hash changed")
        return value

    notes = ROOT / "docs/next-phase-2026-10-21"
    scope = (notes / "SCOPE_v1.txt").read_text()
    clarifications = (notes / "CLARIFICATIONS_v1.txt").read_text()
    schema = json.loads((ROOT / "docs/study-2026-09-28/judgment.schema.json").read_text())
    code = implementation_provenance()
    store = PhaseRecords(target / "programme.sqlite3")
    runs = {}
    originals = {}
    for condition in CONDITIONS:
        models = copy.deepcopy(manifest["models"])
        if condition in ["A_CONFIG_B", "D0_B"]:
            models["r3"]["generation"].update(thinking={"type": "adaptive"}, output_config={"effort": "high"})
        smoke = condition.startswith("D0_")
        ids = [0] if smoke else [38, 42, 53, 77, 34]
        paths = {}
        for sid in ids:
            packet = target / "packets" / condition / str(sid)
            if smoke:
                data = {
                    "paper.pdf": (ROOT / "calibration/fixtures/D0.pdf").read_bytes(),
                    "rubric.yaml": (ROOT / "rubric/rubric.yaml").read_bytes(),
                    "protocol.md": (ROOT / "calibration/protocol-ai-only-v1.md").read_bytes(),
                }
            else:
                paper = next(p for p in manifest["papers"] if p["study_id"] == sid)
                data = {name: asset(ref) for name, ref in paper["files"].items()}
                originals[str(sid)] = paper["files"]
            blocks = extract_blocks(data["paper.pdf"])
            data["paper.txt"] = source_text(blocks).encode()
            procedure = data["protocol.md"].decode() + "\n\n" + scope
            if condition != "H_PROMPT_C":
                procedure += "\n\n" + clarifications
            data["protocol.md"] = procedure.encode()
            for name, value in data.items():
                write_once(packet / name, value)
            paths[sid] = packet
        for execution in [1] if smoke else [1, 2, 3]:
            run = freeze_run(
                store,
                population="synthetic_fixture" if smoke else "development",
                condition=condition,
                execution=execution,
                packet_paths=paths,
                models=models,
                limits={"max_prompt_utf8_bytes": 320000},
                seed="20261021",
                schema=schema,
                code=code,
                validator_version=VERSION,
            )
            runs[f"{condition}:{execution}"] = run
    rng = random.Random(20261021)
    schedules = {"smoke": [], "configuration": [], "prompt": []}
    for condition in ["D0_A", "D0_B", "D0_OPENAI", "D0_ZAI"]:
        schedules["smoke"].append(
            {"run_id": runs[condition + ":1"], "study": 0, "rater": CONDITIONS[condition][0]}
        )
    for stage, conditions, raters in [
        ("configuration", ["A_CONFIG_A", "A_CONFIG_B"], ["r3"]),
        ("prompt", ["H_PROMPT_C", "H_PROMPT_T"], ["r1", "r2", "r3"]),
    ]:
        for execution in [1, 2, 3]:
            ids = [38, 42, 53, 77, 34]
            rng.shuffle(ids)
            for sid in ids:
                selected = list(raters)
                rng.shuffle(selected)
                for rater in selected:
                    order = list(conditions)
                    rng.shuffle(order)
                    for condition in order:
                        schedules[stage].append(
                            {"run_id": runs[f"{condition}:{execution}"], "study": sid, "rater": rater}
                        )
    payloads = []
    for stage, rows in schedules.items():
        for row in rows:
            m = store.manifest(row["run_id"])
            prompt, ctx = build_prompt(store, row["run_id"], row["study"], list(PILLARS))
            payload = payload_for(m["models"][row["rater"]], prompt)
            payloads.append(
                {
                    **row,
                    "stage": stage,
                    "payload_sha256": digest(canonical(payload)),
                    "prompt_sha256": digest(prompt),
                    "context_sha256": digest(canonical(ctx)),
                }
            )
    frozen = {
        "runs": runs,
        "schedules": schedules,
        "payloads": payloads,
        "code_files": code["files"],
        "source_papers": originals,
        "model_rule": "Historical configurations retained for H_PROMPT regardless of A_CONFIG results.",
        "design": "R0 only, no deliberation; fixed five development papers; no held-out materials",
    }
    write_once(target / "FREEZE.json", (json.dumps(frozen, indent=2) + "\n").encode())
    return frozen


def run_stage(stage: str, *, dispatcher=None) -> dict:
    """Resume immutable scheduled requests; stop on credit, identity or transport/configuration blocks."""
    target = location()
    frozen = json.loads((target / "FREEZE.json").read_text())
    store = PhaseRecords(target / "programme.sqlite3")
    dispatcher = dispatcher or Dispatcher(store)
    results = []
    for row in frozen["schedules"][stage]:
        m = store.manifest(row["run_id"])
        check_phase_admission(store, m)
        prompt, context = build_prompt(store, row["run_id"], row["study"], list(PILLARS))
        payload = payload_for(m["models"][row["rater"]], prompt)
        expected = next(
            p
            for p in frozen["payloads"]
            if p["stage"] == stage and all(p[k] == row[k] for k in ["run_id", "study", "rater"])
        )
        if digest(canonical(payload)) != expected["payload_sha256"]:
            raise StudyError("Prospective request changed")
        q = store.request(row["run_id"], row["study"], row["rater"], 0, "rating", 0, payload, context)
        result = dispatcher.execute(q)
        summary = {**row, "request_id": q, "status": result["status"], "usage": store.usage()}
        results.append(summary)
        print(canonical(summary), flush=True)
        exported = store.export(row["run_id"])
        attempt_ids = {a["id"] for a in exported["attempts"] if a["request_id"] == q}
        completions = [c["result"] for c in exported["completions"] if c["attempt_id"] in attempt_ids]
        if any(c.get("model_change") for c in completions) or (
            completions and completions[-1].get("http_status") not in (None, 200)
        ):
            raise StudyError("Provider/configuration/credit error preserved; stage stopped, no top-up")
        if result["status"] == "parked" and not completions:
            raise StudyError("No completed attempt; inspect resource/admission failure before resuming")
        if stage == "smoke":
            if (
                result["status"] != "complete"
                and len([j for j in exported["judgments"] if j["request_id"] == q]) != 4
            ):
                raise StudyError("D0 failed qualification; do not begin genuine experiments")
            receipt = json.loads((target / "ADMISSION.json").read_text())
            receipt.setdefault("smoke_runs", {})[m["condition"]] = row["run_id"]
            (target / "ADMISSION.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return {"stage": stage, "dispositioned": len(results), "planned": len(frozen["schedules"][stage])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "smoke", "configuration", "prompt"])
    args = parser.parse_args()
    result = prepare() if args.action == "prepare" else run_stage(args.action)
    print(canonical({"prepared_runs": len(result["runs"])} if args.action == "prepare" else result))


if __name__ == "__main__":
    main()
