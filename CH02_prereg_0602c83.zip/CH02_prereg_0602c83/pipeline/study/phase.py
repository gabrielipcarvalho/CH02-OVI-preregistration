"""Explicit additional-credit phase; original programme ledger and ceilings remain immutable."""

from __future__ import annotations

import json
import math

from pipeline.study.records import BudgetStop, Records, StudyError, canonical

PHASE = "supervisor-next-phase-v1"
CONDITIONS = {
    "A_CONFIG_A": ["r3"],
    "A_CONFIG_B": ["r3"],
    "H_PROMPT_C": ["r1", "r2", "r3"],
    "H_PROMPT_T": ["r1", "r2", "r3"],
    "D0_A": ["r3"],
    "D0_B": ["r3"],
    "D0_OPENAI": ["r1"],
    "D0_ZAI": ["r2"],
}


class PhaseRecords(Records):
    """One canonical new-phase store records every new charge; no import resets historical spending."""

    PHASE_ID = PHASE

    def programme(self, config: dict | None = None) -> dict:
        if config is not None:
            if (
                config.get("cap_usd") != 100
                or config.get("final_reserve_usd") != 0
                or config.get("smoke_cap_usd") != 3
                or config.get("additional_authorisation") != "user:up-to-USD100-existing-credit-only"
                or set(config.get("provider_limit_usd", {})) != {"openai", "anthropic", "zai"}
                or any(
                    type(v) not in (int, float) or not math.isfinite(v) or v < 0
                    for v in config["provider_limit_usd"].values()
                )
            ):
                raise StudyError(
                    "New phase requires the explicit additional allowance and provider spending caps"
                )
            value = canonical(config)
            with self.db() as db:
                db.execute("INSERT OR IGNORE INTO programme VALUES(?,?)", (PHASE, value))
                if db.execute("SELECT payload FROM programme WHERE id=?", (PHASE,)).fetchone()[0] != value:
                    raise StudyError("Cannot reset phase spending or credit limits")
        with self.db() as db:
            row = db.execute("SELECT payload FROM programme WHERE id=?", (PHASE,)).fetchone()
        if row is None:
            raise StudyError("Phase allowance and provider limits not initialised")
        return json.loads(row[0])

    def create_run(self, manifest: dict, assets: dict[str, bytes]) -> str:
        value = json.loads(canonical(manifest))
        condition = value["condition"]
        if condition not in CONDITIONS or value["versions"].get("evidence_validator") != "physical-block-v3":
            raise StudyError("Unknown phase condition or unqualified validator")
        value["study_phase"] = PHASE
        value["active_raters"] = CONDITIONS[condition]
        if value["population"] != ("synthetic_fixture" if condition.startswith("D0_") else "development"):
            raise StudyError("No evaluation or population substitution in this phase")
        if value["population"] == "development" and {p["study_id"] for p in value["papers"]} != {
            38,
            42,
            53,
            77,
            34,
        }:
            raise StudyError("Only the five agreed development papers are allowed")
        return super().create_run(value, assets)

    def request(self, run_id, study, rater, round_n, kind, replicate, payload, context):
        m = self.manifest(run_id)
        if rater not in m["active_raters"] or round_n != 0 or kind != "rating" or replicate != 0:
            raise StudyError("This phase permits only the declared independent R0 calls")
        return super().request(run_id, study, rater, round_n, kind, replicate, payload, context)

    def admission(self, manifest: dict) -> None:
        """Live-dispatch gate for this phase's store; subclasses bind their own phase."""
        check_phase_admission(self, manifest)

    def additional_budget_guard(self, db, request_id: str, amount: float) -> None:
        """Inside the reserve transaction, bound per-provider spend by declared provider spending caps."""
        row = db.execute(
            "SELECT r.manifest,q.rater FROM requests q JOIN runs r ON r.id=q.run_id WHERE q.id=?",
            (request_id,),
        ).fetchone()
        m = json.loads(row["manifest"])
        provider = m["models"][row["rater"]]["provider"]
        policy = json.loads(
            db.execute("SELECT payload FROM programme WHERE id=?", (self.PHASE_ID,)).fetchone()[0]
        )
        spent = db.execute(
            """SELECT coalesce(sum(coalesce(c.charged,a.reserved)),0) FROM attempts a
            JOIN requests q ON q.id=a.request_id JOIN runs r ON r.id=q.run_id
            LEFT JOIN completions c ON c.attempt_id=a.id
            WHERE json_extract(r.manifest,'$.models.'||q.rater||'.provider')=?""",
            (provider,),
        ).fetchone()[0]
        if spent + amount > policy["provider_limit_usd"][provider]:
            raise BudgetStop("Existing provider credit allowance exhausted; no top-up")


def billing_admitted(receipt: dict) -> bool:
    """Do not invent balance/auto-reload verification; preserve explicit authority to proceed without it."""
    return receipt.get("automatic_topups_disabled") is True or (
        receipt.get("unverified_balance_execution_authorised") is True and receipt.get("no_topups") is True
    )


def check_phase_admission(store: PhaseRecords, manifest: dict) -> None:
    """Require central path, fixed policy, code qualification and successful D0 before real papers."""
    from pipeline.study.scoring import ROOT, implementation_provenance
    from pipeline.study.transport import central_live_ledger

    root = central_live_ledger(ROOT).parents[2]
    expected = root / ".research-private/next-phase-live-v1/programme.sqlite3"
    if store.path != expected.resolve() or manifest.get("study_phase") != PHASE:
        raise StudyError("New phase cannot use an isolated or historical ledger")
    policy = store.programme()
    receipt = store.path.parent / "ADMISSION.json"
    value = json.loads(receipt.read_text()) if receipt.exists() else {}
    if (
        value.get("all_required_passed") is not True
        or value.get("policy") != policy
        or value.get("code_files") != implementation_provenance()["files"]
        or manifest["code"]["files"] != value["code_files"]
    ):
        raise StudyError("Phase qualification, policy or frozen implementation drifted")
    run_id = "run-" + __import__("hashlib").sha256(canonical(manifest).encode()).hexdigest()[:32]
    if run_id not in value.get("allowed_runs", []):
        raise StudyError("Run is not in the prospective phase freeze")
    if not billing_admitted(value):
        raise StudyError("Billing execution authority not recorded")
    if manifest["population"] != "synthetic_fixture":
        needed = ["D0_A", "D0_B"] if manifest["condition"].startswith("A_CONFIG") else list(CONDITIONS)[4:]
        for condition in needed:
            run_id = value.get("smoke_runs", {}).get(condition)
            if not run_id:
                raise StudyError("D0 configuration smoke missing")
            smoke = store.export(run_id)
            expected_cells = 4 * len(CONDITIONS[condition])
            if (
                smoke["manifest"]["condition"] != condition
                or len(smoke["judgments"]) != expected_cells
                or smoke["dispositions"]
            ):
                raise StudyError("D0 smoke did not pass without failures")
