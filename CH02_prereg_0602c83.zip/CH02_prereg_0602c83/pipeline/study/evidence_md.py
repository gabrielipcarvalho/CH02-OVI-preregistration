"""md-v1 page-section localisation: quotes must occur in the authors' Markdown text on the claimed page.

The model input and the validation source are the same frozen md-v1 text, so extraction differences
cannot reject a correct quotation. Generated figure descriptions are removed before matching.
"""

from __future__ import annotations

import re
from collections import Counter

from pipeline.study.evidence_v2 import contains
from pipeline.study.evidence_v3 import anchor_page, typographic, variants
from pipeline.study.markdown_inputs import source_text
from pipeline.study.records import StudyError

VERSION = "md-page-v1.1"  # v1.1 (C2): unmapped glyphs, URL/DOI lines, running headers, page counters
INSTRUCTION = """Evidence localisation md-page-v1: the paper text is Markdown with [PDF PAGE N] markers.
Quote one contiguous passage of the authors' text exactly; Markdown symbols may be omitted.
Start the locator with 'PDF page N', N being the nearest [PDF PAGE N] marker above the passage.
A quotation may run onto the next page. Label printed/journal pagination separately and put
contextual references after '; context:'. Do not splice quotations with ellipses.
FIGURE DESCRIPTION blocks are generated, not the authors' words: never quote them; use them only to
find the authors' own captions, tables or text. Source location does not establish criterion adequacy."""
PAGE_SPLIT = re.compile(r"^\[PDF PAGE (\d+)\]$", re.M)


def plain(text: str) -> str:
    """Drop Markdown/HTML presentation only; words, numbers, signs and units stay literal."""
    text = re.sub(r"<!--.*?-->", " ", text, flags=re.S)
    text = re.sub(r"<br\s*/?>", " ", text)
    text = re.sub(r"</?(?:sup|sub|u|b|i|em|strong)>", "", text)
    text = re.sub(r"^\[(?:FIGURE|IMAGE|OCR-DERIVED)[^\n]*\]$", " ", text, flags=re.M)
    text = re.sub(r"^\s{0,3}(?:#{1,6}|>)\s?", "", text, flags=re.M)
    text = re.sub(r"^\|?\s*:?-{3,}.*$", " ", text, flags=re.M)  # table rule rows
    # Change C2-I: URL/DOI-only lines are publisher page furniture; converters can drop them mid-sentence.
    text = re.sub(r"^\s*(?:https?://\S+|doi:\s*\S+|10\.\d{4,}/\S+)\s*$", " ", text, flags=re.M | re.I)
    text = text.replace("**", "").replace("|", " ")
    return re.sub(r"(?<!\w)_|_(?!\w)", "", text)  # emphasis underscores, not identifier underscores


COUNTER = re.compile(r"^\s*\d+\s+of\s+\d+\s*$")


def pages(markdown: str) -> dict[int, str]:
    """Quotable page sections: authors' text only, with generated description blocks removed.

    Change C2-I extension: running headers/footers (a line repeated identically on 3+ pages) and
    "N of M" page counters are page furniture, removed so a sentence crossing a page still matches.
    """
    parts = PAGE_SPLIT.split(source_text(markdown))
    raw = {int(parts[i]): plain(parts[i + 1]) for i in range(1, len(parts) - 1, 2)}
    seen: Counter = Counter()
    for text in raw.values():
        seen.update({s.strip() for s in text.split("\n") if s.strip()})
    furniture = {line for line, n in seen.items() if n >= 3} if len(raw) >= 3 else set()
    return {
        n: "\n".join(s for s in text.split("\n") if s.strip() not in furniture and not COUNTER.match(s))
        for n, text in raw.items()
    }


def dehyphen(text: str) -> str:
    """Drop hyphens between two letters only: the converter joins line-broken compounds ("lowcost").

    Hyphens and minus signs next to digits stay literal, so signed or ranged quantities still must match.
    """
    return re.sub(r"(?<=[^\W\d_])-(?=[^\W\d_])", "", text)


def unmapped_glyph_match(needle: str, source: str) -> bool:
    """Change C2-H: a source U+FFFD (a glyph the PDF font could not map) matches any one non-space
    character of the quote. Every other character, and the word/number boundaries, stay exact."""
    if "\ufffd" not in source or not needle:
        return False
    pattern = "".join(re.escape(c) if c.isspace() else f"(?:{re.escape(c)}|\ufffd)" for c in needle)
    for match in re.finditer(pattern, source):
        before = source[match.start() - 1 : match.start()] if match.start() else ""
        after = source[match.end() : match.end() + 1]
        if (before and before.isalnum() and needle[0].isalnum()) or (
            after and after.isalnum() and needle[-1].isalnum()
        ):
            continue
        return True
    return False


def _found(needles: tuple[str, ...], text: str) -> bool:
    hays = variants(typographic(text))
    return any(
        contains(n, h) or contains(dehyphen(n), dehyphen(h)) or unmapped_glyph_match(n, h)
        for n in needles
        for h in hays
    )


def evidence_check_md(cell: dict, markdown: str) -> dict:
    """Exact contiguous match on the claimed page, or starting there and running onto the next page."""
    base = {"validator_version": VERSION, "semantic_validity": False}
    if cell["quote"] == "NO_DOCUMENTED_EVIDENCE":
        return {**base, "status": "absence_not_verified"}
    if not cell["quote"].strip():
        if cell["status"] == "scored":
            raise StudyError("Scored evidence is empty")
        return {**base, "status": "not_assessable"}
    if "DESCRIPTION — generated by" in cell["quote"]:
        raise StudyError("Quote not locatable: generated figure descriptions are not source text")
    page = anchor_page(cell["locator"])
    sections = pages(markdown)
    if page not in sections:
        raise StudyError("Quote not locatable: claimed PDF page is outside the frozen source")
    quotation = typographic(plain(cell["quote"]))
    needles = variants(quotation)
    if quotation.startswith("The "):
        needles += variants("the " + quotation[4:])
    elif quotation.startswith("the "):
        needles += variants("The " + quotation[4:])
    if _found(needles, sections[page]):
        return {**base, "status": "text_match", "method": "md_page_section", "pages": [page],
                "locator_page_verified": True}
    following = sections.get(page + 1)
    continues = following is not None and not _found(needles, following)
    if continues and _found(needles, sections[page] + "\n" + following):
        return {**base, "status": "text_match", "method": "md_page_continuation",
                "pages": [page, page + 1], "locator_page_verified": True}
    raise StudyError("Quote not locatable on claimed PDF page in md-v1 source; original preserved")
