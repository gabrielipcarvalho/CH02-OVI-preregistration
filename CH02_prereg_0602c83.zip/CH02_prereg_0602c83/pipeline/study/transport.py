"""Bounded real-provider dispatch with a shared append-only reservation and attempt ledger."""

from __future__ import annotations

import base64
import copy
import fcntl
import json
import os
import re
import subprocess
import time
from pathlib import Path

import httpx
from jsonschema import ValidationError

from pipeline.calibration.providers import PROVIDERS, extract
from pipeline.calibration.store import SUBSTANTIVE
from pipeline.study.evidence_md import VERSION as VERSION_MD
from pipeline.study.evidence_v2 import VERSION
from pipeline.study.evidence_v3 import VERSION as VERSION3
from pipeline.study.records import BudgetStop, Records, StudyError, canonical, digest
from pipeline.study.scoring import validate_individual_cells, validate_response

RATES = {"openai": (10.0, 50.0), "anthropic": (5.0, 25.0), "zai": (1.4, 4.4)}
# Model-specific list prices (US$/M input, output); unknown models fall back to the provider rate above.
MODEL_RATES = {"gpt-6.1-sol": (2.0, 10.0), "claude-sonnet-5-5": (2.0, 10.0)}
MAX_OUTPUT_TOKENS = 16000  # final phase (28 Oct): 6,000 truncated 11/15 adaptive responses on 21 Oct
PRICE_VERIFIED = "2026-10-08"


def central_live_ledger(root: Path) -> Path:
    """Linked worktrees share one production ledger; an isolated clone cannot reset provider spending."""
    common = Path(
        subprocess.check_output(["git", "rev-parse", "--git-common-dir"], cwd=root, text=True).strip()
    )
    if not common.is_absolute():
        common = root / common
    return common.resolve().parent / ".research-private/programme-v1/programme.sqlite3"


def transient_http_failure(status: int, body: bytes) -> bool:
    """Permanent quota/billing errors cannot become rate-limit retries, even when both use HTTP429."""
    try:
        parsed = json.loads(body)
        error = parsed.get("error", {}) if isinstance(parsed, dict) else {}
    except ValueError, UnicodeDecodeError:
        error = {}
    if isinstance(error, dict) and (
        error.get("type") == "insufficient_quota"
        or error.get("code")
        in (
            "insufficient_quota",
            "credit_balance_exhausted",
            "organization_usage_limit_exceeded",
            "project_usage_limit_exceeded",
        )
    ):
        return False
    return status in (429, 500, 502, 503, 504)


def reservation(provider: str, payload: dict) -> float:
    """Use a byte upper bound plus full output cap; conservatively reserve the OpenAI premium tier."""
    size = len(canonical(payload).encode())
    prompt = payload.get("input") or payload["messages"][0]["content"]
    output = payload.get("max_output_tokens", payload.get("max_tokens"))
    if (
        size > 350000
        or len(prompt.encode()) > 320000
        or type(output) is not int
        or not 32 <= output <= MAX_OUTPUT_TOKENS
    ):
        raise StudyError("Approved complete request envelope exceeded; no truncation")
    inp, out = MODEL_RATES.get(payload.get("model"), RATES[provider])
    if provider == "openai" and size + 2048 > 272000:
        inp *= 2
        out *= 1.5
    return ((size + 2048) * inp + output * out) / 1e6


def scientific_projection(text: str, rubric: dict) -> dict:
    """Recognise explicit field/label aliases only; never infer absent scientific content."""
    clean = text.strip()
    if clean.startswith("```"):
        if clean.count("```") != 2:
            raise StudyError("Ambiguous fenced response")
        clean = clean.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    value = json.loads(clean)
    if isinstance(value, dict):
        value = {k: v for k, v in value.items() if k not in ("headline_metric", "headline_metrics")}
    if isinstance(value, dict) and set(value) == {"cells"} and isinstance(value["cells"], list):
        cells = value["cells"]
    elif isinstance(value, dict) and set(value) <= set(("P1", "P2", "P3", "P4")) and value:
        cells = [{**c, "pillar": p} for p, c in value.items()]
    else:
        raise StudyError("Unrecognised raw structure; no speculative recovery")
    titles = {v["title"]: p for p, v in rubric["pillars"].items()}
    result = {}
    for c in cells:
        p = c.get("pillar")
        if p in titles:
            p = titles[p]
        if p not in ("P1", "P2", "P3", "P4") or p in result:
            raise StudyError("Ambiguous raw pillar identity")
        scientific = {}
        for key in SUBSTANTIVE:
            if key not in c:
                raise StudyError("Missing scientific field; cannot reconstruct by re-scoring")
            v = c[key]
            if key == "score" and type(v) is bool:
                raise StudyError("Boolean score cannot be recovered as a numeric judgment")
            if key == "score" and isinstance(v, str) and v in ("0", "1", "2", "3"):
                v = int(v)
            if key != "score":
                if v is None and key in ("alternative", "quote", "locator"):
                    v = ""
                if not isinstance(v, str):
                    raise StudyError("Unrecognised scientific field type")
                v = v.strip()
            scientific[key] = v
        result[p] = {"fields": scientific, "defence": c.get("anonymous_defence")}
    return result


def defence_content(value: str) -> str:
    """Ignore isolated speaker/score labels only; never erase measurements or scientific body words."""
    value = re.sub(
        r"^\s*(?:as|I am)\s+(?:Claude|GPT[- ]?6(?:[- ]Astra)?|GLM[- ]?5\.3)\s*[,.:]\s*", "", value, flags=re.I
    )
    value = re.sub(
        r"^\s*(?:my\s+)?(?:assigned\s+)?(?:score|rating|level)\s*(?:is|:|=)?\s*"
        r"[0-3]\s*[.;]\s*",
        "",
        value,
        flags=re.I,
    )
    return re.sub(r"\s+", " ", value).strip()


def verify_format_equivalence(original: str, cells: list[dict], rubric: dict) -> None:
    """Fail if recovery changes scores, status, source evidence or scientific explanations."""
    before = scientific_projection(original, rubric)
    if set(before) != {c["pillar"] for c in cells}:
        raise StudyError("Format recovery changed pillar coverage")
    for cell in cells:
        raw = before[cell["pillar"]]
        for key in SUBSTANTIVE:
            expected = raw["fields"][key]
            allowed = (
                (expected, "Section: " + expected)
                if key == "locator" and isinstance(expected, str)
                else (expected,)
            )
            if cell[key] not in allowed:
                raise StudyError("Format recovery changed scientific field: " + key)
        old = raw["defence"] or {k: raw["fields"][k] for k in ("quote", "locator", "reason", "alternative")}
        for key in ("reason", "alternative"):
            if not isinstance(old.get(key), str) or defence_content(old[key]) != defence_content(
                cell["anonymous_defence"][key]
            ):
                raise StudyError("Recovery defence changed the scientific body")


class Dispatcher:
    """Sequential calls; transport retries repeat exact requests, and one recovery preserves content."""

    def __init__(self, store: Records, *, transport=None, secret_dir: Path | None = None, sleep=time.sleep):
        self.store = store
        self.transport = transport
        self.secret_dir = secret_dir or Path.home() / ".secrets"
        self.sleep = sleep

    def _attempt(
        self, request_id: str, provider: str, model: str, payload: dict, stage: int, transport_n: int
    ) -> dict:
        """Record a reservation before network, and persist safe observable output on every exit."""
        if os.environ.get("OVI_PANEL_OFFLINE") == "1":
            raise StudyError("Offline: provider calls disabled")
        if not isinstance(self.transport, httpx.MockTransport):
            from pipeline.study.cli import PRIVATE, ROOT, check_admission, programme
            from pipeline.study.phase import PhaseRecords
            from pipeline.study.scoring import implementation_provenance
            if isinstance(self.store, PhaseRecords):
                with self.store.db() as db:
                    q = db.execute("SELECT run_id FROM requests WHERE id=?", (request_id,)).fetchone()
                self.store.admission(self.store.manifest(q["run_id"]))
            else:
                if self.store.path != (
                    PRIVATE / "programme.sqlite3"
                ).resolve() or self.store.path != central_live_ledger(ROOT):
                    raise StudyError("Live dispatch requires the central programme ledger")
                programme()  # reconcile verified prior charges before every new real attempt
                with self.store.db() as db:
                    q = db.execute("SELECT run_id FROM requests WHERE id=?", (request_id,)).fetchone()
                m = self.store.manifest(q["run_id"])
                check_admission(m["population"])
                if m["code"]["files"] != implementation_provenance()["files"]:
                    raise StudyError("Frozen execution implementation drifted; do not append live calls")
        path = self.secret_dir / PROVIDERS[provider]["key"]
        if not path.is_file() or not path.read_text().strip():
            raise StudyError("Provider credential missing/empty")
        key = path.read_text().strip()
        if payload.get("model") != model:
            raise StudyError("Frozen request model mismatch")
        amount = reservation(provider, payload)
        attempt = self.store.reserve(request_id, stage, transport_n, amount, payload)
        result = {
            "status": "failed",
            "provider": provider,
            "model_requested": model,
            "attempt_id": attempt,
            "retryable": False,
            "request_sha256": digest(canonical(payload)),
        }
        charged = amount
        headers = {"Content-Type": "application/json"}
        if provider == "anthropic":
            headers.update({"x-api-key": key, "anthropic-version": "2023-06-01"})
        else:
            headers["Authorization"] = "Bearer " + key
        try:
            with httpx.Client(
                timeout=httpx.Timeout(150, connect=15), transport=self.transport, follow_redirects=False
            ) as client:
                response = client.post(PROVIDERS[provider]["endpoint"], headers=headers, json=payload)
            result.update(http_status=response.status_code, response_sha256=digest(response.content))
            safe_body = response.content.replace(key.encode(), b"[REDACTED]")
            result.update(
                observable_response_base64=base64.b64encode(safe_body).decode("ascii"),
                observable_response_sha256=digest(safe_body),
                response_secret_redacted=safe_body != response.content,
            )
            if response.status_code != 200:
                result.update(
                    error=f"HTTP {response.status_code}",
                    retryable=transient_http_failure(response.status_code, response.content),
                )
            else:
                data = response.json()
                text, input_n, output_n, finish = extract(provider, data)
                if type(input_n) is not int or type(output_n) is not int or input_n < 0 or output_n < 0:
                    raise StudyError("Invalid provider usage counters; full reservation retained")
                inp, out = MODEL_RATES.get(model, RATES[provider])
                if provider == "openai" and input_n > 272000:
                    inp *= 2
                    out *= 1.5
                if input_n > 0 and output_n > 0:
                    charged = (input_n * inp + output_n * out) / 1e6
                result.update(
                    text=text.replace(key, "[REDACTED]"),
                    model_returned=data.get("model"),
                    input_tokens=input_n,
                    output_tokens=output_n,
                    finish_reason=finish,
                    response_id=data.get("id"),
                )
                if key in text:
                    result["error"] = "Secret echo redacted; response rejected"
                elif not isinstance(data.get("model"), str) or not data["model"]:
                    result["error"] = "Returned model identity missing/invalid"
                elif data.get("model") != model:
                    result["error"] = "Provider model identity changed"
                    result["model_change"] = True
                elif not text.strip() or finish in ("length", "max_tokens", "incomplete"):
                    result["error"] = "Incomplete observable output; retained, never scored zero"
                elif charged > amount:
                    result["error"] = "Usage exceeded conservative reservation; programme halted"
                else:
                    result["status"] = "succeeded"
        except httpx.HTTPError as exc:
            result.update(error=type(exc).__name__, retryable=True)
        except (ValueError, KeyError, TypeError, ValidationError) as exc:
            result.update(error=type(exc).__name__)
        finally:
            result["charged_or_reserved_usd"] = charged
            result = json.loads(canonical(result).replace(key, "[REDACTED]"))
            self.store.complete(attempt, charged, result)
        return result

    def _stage(self, request_id: str, provider: str, model: str, payload: dict, stage: int) -> dict:
        """Resume completed attempts; an unknown in-flight attempt is never dispatched again."""
        for transport_n in range(3):
            with self.store.db() as db:
                row = db.execute(
                    "SELECT a.payload,c.result FROM attempts a LEFT JOIN completions c "
                    "ON c.attempt_id=a.id WHERE a.request_id=? AND a.stage=? AND a.transport=?",
                    (request_id, stage, transport_n),
                ).fetchone()
            if row:
                if row["payload"] != canonical(payload):
                    raise StudyError("Attempt payload changed on resume")
                if row["result"] is None:
                    raise StudyError("Unknown interrupted provider attempt; reservation retained")
                result = json.loads(row["result"])
            else:
                result = self._attempt(request_id, provider, model, payload, stage, transport_n)
            if result["status"] == "succeeded" or not result["retryable"]:
                return result
            if transport_n < 2:
                self.sleep(min(2**transport_n, 4))
        return result

    def execute(self, request_id: str, *, previous: dict | None = None) -> dict:
        """One dispatcher owns programme execution; competing workers must not invent orphan failures."""
        with self.store.path.with_suffix(".dispatch.lock").open("a") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise StudyError("Programme dispatcher already active; wait or inspect its status") from exc
            return self._execute_locked(request_id, previous=previous)

    def _execute_locked(self, request_id: str, *, previous: dict | None = None) -> dict:
        """Return validated existing/new judgments or a preserved failure; no content-seeking retry."""
        with self.store.db() as db:
            row = db.execute("SELECT * FROM requests WHERE id=?", (request_id,)).fetchone()
            failure = db.execute(
                "SELECT payload FROM dispositions WHERE request_id=?", (request_id,)
            ).fetchone()
            saved = db.execute(
                "SELECT payload FROM judgments WHERE request_id=? ORDER BY pillar", (request_id,)
            ).fetchall()
        if failure:
            return {
                "status": "partial" if saved else "parked",
                "disposition": json.loads(failure[0]),
                "cells": [json.loads(c[0]) for c in saved],
                "reused": True,
            }
        if saved:
            return {"status": "succeeded", "cells": [json.loads(c[0]) for c in saved], "reused": True}
        if row is None:
            raise StudyError("Unknown frozen request")
        manifest = self.store.manifest(row["run_id"])
        config = manifest["models"][row["rater"]]
        with self.store.db() as db:
            quarantined = db.execute(
                "SELECT 1 FROM completions WHERE json_extract(result,'$.model_change')=1 "
                "AND json_extract(result,'$.provider')=? LIMIT 1",
                (config["provider"],),
            ).fetchone()
        if quarantined:
            self.store.disposition(
                request_id, "model_change", "Provider identity previously changed; quarantined"
            )
            return {
                "status": "parked",
                "disposition": {"status": "model_change", "reason": "Provider quarantined"},
            }
        validator_version = manifest["versions"].get("evidence_validator", "legacy-v1")
        if validator_version not in ("legacy-v1", VERSION, VERSION3, VERSION_MD):
            raise StudyError("Unknown evidence validator version; no dispatch")
        context = json.loads(row["context"])
        request = json.loads(row["payload"])
        paper = next(p for p in manifest["papers"] if p["study_id"] == row["study"])
        if paper.get("input_failure"):
            self.store.disposition(request_id, "process_failure", paper["input_failure"])
            return {
                "status": "parked",
                "disposition": {"status": "process_failure", "reason": paper["input_failure"]},
            }
        schema = json.loads(self.store.asset(manifest["versions"]["schema"]))
        blocks = self.store.asset(paper["physical_blocks"]).decode() if paper.get("physical_blocks") else None
        text = self.store.asset(paper["files"]["paper.txt"]).decode()
        alternate = (
            self.store.asset(paper["reading_order_text"]).decode()
            if paper.get("reading_order_text")
            else None
        )
        content_order = (
            self.store.asset(paper["content_order_text"]).decode()
            if paper.get("content_order_text")
            else None
        )
        import yaml

        rubric = yaml.safe_load(self.store.asset(paper["files"]["rubric.yaml"]))
        failure_status = "process_failure"
        science_fallback = None
        cell_failures = {}
        original_result = None
        try:
            result = self._stage(request_id, config["provider"], config["model"], request, 0)
            if result["status"] != "succeeded":
                failure_status = "model_change" if result.get("model_change") else "process_failure"
                raise StudyError(result.get("error", "Provider failed"))
            original_result = result
            original = result["text"]
            try:
                cells = validate_response(
                    original,
                    schema,
                    context["pending"],
                    text,
                    previous,
                    require_defence=row["kind"] != "check" and manifest["population"] != "final_evaluation",
                    reading_order=alternate,
                    content_order=content_order,
                    validator_version=validator_version,
                    physical_blocks=blocks,
                )
            except (ValueError, ValidationError) as error:
                failure_status = "format_failure"
                try:
                    candidate, cell_failures = validate_individual_cells(
                        original,
                        schema,
                        context["pending"],
                        text,
                        previous,
                        reading_order=alternate,
                        content_order=content_order,
                        validator_version=validator_version,
                        physical_blocks=blocks,
                    )
                    if candidate and (
                        cell_failures or any(c["defence_check"]["status"] == "withheld" for c in candidate)
                    ):
                        science_fallback = candidate
                    if any(f["status"] == "evidence_failure" for f in cell_failures.values()):
                        return self._partial(row, candidate, original_result, cell_failures)
                except ValueError, ValidationError:
                    pass  # the raw attempt remains preserved; invalid scientific fields are never salvaged
                # Without identifiable original scientific content, a repair cannot be verified.
                scientific_projection(original, rubric)
                repair = (
                    'FORMAT-ONLY recovery. Do not re-score. Return exactly {"cells":[...]} with requested '
                    "pillar codes and string fields; only unassessable score may be null. "
                    "Preserve score,status, "
                    "quote,locator,reason,alternative verbatim. Only known pillar labels, "
                    "numeric score strings "
                    "and empty optional null strings may be canonicalised. "
                    "Defence quote/locator copy original. "
                    "Defence body must preserve original scientific words; "
                    "omit only explicit model identity, "
                    "numeric advocated score and tally markers. "
                    "Do not invent missing content or page numbers. "
                    "No external information. The original observable response follows:\n"
                    + original
                    + "\nRequested codes: "
                    + canonical(context["pending"])
                    + "\nSchema:\n"
                    + canonical(schema)
                )
                repaired = copy.deepcopy(request)
                if config["provider"] == "openai":
                    repaired["input"] = repair
                else:
                    repaired["messages"] = [{"role": "user", "content": repair}]
                result = self._stage(request_id, config["provider"], config["model"], repaired, 1)
                if result["status"] != "succeeded":
                    raise StudyError("Format recovery provider failure") from error
                cells = validate_response(
                    result["text"],
                    schema,
                    context["pending"],
                    text,
                    previous,
                    reading_order=alternate,
                    content_order=content_order,
                    validator_version=validator_version,
                    physical_blocks=blocks,
                )
                verify_format_equivalence(original, cells, rubric)
                self.store.event(
                    row["run_id"],
                    "format_recovery",
                    {
                        "request_id": request_id,
                        "original_error": type(error).__name__,
                        "scientific_equivalence_verified": True,
                    },
                )
            from pipeline.study.scoring import save_judgments

            save_judgments(self.store, request_id, cells, result["attempt_id"], result["model_returned"])
            return {
                "status": "succeeded",
                "cells": cells,
                "attempt_id": result["attempt_id"],
                "reused": False,
            }
        except BudgetStop as exc:
            if science_fallback is not None:
                if cell_failures:
                    return self._partial(
                        row, science_fallback, original_result, cell_failures, recovery_error=str(exc)
                    )
                return self._withhold(row, science_fallback, original_result, str(exc))
            self.store.disposition(request_id, "resource_stop", str(exc))
            return {"status": "parked", "disposition": {"status": "resource_stop", "reason": str(exc)}}
        except (ValueError, KeyError, TypeError, ValidationError) as exc:
            if science_fallback is not None:
                if cell_failures:
                    return self._partial(
                        row, science_fallback, original_result, cell_failures, recovery_error=str(exc)
                    )
                return self._withhold(row, science_fallback, original_result, str(exc))
            self.store.disposition(request_id, failure_status, str(exc))
            return {"status": "parked", "disposition": {"status": failure_status, "reason": str(exc)}}

    def _partial(self, row, cells, result, failures, recovery_error=None):
        """Keep valid judgments; a failed cell never erases another pillar or becomes zero."""
        from pipeline.study.scoring import save_judgments

        if cells:
            save_judgments(self.store, row["id"], cells, result["attempt_id"], result["model_returned"])
        status = (
            "evidence_failure"
            if any(f["status"] == "evidence_failure" for f in failures.values())
            else "format_failure"
        )
        reason = "; ".join(p + ": " + f["reason"] for p, f in sorted(failures.items()))
        if recovery_error:
            reason += "; recovery refused: " + recovery_error
        self.store.disposition(row["id"], status, reason, pillars=list(failures), details=failures)
        return {
            "status": "partial" if cells else "parked",
            "cells": cells,
            "failed_pillars": sorted(failures),
            "disposition": {"status": status, "reason": reason},
        }

    def _withhold(self, row, cells, result, reason):
        """Preserve valid initial science while parking only the noncompliant peer channel."""
        from pipeline.study.scoring import save_judgments

        save_judgments(self.store, row["id"], cells, result["attempt_id"], result["model_returned"])
        self.store.event(
            row["run_id"],
            "defence_release_parked",
            {
                "request_id": row["id"],
                "reason": reason,
                "pillars": [c["pillar"] for c in cells if c["defence_check"]["status"] == "withheld"],
            },
        )
        return {"status": "succeeded", "cells": cells, "peer_release_withheld": True, "reason": reason}
