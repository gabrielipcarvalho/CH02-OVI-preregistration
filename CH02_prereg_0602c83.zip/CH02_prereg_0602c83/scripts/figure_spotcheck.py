"""Build a private HTML page of 20 seeded figure descriptions for Gabriel's spot-check before the freeze.

Held-out papers are excluded so the check opens no held-out material. The page stays in the private
archive because the figure images are copyrighted.
"""

from __future__ import annotations

import hashlib
import html
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline.study.final_phase import HELDOUT  # noqa: E402

MD = ROOT / ".research-private/markdown-v1"
SEED = "ch2-figure-spotcheck-20261028"


def main() -> None:
    rows = [json.loads(line) for line in (MD / "figure_descriptions.jsonl").read_text().splitlines()]
    ok = [r for r in rows if r["status"] == "ok" and r["study_id"] not in HELDOUT]
    def order(r: dict) -> str:
        return hashlib.sha256(f"{SEED}:{r['study_id']}:{r['figure_id']}".encode()).hexdigest()

    sample = sorted(ok, key=order)
    parts = ["<!doctype html><meta charset=utf-8><title>Figure spot-check</title>",
             "<style>body{font:15px system-ui;max-width:1100px;margin:auto;padding:16px}"
             "section{display:grid;grid-template-columns:1fr 1fr;gap:16px;"
             "border-top:1px solid #ccc;padding:16px 0}"
             "img{max-width:100%}</style>",
             "<h1>Figure description spot-check (20, non-held-out)</h1>",
             "<p>For each: is every statement visible in the image, and is nothing interpreted? "
             "Note any problem.</p>"]
    for r in sample[:20]:
        conv = json.loads((MD / f"study-{r['study_id']}/conversion.json").read_text())
        fig = next(f for f in conv["figures"] if f["figure_id"] == r["figure_id"])
        img = f"study-{r['study_id']}/figures/{fig['source_image']}"
        parts.append(
            f"<section><div><img src=\"{html.escape(img)}\"></div><div><b>Study {r['study_id']} "
            f"{r['figure_id']} · PDF page {fig['page']}</b>"
            f"<p><i>{html.escape(fig['caption'] or '(no caption)')}</i></p>"
            f"<p>{html.escape(r['description'])}</p></div></section>"
        )
    (MD / "SPOTCHECK.html").write_text("\n".join(parts))
    print(MD / "SPOTCHECK.html")


if __name__ == "__main__":
    main()
