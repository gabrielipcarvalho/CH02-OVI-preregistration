"""Report one frozen final-phase condition from its ledger: LOOP_DESIGN §1 measures with denominators.

Public output holds counts only. A private cell file (quotes, reasons) feeds the refinement analysis.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline.study.final_phase import FinalRecords, location  # noqa: E402
from pipeline.study.records import PILLARS  # noqa: E402

RATERS = ("r1", "r2", "r3")
TRUNCATED = {"max_tokens", "length", "incomplete"}
TARGETS = {"coverage": 0.80, "evidence_failure_rate": 0.10, "conditional_agreement": 0.85}
FALLBACK_COVERAGE = 0.45


def _obj(value):
    """Exports decode some JSON columns already; accept either form."""
    return value if isinstance(value, dict) else json.loads(value)


def outcomes(store: FinalRecords, run: str) -> tuple[dict, dict]:
    """Each requested (study, rater, pillar) → numeric | null | failure category | pending."""
    e = store.export(run)
    m = store.manifest(run)
    ids = [p["study_id"] for p in m["papers"]]
    cells = {(sid, r, pl): {"kind": "pending"} for sid in ids for r in RATERS for pl in PILLARS}
    for j in e["judgments"]:
        c = _obj(j["payload"])
        key = (j["study"], j["rater"], j["pillar"])
        if c["status"] == "scored":
            cells[key] = {
                "kind": "numeric",
                "score": c["score"],
                "quote": c["quote"],
                "locator": c["locator"],
                "reason": c["reason"],
            }
        else:
            cells[key] = {"kind": "null", "status": c["status"], "reason": c["reason"]}
    for d in e["dispositions"]:
        p = _obj(d["payload"])
        failed = p.get("failed_pillars") or list(PILLARS)
        for pl in failed:
            detail = p.get("pillar_failures", {}).get(pl, {})
            cells[(d["study"], d["rater"], pl)] = {
                "kind": "failure",
                "category": detail.get("status", p["status"]),
                "reason": detail.get("reason", p["reason"]),
            }
    attempts = {a["id"]: a for a in e["attempts"]}
    requests = {q["id"]: q for q in e["requests"]}
    usage = Counter()
    for c in e["completions"]:
        r = _obj(c["result"])
        rater = requests[attempts[c["attempt_id"]]["request_id"]]["rater"]
        provider = m["models"][rater]["provider"]
        usage[provider + "_usd"] += c["effective_charge"] or 0
        usage[provider + "_input_tokens"] += r.get("input_tokens") or 0
        usage[provider + "_output_tokens"] += r.get("output_tokens") or 0
        usage["truncated_" + rater] += r.get("finish_reason") in TRUNCATED
        usage["attempts_" + rater] += 1
    return cells, dict(usage)


def report(condition: str) -> tuple[dict, list]:
    frozen = json.loads((location() / "FREEZE.json").read_text())["conditions"][condition]
    store = FinalRecords(location() / "programme.sqlite3")
    per_run, usage = {}, Counter()
    for run in frozen["runs"]:
        per_run[run], u = outcomes(store, run)
        usage.update(u)
    kinds, by_rater, failures = Counter(), {r: Counter() for r in RATERS}, {r: Counter() for r in RATERS}
    panels = complete = agree = unanimous_null = 0
    profiles, private = Counter(), []
    for run, cells in per_run.items():
        for (sid, rater, pl), c in cells.items():
            kinds[c["kind"]] += 1
            by_rater[rater][c["kind"]] += 1
            if c["kind"] == "failure":
                failures[rater][c["category"]] += 1
            private.append({"run": run, "study": sid, "rater": rater, "pillar": pl, **c})
        studies = sorted({k[0] for k in cells})
        for sid in studies:
            for pl in PILLARS:
                panels += 1
                trio = [cells[(sid, r, pl)] for r in RATERS]
                if all(c["kind"] == "numeric" for c in trio):
                    complete += 1
                    agree += len({c["score"] for c in trio}) == 1
                elif all(c["kind"] == "null" and c["status"] == "applicability_uncertain" for c in trio):
                    unanimous_null += 1
            for r in RATERS:
                four = [cells[(sid, r, pl)] for pl in PILLARS]
                if all(c["kind"] == "numeric" for c in four):
                    profiles[f"{r}:OVI={min(c['score'] for c in four)}"] += 1
    repeat_complete = repeat_same = 0
    runs = list(per_run)
    for key in per_run[runs[0]]:
        vals = [per_run[run][key] for run in runs]
        if all(v["kind"] == "numeric" for v in vals):
            repeat_complete += 1
            repeat_same += len({v["score"] for v in vals}) == 1
    requested = sum(kinds.values())
    evidence = sum(f["evidence_failure"] for f in failures.values())
    result = {
        "condition": condition,
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "requested_judgments": requested,
        "judgments": dict(kinds),
        "by_rater": {r: dict(v) for r, v in by_rater.items()},
        "failures_by_rater": {r: dict(v) for r, v in failures.items()},
        "panels_requested": panels,
        "panels_complete": complete,
        "panels_complete_and_agreeing": agree,
        "primary_complete_and_agreeing_rate": round(agree / panels, 4),
        "coverage": round(complete / panels, 4),
        "conditional_agreement": round(agree / complete, 4) if complete else None,
        "evidence_failure_rate": round(evidence / requested, 4),
        # Amendment 2 (post-hoc secondary): agreed scope nulls are resolved, not missing.
        "secondary_unanimous_null_panels": unanimous_null,
        "secondary_resolved_panel_rate": round((agree + unanimous_null) / panels, 4),
        "repeat_tuples_complete": repeat_complete,
        "repeat_tuples_identical": repeat_same,
        "complete_profiles": dict(profiles),
        "usage": {k: round(v, 4) if isinstance(v, float) else v for k, v in usage.items()},
    }
    result["targets_met"] = {
        "coverage": result["coverage"] >= TARGETS["coverage"],
        "evidence_failure_rate": result["evidence_failure_rate"] <= TARGETS["evidence_failure_rate"],
        "conditional_agreement": (result["conditional_agreement"] or 0) >= TARGETS["conditional_agreement"],
    }
    if condition == "DEV_C0":
        result["model_fallback_rule"] = {
            "threshold_coverage": FALLBACK_COVERAGE,
            "triggered": result["coverage"] < FALLBACK_COVERAGE,
        }
    return result, private


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("condition")
    a = ap.parse_args()
    result, private = report(a.condition)
    out = ROOT / f"docs/final-phase-2026-10-28/results/{a.condition}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n")
    (location() / f"{a.condition}_cells.json").write_text(json.dumps(private, indent=1) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
