"""Generate factual figure descriptions for md-v1 papers, then render the described Markdown.

One vision call per captioned figure, append-only JSONL ledger, resumable, hard spending cap. The
describer must not be one of the three study raters. Descriptions are frozen once rendered; a
re-description is a new input version, never an in-place edit.

  --estimate          count figures and price the run; no calls
  --execute           describe pending figures (stops on any billing/credit error)
  --render            write paper.described.md for every paper whose figures are all described
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline.study.markdown_inputs import insert_descriptions, sha256  # noqa: E402

# October study raters plus the final-phase raters (28 Oct switch): none may describe figures.
RATER_MODELS = {"gpt-6-astra", "claude-opus-4-8", "glm-5.3", "gpt-6.1-sol", "claude-sonnet-5-5"}
PROMPT_VERSION = "figure-describe-v1"
PROMPT = """You are describing one figure from a published research paper for a reader who cannot see it.
The printed caption, if any, is given for orientation only.

Describe only what is visible:
- the kind of figure (photograph, line chart, bar chart, table image, diagram, screenshot, ...);
- for charts: each axis label and unit, the legend entries, and the plotted series;
- every number, label or piece of text legible in the image, transcribed exactly;
- the visible pattern stated neutrally (for example "values rise from about 0.6 to 0.9 across epochs").

Do not interpret significance, do not judge quality or readiness, do not infer anything that is not
visible, and do not repeat the caption. If parts are illegible, say so. At most 180 words, plain prose.

Caption: {caption}"""
# USD per million input/output tokens (Anthropic first-party list price, model table cached 2026-10-06).
PRICES = {"claude-opus-5-5": (4.0, 20.0)}
EST_INPUT_TOKENS, EST_OUTPUT_TOKENS = 2200, 400  # output includes any adaptive-thinking tokens
MAX_TOKENS = 2000


def figures(root: Path) -> list[dict]:
    rows = []
    for conv in sorted(root.glob("study-*/conversion.json"), key=lambda p: int(p.parent.name.split("-")[1])):
        data = json.loads(conv.read_text())
        for f in data["figures"]:
            if f["to_describe"]:
                image = conv.parent / "figures" / f["source_image"]
                rows.append({**f, "study_id": data["study_id"], "image": image})
    return rows


def ledger(path: Path) -> dict[tuple[int, str], dict]:
    done = {}
    if path.exists():
        for line in path.read_text().splitlines():
            r = json.loads(line)
            if r.get("status") == "ok":
                done[(r["study_id"], r["figure_id"])] = r
    return done


def spent(path: Path) -> float:
    if not path.exists():
        return 0.0
    return sum(json.loads(line).get("cost_usd", 0.0) for line in path.read_text().splitlines())


def call(model: str, key: str, image: bytes, caption: str) -> dict:
    body = {
        "model": model,
        "max_tokens": MAX_TOKENS,
        # Sampling parameters are rejected by the API; low effort keeps a transcription task short.
        # No refusal fallback: a different model must never silently write part of the frozen input.
        "output_config": {"effort": "low"},
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": base64.b64encode(image).decode(),
                        },
                    },
                    {"type": "text", "text": PROMPT.format(caption=caption or "(none detected)")},
                ],
            }
        ],
    }
    r = httpx.post(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json=body,
        timeout=120,
    )
    return {"http_status": r.status_code, "body": r.json() if r.content else {}}


def execute(root: Path, model: str, max_usd: float, secret: Path) -> None:
    """Describe pending figures until done, a billing error, or the cap would be exceeded."""
    if model in RATER_MODELS:
        raise ValueError("The figure describer must not be one of the study raters")
    if model not in PRICES:
        raise ValueError(f"No verified price recorded for {model}; add it to PRICES first")
    key = secret.read_text().strip()
    path = root / "figure_descriptions.jsonl"
    done = ledger(path)
    pin, pout = PRICES[model]
    for f in figures(root):
        if (f["study_id"], f["figure_id"]) in done:
            continue
        reserve = (EST_INPUT_TOKENS * pin + MAX_TOKENS * pout) / 1e6
        if spent(path) + reserve > max_usd:
            print(f"Stopping: next call could exceed the US${max_usd:.2f} cap")
            return
        image = f["image"].read_bytes()
        if sha256(image) != f["image_sha256"]:
            raise ValueError(f"Image drift for study {f['study_id']} {f['figure_id']}")
        result = call(model, key, image, f["caption"])
        body, status = result["body"], result["http_status"]
        usage = body.get("usage", {})
        cost = (usage.get("input_tokens", 0) * pin + usage.get("output_tokens", 0) * pout) / 1e6
        text = "".join(b.get("text", "") for b in body.get("content", []) if b.get("type") == "text").strip()
        ok = status == 200 and body.get("stop_reason") == "end_turn" and bool(text)
        record = {
            "study_id": f["study_id"],
            "figure_id": f["figure_id"],
            "image_sha256": f["image_sha256"],
            "model": model,
            "returned_model": body.get("model"),
            "prompt_version": PROMPT_VERSION,
            "prompt_sha256": sha256(PROMPT),
            "http_status": status,
            "stop_reason": body.get("stop_reason"),
            "usage": usage,
            "cost_usd": cost,
            "status": "ok" if ok else "failed",
            "description": text if ok else None,
            "error": None if ok else body.get("error"),
            "at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        with path.open("a") as fh:
            fh.write(json.dumps(record) + "\n")
        if status in (400, 401, 402, 403, 429) and not ok:
            print(f"Stopping on provider error {status}: {body.get('error')}")
            return
    print(f"Done. Ledger total US${spent(path):.4f}")


def render(root: Path) -> None:
    """Write paper.described.md only where every figure slot has exactly one successful description."""
    done = ledger(root / "figure_descriptions.jsonl")
    for folder in sorted(root.glob("study-*")):
        sid = int(folder.name.split("-")[1])
        out = folder / "paper.described.md"
        if out.exists():
            continue
        wanted = [f for f in figures(root) if f["study_id"] == sid]
        if any((sid, f["figure_id"]) not in done for f in wanted):
            print(f"study {sid}: incomplete, not rendered")
            continue
        models = {done[(sid, f["figure_id"])]["model"] for f in wanted} or {"none"}
        md = insert_descriptions(
            (folder / "paper.md").read_text(),
            {f["figure_id"]: done[(sid, f["figure_id"])]["description"] for f in wanted},
            model=",".join(sorted(models)),
        )
        out.write_text(md)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", type=Path, default=ROOT / ".research-private/markdown-v1")
    ap.add_argument("--model", default="claude-opus-5-5")
    ap.add_argument("--max-usd", type=float, default=15.0)
    ap.add_argument("--secret", type=Path, default=Path.home() / ".secrets/anthropic-api-key")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--estimate", action="store_true")
    mode.add_argument("--execute", action="store_true")
    mode.add_argument("--render", action="store_true")
    a = ap.parse_args()
    if a.estimate:
        n = len(figures(a.root))
        pin, pout = PRICES[a.model]
        usd = n * (EST_INPUT_TOKENS * pin + EST_OUTPUT_TOKENS * pout) / 1e6
        print(f"{n} figures; estimated US${usd:.2f} with {a.model}")
    elif a.execute:
        execute(a.root, a.model, a.max_usd, a.secret)
    else:
        render(a.root)


if __name__ == "__main__":
    main()
