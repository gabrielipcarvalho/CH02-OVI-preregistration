"""Replay the fixed 52 + 20 localisation cases against md-v1 page sections; no provider calls.

Expected outcomes come from the frozen October qualification manifests and are never edited here.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline.study.evidence_md import VERSION, evidence_check_md  # noqa: E402
from pipeline.study.records import StudyError  # noqa: E402

PRIVATE = ROOT / ".research-private"
MANIFESTS = [
    PRIVATE / "qualification-live-v1/FROZEN_QUALIFICATION.json",
    PRIVATE / "qualification-live-v1/NUMERIC_CHALLENGE.json",
]


def qualify(md_root: Path, md_manifest: Path, out: Path) -> dict:
    """Hash-check that each md-v1 paper derives from the case's source PDF before replaying it."""
    pdf_of = {p["study_id"]: p["pdf_sha256"] for p in json.loads(md_manifest.read_text())["papers"]}
    inputs = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in MANIFESTS}
    rows = []
    for case in [c for p in MANIFESTS for c in json.loads(p.read_text())["cases"]]:
        sid = int(case["source_study"])
        if pdf_of[sid] != case["source_pdf_sha256"]:
            raise ValueError(f"md-v1 study {sid} was not converted from the case's source PDF")
        markdown = (md_root / f"study-{sid}/paper.md").read_text()
        cell = {"quote": case["quote"], "locator": case["locator"], "status": "scored"}
        try:
            detail = evidence_check_md(cell, markdown)
            actual = detail["status"]
        except StudyError as exc:
            actual, detail = "reject", {"reason": str(exc)}
        rows.append({"id": case["id"], "study": sid, "expected": case["expected"], "actual": actual,
                     "passed": actual == case["expected"], "detail": detail})
    result = {
        "validator": VERSION,
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "input_manifest_hashes": inputs,
        "md_manifest_sha256": hashlib.sha256(md_manifest.read_bytes()).hexdigest(),
        "cases": rows,
        "passed": sum(r["passed"] for r in rows),
        "total": len(rows),
        "claim": "Replay of exposed, fixed examples only; not accuracy, prevalence or semantic validity.",
    }
    if out.exists():
        raise FileExistsError("Use a new output path; qualification records are never overwritten")
    out.write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--md-root", type=Path, default=PRIVATE / "markdown-v1")
    ap.add_argument(
        "--md-manifest", type=Path, default=ROOT / "docs/final-phase-2026-10-28/MARKDOWN_MANIFEST.json"
    )
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    r = qualify(a.md_root, a.md_manifest, a.out)
    print(json.dumps({"passed": r["passed"], "total": r["total"]}))
    for row in r["cases"]:
        if not row["passed"]:
            reason = row["detail"].get("reason", "")
            print("FAIL", row["id"], row["study"], row["expected"], row["actual"], reason)
    sys.exit(0 if r["passed"] == r["total"] else 1)
