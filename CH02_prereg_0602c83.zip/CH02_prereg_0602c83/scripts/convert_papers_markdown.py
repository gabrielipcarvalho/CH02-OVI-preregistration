"""Convert the 65 hash-verified primary PDFs into md-v1 inputs; no provider calls, no overwrites.

Paper text and figure images are copyrighted, so they go to the private archive. Only a text-free
manifest (hashes, counts, fidelity) is written for the public record.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pipeline.study.markdown_inputs import convert, fidelity, legacy_text, sha256, toolchain  # noqa: E402

MANIFEST = ROOT / "docs/study-2026-09-28/INPUT_MANIFEST.json"
PAPERS = ROOT / "reviewer_packet/papers"
RECALL_REVIEW = 0.95
UNRESOLVED_REVIEW = 3  # isolated unresolved runs are mostly URLs/e-mails; three or more suggest real gluing


def source_pdf(sid: int, expected: str) -> Path:
    """Exactly one local PDF whose bytes match the frozen study manifest, or a loud failure."""
    matches = list(PAPERS.glob(f"{sid}.*.pdf"))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected exactly one PDF for study {sid}, found {len(matches)}")
    if sha256(matches[0].read_bytes()) != expected:
        raise ValueError(f"Study {sid} PDF does not match the frozen manifest hash")
    return matches[0]


def run(out: Path, public: Path, only: list[int] | None) -> dict:
    if out.exists() or public.exists():
        raise FileExistsError("Refusing to overwrite an existing conversion; choose new output paths")
    papers = json.loads(MANIFEST.read_text())["papers"]
    if only:
        papers = [p for p in papers if p["study_id"] in set(only)]
    out.mkdir(parents=True)
    rows = []
    for p in sorted(papers, key=lambda p: p["study_id"]):
        sid = p["study_id"]
        pdf = source_pdf(sid, p["pdf_sha256"])
        folder = out / f"study-{sid}"
        result = convert(pdf, folder / "figures")
        (folder / "paper.md").write_text(result["markdown"])
        check = fidelity(result["markdown"], legacy_text(pdf))
        record = {
            "study_id": sid,
            "pdf_sha256": p["pdf_sha256"],
            "md_sha256": sha256(result["markdown"]),
            "md_bytes": len(result["markdown"].encode()),
            "pages": result["pages"],
            "ocr": result["ocr"],
            "figures_total": len(result["figures"]),
            "figures_to_describe": sum(f["to_describe"] for f in result["figures"]),
            "fidelity": check,
            "spacing": result["spacing"],
            "needs_review": check["recall"] is None
            or check["recall"] < RECALL_REVIEW
            or result["ocr"]
            or result["spacing"]["unresolved_runs"] >= UNRESOLVED_REVIEW,
        }
        detail = {**record, "figures": result["figures"]}
        (folder / "conversion.json").write_text(json.dumps(detail, indent=1))
        rows.append(record)
        n_fig = record["figures_to_describe"]
        print(f"study {sid}: {result['pages']}p, {n_fig} figures, recall {check['recall']}")
    manifest = {
        "version": "md-v1",
        "toolchain": toolchain(),
        "recall_review_threshold": RECALL_REVIEW,
        "papers": rows,
        "note": "Hashes and counts only; paper text and images are private (copyright).",
    }
    public.parent.mkdir(parents=True, exist_ok=True)
    public.write_text(json.dumps(manifest, indent=1) + "\n")
    return manifest


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", type=Path, required=True, help="new private directory for md-v1 papers")
    ap.add_argument("--public-manifest", type=Path, required=True, help="new text-free manifest path")
    ap.add_argument("--only", type=int, nargs="*", help="restrict to these study IDs")
    args = ap.parse_args()
    m = run(args.out, args.public_manifest, args.only)
    review = [r["study_id"] for r in m["papers"] if r["needs_review"]]
    print(f"{len(m['papers'])} papers converted; needs review: {review}")


if __name__ == "__main__":
    main()
