"""The 42-paper run, CORPUS3: v1.2 + H5 against v1.0 + the EVAL_ORIGINAL handbook, discussion in both arms.

Measures declared in CORPUS_RUN_MEASURES.md (29 Oct, and the 30 and 31 Oct addenda) before freezing. Panels
are paired by paper × pillar × execution; only paper-executions complete in both arms enter the comparison.
With --refined CORPUS3B_V12: the v1.2 arm re-run under revision 3 against the same v1.0 arm (CORPUS3B).
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from discussion_report import classify  # noqa: E402
from final_cycle_report import _obj  # noqa: E402
from v11_report import mechanics, trios  # noqa: E402

from pipeline.study.final_phase import (  # noqa: E402
    ARM_V10,
    ARM_V12,
    ARM_V12_R3,
    CORPUS,
    CORPUS_SCHEDULE,
    CORPUS_SEED,
    FinalRecords,
    location,
)
from pipeline.study.records import PILLARS, RATERS  # noqa: E402

RESOLVED = ("agree_score", "agree_not_applicable")
# The papers behind a v1.2 ruling, or considered for one (61); the declared sub-analysis splits on them.
RULED = (4, 11, 26, 41, 46, 50, 61, 66, 81)
# The papers behind revision 3 (CORPUS3_P4_FINDINGS.md), reported descriptively for CORPUS3B.
REVISION_3 = (35, 41, 48, 64, 67)
# The refined arm under comparison; main() sets it from --refined.
REFINED = ARM_V12
SEED, RESAMPLES = CORPUS_SEED, 10000


def complete(store: FinalRecords, run: str) -> set[int]:
    """Papers whose three R0 requests each ended in judgments or a recorded failure."""
    e = store.export(run)
    done = {j["request_id"] for j in e["judgments"]} | {d["request_id"] for d in e["dispositions"]}
    by_paper = Counter(q["study"] for q in e["requests"] if q["round"] == 0 and q["id"] in done)
    return {s for s, n in by_paper.items() if n == len(RATERS)}


def ovi(trio_by_pillar: dict) -> int | None:
    """OVI-Gate of an agreed profile: four agreed scores, minimum taken (DEC-0002)."""
    scores = []
    for p in PILLARS:
        t = trio_by_pillar[p]
        if classify(t) != "agree_score":
            return None
        scores.append(t[0][1])
    return min(scores)


def interval(per_paper: dict[int, tuple[int, int, int]], seed: str | None = None,
             resamples: int | None = None) -> list[float]:
    """95% interval of the pooled difference, resampling papers; values are (refined hits, v1.0 hits, panels).

    seed and resamples default to this run's (CORPUS_SEED, 10,000); the post-SLR report passes its own.
    """
    seed = SEED if seed is None else seed
    resamples = RESAMPLES if resamples is None else resamples
    rng, papers, diffs = random.Random(seed), sorted(per_paper), []
    for _ in range(resamples):
        a = b = n = 0
        for s in rng.choices(papers, k=len(papers)):
            x, y, k = per_paper[s]
            a, b, n = a + x, b + y, n + k
        diffs.append((a - b) / n)
    diffs.sort()
    return [round(diffs[int(0.025 * resamples)], 4), round(diffs[int(0.975 * resamples) - 1], 4)]


def compare(rows: list[dict], measure, refined: str | None = None, comparator: str | None = None,
            seed: str | None = None) -> dict:
    """Paired comparison of two arms on the same panels; arms and seed default to this run's."""
    refined = REFINED if refined is None else refined
    comparator = ARM_V10 if comparator is None else comparator
    per_paper: dict[int, list[int]] = {}
    for r in rows:
        x = per_paper.setdefault(r["study"], [0, 0, 0])
        x[0] += measure(r[refined])
        x[1] += measure(r[comparator])
        x[2] += 1
    n = len(rows)
    hits = {arm: sum(measure(r[arm]) for r in rows) for arm in (refined, comparator)}
    return {
        "panels": n,
        "v1_2": hits[refined], "v1_0": hits[comparator],
        "difference": round((hits[refined] - hits[comparator]) / n, 4) if n else None,
        "interval_95": interval({s: tuple(v) for s, v in per_paper.items()}, seed) if n else None,
        "only_v1_2": sum(measure(r[refined]) and not measure(r[comparator]) for r in rows),
        "only_v1_0": sum(measure(r[comparator]) and not measure(r[refined]) for r in rows),
    }


def main() -> None:
    global REFINED
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--refined", choices=(ARM_V12, ARM_V12_R3), default=ARM_V12)
    REFINED = ap.parse_args().refined
    schedule = CORPUS_SCHEDULE if REFINED == ARM_V12 else REFINED.split("_")[0]
    frozen = json.loads((location() / "FREEZE.json").read_text())["conditions"]
    store = FinalRecords(location() / "programme.sqlite3")
    runs = {arm: frozen[arm]["runs"] for arm in (REFINED, ARM_V10)}
    done = {(arm, e): complete(store, run) for arm in runs for e, run in enumerate(runs[arm], 1)}
    rows, profiles = [], {arm: Counter() for arm in runs}
    for e in (1, 2):
        both = done[(REFINED, e)] & done[(ARM_V10, e)]
        for s in sorted(both):
            t = {arm: trios(store, runs[arm][e - 1], s) for arm in runs}
            for arm in runs:
                value = ovi(t[arm])
                profiles[arm]["ovi_" + str(value) if value is not None else "no_agreed_profile"] += 1
                if all(classify(t[arm][p]) == "agree_not_applicable" for p in PILLARS[:3]):
                    profiles[arm]["p1_p3_agreed_not_applicable"] += 1
            for p in PILLARS:
                rows.append({"execution": e, "study": s, "pillar": p,
                             **{arm: classify(t[arm][p]) for arm in runs},
                             **{arm + "_trio": t[arm][p] for arm in runs}})
    missing = {f"{arm}/{e}": sorted(set(CORPUS) - papers) for (arm, e), papers in done.items()}

    def resolved(c):
        return c in RESOLVED

    def agreeing(c):
        return c == "agree_score"

    stability = {}
    for arm in runs:
        pairs = Counter()
        for s in CORPUS:
            for p in PILLARS:
                two = [r for r in rows if r["study"] == s and r["pillar"] == p]
                if len(two) == 2 and all(resolved(r[arm]) for r in two):
                    pairs["same" if two[0][arm + "_trio"] == two[1][arm + "_trio"] else "changed"] += 1
                elif len(two) == 2:
                    pairs["not_resolved_in_both"] += 1
        stability[arm] = dict(pairs)

    after, final_class = {}, {}
    for arm in runs:
        for e, run in enumerate(runs[arm], 1):
            event = [ev for ev in store.export(run)["events"] if ev["kind"] == "discussion_dispositioned"]
            if event:
                outcomes = _obj(event[0]["payload"])["outcomes"]
                c = Counter()
                for study, by_pillar in outcomes.items():
                    for p in PILLARS:
                        final = by_pillar[p].get("final")
                        trio = [tuple(final[r]) if final.get(r) else None for r in RATERS] if final else None
                        verdict = classify(trio) if trio else by_pillar[p]["stop"]
                        c[verdict] += 1
                        final_class[(arm, e, int(study), p)] = verdict
                after[f"{arm}/{e}"] = dict(c)
    # Paired after-discussion rows: only paper-executions discussed (or settled) in both arms.
    after_rows = [{"study": r["study"], **{arm: final_class[(arm, r["execution"], r["study"], r["pillar"])]
                                           for arm in runs}}
                  for r in rows if all((arm, r["execution"], r["study"], r["pillar"]) in final_class
                                       for arm in runs)]

    # Descriptive: the published package run twice, CORPUS2_V10 against this run's v1.0 arm, same papers.
    replication = Counter()
    earlier = frozen.get("CORPUS2_V10", {}).get("runs", [])
    for e, (old, new) in enumerate(zip(earlier, runs[ARM_V10], strict=False), 1):
        for s in sorted(done[(ARM_V10, e)] & complete(store, old)):
            a, b = trios(store, old, s), trios(store, new, s)
            for p in PILLARS:
                replication["same_trio" if a[p] == b[p] else "different_trio"] += 1
                replication["resolved_corpus2"] += classify(a[p]) in RESOLVED
                replication["resolved_corpus3"] += classify(b[p]) in RESOLVED

    # Descriptive for CORPUS3B: the same refined arm under revision 2 (CORPUS3) and revision 3, same panels.
    revisions = Counter()
    if REFINED != ARM_V12:
        for e, (old, new) in enumerate(zip(frozen[ARM_V12]["runs"], runs[REFINED], strict=True), 1):
            for s in sorted(done[(REFINED, e)] & complete(store, old)):
                a, b = trios(store, old, s), trios(store, new, s)
                for p in PILLARS:
                    revisions["same_trio" if a[p] == b[p] else "different_trio"] += 1
                    revisions["resolved_revision_2"] += classify(a[p]) in RESOLVED
                    revisions["resolved_revision_3"] += classify(b[p]) in RESOLVED
                    if p == "P4":
                        revisions["p4_resolved_revision_2"] += classify(a[p]) in RESOLVED
                        revisions["p4_resolved_revision_3"] += classify(b[p]) in RESOLVED

    report = {
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "label": f"42-paper run {schedule} ({REFINED} against {ARM_V10}); measures declared before freezing "
        "(CORPUS_RUN_MEASURES.md)",
        "missing_paper_executions": missing,
        "counts": {arm: dict(Counter(r[arm] for r in rows)) for arm in runs},
        "primary_resolved": compare(rows, resolved),
        "secondary_complete_and_agreeing": compare(rows, agreeing),
        "primary_by_paper_group": {
            "ruled": compare([r for r in rows if r["study"] in RULED], resolved),
            "other": compare([r for r in rows if r["study"] not in RULED], resolved),
        },
        "descriptive_revision_3_papers": compare([r for r in rows if r["study"] in REVISION_3], resolved),
        "by_pillar": {p: {arm: dict(Counter(r[arm] for r in rows if r["pillar"] == p)) for arm in runs}
                      for p in PILLARS},
        "profiles": {arm: dict(v) for arm, v in profiles.items()},
        "repeat_stability": stability,
        "mechanics": {arm: mechanics(store, runs[arm]) for arm in runs},
        "after_discussion": after,
        "secondary_after_discussion_resolved": compare(after_rows, resolved) if after_rows else None,
        "descriptive_v1_0_corpus2_vs_corpus3": dict(replication),
        "descriptive_revision_2_vs_revision_3": dict(revisions) or None,
        "rows": rows,
    }
    out = ROOT / f"docs/final-phase-2026-10-28/results/{schedule}_RUN.json"
    out.write_text(json.dumps(report, indent=2, default=list) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "rows"}, indent=1, default=list))


if __name__ == "__main__":
    main()
