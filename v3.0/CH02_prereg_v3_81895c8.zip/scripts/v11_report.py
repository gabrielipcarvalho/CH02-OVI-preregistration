"""Exploratory rubric v1.1 checks (CHECK_V11, CHECK_V11_DEV) against the refined-handbook runs.

Expectations E1–E6 were declared in WORKPLAN_RUBRIC_V1_1.md before dispatch. Comparators share the
current pipeline except rubric and handbook: DISC_V13_B for papers 17, 27, 28, 40, 47 and 59, and
CHECK_V13 executions 1–2 for 18, 31 and 72. CHECK_V11_DEV is compared with the C3 development cycle on
the cells that rules B–O were written for. Exploratory, not pre-registered: these papers were used to
write the rules.
"""

from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from discussion_report import classify  # noqa: E402
from final_cycle_report import _obj  # noqa: E402

from pipeline.study.discussion import round_results, verdict  # noqa: E402
from pipeline.study.final_phase import V11, FinalRecords, location  # noqa: E402
from pipeline.study.records import PILLARS, RATERS  # noqa: E402

CONTROLS = (18, 31, 72)
SCOPE = (28, 40, 47, 59)
# Development cells each handbook rule was written for (CHANGESET_C1..C3.md).
RULE_CELLS = {
    "B": [(42, "P1"), (42, "P3")], "C": [(77, "P2")], "D": [(60, "P1")], "E": [(77, "P3")],
    "F/J/O": [(6, "P4"), (53, "P4")], "K": [(38, "P4"), (83, "P4")], "L": [(77, "P3")],
    "M": [(60, "P1")], "N": [(60, "P2")],
}


def trios(store: FinalRecords, run: str, study: int, n: int = 0) -> dict:
    r = round_results(store, run, study, n)
    return {p: [verdict(r[(x, p)]) if r.get((x, p)) else None for x in RATERS] for p in PILLARS}


def majority(trio: list) -> tuple | None:
    top, k = Counter(v for v in trio if v).most_common(1)[0] if any(trio) else (None, 0)
    return top if k >= 2 else None


def failures(store: FinalRecords, run: str) -> Counter:
    out = Counter()
    for d in store.export(run)["dispositions"]:
        reason = str(_obj(d["payload"]).get("reason", ""))
        out["evidence" if "evidence" in reason.lower() or "quote" in reason.lower() else "format/other"] += 1
    return out


def mechanics(store: FinalRecords, runs: list[str]) -> dict:
    stage2 = resampled = adjacent = cost = 0.0
    fail = Counter()
    for run in runs:
        e = store.export(run)
        stage2 += sum(a["stage"] % 3 == 2 for a in e["attempts"])  # 5: correction on a re-request
        # one per re-request: stages 3, 6 and 9 (the last two under unreadable-resample-v4)
        resampled += sum(a["stage"] >= 3 and a["stage"] % 3 == 0 and a["transport"] == 0
                         for a in e["attempts"])
        cost += sum(c["charged"] or 0 for c in e["completions"])
        for j in e["judgments"]:
            method = str(_obj(j["payload"]).get("evidence_check", {}).get("method", ""))
            adjacent += "adjacent_page" in method
        fail += failures(store, run)
    return {"correction_turns": int(stage2), "re_requests": int(resampled),
            "adjacent_page_accepts": int(adjacent),
            "failed_requests": dict(fail), "cost_usd": round(cost, 2)}


def main() -> None:
    frozen = json.loads((location() / "FREEZE.json").read_text())["conditions"]
    store = FinalRecords(location() / "programme.sqlite3")
    v11 = frozen["CHECK_V11"]["runs"]
    comparator = {s: frozen["DISC_V13_B"]["runs"] for s in (17, 27, 28, 40, 47, 59)}
    comparator |= {s: frozen["CHECK_V13"]["runs"][:2] for s in CONTROLS}

    per_paper, before, after, ref = {}, Counter(), Counter(), Counter()
    for s in V11:
        rows = []
        for e, (run, old) in enumerate(zip(v11, comparator[s], strict=True), 1):
            now, prior = trios(store, run, s), trios(store, old, s)
            outcomes = next(_obj(ev["payload"])["outcomes"] for ev in store.export(run)["events"]
                            if ev["kind"] == "discussion_dispositioned")[str(s)]
            for p in PILLARS:
                final = [tuple(v) if v else None for v in (outcomes[p]["final"][r] for r in RATERS)]
                rows.append({"execution": e, "pillar": p, "v11_r0": now[p], "v11_after": final,
                             "c3_r0": prior[p], "class_v11_r0": classify(now[p]),
                             "class_v11_after": classify(final), "class_c3_r0": classify(prior[p])})
                before[classify(now[p])] += 1
                after[classify(final)] += 1
                ref[classify(prior[p])] += 1
        per_paper[s] = rows

    def resolved(rows, key):
        return sum(r[key] in ("agree_score", "agree_not_applicable") for r in rows)

    def cells(s, p, key="v11_r0"):
        return [r[key] for r in per_paper[s] if r["pillar"] == p]

    na = ("applicability_uncertain", None)
    expectations = {
        "E1_paper17_P1_unanimous_0": all(t == [("scored", 0)] * 3 for t in cells(17, "P1")),
        "E2_paper28_P1_P3_unanimous_na": all(t == [na] * 3 for p in ("P1", "P2", "P3") for t in cells(28, p)),
        "E3_scope_agreed_na": {
            "v11": sum(r["class_v11_r0"] == "agree_not_applicable" for s in SCOPE for r in per_paper[s]
                       if r["pillar"] != "P4"),
            "c3": sum(r["class_c3_r0"] == "agree_not_applicable" for s in SCOPE for r in per_paper[s]
                      if r["pillar"] != "P4"),
            "of": 24,
        },
        "E4_P4_r0": {s: cells(s, "P4") for s in (27, 47, 59)},
        "E5_controls_resolved": {s: {"v11": resolved(per_paper[s], "class_v11_r0"),
                                     "c3": resolved(per_paper[s], "class_c3_r0"), "of": 8} for s in CONTROLS},
    }
    resolved_by_paper = {
        s: {k: resolved(r, "class_" + k) for k in ("v11_r0", "v11_after", "c3_r0")}
        for s, r in per_paper.items()
    }

    dev_run = frozen["CHECK_V11_DEV"]["runs"][0]
    c3_runs = frozen["DEV_C3"]["runs"]
    rules = {}
    for rule, targets in RULE_CELLS.items():
        rules[rule] = []
        for s, p in targets:
            c3 = [trios(store, run, s)[p] for run in c3_runs]
            rules[rule].append({"study": s, "pillar": p, "c3_majorities": [majority(t) for t in c3],
                                "v11": trios(store, dev_run, s)[p]})
    dev_classes = Counter(classify(t) for s in {sid for v in RULE_CELLS.values() for sid, _ in v}
                          for t in trios(store, dev_run, s).values())
    dev_all = Counter()
    c3_all = Counter()
    for paper in store.manifest(dev_run)["papers"]:
        s = paper["study_id"]
        dev_all.update(classify(t) for t in trios(store, dev_run, s).values())
        for run in c3_runs:
            c3_all.update(classify(t) for t in trios(store, run, s).values())

    report = {
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "label": "exploratory, not pre-registered; papers used to write the rules",
        "check_v11": {
            "panels": sum(before.values()),
            "v11_r0": dict(before), "v11_after_discussion": dict(after), "c3_r0_comparator": dict(ref),
            "resolved_by_paper": resolved_by_paper, "expectations": expectations,
            "mechanics": mechanics(store, v11),
            "comparator_mechanics": mechanics(store, frozen["DISC_V13_B"]["runs"]),
        },
        "check_v11_dev": {
            "panels_v11": sum(dev_all.values()), "v11_r0": dict(dev_all),
            "c3_r0_two_executions": dict(c3_all), "rule_cells": rules,
            "rule_papers_v11": dict(dev_classes), "mechanics": mechanics(store, [dev_run]),
        },
        "rows": {str(k): v for k, v in per_paper.items()},
    }
    out = ROOT / "docs/final-phase-2026-10-28/results/CHECK_V11.json"
    out.write_text(json.dumps(report, indent=2, default=list) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "rows"}, indent=1, default=list))


if __name__ == "__main__":
    main()
