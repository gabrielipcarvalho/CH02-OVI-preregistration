"""The replication report: REPL_V12 against REPL_V10 (confirmatory) and REPL_V10_NOCONJ against REPL_V10
(exploratory ablation), as declared in docs/rerun-2026-11/PREREGISTRATION_REPLICATION.md (v3.0).

Every measure was written and tested before any replication data existed (Goal A, 18 Nov 2026).
- Rows: panels (paper × pillar × execution) of the paper-executions complete in each comparison's own two
  arms (all of them when the run completes; pre-registration, "Rows").
- Paired differences and paper-bootstrap intervals: `corpus_report.compare`, the same code as every earlier
  test, with the replication seed. The 90% interval for the equivalence reading comes from the same draws.
- Scope and score agreement: `posthoc_analyses.scope_vs_scores`, the code behind Table S8.
- `--parity` runs the confirmatory measures on the completed post-SLR ledger with its arms mapped in, and
  checks them against the committed POSTSLR_RUN_RESUMED.json and POSTHOC_ANALYSES.json before anything here
  is trusted.

Read a `.backup` copy of the ledger (`--ledger`), never the live one; FREEZE.json is read beside it. The
output holds IDs, classes and counts only: no paper text and no quotation.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import Counter
from math import comb
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from corpus_report import RESOLVED, compare, complete, interval  # noqa: E402
from discussion_report import classify  # noqa: E402
from posthoc_analyses import bca, paper_executions, scope_verdict, scope_vs_scores  # noqa: E402
from postslr_report import (  # noqa: E402
    agreed_levels,
    agreement_beyond_zero,
    coverage,
    out_of_scope,
    profiles,
    request_paths,
    stability,
)
from v11_report import mechanics, trios  # noqa: E402

from pipeline.study import final_phase as fp  # noqa: E402
from pipeline.study.records import PILLARS  # noqa: E402

REFINED, PUBLISHED, ABLATION = fp.ARM_REPL_V12, fp.ARM_REPL_V10, fp.ARM_REPL_NOCONJ
ARMS = (REFINED, PUBLISHED, ABLATION)
SEED = fp.REPL_SEED  # bootstrap, BCa and permutation seed, declared in the pre-registration
EXECUTIONS = (1, 2)
RESAMPLES = 10000
PERMUTATIONS = 20000
EQUIVALENCE_BOUND = 0.10  # ±10 points of resolved panels, a feasibility bound chosen in advance (D43)
MIN_PAPERS = 10  # below this, the three-way and equivalence readings are not used (descriptive only)
RESULTS = ROOT / "docs/rerun-2026-11/results"
POSTSLR_RESUMED = ROOT / "docs/postslr-2026-11/results/POSTSLR_RUN_RESUMED.json"
POSTHOC = ROOT / "docs/chapter-draft/supplement/POSTHOC_ANALYSES.json"
POSTHOC_SEED = "ch2-posthoc-20261112"  # the seed POSTHOC_ANALYSES.json used for its permutation test
LIVE = (ROOT / ".research-private/final-phase-live-v1/programme.sqlite3").resolve()


def resolved(c: str) -> bool:
    return c in RESOLVED


def agreeing(c: str) -> bool:
    return c == "agree_score"


def reading(interval_95: list[float] | None) -> str | None:
    """The three-way reading, unchanged from v2.0: lower bound > 0 transfers; upper < 0 reverses."""
    if interval_95 is None:
        return None
    low, high = interval_95
    return "transfers" if low > 0 else "reverses" if high < 0 else "not detected"


def equivalence(interval_90: list[float] | None, margin: float = EQUIVALENCE_BOUND) -> str | None:
    """The equivalence reading on the unrounded 90% interval (two one-sided tests at 5%):
    "within the bound" when it lies strictly inside (-margin, +margin); "beyond the bound" when it lies wholly
    at or beyond +margin or -margin; otherwise "not shown"."""
    if interval_90 is None:
        return None
    low, high = interval_90
    if -margin < low and high < margin:
        return "within the bound"
    return "beyond the bound" if low >= margin or high <= -margin else "not shown"


def rows_all_arms(store, runs: dict[str, list[str]], papers, arms) -> tuple[list[dict], dict]:
    """Panels of the paper-executions complete in every arm given (a recorded failure counts as complete);
    with two arms this is postslr_report.paired_rows."""
    done = {(arm, e): complete(store, run) for arm in arms for e, run in enumerate(runs[arm], 1)}
    rows = []
    for e in EXECUTIONS:
        common = set(papers)
        for arm in arms:
            common &= done[(arm, e)]
        for s in sorted(common):
            t = {arm: trios(store, runs[arm][e - 1], s) for arm in arms}
            for p in PILLARS:
                rows.append({
                    "execution": e,
                    "study": s,
                    "pillar": p,
                    **{arm: classify(t[arm][p]) for arm in arms},
                    **{arm + "_trio": t[arm][p] for arm in arms},
                })
    missing = {f"{arm}/{e}": sorted(set(papers) - d) for (arm, e), d in done.items()}
    return rows, missing


def per_paper(rows: list[dict], measure, a1: str, a0: str) -> dict[int, tuple[int, int, int]]:
    """(hits in a1, hits in a0, panels) per paper, in row order (the order the permutation test uses)."""
    out: dict[int, list[int]] = {}
    for r in rows:
        x = out.setdefault(r["study"], [0, 0, 0])
        x[0] += measure(r[a1])
        x[1] += measure(r[a0])
        x[2] += 1
    return {s: tuple(v) for s, v in out.items()}


def intervals(pp: dict, seed: str, resamples: int = RESAMPLES) -> dict[str, list[float]]:
    """95% and 90% percentile intervals from corpus_report.interval's draws (guard: the 95% one is equal)."""
    rng, papers, diffs = random.Random(seed), sorted(pp), []
    for _ in range(resamples):
        a = b = n = 0
        for s in rng.choices(papers, k=len(papers)):
            x, y, k = pp[s]
            a, b, n = a + x, b + y, n + k
        diffs.append((a - b) / n)
    diffs.sort()
    exact90 = [diffs[int(0.05 * resamples)], diffs[int(0.95 * resamples) - 1]]
    out = {
        "interval_95": [round(diffs[int(0.025 * resamples)], 4), round(diffs[int(0.975 * resamples) - 1], 4)],
        "interval_90": [round(v, 4) for v in exact90],
        "interval_90_exact": exact90,
    }
    if out["interval_95"] != interval(pp, seed, resamples):
        raise SystemExit("Bootstrap draws do not reproduce corpus_report.interval")
    return out


def paired(rows: list[dict], measure, a1: str, a0: str, seed: str) -> dict | None:
    """corpus_report.compare plus the 90% interval from the same draws; None when there are no panels."""
    if not rows:
        return None
    out = compare(rows, measure, a1, a0, seed)
    more = intervals(per_paper(rows, measure, a1, a0), seed)
    out["interval_90"], out["interval_90_exact"] = more["interval_90"], more["interval_90_exact"]
    return out


def permutation(pp: dict, seed: str, permutations: int = PERMUTATIONS) -> dict:
    """Paper-level sign-flip permutation test of the pooled difference (two-sided), and the exact sign test
    on papers; the procedure of posthoc_analyses.sign_and_permutation with the seed as a parameter."""
    d = {s: x - y for s, (x, y, _) in pp.items()}
    pos, neg = sum(v > 0 for v in d.values()), sum(v < 0 for v in d.values())
    m = pos + neg
    tail = sum(comb(m, k) for k in range(min(pos, neg) + 1)) / 2**m if m else 1.0
    total = sum(n for *_, n in pp.values())
    obs = sum(d.values()) / total
    rng, hits = random.Random(seed), 0
    vals = list(d.values())
    for _ in range(permutations):
        stat = sum(v if rng.random() < 0.5 else -v for v in vals) / total
        hits += abs(stat) >= abs(obs) - 1e-12
    return {
        "papers": len(d),
        "papers_favouring_first_arm": pos,
        "papers_favouring_second_arm": neg,
        "ties": len(d) - m,
        "sign_test_p_two_sided": round(min(1.0, 2 * tail), 6),
        "permutation_p_two_sided": round((hits + 1) / (permutations + 1), 6),
        "permutations": permutations,
        "seed": seed,
        "observed_difference": round(obs, 4),
    }


def kind_of_agreement(rows: list[dict], arm: str) -> dict:
    """Resolved panels split as in OUTCOME_RULES §2: agreed level 0, agreed above 0, agreed not applicable."""
    agreed = [r[arm + "_trio"][0][1] for r in rows if r[arm] == "agree_score"]
    return {
        "agreed_0": sum(v == 0 for v in agreed),
        "agreed_above_0": sum(v > 0 for v in agreed),
        "agreed_not_applicable": sum(r[arm] == "agree_not_applicable" for r in rows),
    }


def all_scored(trio) -> bool:
    return None not in trio and all(v[0] == "scored" for v in trio)


def scores_all_scored(rows: list[dict], a1: str, a0: str, seed: str, pillars=PILLARS) -> dict | None:
    """Identical scores on panels all three raters scored in both arms (Table S8 b), for the given pillars."""
    sub = [r for r in rows if r["pillar"] in pillars and all_scored(r[a1 + "_trio"])
           and all_scored(r[a0 + "_trio"])]
    return paired(sub, agreeing, a1, a0, seed)


def above_zero(trio) -> bool:
    """A panel with a score above 0: at least one rater gave a checked score above 0."""
    return any(v is not None and v[0] == "scored" and v[1] > 0 for v in trio)


def kind_rows(rows: list[dict], a1: str, a0: str, kind: str) -> list[dict]:
    """Rows with each arm's class replaced by whether the panel is resolved in that way (OUTCOME_RULES §2)."""
    def hit(r, a):
        if kind == "agreed_not_applicable":
            return r[a] == "agree_not_applicable"
        if r[a] != "agree_score":
            return False
        return (r[a + "_trio"][0][1] == 0) == (kind == "agreed_0")

    return [{**r, a1: hit(r, a1), a0: hit(r, a0)} for r in rows]


def scope_rows(rows: list[dict], a1: str, a0: str) -> tuple[list[dict], list[dict]]:
    """The rows behind Table S8 a (posthoc_analyses.scope_vs_scores), so their 90% interval can be added:
    per paper-execution (three identical in/out calls from P1-P3) and per panel (no failed judgment, and
    all three scored or all three did not)."""
    pe = {a: paper_executions(rows, a) for a in (a1, a0)}

    def agreed(by_pillar):
        calls = [scope_verdict(by_pillar, i) for i in range(3)]
        return calls[0] in ("in", "out") and len(set(calls)) == 1

    per_pe = [{"study": k[0], **{a: agreed(pe[a][k]) for a in (a1, a0)}} for k in sorted(pe[a1])]

    def same_scope(trio):
        return None not in trio and len({v[0] == "scored" for v in trio}) == 1

    per_panel = [{"study": r["study"], **{a: same_scope(r[a + "_trio"]) for a in (a1, a0)}} for r in rows]
    return per_pe, per_panel


def with_90(published: dict, mine: dict | None) -> dict:
    """posthoc's paired result with the 90% interval from the same rows; guard: the 95% parts are equal."""
    if mine is None:
        return published
    if {k: v for k, v in mine.items() if not k.startswith("interval_90")} != published:
        raise SystemExit("Scope or score rows differ from posthoc_analyses.scope_vs_scores")
    return mine


def comparison(rows: list[dict], a1: str, a0: str, seed: str, hazard: set[int]) -> dict:
    """Every declared measure of one paired comparison (first arm minus second)."""
    t = {"refined": a1, "comparator": a0, "rows": rows, "seed": seed}
    sv = scope_vs_scores(t) if rows else None
    no_hazard = [r for r in rows if r["study"] not in hazard]
    pp = per_paper(rows, resolved, a1, a0)
    scores = scope_pe = scope_panel = None
    if sv:
        scores = scores_all_scored(rows, a1, a0, seed)
        if sv["b_scores_on_panels_all_scored_in_both_arms"] is not None:
            scores = with_90(sv["b_scores_on_panels_all_scored_in_both_arms"], scores)
        pe_rows, panel_rows = scope_rows(rows, a1, a0)
        scope_pe = {**sv["a_scope_per_paper_execution"],
                    "paired": with_90(sv["a_scope_per_paper_execution"]["paired"],
                                      paired(pe_rows, bool, a1, a0, seed))}
        panel_paired = paired(panel_rows, bool, a1, a0, seed)
        scope_panel = {
            **sv["a_scope_per_panel"], "paired": with_90(sv["a_scope_per_panel"]["paired"], panel_paired)
        }
    return {
        "arms": [a1, a0],
        "resolved": paired(rows, resolved, a1, a0, seed),
        "complete_and_agreeing": paired(rows, agreeing, a1, a0, seed),
        "kind_of_agreement": {a: kind_of_agreement(rows, a) for a in (a1, a0)},
        "kind_of_agreement_paired": {
            k: paired(kind_rows(rows, a1, a0, k), bool, a1, a0, seed)
            for k in ("agreed_0", "agreed_above_0", "agreed_not_applicable")
        },
        "score_agreement_all_scored_in_both_arms": scores,
        "score_agreement_all_scored_in_both_arms_without_p3": scores_all_scored(
            rows, a1, a0, seed, tuple(p for p in PILLARS if p != "P3")
        ),
        "scope_agreement_per_paper_execution": scope_pe,
        "scope_agreement_per_panel": scope_panel,
        "without_hazard_detectors": {
            "resolved": paired(no_hazard, resolved, a1, a0, seed),
            "complete_and_agreeing": paired(no_hazard, agreeing, a1, a0, seed),
        },
        "permutation": permutation(pp, seed) if pp else None,
        "bca": bca(pp, seed) if len(pp) > 1 else None,
        "by_pillar_resolved": {
            p: paired([r for r in rows if r["pillar"] == p], resolved, a1, a0, seed) for p in PILLARS
        },
        "panels_with_a_failed_judgment": paired(
            [{**r, a1: None in r[a1 + "_trio"], a0: None in r[a0 + "_trio"]} for r in rows],
            bool, a1, a0, seed,
        ),
        "panels_with_a_score_above_0": paired(
            [{**r, a1: above_zero(r[a1 + "_trio"]), a0: above_zero(r[a0 + "_trio"])} for r in rows],
            bool, a1, a0, seed,
        ),
        "agreement_beyond_zero": {a: agreement_beyond_zero(rows, a) for a in (a1, a0)},
        "levels": {a: agreed_levels(rows, a) for a in (a1, a0)},
        "out_of_scope": {a: out_of_scope(rows, a) for a in (a1, a0)},
        "ovi_gate_profiles": {a: profiles(rows, a) for a in (a1, a0)},
        "repeat_stability": {a: stability(rows, a) for a in (a1, a0)},
        "coverage": {a: coverage(rows, a) for a in (a1, a0)},
        "counts": {a: dict(Counter(r[a] for r in rows)) for a in (a1, a0)},
    }


def refuse_live(ledger: Path) -> None:
    """FinalRecords opens a ledger read-write; the analysis must only ever open a .backup copy."""
    if ledger.resolve() == LIVE:
        raise SystemExit("Refusing: analyse a .backup copy, never the live ledger")


def report(ledger: Path) -> dict:
    refuse_live(ledger)
    store = fp.FinalRecords(ledger)
    frozen = json.loads((ledger.parent / "FREEZE.json").read_text())["conditions"]
    runs = {arm: frozen[arm]["runs"] for arm in ARMS}
    inputs = fp.postslr_inputs()
    papers = sorted(inputs)
    hazard = {s for s, p in inputs.items() if p["hazard_detector"]}
    # Each comparison uses the paper-executions complete in its own two arms (all, when the run completes).
    rows, _ = rows_all_arms(store, runs, papers, (REFINED, PUBLISHED))
    ablation_rows, _ = rows_all_arms(store, runs, papers, (ABLATION, PUBLISHED))
    _, missing = rows_all_arms(store, runs, papers, ARMS)  # incomplete paper-executions, per arm
    compared = sorted({r["study"] for r in rows})
    eligible = len(compared) >= MIN_PAPERS
    eligible_no_hazard = len(set(compared) - hazard) >= MIN_PAPERS
    main = comparison(rows, REFINED, PUBLISHED, SEED, hazard)
    ablation = comparison(ablation_rows, ABLATION, PUBLISHED, SEED, hazard)
    primary = main["resolved"]
    requests = {arm: request_paths(store, runs[arm]) for arm in ARMS}
    return {
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "label": "Replication (REPL): REPL_V12 (v1.2 r3 + H5) against REPL_V10 (v1.0 + original procedure), "
        "confirmatory; REPL_V10_NOCONJ against REPL_V10, exploratory; PREREGISTRATION_REPLICATION.md (v3.0)",
        "seed": SEED,
        "equivalence_bound": EQUIVALENCE_BOUND,
        "requests_dispositioned": sum(
            n for paths in requests.values() for k, n in paths["request_outcomes"].items() if k != "pending"
        ),
        "papers": len(papers),
        "papers_compared": len(compared),
        "hazard_detector_papers": sorted(hazard),
        "paper_executions_in_comparison": len({(r["study"], r["execution"]) for r in rows}),
        "paper_executions_possible": len(papers) * len(EXECUTIONS),
        "missing_paper_executions": missing,
        "eligible_for_readings": eligible,
        "ablation_paper_executions": len({(r["study"], r["execution"]) for r in ablation_rows}),
        "ablation_papers_compared": len({r["study"] for r in ablation_rows}),
        "reading": reading(primary["interval_95"]) if eligible and primary else None,
        "equivalence": equivalence(primary["interval_90_exact"]) if eligible and primary else None,
        "sensitivity_reading_without_hazard": reading(
            main["without_hazard_detectors"]["resolved"]["interval_95"]
        ) if eligible_no_hazard and main["without_hazard_detectors"]["resolved"] else None,
        "confirmatory": main,
        "exploratory_ablation": {
            "note": "Exploratory, declared in advance; no reading is applied.",
            **ablation,
        },
        "request_paths": requests,
        "mechanics": {arm: mechanics(store, runs[arm]) for arm in ARMS},
        "rows": rows,
        "rows_ablation": ablation_rows,
    }


def parity(ledger: Path) -> dict:
    """The confirmatory measures on the completed post-SLR ledger (arms mapped in) against the committed
    reports: rows, primary, complete and agreeing (POSTSLR_RUN_RESUMED.json); Table S8 a/b and the
    permutation p (POSTHOC_ANALYSES.json, with that file's permutation seed)."""
    refuse_live(ledger)
    store = fp.FinalRecords(ledger)
    frozen = json.loads((ledger.parent / "FREEZE.json").read_text())["conditions"]
    a1, a0 = fp.ARM_POSTSLR_V12, fp.ARM_POSTSLR_V10
    runs = {a: frozen[a]["runs"] for a in (a1, a0)}
    inputs = fp.postslr_inputs()
    hazard = {s for s, p in inputs.items() if p["hazard_detector"]}
    rows, _ = rows_all_arms(store, runs, sorted(inputs), (a1, a0))
    got = comparison(rows, a1, a0, fp.POSTSLR_SEED, hazard)
    resumed = json.loads(POSTSLR_RESUMED.read_text())
    s8 = json.loads(POSTHOC.read_text())["analyses"]["8_scope_vs_scores"]["tests"]["newlit_completed"]
    s15 = json.loads(POSTHOC.read_text())["analyses"]["15_primary_sensitivity"]["tests"]["newlit_completed"]
    perm = permutation(per_paper(rows, resolved, a1, a0), POSTHOC_SEED)

    def strip90(c: dict) -> dict:
        return {k: v for k, v in c.items() if not k.startswith("interval_90")}

    def strip_scope(c: dict) -> dict:
        return {**c, "paired": strip90(c["paired"])}

    def norm(rs: list[dict]) -> list:
        return [(r["execution"], r["study"], r["pillar"], r[a1], r[a0],
                 [list(v) if v else None for v in r[a1 + "_trio"]],
                 [list(v) if v else None for v in r[a0 + "_trio"]]) for r in rs]

    checks = {
        "rows": norm(rows) == norm(resumed["rows"]),
        "primary_resolved": strip90(got["resolved"]) == resumed["primary_resolved"],
        "complete_and_agreeing": strip90(got["complete_and_agreeing"])
        == resumed["secondary_complete_and_agreeing"],
        "without_hazard_resolved": strip90(got["without_hazard_detectors"]["resolved"])
        == resumed["sensitivity_without_hazard"]["primary_resolved"],
        "s8_score_agreement": strip90(got["score_agreement_all_scored_in_both_arms"])
        == s8["b_scores_on_panels_all_scored_in_both_arms"],
        "s8_scope_per_panel": strip_scope(got["scope_agreement_per_panel"]) == s8["a_scope_per_panel"],
        "s8_scope_per_paper_execution": strip_scope(got["scope_agreement_per_paper_execution"])
        == s8["a_scope_per_paper_execution"],
        "permutation_p": perm["permutation_p_two_sided"] == s15["permutation_p_two_sided"],
        "bca": got["bca"] == s15["bootstrap"],
    }
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "primary_resolved": got["resolved"],
        "complete_and_agreeing": got["complete_and_agreeing"],
        "s8_score_agreement": got["score_agreement_all_scored_in_both_arms"],
        "s8_scope_per_panel": got["scope_agreement_per_panel"]["paired"],
        "permutation_p_with_posthoc_seed": perm["permutation_p_two_sided"],
        "bca_95": got["bca"]["bca_95"],
    }


def signed(x: float) -> str:
    v = round(100 * x, 1)
    return ("+" if v > 0 else "$-$" if v < 0 else "") + f"{abs(v):.1f}"


def tex_comparison(prefix: str, c: dict | None) -> dict[str, str]:
    """\\repl<Measure><Field>: Panels, First, Second (hits), Diff, Low, High (95%), LowNinety, HighNinety."""
    fields = ("Panels", "First", "Second", "Diff", "Low", "High", "LowNinety", "HighNinety")
    if not c or not c.get("panels"):
        return {prefix + f: "n/a" for f in fields}
    return {
        prefix + "Panels": str(c["panels"]),
        prefix + "First": str(c["v1_2"]),
        prefix + "Second": str(c["v1_0"]),
        prefix + "Diff": signed(c["difference"]),
        prefix + "Low": signed(c["interval_95"][0]),
        prefix + "High": signed(c["interval_95"][1]),
        prefix + "LowNinety": signed(c["interval_90"][0]) if "interval_90" in c else "n/a",
        prefix + "HighNinety": signed(c["interval_90"][1]) if "interval_90" in c else "n/a",
    }


def macros(out: dict) -> str:
    m: dict[str, str] = {
        "replPapers": str(out["papers"]),
        "replPapersCompared": str(out["papers_compared"]),
        "replPaperExecutions": str(out["paper_executions_in_comparison"]),
        "replPaperExecutionsPossible": str(out["paper_executions_possible"]),
        "replReading": out["reading"] or "descriptive only",
        "replEquivalence": out["equivalence"] or "descriptive only",
        "replSensitivityReading": out["sensitivity_reading_without_hazard"] or "descriptive only",
        "replBound": f"{100 * out['equivalence_bound']:.0f}",
        "replAblPaperExecutions": str(out["ablation_paper_executions"]),
        "replAblPapersCompared": str(out["ablation_papers_compared"]),
        "replRequestsDispositioned": f"{out['requests_dispositioned']:,}",
    }
    for key, c in (("repl", out["confirmatory"]), ("replAbl", out["exploratory_ablation"])):
        m.update(tex_comparison(key + "Resolved", c["resolved"]))
        m.update(tex_comparison(key + "CA", c["complete_and_agreeing"]))
        m.update(tex_comparison(key + "Scores", c["score_agreement_all_scored_in_both_arms"]))
        no_p3 = c["score_agreement_all_scored_in_both_arms_without_p3"]
        m.update(tex_comparison(key + "ScoresNoPThree", no_p3))
        scope = c["scope_agreement_per_panel"]
        m.update(tex_comparison(key + "ScopePanel", scope["paired"] if scope else None))
        scope_pe = c["scope_agreement_per_paper_execution"]
        m.update(tex_comparison(key + "ScopePaper", scope_pe["paired"] if scope_pe else None))
        m.update(tex_comparison(key + "NoHazard", c["without_hazard_detectors"]["resolved"]))
        m.update(tex_comparison(key + "AboveZero", c["panels_with_a_score_above_0"]))
        m.update(tex_comparison(key + "Failed", c["panels_with_a_failed_judgment"]))
        kinds = c["kind_of_agreement_paired"]
        m.update(tex_comparison(key + "KindZero", kinds["agreed_0"]))
        m.update(tex_comparison(key + "KindAboveZero", kinds["agreed_above_0"]))
        m.update(tex_comparison(key + "KindNA", kinds["agreed_not_applicable"]))
        perm = c["permutation"]
        m[key + "PermP"] = f"{perm['permutation_p_two_sided']:.3f}" if perm else "n/a"
        b = c["bca"]
        bounds = (signed(b["bca_95"][0]), signed(b["bca_95"][1])) if b else ("n/a", "n/a")
        m[key + "BcaLow"], m[key + "BcaHigh"] = bounds
        for arm_key, arm in (("First", c["arms"][0]), ("Second", c["arms"][1])):
            k = c["kind_of_agreement"][arm]
            m[key + "AgreedZero" + arm_key] = str(k["agreed_0"])
            m[key + "AgreedAboveZero" + arm_key] = str(k["agreed_above_0"])
            m[key + "AgreedNA" + arm_key] = str(k["agreed_not_applicable"])
    head = ("% Generated by scripts/repl_report.py from docs/rerun-2026-11/results/REPL_RUN.json.\n"
            "% Do not edit.\n"
            "% First = REPL_V12 (confirmatory) or REPL_V10_NOCONJ (replAbl); Second = REPL_V10.\n")
    return head + "".join(f"\\newcommand{{\\{k}}}{{{v}}}\n" for k, v in m.items())


def row_md(name: str, c: dict | None) -> str:
    if not c or not c.get("panels"):
        return f"| {name} | — | — | — | — | — | — |"
    pc = lambda x: signed(x).replace("$-$", "−")  # noqa: E731
    i95, i90 = c["interval_95"], c.get("interval_90")
    ninety = f"[{pc(i90[0])}, {pc(i90[1])}]" if i90 else "—"
    return (f"| {name} | {c['panels']} | {c['v1_2']} / {c['v1_0']} | {pc(c['difference'])} | "
            f"[{pc(i95[0])}, {pc(i95[1])}] | {ninety} | {c['only_v1_2']} / {c['only_v1_0']} |")


def markdown(out: dict) -> str:
    """REPL_RUN.md: every number rendered from the JSON; the interpretation is applied from
    REPORTING_RULES_REPLICATION.md by hand in Goal B."""
    head = ("| Measure | Panels | First / second arm | Difference (points) | 95% interval | 90% interval "
            "| Only first / only second |\n|---|---:|---:|---:|---|---|---|")

    def block(c: dict) -> str:
        scope, scope_pe = c["scope_agreement_per_panel"], c["scope_agreement_per_paper_execution"]
        lines = [
            row_md("Resolved, R0", c["resolved"]),
            row_md("Complete and agreeing", c["complete_and_agreeing"]),
            row_md("Identical scores, all scored in both arms", c["score_agreement_all_scored_in_both_arms"]),
            row_md("… without P3", c["score_agreement_all_scored_in_both_arms_without_p3"]),
            row_md("Scope agreement, per panel", scope["paired"] if scope else None),
            row_md("Scope agreement, per paper-execution", scope_pe["paired"] if scope_pe else None),
            row_md("Resolved, without hazard detectors", c["without_hazard_detectors"]["resolved"]),
            row_md("C&A, without hazard detectors", c["without_hazard_detectors"]["complete_and_agreeing"]),
            row_md("Panels with a score above 0", c["panels_with_a_score_above_0"]),
            row_md("Panels with a failed judgment", c["panels_with_a_failed_judgment"]),
            row_md("Resolved as agreed level 0", c["kind_of_agreement_paired"]["agreed_0"]),
            row_md("Resolved as agreed above 0", c["kind_of_agreement_paired"]["agreed_above_0"]),
            row_md("Resolved as agreed not applicable",
                   c["kind_of_agreement_paired"]["agreed_not_applicable"]),
            *(row_md(f"Resolved, {p}", c["by_pillar_resolved"][p]) for p in PILLARS),
        ]
        return head + "\n" + "\n".join(lines)

    main, abl = out["confirmatory"], out["exploratory_ablation"]
    return f"""# Replication run (REPL): results

Provenance: agent:claude-opus-5-5. AI judgments only (`human_confirmed=false`). Generated by
`scripts/repl_report.py` from REPL_RUN.json. Pre-registration: PREREGISTRATION_REPLICATION.md (v3.0);
reporting sentences: REPORTING_RULES_REPLICATION.md.

- Papers: {out["papers"]}; compared: {out["papers_compared"]}; paper-executions complete in both
  confirmatory arms: {out["paper_executions_in_comparison"]} of {out["paper_executions_possible"]}.
- Seed `{out["seed"]}`; 10,000 paper-bootstrap resamples; equivalence bound
  ±{100 * out["equivalence_bound"]:.0f} points; requests dispositioned:
  {out["requests_dispositioned"]} of 1,026.

## Confirmatory: {main["arms"][0]} against {main["arms"][1]}

**Three-way reading: {out["reading"]}.
Equivalence reading (90% interval against ±{100 * EQUIVALENCE_BOUND:.0f}):
{out["equivalence"]}.** Without hazard detectors: {out["sensitivity_reading_without_hazard"]}.

{block(main)}

- Kind of agreement: {json.dumps(main["kind_of_agreement"])}
- Permutation test: {json.dumps(main["permutation"])}
- BCa: {json.dumps(main["bca"])}

## Exploratory ablation: {abl["arms"][0]} against {abl["arms"][1]} (no reading applied)

{block(abl)}

- Kind of agreement: {json.dumps(abl["kind_of_agreement"])}
- Permutation test: {json.dumps(abl["permutation"])}

## Coverage, failures and mechanics

- Coverage: {json.dumps({**main["coverage"], ABLATION: abl["coverage"][ABLATION]})}
- Request paths: {json.dumps(out["request_paths"])}
- Mechanics: {json.dumps(out["mechanics"])}
- Missing paper-executions: {json.dumps(out["missing_paper_executions"])}
"""


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ledger", type=Path, required=True,
                    help="a .backup copy of programme.sqlite3 (FREEZE.json is read from the same folder)")
    ap.add_argument("--parity", action="store_true", help="check against the completed post-SLR run and exit")
    ap.add_argument("--out-dir", type=Path, default=RESULTS)
    a = ap.parse_args()
    if a.parity:
        result = parity(a.ledger)
        print(json.dumps(result, indent=1))
        sys.exit(0 if result["ok"] else 1)
    out = report(a.ledger)
    a.out_dir.mkdir(parents=True, exist_ok=True)
    target = a.out_dir / "REPL_RUN.json"
    if target.exists():
        sys.exit("REPL_RUN.json exists and is never rewritten (write-once, as POSTSLR_RUN.json)")
    target.write_text(json.dumps(out, indent=2, default=list) + "\n")
    (a.out_dir / "REPL_RUN.md").write_text(markdown(out))
    (a.out_dir / "repl_numbers.tex").write_text(macros(out))
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1, default=list)[:4000])


if __name__ == "__main__":
    main()
