"""Spend and progress monitor for the replication run (Goal B), from logs and `.backup` copies only.

Usage, while the run writes the live ledger:
    .venv/bin/python scripts/repl_spend.py --log .research-private/final-phase-live-v1/repl-r0.log
    .venv/bin/python scripts/repl_spend.py --ledger <copy>/programme.sqlite3 --freeze <copy>/FREEZE.json

- `--log` counts dispositioned requests and their statuses from the runner's log (one JSON line per request).
- `--ledger` sums the charged (or still reserved) cost of every attempt of the replication's R0 requests,
  smoke run included, per provider, and compares it with the caps (estimate × 1.3, docs/rerun-2026-11/
  04_PROGRESS.md). The ledger must be a `.backup` copy, opened read-only; the live ledger is refused.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from repl_cost_estimate import LIVE, spend  # noqa: E402

from pipeline.study import final_phase as fp  # noqa: E402

CAPS = {"anthropic": 37.42, "openai": 22.80, "zai": 33.27}  # task C1, 18 Nov 2026
TOTAL_REQUESTS = 1026


def from_log(path: Path) -> dict:
    """Totals only: never counts by run or arm, so nothing arm-specific is seen before the run ends."""
    statuses = Counter()
    for line in path.read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict) and "status" in row and "run_id" in row:
            statuses[row["status"]] += 1
    n = sum(statuses.values())
    return {"dispositioned": n, "of": TOTAL_REQUESTS, "statuses": dict(statuses)}


def from_ledger(ledger: Path, freeze: Path) -> dict:
    if ledger.resolve() == LIVE:
        raise SystemExit("Refusing: read a .backup copy, never the live ledger")
    conditions = json.loads(freeze.read_text())["conditions"]
    runs = [r for c in fp.REPL_CONDITIONS for r in conditions[c]["runs"]]
    db = sqlite3.connect(ledger.resolve().as_uri() + "?mode=ro", uri=True)
    got = spend(db, runs)
    db.close()
    out = {}
    for p, cap in CAPS.items():
        charged = got.get(p, {}).get("charged", 0.0)
        seen = got.get(p, {})
        out[p] = {"charged": round(charged, 2), "cap": cap, "share_of_cap": round(charged / cap, 3),
                  "requests": seen.get("requests", 0), "attempts": seen.get("attempts", 0),
                  "over_cap": charged > cap}
    return {"by_provider": out, "total": round(sum(v["charged"] for v in out.values()), 2)}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--log", type=Path)
    ap.add_argument("--ledger", type=Path)
    ap.add_argument("--freeze", type=Path)
    a = ap.parse_args()
    if not a.log and not a.ledger:
        ap.error("give --log, or --ledger with --freeze")
    out = {}
    if a.log:
        out["log"] = from_log(a.log)
    if a.ledger:
        if not a.freeze:
            ap.error("--ledger needs --freeze (the FREEZE.json copied beside the backup)")
        out["spend"] = from_ledger(a.ledger, a.freeze)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
