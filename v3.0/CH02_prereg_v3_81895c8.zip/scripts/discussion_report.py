"""Exploratory discussion-v1 check (DISC_V13_B): independent R0 against the state after discussion.

DISC_V13 stopped after R0 (the ledger refused discussion rounds); its R0 is reported as an extra
independent replicate only.

R0 is the independent reliability measure; the discussion outcome is dependent reconciliation and is
reported separately. Papers 17, 27, 28, 40, 47 and 59 were already evaluated, so nothing here revises
the pre-registered result.
"""

from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from final_cycle_report import _obj  # noqa: E402

from pipeline.study.discussion import round_results, verdict  # noqa: E402
from pipeline.study.final_phase import FinalRecords, location  # noqa: E402
from pipeline.study.records import PILLARS, RATERS  # noqa: E402

NAMES = {"r1": "gpt", "r2": "glm", "r3": "sonnet"}
OUT_OF_SCOPE = (28, 40, 47, 59)


def classify(trio: list) -> str:
    """trio of verdicts (or None for a failed judgment)."""
    if None in trio:
        return "failure"
    if len(set(trio)) == 1:
        return "agree_score" if trio[0][0] == "scored" else "agree_not_applicable"
    if all(v[0] == "scored" for v in trio):
        return "score_disagreement"
    return "split_not_applicable_vs_score"


def majority(trio: list) -> tuple | None:
    top, n = Counter(trio).most_common(1)[0]
    return top if n >= 2 else None


def r0_only(store: FinalRecords, runs: list[str]) -> dict:
    counts = Counter()
    for run in runs:
        for p_ in store.manifest(run)["papers"]:
            r0 = round_results(store, run, p_["study_id"], 0)
            for p in PILLARS:
                counts[classify([verdict(r0[(r, p)]) if r0.get((r, p)) else None for r in RATERS])] += 1
    return dict(counts)


def main() -> None:
    conditions = json.loads((location() / "FREEZE.json").read_text())["conditions"]
    frozen = conditions["DISC_V13_B"]
    store = FinalRecords(location() / "programme.sqlite3")
    before, after, transitions, stops, moves, by_group = Counter(), Counter(), Counter(), Counter(), [], {}
    cost, withheld, rounds_used = Counter(), 0, Counter()
    for execution, run in enumerate(frozen["runs"], 1):
        e = store.export(run)
        events = [ev for ev in e["events"] if ev["kind"] == "discussion_dispositioned"]
        if not events:
            raise SystemExit(f"Discussion not dispositioned for {run}")
        outcomes = _obj(events[-1]["payload"])["outcomes"]
        withheld += sum(len(_obj(ev["payload"])["withheld"]) for ev in e["events"]
                        if ev["kind"] == "discussion_withheld")
        requests = {q["id"]: q for q in e["requests"]}
        attempts = {a["id"]: a for a in e["attempts"]}
        for c in e["completions"]:
            q = requests[attempts[c["attempt_id"]]["request_id"]]
            cost["r0" if q["round"] == 0 else "discussion"] += c["effective_charge"] or 0
            rounds_used[q["round"]] += q["round"] > 0
        for sid, pillars in outcomes.items():
            study = int(sid)
            r0 = round_results(store, run, study, 0)
            group = "out_of_scope_papers" if study in OUT_OF_SCOPE else "drowning_system_papers"
            for p in PILLARS:
                start = [verdict(r0[(r, p)]) if r0.get((r, p)) else None for r in RATERS]
                end = [tuple(v) if v else None for v in (pillars[p]["final"][r] for r in RATERS)]
                a, b = classify(start), classify(end)
                before[a] += 1
                after[b] += 1
                transitions[f"{a} -> {b}"] += 1
                stops[pillars[p]["stop"]] += 1
                by_group.setdefault(group, Counter())[f"{a} -> {b}"] += 1
                if a in ("failure",) or start == end:
                    continue
                lead = majority(start)
                for r, s0, s1 in zip(RATERS, start, end, strict=True):
                    if s0 != s1:
                        moves.append({
                            "execution": execution, "study": study, "pillar": p, "rater": NAMES[r],
                            "from": s0, "to": s1, "r0_majority": lead,
                            "toward_r0_majority": lead is not None and s1 == lead and s0 != lead,
                            "rounds": pillars[p]["round"],
                        })
    resolved = {
        k: v["agree_score"] + v["agree_not_applicable"] for k, v in (("r0", before), ("after", after))
    }
    report = {
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "label": "exploratory, not pre-registered; papers already evaluated; discussion is dependent",
        "panels": sum(before.values()),
        "r0_independent": dict(before),
        "after_discussion": dict(after),
        "extra_r0_replicate_disc_v13": r0_only(store, conditions["DISC_V13"]["runs"]),
        "resolved": resolved,
        "transitions": dict(transitions),
        "transitions_by_group": {k: dict(v) for k, v in by_group.items()},
        "stop_reasons": dict(stops),
        "revision_requests_by_round": {str(k): v for k, v in sorted(rounds_used.items()) if k},
        "moves": moves,
        "moves_by_rater": dict(Counter(m["rater"] for m in moves)),
        "moves_toward_r0_majority": sum(m["toward_r0_majority"] for m in moves),
        "arguments_withheld": withheld,
        "cost_usd": {k: round(v, 4) for k, v in cost.items()},
    }
    out = ROOT / "docs/final-phase-2026-10-28/results/DISC_V13.json"
    out.write_text(json.dumps(report, indent=2, default=list) + "\n")
    print(json.dumps(report, indent=2, default=list))


if __name__ == "__main__":
    main()
