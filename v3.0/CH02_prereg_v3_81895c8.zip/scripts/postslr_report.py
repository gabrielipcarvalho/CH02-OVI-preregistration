"""The post-SLR evaluation report: v1.2 revision 3 against the published v1.0 on 57 papers published after
the SLR (PREREGISTRATION_POSTSLR.md, published as v2.0 of CH02-OVI-preregistration, 10 Nov 2026).

The measures and their reading were declared before the first rated request. Panels are paired by
paper × pillar × execution, and only paper-executions complete in both arms enter a comparison. The paired
difference and its paper-bootstrap interval come from the same code as CORPUS2 and CORPUS3B
(`corpus_report.compare`), with this run's seed. `--parity` re-derives CORPUS3B's primary through this
script's row builder and checks it against the committed CORPUS3B_RUN.json before anything is trusted.

Read a copy of the ledger (`--ledger`), never the live one while a run writes to it. The output holds IDs,
classes and counts only: no paper text and no quotation (copyright).
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from agreement_split import kappa_with_interval, scope_and_levels  # noqa: E402
from corpus_report import RESOLVED, compare, complete, ovi  # noqa: E402
from discussion_report import classify  # noqa: E402
from final_cycle_report import _obj  # noqa: E402
from v11_report import mechanics, trios  # noqa: E402

from pipeline.study import final_phase as fp  # noqa: E402
from pipeline.study.records import PILLARS, RATERS  # noqa: E402

REFINED, COMPARATOR = fp.ARM_POSTSLR_V12, fp.ARM_POSTSLR_V10
RESULTS = ROOT / "docs/postslr-2026-11/results"
EARLIER = ROOT / "docs/final-phase-2026-10-28/results"
EXECUTIONS = (1, 2)
# Record IDs whose full-text screening note classes them as people detectors (decisions.json, 10 Nov 2026;
# FULLTEXT_LOG.md "People detectors: 15"). Used only for exploratory splits.
PEOPLE_DETECTORS = (
    "S0021",
    "S0026",
    "S0077",
    "S0114",
    "S0173",
    "S0199",
    "S0626",
    "S0777",
    "S0796",
    "S0885",
    "S1116",
    "S1142",
    "S1284",
    "S1301",
    "S1319",
)
RECORDS_BASED = ("S0141", "S0589", "S0973")
KAPPA_SEED = "ch2-kappa-exploratory-20261111"


def resolved(c: str) -> bool:
    return c in RESOLVED


def agreeing(c: str) -> bool:
    return c == "agree_score"


def reading(interval: list[float] | None) -> str | None:
    """The pre-registered reading of the primary interval (PREREGISTRATION_POSTSLR.md §Reading)."""
    if interval is None:
        return None
    low, high = interval
    if low > 0:
        return "transfers"
    if high < 0:
        return "reverses"
    return "not detected"


def paired_rows(store, runs: dict[str, list[str]], papers, refined: str, comparator: str):
    """Rows for paper-executions complete in both arms, and the paper-executions left out per arm."""
    done = {
        (arm, e): complete(store, run) for arm in (refined, comparator) for e, run in enumerate(runs[arm], 1)
    }
    rows = []
    for e in EXECUTIONS:
        both = done[(refined, e)] & done[(comparator, e)] & set(papers)
        for s in sorted(both):
            t = {arm: trios(store, runs[arm][e - 1], s) for arm in (refined, comparator)}
            for p in PILLARS:
                rows.append(
                    {
                        "execution": e,
                        "study": s,
                        "pillar": p,
                        **{arm: classify(t[arm][p]) for arm in t},
                        **{arm + "_trio": t[arm][p] for arm in t},
                    }
                )
    missing = {f"{arm}/{e}": sorted(set(papers) - d) for (arm, e), d in done.items()}
    return rows, missing


def discussion_classes(store, runs: dict[str, list[str]]):
    """After-discussion class per (arm, execution, study, pillar), and counts per arm/execution."""
    final_class, counts = {}, {}
    for arm, arm_runs in runs.items():
        for e, run in enumerate(arm_runs, 1):
            event = [ev for ev in store.export(run)["events"] if ev["kind"] == "discussion_dispositioned"]
            if not event:
                continue
            # The last disposition is the run's result (as discussion_report reads it); the count is reported.
            c = Counter({"_discussion_events": len(event)})
            for study, by_pillar in _obj(event[-1]["payload"])["outcomes"].items():
                for p in PILLARS:
                    final = by_pillar[p].get("final")
                    trio = [tuple(final[r]) if final.get(r) else None for r in RATERS] if final else None
                    verdict = classify(trio) if trio else by_pillar[p]["stop"]
                    c[verdict] += 1
                    final_class[(arm, e, int(study), p)] = verdict
            counts[f"{arm}/{e}"] = dict(c)
    return final_class, counts


def after_rows(rows: list[dict], final_class: dict, arms: tuple[str, str]) -> list[dict]:
    """Paired after-discussion rows: panels discussed (or settled) in both arms."""
    out = []
    for r in rows:
        keys = {arm: (arm, r["execution"], r["study"], r["pillar"]) for arm in arms}
        if all(k in final_class for k in keys.values()):
            out.append({"study": r["study"], **{arm: final_class[k] for arm, k in keys.items()}})
    return out


def measures(rows, final_class, arms, seed) -> dict:
    refined, comparator = arms
    paired_after = after_rows(rows, final_class, arms)
    return {
        "primary_resolved": compare(rows, resolved, refined, comparator, seed),
        "secondary_complete_and_agreeing": compare(rows, agreeing, refined, comparator, seed),
        "secondary_after_discussion_resolved": compare(paired_after, resolved, refined, comparator, seed)
        if paired_after
        else None,
    }


def agreement_beyond_zero(rows: list[dict], arm: str) -> dict:
    """Among panels with three scored judgments, at least one above 0: how many agree."""
    n = agree = 0
    for r in rows:
        trio = r[arm + "_trio"]
        if None in trio or any(v[0] != "scored" for v in trio):
            continue
        if any(v[1] > 0 for v in trio):
            n += 1
            agree += len(set(map(tuple, trio))) == 1
    return {"panels_with_a_score_above_0": n, "agreeing": agree}


def agreed_levels(rows: list[dict], arm: str) -> dict:
    """Level of every agreed-score panel, and every level any rater gave in R0 (descriptive: floor effect)."""
    agreed, given = Counter(), Counter()
    for r in rows:
        trio = r[arm + "_trio"]
        if r[arm] == "agree_score":
            agreed[str(trio[0][1])] += 1
        for v in trio:
            if v is not None and v[0] == "scored":
                given[str(v[1])] += 1
    return {
        "agreed_score_panels_by_level": dict(sorted(agreed.items())),
        "scored_judgments_by_level": dict(sorted(given.items())),
    }


def profiles(rows: list[dict], arm: str) -> dict:
    """OVI-Gate of every agreed four-pillar profile (DEC-0002), and its pillar pattern."""
    by_pe: dict[tuple, dict] = {}
    for r in rows:
        by_pe.setdefault((r["study"], r["execution"]), {})[r["pillar"]] = r[arm + "_trio"]
    gates, p4, p1_p3_zero, papers = Counter(), Counter(), 0, set()
    for (study, _), trio_by_pillar in by_pe.items():
        gate = ovi(trio_by_pillar)
        gates["ovi_" + str(gate) if gate is not None else "no_agreed_profile"] += 1
        if gate is not None:
            papers.add(study)
            levels = {p: trio_by_pillar[p][0][1] for p in PILLARS}
            p1_p3_zero += all(levels[p] == 0 for p in PILLARS[:3])
            p4[levels["P4"]] += 1
    return {
        "gates": dict(gates),
        "agreed_profiles_papers": len(papers),
        "agreed_profiles_p1_p3_all_0": p1_p3_zero,
        "agreed_profiles_p4_levels": dict(p4),
    }


def rater_subsets(rows: list[dict], arm: str) -> dict:
    """Exploratory ablation from stored judgments: each rater's share of valid judgments, and how often each
    pair of raters gives the same verdict (both valid), as if the panel had two raters instead of three."""
    names = ("r1", "r2", "r3")
    valid = {n: sum(r[arm + "_trio"][i] is not None for r in rows) for i, n in enumerate(names)}
    pairs = {}
    for i in range(3):
        for j in range(i + 1, 3):
            both = [r for r in rows if r[arm + "_trio"][i] is not None and r[arm + "_trio"][j] is not None]
            same = sum(tuple(r[arm + "_trio"][i]) == tuple(r[arm + "_trio"][j]) for r in both)
            pairs[f"{names[i]}+{names[j]}"] = {"both_valid": len(both), "same_verdict": same}
    return {"panels": len(rows), "valid_judgments_by_rater": valid, "pairs": pairs}


def unanimous_statuses(rows: list[dict], arm: str) -> dict:
    """Which non-scored status the unanimous 'agree_not_applicable' panels carry (classify counts any)."""
    return dict(Counter(r[arm + "_trio"][0][0] for r in rows if r[arm] == "agree_not_applicable"))


def out_of_scope(rows: list[dict], arm: str) -> dict:
    """Paper-executions with P1–P3 agreed not applicable (outside the rubric's scope, CORPUS_RUN_MEASURES)."""
    by_pe: dict[tuple, dict] = {}
    for r in rows:
        by_pe.setdefault((r["study"], r["execution"]), {})[r["pillar"]] = r[arm]
    hits = {pe for pe, c in by_pe.items() if all(c.get(p) == "agree_not_applicable" for p in PILLARS[:3])}
    per_paper = Counter(s for s, _ in hits)
    return {
        "paper_executions": len(hits),
        "papers": sorted(per_paper),
        "papers_in_both_executions": sorted(s for s, n in per_paper.items() if n == len(EXECUTIONS)),
    }


def stability(rows: list[dict], arm: str) -> dict:
    pairs, by_panel = Counter(), {}
    for r in rows:
        by_panel.setdefault((r["study"], r["pillar"]), []).append(r)
    for two in by_panel.values():
        if len(two) != len(EXECUTIONS):
            continue
        if all(resolved(r[arm]) for r in two):
            pairs["same" if two[0][arm + "_trio"] == two[1][arm + "_trio"] else "changed"] += 1
        else:
            pairs["not_resolved_in_both"] += 1
    return dict(pairs)


def request_paths(store, arm_runs: list[str]) -> dict:
    """How each R0 request got its result: first attempt only, or after format recovery (stage 1), a
    quotation correction (stage 2), or one to three re-requests (stages 3, 6, 9). Request-level, because
    judgments are stored per request, not per attempt."""
    paths, re_requests, outcome = Counter(), Counter(), Counter()
    for run in arm_runs:
        e = store.export(run)
        r0 = {q["id"] for q in e["requests"] if q["round"] == 0 and q["kind"] == "rating"}
        stages: dict[str, int] = {}
        for a in e["attempts"]:
            if a["request_id"] in r0:
                stages[a["request_id"]] = max(stages.get(a["request_id"], 0), a["stage"])
        for q in r0:
            top = stages.get(q, 0)
            paths[
                "first_attempt_only"
                if top == 0
                else "format_recovery"
                if top == 1
                else "quote_correction"
                if top == 2
                else f"re_request_{top // 3}"
            ] += 1
        for ev in e["events"]:
            if ev["kind"] == "unreadable_resample":
                payload = _obj(ev["payload"])
                if payload.get("request_id") in r0:
                    re_requests[str(payload.get("re_request", "unnumbered (pillar resample decision)"))] += 1
        judged = {j["request_id"] for j in e["judgments"]}
        failed = {d["request_id"] for d in e["dispositions"]}
        for q in r0:
            outcome[
                "judgments"
                if q in judged and q not in failed
                else "partial"
                if q in judged
                else "failed"
                if q in failed
                else "pending"
            ] += 1
    return {
        "paths": dict(paths),
        "re_request_events_by_number": dict(re_requests),
        "request_outcomes": dict(outcome),
    }


def coverage(rows: list[dict], arm: str) -> dict:
    """Share of pillar judgments that are valid (not failed), over all panels in the comparison."""
    valid = sum(sum(v is not None for v in r[arm + "_trio"]) for r in rows)
    return {"valid_judgments": valid, "judgments": len(rows) * len(RATERS)}


def effect_sizes(postslr: dict, postslr_no_hazard: dict) -> dict:
    """This run's primary beside the earlier corpus runs, read from their committed reports."""
    c3b = json.loads((EARLIER / "CORPUS3B_RUN.json").read_text())["primary_resolved"]
    c2 = json.loads((EARLIER / "CORPUS_RUN.json").read_text())["primary_resolved"]
    hz = json.loads((EARLIER / "HAZARD_SENSITIVITY.json").read_text())["corpus"]
    pick = ("panels", "refined", "v1_0", "difference", "interval_95")

    def norm(c: dict) -> dict:  # CORPUS2 labels its refined arm v1_1, the others v1_2
        return {k: c.get(k, c.get("v1_2", c.get("v1_1"))) if k == "refined" else c.get(k) for k in pick}

    return {
        "POSTSLR (v1.2 r3, post-review)": norm(postslr),
        "POSTSLR without hazard detectors": norm(postslr_no_hazard),
        "CORPUS3B (v1.2 r3, exposed)": norm(c3b),
        "CORPUS3B without hazard detectors (post hoc)": norm(
            hz["CORPUS3B"]["without_hazard"]["primary_resolved"]
        ),
        "CORPUS2 (v1.1, unseen)": norm(c2),
        "CORPUS2 without hazard detectors (post hoc)": norm(
            hz["CORPUS2"]["without_hazard"]["primary_resolved"]
        ),
        "note": "Comparisons across tests are confounded by paper mix and the re-request policy (v4 here).",
    }


def parity(ledger: Path) -> dict:
    """CORPUS3B's primary re-derived through paired_rows + compare must equal the committed report."""
    store = fp.FinalRecords(ledger)
    frozen = json.loads((ledger.parent / "FREEZE.json").read_text())["conditions"]
    runs = {arm: frozen[arm]["runs"] for arm in (fp.ARM_V12_R3, fp.ARM_V10)}
    rows, _ = paired_rows(store, runs, fp.CORPUS, fp.ARM_V12_R3, fp.ARM_V10)
    got = compare(rows, resolved, fp.ARM_V12_R3, fp.ARM_V10, fp.CORPUS_SEED)
    want = json.loads((EARLIER / "CORPUS3B_RUN.json").read_text())["primary_resolved"]
    return {"ok": got == want, "got": got, "committed": want}


# The request the run stopped on (HTTP 520, attempt b2cb48be…, request 45f72a71…, r1, v1.2 r3 arm) belongs to
# paper 10077, execution 1; it was parked, so its four panels enter the primary as failures (12 Nov 2026).
STOP_PAPER_EXECUTION = (10077, 1)
ATYPICALITY_SEED = "ch2-atypicality-20261112"


def post_hoc_stop(
    rows: list[dict], schedule: list[dict], runs: dict, arms, hazard, people, seed: str
) -> dict:
    """Post hoc, added 12 Nov after the results (review cycle 3): (a) the primary without the paper-execution
    whose request the stop parked; (b) how often a random dispatch order would leave as many hazard detectors
    and as few people detectors among the papers finished in both arms by the same request count."""
    import random
    from collections import defaultdict

    without = [r for r in rows if (r["study"], r["execution"]) != STOP_PAPER_EXECUTION]
    execution_of = {run: i + 1 for arm in arms for i, run in enumerate(runs[arm])}
    items = [(x["study"], execution_of[x["run_id"]]) for x in schedule if x["run_id"] in execution_of]
    finished_rows = {(r["study"], r["execution"]) for r in rows}
    cutoff = max(i for i, pe in enumerate(items) if pe in finished_rows) + 1
    dispositioned = sum(1 for _ in items[:cutoff])
    rng = random.Random(ATYPICALITY_SEED)
    hazard_n = len({s for s, _ in finished_rows} & set(hazard))
    people_n = len({s for s, _ in finished_rows} & set(people))
    trials, more_hazard, fewer_people = 5000, 0, 0
    for _ in range(trials):
        order = items[:]
        rng.shuffle(order)
        last: dict = defaultdict(int)
        for i, pe in enumerate(order):
            last[pe] = i
        done = {pe[0] for pe, i in last.items() if i < dispositioned}
        more_hazard += len(done & set(hazard)) >= hazard_n
        fewer_people += len(done & set(people)) <= people_n
    return {
        "note": "Post hoc (review cycle 3, 12 Nov 2026); not pre-registered.",
        "without_stop_paper_execution": {
            "excluded": list(STOP_PAPER_EXECUTION),
            **compare(without, resolved, *arms, seed),
        },
        "dispatch_prefix_requests": dispositioned,
        "atypicality": {
            "trials": trials,
            "seed": ATYPICALITY_SEED,
            "p_at_least_hazard_papers": round(more_hazard / trials, 4),
            "hazard_papers": hazard_n,
            "p_at_most_people_papers": round(fewer_people / trials, 4),
            "people_papers": people_n,
        },
    }


STOP_UTC = "2026-11-11T20:19:51"  # the 520 at 20:19:50 UTC; later first attempts belong to the second launch


def resumed_extras(ledger: Path, rows: list[dict], primary_rows: list[dict], arms, seed: str) -> dict:
    """Descriptive, for the resumed run only (RESUME_REPORTING_RULES.md, committed before its results):
    the paper-executions added by the resume alone, and requests by launch."""
    store = fp.FinalRecords(ledger)
    runs = {a: json.loads((ledger.parent / "FREEZE.json").read_text())["conditions"][a]["runs"] for a in arms}
    stopped = {(r["study"], r["execution"]) for r in primary_rows}
    added = [r for r in rows if (r["study"], r["execution"]) not in stopped]
    run_arm = {run: (arm, i + 1) for arm in arms for i, run in enumerate(runs[arm])}
    with store.db() as db:
        first = db.execute(
            "SELECT q.run_id,q.study,q.rater,MIN(a.created) AS t,"
            "EXISTS(SELECT 1 FROM dispositions d WHERE d.request_id=q.id) AS failed "
            "FROM requests q JOIN attempts a ON a.request_id=q.id "
            "WHERE q.round=0 AND q.kind='rating' AND q.replicate=0 AND q.run_id IN ({}) GROUP BY q.id".format(
                ",".join("?" * len(run_arm))
            ),
            tuple(run_arm),
        ).fetchall()
    launch = {}
    by_launch: dict = {1: Counter(), 2: Counter()}
    for row in first:
        n = 2 if row["t"] > STOP_UTC else 1
        arm, execution = run_arm[row["run_id"]]
        launch[(row["study"], execution, arm, row["rater"])] = n
        by_launch[n][f"{arm}/{row['rater']}"] += 1
        by_launch[n]["with_failure_record" if row["failed"] else "without_failure_record"] += 1
    compared = {(r["study"], r["execution"]) for r in rows}
    mixed = sum(
        1 for s, e in compared if len({launch.get((s, e, a, q)) for a in arms for q in RATERS} - {None}) > 1
    )
    return {
        "note": "Descriptive; resumed run only (declared deviation). Launch 2 = first attempt after the "
        "stop at 20:19:50 UTC on 11 Nov 2026.",
        "added_paper_executions_only": compare(added, resolved, *arms, seed) if added else None,
        "added_paper_executions": len({(r["study"], r["execution"]) for r in added}),
        "requests_by_launch": {str(k): dict(v) for k, v in by_launch.items()},
        "launch_two_requests": sum(v for k, v in by_launch[2].items() if "/" in k),
        "launch_two_by_arm": {
            a: sum(v for k, v in by_launch[2].items() if k.startswith(a + "/")) for a in arms
        },
        "compared_paper_executions_with_requests_from_both_launches": mixed,
    }


def report(ledger: Path) -> dict:
    store = fp.FinalRecords(ledger)
    frozen = json.loads((ledger.parent / "FREEZE.json").read_text())["conditions"]
    arms = (REFINED, COMPARATOR)
    runs = {arm: frozen[arm]["runs"] for arm in arms}
    inputs = fp.postslr_inputs()
    papers = sorted(inputs)
    hazard = sorted(s for s, p in inputs.items() if p["hazard_detector"])
    records_based = sorted(s for s, p in inputs.items() if p["record_id"] in RECORDS_BASED)
    people = sorted(s for s, p in inputs.items() if p["record_id"] in PEOPLE_DETECTORS)
    seed = fp.POSTSLR_SEED
    rows, missing = paired_rows(store, runs, papers, *arms)
    final_class, after_counts = discussion_classes(store, runs)
    main = measures(rows, final_class, arms, seed)
    no_hazard = measures([r for r in rows if r["study"] not in hazard], final_class, arms, seed)
    paper_executions = len({(r["study"], r["execution"]) for r in rows})

    def group(ids):
        sub = [r for r in rows if r["study"] in ids]
        return compare(sub, resolved, *arms, seed) if sub else None

    return {
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "label": f"Post-SLR evaluation {fp.POSTSLR_SCHEDULE}: {REFINED} (rubric v1.2 r3 + H5) against "
        f"{COMPARATOR} (published v1.0 + original handbook); measures and reading declared in "
        "PREREGISTRATION_POSTSLR.md (v2.0) before the first rated request",
        "seed": seed,
        "papers": len(papers),
        "hazard_detector_papers": hazard,
        "people_detector_papers": people,
        "records_based_papers": records_based,
        "paper_executions_in_comparison": paper_executions,
        "paper_executions_possible": len(papers) * len(EXECUTIONS),
        "missing_paper_executions": missing,
        **main,
        "reading": reading(main["primary_resolved"]["interval_95"]),
        "sensitivity_without_hazard": no_hazard,
        "sensitivity_reading": reading(no_hazard["primary_resolved"]["interval_95"]),
        "counts": {arm: dict(Counter(r[arm] for r in rows)) for arm in arms},
        "by_pillar": {
            p: {arm: dict(Counter(r[arm] for r in rows if r["pillar"] == p)) for arm in arms} for p in PILLARS
        },
        "out_of_scope_papers": {arm: out_of_scope(rows, arm) for arm in arms},
        "coverage_final": {arm: coverage(rows, arm) for arm in arms},
        "request_paths": {arm: request_paths(store, runs[arm]) for arm in arms},
        "mechanics": {arm: mechanics(store, runs[arm]) for arm in arms},
        "agreement_beyond_zero": {arm: agreement_beyond_zero(rows, arm) for arm in arms},
        "levels": {arm: agreed_levels(rows, arm) for arm in arms},
        "unanimous_non_scored_status": {arm: unanimous_statuses(rows, arm) for arm in arms},
        "exploratory_rater_subsets": {arm: rater_subsets(rows, arm) for arm in arms},
        "profiles": {arm: profiles(rows, arm) for arm in arms},
        "repeat_stability": {arm: stability(rows, arm) for arm in arms},
        "after_discussion": after_counts,
        "effect_sizes": effect_sizes(main["primary_resolved"], no_hazard["primary_resolved"]),
        "exploratory_by_paper_type": {
            "note": "Not pre-registered; exploratory. Types from full-text screening notes: hazard detectors "
            "(DEC-0010), people detectors, records-based studies (ruling of 1 Nov 2026), and the rest.",
            "hazard_detectors": group(set(hazard)),
            "people_detectors": group(set(people)),
            "records_based": group(set(records_based)),
            "other": group(set(papers) - set(hazard) - set(people) - set(records_based)),
            "without_records_based": group(set(papers) - set(records_based)),
        },
        "exploratory_p4_only": compare([r for r in rows if r["pillar"] == "P4"], resolved, *arms, seed),
        "post_hoc_stop": post_hoc_stop(
            rows, frozen[fp.POSTSLR_SCHEDULE]["schedule"], runs, arms, hazard, people, seed
        ),
        "exploratory_fleiss_kappa": {
            arm: {
                "scores_only": kappa_with_interval(rows, arm, False, KAPPA_SEED),
                "with_not_applicable": kappa_with_interval(rows, arm, True, KAPPA_SEED),
            }
            for arm in arms
        },
        "scope_and_levels": {arm: scope_and_levels(rows, arm) for arm in arms},
        "rows": rows,
    }


def pct(x: float | None) -> str:
    return "—" if x is None else f"{100 * x:+.1f}"


def comparison_row(name: str, c: dict | None) -> str:
    if not c or not c["panels"]:
        return f"| {name} | — | — | — | — | — | — |"
    lo, hi = c["interval_95"]
    return (
        f"| {name} | {c['panels']} | {c['v1_2']} | {c['v1_0']} | {pct(c['difference'])} | "
        f"[{pct(lo)}, {pct(hi)}] | {c['only_v1_2']} / {c['only_v1_0']} |"
    )


def tables(out: dict) -> str:
    """The numeric tables of POSTSLR_RUN.md, rendered from the JSON so no number is retyped."""
    head = (
        "| Measure | Panels | v1.2 r3 | v1.0 | Difference (points) | 95% interval "
        "| Only v1.2 r3 / only v1.0 |\n|---|---:|---:|---:|---:|---|---|"
    )
    main = [
        comparison_row("**Primary: resolved, R0**", out["primary_resolved"]),
        comparison_row("Complete and agreeing, R0", out["secondary_complete_and_agreeing"]),
        comparison_row("Resolved after discussion", out["secondary_after_discussion_resolved"]),
    ]
    nh = out["sensitivity_without_hazard"]
    sens = [
        comparison_row("Resolved, R0", nh["primary_resolved"]),
        comparison_row("Complete and agreeing, R0", nh["secondary_complete_and_agreeing"]),
        comparison_row("Resolved after discussion", nh["secondary_after_discussion_resolved"]),
    ]
    ex = out["exploratory_by_paper_type"]
    expl = [
        comparison_row("Hazard detectors", ex["hazard_detectors"]),
        comparison_row("Records-based studies", ex["records_based"]),
        comparison_row("Other papers", ex["other"]),
    ]
    classes = [
        "agree_score",
        "agree_not_applicable",
        "score_disagreement",
        "split_not_applicable_vs_score",
        "failure",
    ]
    arms = list(out["counts"])
    count_rows = "\n".join(
        f"| {c} | " + " | ".join(str(out["counts"][a].get(c, 0)) for a in arms) + " |" for c in classes
    )
    pillar_rows = "\n".join(
        f"| {p} | "
        + " | ".join(
            f"{sum(v for k, v in out['by_pillar'][p][a].items() if k in RESOLVED)}"
            f" / {sum(out['by_pillar'][p][a].values())}"
            for a in arms
        )
        + " |"
        for p in PILLARS
    )
    done, possible = out["paper_executions_in_comparison"], out["paper_executions_possible"]
    return f"""## Primary and secondary (all {out["papers"]} papers; {done} of {possible} paper-executions \
complete in both arms)

{head}
{chr(10).join(main)}

**Pre-registered reading of the primary interval: {out["reading"]}.**

## Sensitivity: without the {len(out["hazard_detector_papers"])} hazard-detector papers

{head}
{chr(10).join(sens)}

Reading of the sensitivity interval (descriptive; the pre-registered reading applies to the primary):
{out["sensitivity_reading"]}.

## Exploratory, not pre-registered: by paper type

{head}
{chr(10).join(expl)}

## Where R0 panels end up

| Class | {" | ".join(arms)} |
|---|{"---:|" * len(arms)}
{count_rows}

## Resolved R0 panels by pillar (resolved / panels)

| Pillar | {" | ".join(arms)} |
|---|{"---:|" * len(arms)}
{pillar_rows}
"""


def report_md(
    out: dict, interpretation: str = "INTERPRETATION: to be written by hand from these tables."
) -> str:
    """The full POSTSLR_RUN.md, every measure rendered from the JSON; only the interpretation is prose."""
    arms = list(out["counts"])
    a, b = arms[0], arms[1]

    def pair(key: str) -> str:
        return f"{json.dumps(out[key][a], sort_keys=True)} / {json.dumps(out[key][b], sort_keys=True)}"

    kap = out["exploratory_fleiss_kappa"]
    eff = out["effect_sizes"]
    eff_rows = "\n".join(
        f"| {name} | {v['panels']} | {v['refined']} | {v['v1_0']} | {pct(v['difference'])} | "
        f"[{pct(v['interval_95'][0])}, {pct(v['interval_95'][1])}] |"
        for name, v in eff.items()
        if isinstance(v, dict) and v.get("interval_95")
    )
    return f"""# New-literature (post-SLR) test: v1.2 revision 3 against the published v1.0 on 57 papers

Provenance: agent:claude-opus-5-5. AI judgments only (`human_confirmed=false`). Machine report:
[POSTSLR_RUN.json](POSTSLR_RUN.json), from `scripts/postslr_report.py`. Measures and reading:
[PREREGISTRATION_POSTSLR.md](../PREREGISTRATION_POSTSLR.md) (v2.0, published before the first rated request);
reporting rules added before any paired result: [OUTCOME_RULES.md](../OUTCOME_RULES.md).

- **Arms:** {a} (rubric v1.2 r3 + H5) against {b} (published v1.0 + the original handbook).
- **Papers:** {out["papers"]} ({len(out["hazard_detector_papers"])} hazard detectors).
- **Paper-executions finished in both arms:** {out["paper_executions_in_comparison"]} of
  {out["paper_executions_possible"]}. Missing: {json.dumps(out["missing_paper_executions"])}.
- **Seed:** `{out["seed"]}`; 10,000 paper-bootstrap resamples, percentile interval.

## Interpretation

{interpretation}

{tables(out)}
## Kind of agreement and levels (declared in OUTCOME_RULES)

- Agreed-score panels by level ({a} / {b}): {pair("levels")}
- Agreement beyond 0 (all scored, at least one above 0): {pair("agreement_beyond_zero")}
- Unanimous non-scored status of "agreed not applicable" panels: {pair("unanimous_non_scored_status")}
- Scope and scores above 0 by pillar: {pair("scope_and_levels")}

## Exploratory

- **Fleiss' kappa** (paper-bootstrap 95% interval, 2,000 resamples):
  - {a}: scores only {kap[a]["scores_only"]["kappa"]} {kap[a]["scores_only"]["interval_95"]}; with not
    applicable {kap[a]["with_not_applicable"]["kappa"]} {kap[a]["with_not_applicable"]["interval_95"]}
  - {b}: scores only {kap[b]["scores_only"]["kappa"]} {kap[b]["scores_only"]["interval_95"]}; with not
    applicable {kap[b]["with_not_applicable"]["kappa"]} {kap[b]["with_not_applicable"]["interval_95"]}
- **P4 only (paired):** {json.dumps(out["exploratory_p4_only"])}
- **Rater pairs and per-rater usable judgments:** {pair("exploratory_rater_subsets")}

## Coverage, failures, mechanics and cost

- Coverage (panels / judgments): {pair("coverage_final")}
- Request paths and re-requests (coverage before re-requests is request-level: a declared deviation):
  {pair("request_paths")}
- Mechanics (correction turns, re-requests, adjacent-page accepts, failed requests, cost USD):
  {pair("mechanics")}

## Profiles, scope and stability

- OVI-Gate of agreed profiles: {pair("profiles")}
- Papers agreed out of scope (P1–P3 not applicable): {pair("out_of_scope_papers")}
- Repeat stability (panels resolved in both executions: same trio / changed): {pair("repeat_stability")}
- After discussion (class counts per run): {json.dumps(out["after_discussion"], sort_keys=True)}

## Effect sizes beside the earlier tests (side by side, not compared formally)

| Test | Panels | Refined | v1.0 | Difference | 95% interval |
|---|---:|---:|---:|---:|---|
{eff_rows}

{eff["note"]}

## Deviations

From the stage 2 amendment: search sources (Scholar not run, OpenAlex added, SciSpace in part); the analyst
screened and Gabriel checked (extent at title/abstract stage to be confirmed); 10 full texts not retrieved;
stage 1 published after screening; cost estimate 25 → 53. Found later: the planned citation tracking was not
done; the screening notes anticipated v1.2 scope outcomes; coverage before re-requests is request-level.
RUN-DEVIATIONS (any stop or resume during the run).
"""


RESUMED_NOTE = (
    "Resumed run, a declared deviation from the stopping rule (Gabriel, 12 Nov 2026): the stopped "
    "comparison in POSTSLR_RUN.json stays primary with its pre-registered reading; this completed "
    "comparison is reported beside it. Code amendment: CODE_AMENDMENT.json. The parked request "
    "(paper 10077, execution 1, r1) was not re-sent."
)


def resumed_labels(text: str) -> str:
    """Relabel the shared renderers' wording so the resumed run is never presented as the primary."""
    for old, new in (
        (" on 57 papers\n", " on 57 papers: the RESUMED run (declared deviation; not the primary)\n"),
        ("**Primary: resolved, R0**", "**Resolved, R0 (resumed run; not the pre-registered primary)**"),
        (
            "Pre-registered reading of the primary interval",
            "Reading by the pre-registered rule (descriptive)",
        ),
        ("POSTSLR (v1.2 r3, post-review)", "POSTSLR resumed (v1.2 r3; declared deviation)"),
    ):
        text = text.replace(old, new)
    return text


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--ledger",
        type=Path,
        required=True,
        help="a copy of programme.sqlite3 (FREEZE.json is read from the same folder)",
    )
    ap.add_argument("--parity", action="store_true", help="only check CORPUS3B parity and exit")
    ap.add_argument(
        "--resumed",
        action="store_true",
        help="the completed ledger after the declared resume: write POSTSLR_RUN_RESUMED.* and leave the "
        "stopped (primary) POSTSLR_RUN.* untouched",
    )
    a = ap.parse_args()
    if a.parity:
        result = parity(a.ledger)
        print(json.dumps(result, indent=1))
        sys.exit(0 if result["ok"] else 1)
    out = report(a.ledger)
    stem = "POSTSLR_RUN_RESUMED" if a.resumed else "POSTSLR_RUN"
    target = RESULTS / f"{stem}.json"
    if not a.resumed and target.exists():
        # The stopped comparison is the pre-registered primary: write-once (methods review, 12 Nov 2026).
        sys.exit("POSTSLR_RUN.json (the primary) exists and is never rewritten; use --resumed")
    if a.resumed:
        primary = json.loads((RESULTS / "POSTSLR_RUN.json").read_text())
        out["resumed_run"] = RESUMED_NOTE
        eff = out["effect_sizes"]
        eff["POSTSLR resumed (v1.2 r3; declared deviation)"] = eff.pop("POSTSLR (v1.2 r3, post-review)")
        out["resumed_extras"] = resumed_extras(
            a.ledger, out["rows"], primary["rows"], (REFINED, COMPARATOR), fp.POSTSLR_SEED
        )
    RESULTS.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(out, indent=2, default=list) + "\n")
    md = RESULTS / f"{stem}.md"
    if not md.exists():  # never overwrite the hand-written interpretation
        text = report_md(out)
        if a.resumed:
            link = "[POSTSLR_RUN.json](POSTSLR_RUN.json)"
            text = resumed_labels(text.replace(link, f"[{stem}.json]({stem}.json)", 1))
        md.write_text(text)
    tables_name = "POSTSLR_TABLES_RESUMED.md" if a.resumed else "POSTSLR_TABLES.md"
    body = tables(out)
    head = f"# Post-SLR evaluation: tables rendered from {stem}.json\n\n"
    if a.resumed:
        body, head = resumed_labels(body), head + f"**{RESUMED_NOTE}**\n\n"
    (RESULTS / tables_name).write_text(
        head + "Provenance: agent:claude-opus-5-5; "
        "generated by scripts/postslr_report.py. AI judgments only (human_confirmed=false).\n\n" + body
    )
    print(json.dumps({k: v for k, v in out.items() if k != "rows"}, indent=1, default=list))


if __name__ == "__main__":
    main()
