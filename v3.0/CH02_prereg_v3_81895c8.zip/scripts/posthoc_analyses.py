"""Post hoc, exploratory analyses requested in review (docs/overnight-2026-11-11/REVIEW_LOG.md, Cycle 5):
ablation and baselines, operating characteristics, rater pairs, difference-of-differences, validity anchors,
a stage table and the change log.

Everything comes from stored data:
- the committed stage reports and their per-panel `rows` (CORPUS_RUN.json, CORPUS3B_RUN.json,
  POSTSLR_RUN.json, POSTSLR_RUN_RESUMED.json, ...);
- the post-resume BACKUP copy of the final-phase ledger, opened read-only and immutable (held-out and
  development rows, requests, attempts, charges, timestamps). Nothing is dispatched, no pipeline runner is
  invoked, and no ledger is written;
- the read-only SLR tree, for the review authors' worked-example scores only.

Before any analysis, the ledger reader is checked against the committed reports (rows, class counts,
primary intervals, costs, request outcomes); any mismatch stops the script.

Outputs hold IDs, classes, counts, scores and hashes only: judgment payloads are read through json_extract
of pillar, status and score, and completions through their numeric fields, so no paper text, figure or
quotation is read into this script or written by it. Rubric changes are referenced by file and row, never
paraphrased.

Provenance of every output: agent:claude-opus-5-5 (subagent), post hoc, exploratory, not pre-registered;
AI judgments only.
"""

from __future__ import annotations

import hashlib
import json
import random
import re
import sqlite3
import statistics
import sys
from collections import Counter
from datetime import datetime
from math import comb
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from corpus_report import RESOLVED, compare, interval  # noqa: E402
from discussion_report import classify  # noqa: E402
from postslr_report import STOP_UTC  # noqa: E402

from pipeline.study.records import PILLARS, RATERS  # noqa: E402

PROVENANCE = "agent:claude-opus-5-5 (subagent), post hoc, exploratory, not pre-registered; AI judgments only"
RESULTS = ROOT / "docs/final-phase-2026-10-28/results"
POSTSLR = ROOT / "docs/postslr-2026-11/results"
FINAL_DOCS = ROOT / "docs/final-phase-2026-10-28"
OUT = ROOT / "docs/chapter-draft/supplement"
LEDGER = ROOT / ".research-private/final-phase-live-v1/backup-post-resume-20261112/programme.sqlite3"
SLR_SUPPLEMENT = Path("/Users/gabriel/Projects/Griffith/SLR - new/IEEE_ACCESS_SLR_revision/supplementary.tex")
SEED = "ch2-posthoc-20261112"  # every new bootstrap below; declared here, after the results (post hoc)
RESAMPLES, KAPPA_RESAMPLES = 10000, 2000
PAIRS = ((0, 1), (0, 2), (1, 2))
NAMES = {"r1": "gpt-6.1-sol", "r2": "glm-5.3", "r3": "claude-sonnet-5-5"}

# Two-arm tests. `source` None: rows are rebuilt from the backup ledger (the held-out report kept counts
# only). `seed`: the bootstrap seed each stage declared (corpus_report / hazard_sensitivity / postslr_report);
# the held-out evaluation declared no bootstrap, so it gets the post hoc seed.
TESTS = {
    "heldout": {
        "label": "Held-out (15 papers), refined vs original handbook, both v1.0",
        "refined": "EVAL_REFINED",
        "comparator": "EVAL_ORIGINAL",
        "source": None,
        "seed": SEED,
    },
    "unseen": {
        "label": "Unseen corpus (42), v1.1 vs v1.0",
        "refined": "CORPUS2_V11",
        "comparator": "CORPUS2_V10",
        "source": RESULTS / "CORPUS_RUN.json",
        "seed": "corpus-run-20261030",
    },
    "exposed": {
        "label": "Exposed corpus (42), v1.2 r3 vs v1.0",
        "refined": "CORPUS3B_V12",
        "comparator": "CORPUS3_V10",
        "source": RESULTS / "CORPUS3B_RUN.json",
        "seed": "corpus3-run-20261031",
    },
    "newlit_stopped": {
        "label": "New literature, stopped (pre-registered primary), v1.2 r3 vs v1.0",
        "refined": "POSTSLR_V12",
        "comparator": "POSTSLR_V10",
        "source": POSTSLR / "POSTSLR_RUN.json",
        "seed": "ch2-postslr-20261101",
    },
    "newlit_completed": {
        "label": "New literature, completed (resumed; declared deviation), v1.2 r3 vs v1.0",
        "refined": "POSTSLR_V12",
        "comparator": "POSTSLR_V10",
        "source": POSTSLR / "POSTSLR_RUN_RESUMED.json",
        "seed": "ch2-postslr-20261101",
    },
}
# Revision 2 of v1.2 on the exposed corpus: stage table and operating characteristics only.
EXPOSED_R2 = {"refined": "CORPUS3_V12", "comparator": "CORPUS3_V10", "source": RESULTS / "CORPUS3_RUN.json"}
DEV_CYCLES = ("DEV_C0", "DEV_C1", "DEV_C2", "DEV_C3")

# Validity anchors: the review's worked-example table (supplementary.tex, label tab:rubric_examples). The row
# line, the surname token that must appear in it, and the study it maps to in data/primaries.csv (study_key
# and title checked by hand on 12 Nov 2026; He et al. 2023 is disambiguated by its infant-drowning
# descriptor).
WORKED_EXAMPLES = {
    344: (34, "Johnson_2022", "Johnson"),
    345: (25, "HeQ_2023", "He et al"),
    346: (27, "Hou_2025", "Hou et al"),
    347: (4, "Alshibli_2025", "Alshibli"),
}
ANCHOR_ARMS = {
    "v1.0 rubric": (
        "DEV_C0",
        "DEV_C1",
        "DEV_C2",
        "DEV_C3",
        "EVAL_ORIGINAL",
        "EVAL_REFINED",
        "CORPUS2_V10",
        "CORPUS3_V10",
    ),
    "refined rubric": ("CORPUS2_V11", "CORPUS3_V12", "CORPUS3B_V12"),
}

# Corpus paper types, for post-stratification. Only hazard detectors were classified for every corpus paper
# (DEC-0010, "from the papers, not from any score"); the other two types come from rulings documents that
# named the papers behind a ruling, so the corpus "other" stratum may still hold unflagged papers of them.
CORPUS_TYPE_SOURCES = {
    "hazard_detector": "HAZARD_SENSITIVITY.json hazard_papers (DEC-0010 table) intersected with the corpus",
    "people_detector": "RUBRIC_V1_2.md row 12 (papers 4, 11, 46); PROGRAMME_RESULTS.md Finding 5",
    "records_based": "DEC-0010, 'Considered and not included' (paper 75)",
}
CORPUS_PEOPLE, CORPUS_RECORDS, CORPUS_AMBIGUOUS = (4, 11, 46), (75,), 63  # 63: DEC-0010, drowning or people

# The 19 documented rubric changes (RUBRIC_V1_1.md rows 1-11, RUBRIC_V1_2.md rows 12-19). Class: the panel
# class of the disagreement that prompted the change, from the row's evidence column; basis "stated" when the
# row states the split or the scores, "inferred" when it describes one rater's reading against the others',
# "not stated" when the row does not say. Regression: prompted by a fall in agreement after an earlier
# revision. Text location: the key of the rubric YAML that carries the changed text.
CHANGES = (
    (
        1,
        "v1.1",
        1,
        "scope",
        "P1-P3",
        "split_not_applicable_vs_score",
        "stated",
        (42, 77, 60, 28, 40, 47, 59),
        "B, C, D",
        False,
    ),
    (2, "v1.1", 1, "reading_the_criteria", "all", "none (co-author query, D2)", "stated", (), "", False),
    (3, "v1.1", 1, "pillars.P1.definitions", "P1", "score_disagreement", "stated", (60, 17), "M", False),
    (4, "v1.1", 1, "pillars.P2.definitions", "P2", "score_disagreement", "stated", (60,), "N", False),
    (5, "v1.1", 1, "pillars.P3.definitions", "P3", "score_disagreement", "inferred", (77,), "E, L", False),
    (
        6,
        "v1.1",
        1,
        "pillars.P4.levels.0",
        "P4",
        "P4 split, class not stated; rubric gap",
        "not stated",
        (38, 83),
        "K",
        False,
    ),
    (
        7,
        "v1.1",
        1,
        "pillars.P4.levels.1",
        "P4",
        "unresolved P4 panels, class not stated",
        "not stated",
        (27, 47, 59),
        "",
        False,
    ),
    (
        8,
        "v1.1",
        1,
        "pillars.P4.definitions",
        "P4",
        "P4 splits, class not stated",
        "not stated",
        (6, 53, 27, 47, 59),
        "F, J, O",
        False,
    ),
    (9, "v1.1", 2, "scope", "P1-P3", "split_not_applicable_vs_score", "stated", (72,), "", True),
    (10, "v1.1", 2, "pillars.P4.definitions", "P4", "score_disagreement", "inferred", (47,), "", False),
    (11, "v1.1", 2, "pillars.P4.definitions", "P4", "score_disagreement", "stated", (27,), "", False),
    (12, "v1.2", 1, "scope", "P1-P3", "split_not_applicable_vs_score", "stated", (4, 11, 46), "", False),
    (13, "v1.2", 1, "pillars.P4.definitions", "P4", "score_disagreement", "inferred", (66, 81), "", False),
    (14, "v1.2", 1, "pillars.P4.definitions", "P4", "score_disagreement", "inferred", (26, 41), "", False),
    (15, "v1.2", 1, "pillars.P1.definitions", "P1", "score_disagreement", "stated", (50,), "", False),
    (16, "v1.2", 2, "scope", "P1-P3", "split_not_applicable_vs_score", "inferred", (29,), "", True),
    (17, "v1.2", 2, "scope", "P1-P3", "split_not_applicable_vs_score", "inferred", (50,), "", True),
    (18, "v1.2", 2, "pillars.P4.definitions", "P4", "score_disagreement", "stated", (41,), "", False),
    (
        19,
        "v1.2",
        3,
        "pillars.P4.definitions",
        "P4",
        "score_disagreement",
        "stated",
        (35, 48, 64, 67),
        "",
        True,
    ),
)
CHANGE_LOGS = {"v1.1": FINAL_DOCS / "RUBRIC_V1_1.md", "v1.2": FINAL_DOCS / "RUBRIC_V1_2.md"}
CHANGE_TEXT = {
    ("v1.1", 1): "rubric/rubric_v1_1.yaml",
    ("v1.1", 2): "rubric/rubric_v1_1.yaml",
    ("v1.2", 1): "rubric/rubric_v1_2.yaml",
    ("v1.2", 2): "rubric/rubric_v1_2.yaml",
    ("v1.2", 3): "rubric/rubric_v1_2_r3.yaml",
}


# --------------------------------------------------------------------------------------------------------
# Reading stored data


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def open_ledger(path: Path = LEDGER) -> sqlite3.Connection:
    """The post-resume backup copy only, read-only and immutable. Guard: any other file (a live ledger) is
    refused, and a missing backup stops the script."""
    if path.resolve() != LEDGER.resolve():
        raise SystemExit(f"Refusing {path}: only the backup copy {LEDGER} may be read")
    if not path.is_file():
        raise SystemExit(f"Backup ledger missing: {path}")
    db = sqlite3.connect(f"{path.resolve().as_uri()}?mode=ro&immutable=1", uri=True)
    db.row_factory = sqlite3.Row
    return db


def conditions() -> dict:
    """FREEZE.json beside the backup: condition -> runs (execution order) and frozen hashes."""
    return json.loads((LEDGER.parent / "FREEZE.json").read_text())["conditions"]


def manifest(db: sqlite3.Connection, run: str) -> dict:
    row = db.execute("SELECT manifest FROM runs WHERE id=?", (run,)).fetchone()
    if row is None:
        raise SystemExit(f"Run {run} not in the backup ledger")
    return json.loads(row["manifest"])


def run_trios(db: sqlite3.Connection, run: str) -> dict[int, dict[str, list]]:
    """Paper -> pillar -> (r1, r2, r3) R0 verdicts, None for a failed judgment. Mirrors
    pipeline.study.discussion.round_results and verdict: failures first (failed_pillars, else the request's
    pending pillars), then judgments override. Only pillar, status and score are read from a judgment."""
    cells: dict[tuple, tuple | None] = {}
    for r in db.execute(
        "SELECT q.study, q.rater, json_extract(q.context,'$.pending') AS pending, "
        "json_extract(d.payload,'$.failed_pillars') AS failed FROM dispositions d "
        "JOIN requests q ON q.id=d.request_id WHERE q.run_id=? AND q.round=0 AND q.kind='rating'",
        (run,),
    ):
        failed = json.loads(r["failed"]) if r["failed"] is not None else None
        for p in failed or json.loads(r["pending"]):
            cells[(r["study"], r["rater"], p)] = None
    for r in db.execute(
        "SELECT q.study, q.rater, json_extract(j.payload,'$.pillar') AS pillar, "
        "json_extract(j.payload,'$.status') AS status, json_extract(j.payload,'$.score') AS score "
        "FROM judgments j JOIN requests q ON q.id=j.request_id "
        "WHERE q.run_id=? AND q.round=0 AND q.kind='rating'",
        (run,),
    ):
        verdict = ("scored", r["score"]) if r["status"] == "scored" else (r["status"], None)
        cells[(r["study"], r["rater"], r["pillar"])] = verdict
    papers = [p["study_id"] for p in manifest(db, run)["papers"]]
    return {s: {p: [cells.get((s, x, p)) for x in RATERS] for p in PILLARS} for s in papers}


def finished(db: sqlite3.Connection, run: str) -> set[int]:
    """Papers whose three R0 requests each ended in judgments or a recorded failure
    (corpus_report.complete)."""
    rows = db.execute(
        "SELECT q.study, COUNT(*) AS n FROM requests q WHERE q.run_id=? AND q.round=0 AND ("
        "EXISTS(SELECT 1 FROM judgments j WHERE j.request_id=q.id) OR "
        "EXISTS(SELECT 1 FROM dispositions d WHERE d.request_id=q.id)) GROUP BY q.study",
        (run,),
    ).fetchall()
    return {r["study"] for r in rows if r["n"] == len(RATERS)}


def ledger_rows(db, runs: dict[str, list[str]], require_all: bool = False) -> list[dict]:
    """Panels paired by execution x paper x pillar over paper-executions finished in every arm (the stage
    reports' rule). Guard: with require_all, an unfinished paper-execution stops the script."""
    arms = list(runs)
    executions = {len(v) for v in runs.values()}
    if len(executions) != 1:
        raise SystemExit(f"Arms {arms} have different execution counts")
    rows = []
    for e in range(executions.pop()):
        trios = {arm: run_trios(db, runs[arm][e]) for arm in arms}
        both = set.intersection(*(finished(db, runs[arm][e]) for arm in arms))
        papers = set.intersection(*(set(t) for t in trios.values()))
        if require_all and both != papers:
            raise SystemExit(
                f"Unfinished paper-executions in {arms} execution {e + 1}: {sorted(papers - both)}"
            )
        for s in sorted(both):
            for p in PILLARS:
                row = {"execution": e + 1, "study": s, "pillar": p}
                for arm in arms:
                    row[arm] = classify(trios[arm][s][p])
                    row[arm + "_trio"] = trios[arm][s][p]
                rows.append(row)
    return rows


def committed_rows(path: Path, arms: tuple[str, ...]) -> list[dict]:
    """A committed report's rows, trios as tuples. Guard: every row carries both arms."""
    rows = json.loads(path.read_text())["rows"]
    out = []
    for r in rows:
        if any(a not in r or a + "_trio" not in r for a in arms):
            raise SystemExit(f"{path.name}: a row lacks arm {arms}")
        row = {k: r[k] for k in ("execution", "study", "pillar")}
        for a in arms:
            row[a] = r[a]
            row[a + "_trio"] = [tuple(v) if v else None for v in r[a + "_trio"]]
        out.append(row)
    return out


def normalised(rows: list[dict], arms: tuple[str, ...]) -> list[tuple]:
    return sorted(
        (
            r["execution"],
            r["study"],
            r["pillar"],
            *(r[a] for a in arms),
            *(tuple(tuple(v) if v else None for v in r[a + "_trio"]) for a in arms),
        )
        for r in rows
    )


def load_requests(db, runs: list[str]) -> list[dict]:
    """Every request of the runs, with its attempts, number of stored judgments and disposition status.
    Reads stages, timestamps, charges and numeric completion fields only (json_extract): never reply text."""
    marks = ",".join("?" * len(runs))
    reqs = {
        r["id"]: {**dict(r), "attempts": [], "judged": 0, "disposition": None}
        for r in db.execute(
            f"SELECT id, run_id, study, rater, round, kind FROM requests WHERE run_id IN ({marks})", runs
        )
    }
    for a in db.execute(
        "SELECT a.request_id, a.stage, a.transport, a.created, c.created AS done, c.charged, "
        "json_extract(c.result,'$.input_tokens') AS tokens_in, "
        "json_extract(c.result,'$.output_tokens') AS tokens_out "
        "FROM attempts a JOIN requests q ON q.id=a.request_id "
        f"LEFT JOIN completions c ON c.attempt_id=a.id WHERE q.run_id IN ({marks})",
        runs,
    ):
        reqs[a["request_id"]]["attempts"].append(dict(a))
    for j in db.execute(
        "SELECT j.request_id, COUNT(*) AS n FROM judgments j JOIN requests q ON q.id=j.request_id "
        f"WHERE q.run_id IN ({marks}) GROUP BY j.request_id",
        runs,
    ):
        reqs[j["request_id"]]["judged"] = j["n"]
    for d in db.execute(
        "SELECT d.request_id, json_extract(d.payload,'$.status') AS status, CASE WHEN "
        "json_extract(d.payload,'$.status')='process_failure' THEN json_extract(d.payload,'$.reason') END AS "
        f"reason FROM dispositions d JOIN requests q ON q.id=d.request_id WHERE q.run_id IN ({marks})",
        runs,
    ):  # the reason is read for process failures only: a runner message (provider status, timeout)
        reqs[d["request_id"]]["disposition"] = d["status"] or "unstated"
        reqs[d["request_id"]]["reason"] = d["reason"]
    return list(reqs.values())


# --------------------------------------------------------------------------------------------------------
# Panel rules (analysis 1)


def unanimous(t: list) -> bool:
    """The primary rule: no failed judgment and three identical verdicts."""
    return None not in t and len(set(t)) == 1


def majority(t: list) -> bool:
    """Two of three: at least two identical usable verdicts (failed judgments are no vote)."""
    return any(n >= 2 for n in Counter(v for v in t if v is not None).values())


def failures_ignored(t: list) -> bool:
    """Unanimity among usable judgments, with at least two usable."""
    usable = [v for v in t if v is not None]
    return len(usable) >= 2 and len(set(usable)) == 1


def pair_rule(i: int, j: int):
    def rule(t: list) -> bool:
        return t[i] is not None and t[j] is not None and t[i] == t[j]

    return rule


RULES = {
    "unanimity (resolved)": unanimous,
    "majority of three": majority,
    "unanimity, failed judgments ignored": failures_ignored,
    **{f"pair {RATERS[i]}+{RATERS[j]}": pair_rule(i, j) for i, j in PAIRS},
}


def trio_rows(rows: list[dict], arms: tuple[str, str]) -> list[dict]:
    """Rows whose arm values are the trios, so corpus_report.compare applies a trio rule."""
    return [{"study": r["study"], **{a: r[a + "_trio"] for a in arms}} for r in rows]


def paired_rule(rows, rule, arms, seed) -> dict:
    """Paired refined-minus-comparator difference under a rule (corpus_report.compare, 10,000 resamples)."""
    c = compare(trio_rows(rows, arms), rule, arms[0], arms[1], seed)
    return {
        "panels": c["panels"],
        "refined": c["v1_2"],
        "comparator": c["v1_0"],
        "difference": c["difference"],
        "interval_95": c["interval_95"],
    }


def arm_rules(rows: list[dict], arm: str) -> dict:
    """Per-arm shares under each rule, failed judgments counted or excluded, and leave-one-out agreement."""
    trios = [r[arm + "_trio"] for r in rows]
    n = len(trios)
    no_fail = [t for t in trios if None not in t]
    pairs = {}
    for i, j in PAIRS:
        both = [t for t in trios if t[i] is not None and t[j] is not None]
        same = sum(t[i] == t[j] for t in both)
        pairs[f"{RATERS[i]}+{RATERS[j]}"] = {
            "both_usable": len(both),
            "same_verdict": same,
            "share_of_all_panels": round(same / n, 4),
        }
    loo = {}
    for i, x in enumerate(RATERS):
        j, k = (y for y in range(3) if y != i)
        agree = [t for t in trios if t[j] is not None and t[k] is not None and t[j] == t[k]]
        loo[x] = {
            "other_two_agree": len(agree),
            "matches": sum(t[i] == t[j] for t in agree),
            "differs_usable": sum(t[i] is not None and t[i] != t[j] for t in agree),
            "failed": sum(t[i] is None for t in agree),
        }
    return {
        "panels": n,
        "resolved_three_raters": sum(map(unanimous, trios)),
        "complete_and_agreeing": sum(r[arm] == "agree_score" for r in rows),
        "majority_of_three": sum(map(majority, trios)),
        "majority_on_a_score": sum(
            any(c >= 2 and v[0] == "scored" for v, c in Counter(v for v in t if v).items()) for t in trios
        ),
        "failures_ignored": sum(map(failures_ignored, trios)),
        "failed_judgments_excluded": {
            "panels_without_failure": len(no_fail),
            "resolved": sum(map(unanimous, no_fail)),
        },
        "pairs": pairs,
        "leave_one_out": loo,
    }


def ablation(tests: dict) -> dict:
    out = {}
    for key, t in tests.items():
        arms = (t["refined"], t["comparator"])
        rows = t["rows"]
        complete_case = [r for r in rows if all(None not in r[a + "_trio"] for a in arms)]
        out[key] = {
            "label": t["label"],
            "seed": t["seed"],
            "per_arm": {a: arm_rules(rows, a) for a in arms},
            "paired_differences": {
                **{name: paired_rule(rows, rule, arms, t["seed"]) for name, rule in RULES.items()},
                "unanimity, complete cases only": paired_rule(complete_case, unanimous, arms, t["seed"]),
            },
        }
    return out


# --------------------------------------------------------------------------------------------------------
# Operating characteristics (analysis 2)


def seconds(start: str, end: str) -> float:
    return (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds()


def quantile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    s = sorted(values)
    return round(s[max(0, -(-int(q * 100) * len(s) // 100) - 1)], 1)


def outcome(q: dict) -> str:
    """judgments (no failure record), partial (judgments and a failure record), failed (failure record
    only), pending (neither: never dispositioned)."""
    if q["judged"] and q["disposition"]:
        return "partial"
    if q["judged"]:
        return "judgments"
    return "failed" if q["disposition"] else "pending"


def attempt_kinds(attempts: list[dict]) -> Counter:
    """Stages as the runner numbers them (v11_report.mechanics): 3k+1 format recovery, 3k+2 correction
    turn, 3k (k >= 1, transport 0) re-request; transport > 0 is a transport retry."""
    c = Counter()
    for a in attempts:
        c["attempts"] += 1
        c["format_recovery"] += a["stage"] % 3 == 1
        c["correction_turn"] += a["stage"] % 3 == 2
        c["re_request"] += a["stage"] >= 3 and a["stage"] % 3 == 0 and a["transport"] == 0
        c["transport_retry"] += a["transport"] > 0
    return c


def summarise_requests(reqs: list[dict]) -> dict:
    out = Counter(outcome(q) for q in reqs)
    kinds = sum((attempt_kinds(q["attempts"]) for q in reqs), Counter())
    latencies = [seconds(a["created"], a["done"]) for q in reqs for a in q["attempts"] if a["done"]]
    n = len(reqs)
    process = [q for q in reqs if q["disposition"] == "process_failure" and not q["judged"]]
    tokens_in = [a["tokens_in"] for q in reqs for a in q["attempts"] if a["done"]]
    tokens_out = [a["tokens_out"] for q in reqs for a in q["attempts"] if a["done"]]
    return {
        "requests": n,
        "outcomes": dict(sorted(out.items())),
        "failure_records_by_status": dict(Counter(q["disposition"] for q in reqs if q["disposition"])),
        "rates": {k: round(out[k] / n, 4) if n else None for k in ("failed", "partial", "pending")}
        | {"process_failure": round(len(process) / n, 4) if n else None},
        "process_failures": len(process),
        "process_failure_reasons": dict(Counter(q.get("reason") for q in process)),
        "attempts": dict(sorted(kinds.items())),
        "cost_usd": round(sum(a["charged"] or 0 for q in reqs for a in q["attempts"]), 4),
        "tokens": {
            "input": sum(x for x in tokens_in if x is not None),
            "output": sum(x for x in tokens_out if x is not None),
            "attempts_without_token_fields": sum(x is None for x in tokens_in),
        },
        "latency_s": {
            "attempts_with_completion": len(latencies),
            "median": round(statistics.median(latencies), 1) if latencies else None,
            "p90": quantile(latencies, 0.9),
            "max": round(max(latencies), 1) if latencies else None,
        },
        "attempts_without_completion": sum(not a["done"] for q in reqs for a in q["attempts"]),
    }


def operating(reqs: list[dict], rows: list[dict] | None, arm: str, cutoff: str | None) -> dict:
    """R0 rating requests of one arm (with cutoff: those whose first attempt came before it, i.e. launch 1
    of the stopped run), by rater; discussion requests separately; failed pillar judgments per rater in the
    comparison rows."""

    def first(q):
        return min((a["created"] for a in q["attempts"]), default=None)

    if cutoff:
        reqs = [q for q in reqs if first(q) is not None and first(q) <= cutoff]
        for q in reqs:
            q["attempts"] = [a for a in q["attempts"] if a["created"] <= cutoff]
    r0 = [q for q in reqs if q["round"] == 0 and q["kind"] == "rating"]
    later = [q for q in reqs if q["round"] > 0]
    starts = [a["created"] for q in r0 for a in q["attempts"]]
    ends = [a["done"] for q in r0 for a in q["attempts"] if a["done"]]
    failed_judgments = None
    if rows is not None:
        failed_judgments = {x: sum(r[arm + "_trio"][i] is None for r in rows) for i, x in enumerate(RATERS)}
    return {
        "r0": summarise_requests(r0),
        "r0_by_rater": {x: summarise_requests([q for q in r0 if q["rater"] == x]) for x in RATERS},
        "discussion": {
            "requests": len(later),
            "cost_usd": round(sum(a["charged"] or 0 for q in later for a in q["attempts"]), 4),
        },
        "cost_total_usd": round(sum(a["charged"] or 0 for q in reqs for a in q["attempts"]), 4),
        "r0_wall_clock_hours": round(seconds(min(starts), max(ends)) / 3600, 2) if starts and ends else None,
        "failed_pillar_judgments_in_comparison": failed_judgments,
        "comparison_panels": len(rows) if rows is not None else None,
    }


# --------------------------------------------------------------------------------------------------------
# Rater pairs (analysis 3)


def category(v: tuple | None, with_na: bool) -> str | None:
    """A judgment's category: its level; 'na' for any non-scored status when with_na (else excluded);
    None for a failed judgment."""
    if v is None:
        return None
    if v[0] == "scored":
        return str(v[1])
    return "na" if with_na else None


def cohen_kappa(conf: Counter) -> float | None:
    """Unweighted Cohen's kappa from (a, b) category counts; None when undefined (no items, or chance
    agreement 1 because both raters used one and the same category throughout)."""
    n = sum(conf.values())
    if not n:
        return None
    po = sum(c for (a, b), c in conf.items() if a == b) / n
    ra, rb = Counter(), Counter()
    for (a, b), c in conf.items():
        ra[a] += c
        rb[b] += c
    pe = sum(ra[x] * rb[x] for x in ra) / n**2
    return None if pe >= 1 else round((po - pe) / (1 - pe), 4)


def percentile_interval(draws: list[float]) -> list[float] | None:
    if not draws:
        return None
    draws = sorted(draws)
    return [round(draws[int(0.025 * len(draws))], 4), round(draws[int(0.975 * len(draws)) - 1], 4)]


def pair_agreement(rows: list[dict], arm: str, i: int, j: int, with_na: bool) -> dict:
    """Exact agreement and Cohen's kappa for raters i and j over panels where both have a category;
    paper-bootstrap 95% intervals (KAPPA_RESAMPLES, seed SEED, fresh per call so draws are shared)."""
    by_paper: dict[int, Counter] = {}
    for r in rows:
        c = by_paper.setdefault(r["study"], Counter())
        a, b = (category(r[arm + "_trio"][k], with_na) for k in (i, j))
        if a is not None and b is not None:
            c[(a, b)] += 1
    total = sum(by_paper.values(), Counter())
    n = sum(total.values())
    rng, papers, kappas, exact = random.Random(SEED), sorted(by_paper), [], []
    for _ in range(KAPPA_RESAMPLES):
        conf = Counter()
        for s in rng.choices(papers, k=len(papers)):
            conf.update(by_paper[s])
        m = sum(conf.values())
        if m:
            exact.append(sum(c for (a, b), c in conf.items() if a == b) / m)
        k = cohen_kappa(conf)
        if k is not None:
            kappas.append(k)
    agree = sum(c for (a, b), c in total.items() if a == b)
    return {
        "items": n,
        "exact_agreement": round(agree / n, 4) if n else None,
        "exact_interval_95": percentile_interval(exact),
        "kappa": cohen_kappa(total),
        "kappa_interval_95": percentile_interval(kappas),
        "kappa_resamples_defined": len(kappas),
    }


def pairwise(tests: dict) -> dict:
    out = {}
    for key, t in tests.items():
        out[key] = {
            a: {
                f"{RATERS[i]}+{RATERS[j]}": {
                    "scores_only": pair_agreement(t["rows"], a, i, j, False),
                    "with_not_applicable": pair_agreement(t["rows"], a, i, j, True),
                }
                for i, j in PAIRS
            }
            for a in (t["refined"], t["comparator"])
        }
    return out


# --------------------------------------------------------------------------------------------------------
# Difference-of-differences and post-stratification (analysis 4)


def paper_hits(rows: list[dict], measure, arms: tuple[str, str]) -> dict[int, tuple[int, int, int]]:
    out: dict[int, list[int]] = {}
    for r in rows:
        x = out.setdefault(r["study"], [0, 0, 0])
        x[0] += measure(r[arms[0]])
        x[1] += measure(r[arms[1]])
        x[2] += 1
    return {s: tuple(v) for s, v in out.items()}


def delta(hits: dict, papers) -> float:
    a = b = n = 0
    for s in papers:
        x, y, k = hits[s]
        a, b, n = a + x, b + y, n + k
    return (a - b) / n


def stratified_delta(hits: dict, strata: dict[str, list[int]], weights: dict[str, float]) -> float:
    return sum(w * delta(hits, strata[s]) for s, w in weights.items())


def did(corpus: dict, new: dict, strata: dict | None, weights: dict | None, seed: str) -> dict:
    """Exposed-corpus gain minus new-literature gain, papers resampled independently in each set
    (new-literature papers within strata when post-stratified); RESAMPLES draws, percentile interval."""

    def new_delta(sample):
        return stratified_delta(new, sample, weights) if strata else delta(new, sample)

    cp, base = sorted(corpus), strata or sorted(new)
    rng, draws = random.Random(seed), []
    for _ in range(RESAMPLES):
        c = delta(corpus, rng.choices(cp, k=len(cp)))
        if strata:
            sample = {s: rng.choices(v, k=len(v)) for s, v in strata.items()}
        else:
            sample = rng.choices(base, k=len(base))
        draws.append(c - new_delta(sample))
    e, nl = delta(corpus, cp), new_delta(strata or sorted(new))
    return {
        "exposed_gain": round(e, 4),
        "new_literature_gain": round(nl, 4),
        "difference_of_differences": round(e - nl, 4),
        "interval_95": percentile_interval(draws),
    }


def poststratified_gain(new: dict, strata: dict, weights: dict, seed: str) -> dict:
    rng, draws = random.Random(seed), []
    for _ in range(RESAMPLES):
        draws.append(stratified_delta(new, {s: rng.choices(v, k=len(v)) for s, v in strata.items()}, weights))
    return {
        "estimate": round(stratified_delta(new, strata, weights), 4),
        "interval_95": percentile_interval(draws),
    }


def corpus_types(corpus_papers: set[int], people_extra: tuple[int, ...] = ()) -> dict[int, str]:
    """Corpus paper -> type. Guard: every listed paper is a corpus paper; hazard detectors are those of
    HAZARD_SENSITIVITY.json present in the corpus, checked against its CORPUS3B entry."""
    hz = json.loads((RESULTS / "HAZARD_SENSITIVITY.json").read_text())
    hazard = set(hz["hazard_papers"]) & corpus_papers
    if sorted(hazard) != sorted(hz["corpus"]["CORPUS3B"]["hazard_papers_present"]):
        raise SystemExit("Corpus hazard detectors disagree with HAZARD_SENSITIVITY.json")
    people, records = set(CORPUS_PEOPLE) | set(people_extra), set(CORPUS_RECORDS)
    if not (people | records) <= corpus_papers or hazard & (people | records):
        raise SystemExit("Corpus type lists are inconsistent with the corpus")
    return {
        s: "hazard_detector"
        if s in hazard
        else "people_detector"
        if s in people
        else "records_based"
        if s in records
        else "other"
        for s in corpus_papers
    }


def new_types(path: Path) -> dict[int, str]:
    """New-literature paper -> type from the committed report's lists. Guard: the lists are disjoint."""
    d = json.loads(path.read_text())
    h, p, rb = (
        set(d["hazard_detector_papers"]),
        set(d["people_detector_papers"]),
        set(d["records_based_papers"]),
    )
    if h & p or h & rb or p & rb:
        raise SystemExit("New-literature type lists overlap")
    papers = {r["study"] for r in d["rows"]} | h | p | rb
    return {
        s: "hazard_detector"
        if s in h
        else "people_detector"
        if s in p
        else "records_based"
        if s in rb
        else "other"
        for s in papers
    }


def mix(types: dict[int, str], papers) -> dict[str, int]:
    return dict(sorted(Counter(types[s] for s in papers).items()))


def by_type(hits: dict, types: dict[int, str]) -> dict:
    out = {}
    for t in sorted(set(types[s] for s in hits)):
        ps = [s for s in hits if types[s] == t]
        out[t] = {
            "papers": len(ps),
            "panels": sum(hits[s][2] for s in ps),
            "difference": round(delta(hits, ps), 4),
        }
    return out


def collapse(types: dict[int, str], scheme: str) -> dict[int, str]:
    if scheme == "hazard vs rest":
        return {s: "hazard_detector" if t == "hazard_detector" else "rest" for s, t in types.items()}
    return types


def difference_of_differences(tests: dict) -> dict:
    exposed = tests["exposed"]
    arms_e = (exposed["refined"], exposed["comparator"])
    corpus_papers = {r["study"] for r in exposed["rows"]}
    if len(exposed["rows"]) != 8 * len(corpus_papers):
        raise SystemExit("Exposed-corpus rows are not 8 panels per paper; corpus weights would be wrong")
    schemes = {
        "hazard vs rest": corpus_types(corpus_papers),
        "four types": corpus_types(corpus_papers),
        "four types, paper 63 as a people detector": corpus_types(corpus_papers, (CORPUS_AMBIGUOUS,)),
    }
    measures = {"resolved": lambda c: c in RESOLVED, "complete_and_agreeing": lambda c: c == "agree_score"}
    out = {"corpus_type_sources": CORPUS_TYPE_SOURCES, "seed": SEED, "resamples": RESAMPLES, "targets": {}}
    for key in ("newlit_stopped", "newlit_completed"):
        new = tests[key]
        arms_n = (new["refined"], new["comparator"])
        ntypes = new_types(new["source"])
        res = {"paper_mix_new": mix(ntypes, {r["study"] for r in new["rows"]})}
        for mname, m in measures.items():
            ce, nn = paper_hits(exposed["rows"], m, arms_e), paper_hits(new["rows"], m, arms_n)
            entry = {"unweighted": did(ce, nn, None, None, SEED), "poststratified": {}}
            for sname, ctypes in schemes.items():
                ct, nt = collapse(ctypes, sname), collapse(ntypes, sname)
                weights = {k: v / len(corpus_papers) for k, v in mix(ct, corpus_papers).items()}
                strata = {k: sorted(s for s in nn if nt[s] == k) for k in weights}
                empty = [k for k, v in strata.items() if not v]
                note = None
                if empty:  # drop empty strata and renormalise: flagged, approximate
                    kept = sum(w for k, w in weights.items() if k not in empty)
                    weights = {k: w / kept for k, w in weights.items() if k not in empty}
                    strata = {k: v for k, v in strata.items() if k not in empty}
                    note = (
                        f"stratum {empty} empty in this comparison: its corpus weight was dropped and the "
                        "rest renormalised (approximate)"
                    )
                entry["poststratified"][sname] = {
                    "corpus_weights": {k: round(w, 4) for k, w in weights.items()},
                    "new_literature_by_stratum": by_type(nn, nt),
                    "exposed_by_stratum": by_type(ce, ct),
                    "new_literature_gain_poststratified": poststratified_gain(nn, strata, weights, SEED),
                    "difference_of_differences": did(ce, nn, strata, weights, SEED),
                    "note": note,
                }
            res[mname] = entry
        out["targets"][key] = res
    out["corpus_paper_mix"] = {s: mix(collapse(c, s), corpus_papers) for s, c in schemes.items()}
    return out


# --------------------------------------------------------------------------------------------------------
# Validity anchors (analysis 5)


def worked_examples(path: Path = SLR_SUPPLEMENT) -> dict[int, dict]:
    """The review authors' worked-example scores, read-only. Guard: the table label precedes the rows, each
    mapped row carries its surname token and exactly five integer cells, and the OVI equals the minimum."""
    if not path.is_file():
        raise SystemExit(f"SLR supplement not found (read-only): {path}")
    lines = path.read_text().splitlines()
    start = min(WORKED_EXAMPLES)
    if not any("tab:rubric_examples" in x for x in lines[start - 12 : start]):
        raise SystemExit("Worked-example table label not found above the expected rows")
    out = {}
    for line, (study, key, token) in WORKED_EXAMPLES.items():
        text = lines[line - 1]
        cells = [c.strip().rstrip("\\").strip() for c in re.split(r"(?<!\\)&", text)[1:]]  # \& is text
        if token not in text or len(cells) != 5 or not all(re.fullmatch(r"[0-3]", c) for c in cells):
            raise SystemExit(f"supplementary.tex line {line} is not the expected worked-example row")
        scores = dict(zip(PILLARS, map(int, cells[:4]), strict=True))
        if int(cells[4]) != min(scores.values()):
            raise SystemExit(f"supplementary.tex line {line}: OVI is not the minimum of the pillars")
        out[study] = {"study_key": key, "slr_line": line, "scores": scores, "ovi": int(cells[4])}
    keys = {
        int(r.split(",")[0]): r.split(",")[1]
        for r in (ROOT / "data/primaries.csv").read_text().splitlines()[1:]
    }
    for study, v in out.items():
        if keys.get(study) != v["study_key"]:
            raise SystemExit(f"data/primaries.csv study {study} is not {v['study_key']}")
    return out


def weighted_kappa(items: list[tuple[int, int]], k: int = 4) -> float | None:
    """Linear-weighted Cohen's kappa on levels 0..k-1; None when undefined (no items, or no expected
    disagreement)."""
    n = len(items)
    if not n:
        return None
    ra, rb = Counter(a for a, _ in items), Counter(b for _, b in items)
    observed = sum(abs(a - b) for a, b in items) / ((k - 1) * n)
    expected = sum(abs(i - j) * ra[i] * rb[j] for i in range(k) for j in range(k)) / ((k - 1) * n * n)
    return None if expected == 0 else round(1 - observed / expected, 4)


def agreement_stats(items: list[tuple[int, int]]) -> dict:
    """items: (review authors' score, AI agreed score)."""
    n = len(items)
    return {
        "items": n,
        "exact": sum(a == b for a, b in items),
        "within_one": sum(abs(a - b) <= 1 for a, b in items),
        "ai_higher": sum(b > a for a, b in items),
        "ai_lower": sum(b < a for a, b in items),
        "weighted_kappa_linear": weighted_kappa(items),
    }


def validity(db, conds: dict) -> dict:
    ref = worked_examples()
    panels = []
    for group, arms in ANCHOR_ARMS.items():
        for arm in arms:
            for e, run in enumerate(conds[arm]["runs"], 1):
                trios = run_trios(db, run)
                for s in sorted(set(trios) & set(ref)):
                    for p in PILLARS:
                        t = trios[s][p]
                        c = classify(t)
                        panels.append(
                            {
                                "group": group,
                                "arm": arm,
                                "execution": e,
                                "study": s,
                                "pillar": p,
                                "class": c,
                                "ai_score": t[0][1] if c == "agree_score" else None,
                                "review_score": ref[s]["scores"][p],
                            }
                        )
    groups = {}
    for group in ANCHOR_ARMS:
        g = [x for x in panels if x["group"] == group]
        agreed = [(x["review_score"], x["ai_score"]) for x in g if x["ai_score"] is not None]
        per_pillar = {
            p: agreement_stats(
                [
                    (x["review_score"], x["ai_score"])
                    for x in g
                    if x["pillar"] == p and x["ai_score"] is not None
                ]
            )
            for p in PILLARS
        }
        modal = []
        for s in sorted({x["study"] for x in g}):
            for p in PILLARS:
                c = Counter(
                    x["ai_score"]
                    for x in g
                    if x["study"] == s and x["pillar"] == p and x["ai_score"] is not None
                )
                top = c.most_common(2)
                if top and (len(top) == 1 or top[0][1] > top[1][1]):
                    modal.append((ref[s]["scores"][p], top[0][0]))
        groups[group] = {
            "arms": list(ANCHOR_ARMS[group]),
            "panels": len(g),
            "panel_classes": dict(sorted(Counter(x["class"] for x in g).items())),
            "agreed_score_panels": agreement_stats(agreed),
            "agreed_score_panels_by_pillar": per_pillar,
            "one_item_per_paper_pillar_modal_agreed_score": agreement_stats(modal),
        }
    cells = {}
    for s in sorted(ref):
        for p in PILLARS:
            entry = {"review_score": ref[s]["scores"][p]}
            for group in ANCHOR_ARMS:
                g = [x for x in panels if x["group"] == group and x["study"] == s and x["pillar"] == p]
                if g:
                    entry[group] = {
                        "panels": len(g),
                        "agreed_scores": dict(
                            sorted(
                                Counter(str(x["ai_score"]) for x in g if x["ai_score"] is not None).items()
                            )
                        ),
                        "other_classes": dict(
                            sorted(Counter(x["class"] for x in g if x["ai_score"] is None).items())
                        ),
                    }
            cells[f"{s}/{p}"] = entry
    profiles = Counter()
    for group, arm, e, s in {(x["group"], x["arm"], x["execution"], x["study"]) for x in panels}:
        four = [x for x in panels if (x["group"], x["arm"], x["execution"], x["study"]) == (group, arm, e, s)]
        if all(x["ai_score"] is not None for x in four):
            gate = min(x["ai_score"] for x in four)
            profiles[f"{group}: study {s} review OVI {ref[s]['ovi']}, AI OVI-Gate {gate}"] += 1
    return {
        "reference": {str(s): v for s, v in ref.items()},
        "reference_file": str(SLR_SUPPLEMENT),
        "reference_file_sha256": sha256_file(SLR_SUPPLEMENT),
        "by_group": groups,
        "by_paper_pillar": cells,
        "agreed_profiles": dict(sorted(profiles.items())),
    }


# --------------------------------------------------------------------------------------------------------
# Stage table (analysis 6) and change log (analysis 7)


def file_by_hash(candidates: list[Path]) -> dict[str, str]:
    return {sha256_file(p): str(p.relative_to(ROOT)) for p in candidates}


def rater_settings(models: dict) -> dict[str, str]:
    out = {}
    for r, m in sorted(models.items()):
        g = m.get("generation", m)
        flat = []
        for k, v in sorted(g.items()):
            if k in ("model", "store"):
                continue
            if isinstance(v, dict):
                flat += [f"{k}.{kk}={vv}" for kk, vv in sorted(v.items())]
            else:
                flat.append(f"{k}={v}")
        out[r] = f"{g.get('model', m.get('model'))} ({'; '.join(flat)})"
    return out


def stage_entry(db, conds, hashes, label, arm, rows, op, short: str) -> dict:
    runs = conds[arm]["runs"]
    ms = [manifest(db, r) for r in runs]
    files = ms[0]["papers"][0]["files"]
    settings = {json.dumps(rater_settings(m["models"]), sort_keys=True) for m in ms}
    versions = {
        json.dumps(
            {
                k: v
                for k, v in m.get("versions", {}).items()
                if k
                in (
                    "evidence_validator",
                    "evidence_correction",
                    "unreadable_resample",
                    "response_policy",
                    "discussion",
                )
            },
            sort_keys=True,
        )
        for m in ms
    }
    counts = Counter(r[arm] for r in rows)
    return {
        "stage": label,
        "stage_short": short,
        "arm": arm,
        "rubric_file": hashes.get(files["rubric.yaml"], "unmatched sha256:" + files["rubric.yaml"][:12]),
        # the procedure is identified by FREEZE.json's handbook_sha256 (the rated protocol.md wraps it)
        "procedure_file": hashes.get(
            conds[arm]["handbook_sha256"], "unmatched sha256:" + conds[arm]["handbook_sha256"][:12]
        ),
        "papers_in_manifest": len(ms[0]["papers"]),
        "executions": len(runs),
        "papers_compared": len({r["study"] for r in rows}),
        "paper_executions_compared": len({(r["study"], r["execution"]) for r in rows}),
        "panels": len(rows),
        "raters": [json.loads(s) for s in settings],
        "policies": [json.loads(v) for v in versions],
        "resolved": counts["agree_score"] + counts["agree_not_applicable"],
        "complete_and_agreeing": counts["agree_score"],
        "panels_with_a_failed_judgment": counts["failure"],
        "r0_requests": op["r0"]["requests"],
        "cost_r0_usd": op["r0"]["cost_usd"],
        "cost_total_usd": op["cost_total_usd"],
    }


def yaml_has(path: Path, key: str) -> bool:
    node = yaml.safe_load(path.read_text())
    for part in key.split("."):
        part = int(part) if part.isdigit() else part
        if not isinstance(node, dict) or part not in node:
            return False
        node = node[part]
    return True


def change_log() -> list[dict]:
    """The 19 changes with their change-log row (file:line) and the YAML key carrying the text. Guards:
    exactly one table row per id in its change log, the YAML key exists, and ids run 1..19."""
    if [c[0] for c in CHANGES] != list(range(1, 20)):
        raise SystemExit("Change ids are not 1..19")
    out = []
    for cid, version, rev, key, pillar, cls, basis, papers, rules, regression in CHANGES:
        log = CHANGE_LOGS[version]
        hits = [i for i, x in enumerate(log.read_text().splitlines(), 1) if x.startswith(f"| {cid} |")]
        text_file = ROOT / CHANGE_TEXT[(version, rev)]
        if len(hits) != 1 or not yaml_has(text_file, key):
            raise SystemExit(f"Change {cid}: row or YAML key {key} not found")
        out.append(
            {
                "id": cid,
                "version": version,
                "revision": rev,
                "pillar": pillar,
                "prompted_by_class": cls,
                "class_basis": basis,
                "evidence_papers": list(papers),
                "handbook_rules_cited": rules,
                "prompted_by_regression_of_an_earlier_revision": regression,
                "change_log_row": f"{log.relative_to(ROOT)}:{hits[0]}",
                "rubric_text_at": f"{CHANGE_TEXT[(version, rev)]} :: {key}",
            }
        )
    return out


# --------------------------------------------------------------------------------------------------------
# Second request (8-16), from an independent referee: corpus tests and both new-literature comparisons

EXTRA = ("unseen", "exposed", "newlit_stopped", "newlit_completed")
RECORDS_BASED_IDS = (10141, 10589, 10973)  # S0141, S0589, S0973 (postslr_report.RECORDS_BASED)
PERMUTATIONS = 20000
Q = 4  # score categories for AC1 / Brennan-Prediger: levels 0-3


def arms_of(t: dict) -> tuple[str, str]:
    return t["refined"], t["comparator"]


def resolved_measure(c: str) -> bool:
    return c in RESOLVED


def paper_executions(rows: list[dict], arm: str) -> dict[tuple, dict[str, list]]:
    """(study, execution) -> pillar -> trio. Guard: every paper-execution has all four pillars."""
    out: dict[tuple, dict] = {}
    for r in rows:
        out.setdefault((r["study"], r["execution"]), {})[r["pillar"]] = r[arm + "_trio"]
    if any(len(v) != len(PILLARS) for v in out.values()):
        raise SystemExit(f"{arm}: a paper-execution lacks a pillar")
    return out


def scope_verdict(by_pillar: dict[str, list], i: int) -> str:
    """One rater's scope call for a publication, from P1-P3 (the pillars the scope statement governs): 'in'
    when all three are scored, 'out' when none is, 'failed' when any judgment failed, else 'mixed'."""
    vs = [by_pillar[p][i] for p in PILLARS[:3]]
    if any(v is None for v in vs):
        return "failed"
    if all(v[0] == "scored" for v in vs):
        return "in"
    return "out" if all(v[0] != "scored" for v in vs) else "mixed"


def vocabulary(rows: list[dict], arms) -> dict:
    """Non-scored statuses seen in the trios, and the status of each unanimous non-scored panel."""
    seen, agreed = Counter(), {}
    for a in arms:
        agreed[a] = dict(Counter(r[a + "_trio"][0][0] for r in rows if r[a] == "agree_not_applicable"))
        seen.update(v[0] for r in rows for v in r[a + "_trio"] if v and v[0] != "scored")
    return {"non_scored_statuses_seen": dict(seen), "agreed_not_applicable_panels_by_status": agreed}


def vocabulary_ledger(db) -> dict:
    """Every non-scored status in the backup's judgments, by condition and round (any run, any stage)."""
    cond = {
        r["id"]: json.loads(r["manifest"])["condition"] for r in db.execute("SELECT id, manifest FROM runs")
    }
    out: dict[str, Counter] = {}
    for r in db.execute(
        "SELECT q.run_id, q.round, json_extract(j.payload,'$.status') AS st, COUNT(*) AS n FROM judgments j "
        "JOIN requests q ON q.id=j.request_id WHERE json_extract(j.payload,'$.status') != 'scored' "
        "GROUP BY q.run_id, q.round, st"
    ):
        out.setdefault(cond[r["run_id"]], Counter())[
            f"{'R0' if r['round'] == 0 else 'discussion'} {r['st']}"
        ] += r["n"]
    return {k: dict(sorted(v.items())) for k, v in sorted(out.items())}


def scope_vs_scores(t: dict) -> dict:
    """(a) scope agreement per paper-execution and per panel; (b) agreement on scores where all three
    scored: on panels complete in both arms (paired), per arm (unpaired), and on paper-executions agreed in
    scope in both arms. Paired differences: corpus_report.compare with the stage's seed."""
    a1, a0 = arms_of(t)
    rows, seed = t["rows"], t["seed"]
    pe = {a: paper_executions(rows, a) for a in (a1, a0)}
    keys = sorted(pe[a1])
    verdicts = {a: {k: [scope_verdict(pe[a][k], i) for i in range(3)] for k in keys} for a in (a1, a0)}

    def agreed(vs):
        return vs[0] in ("in", "out") and len(set(vs)) == 1

    def pattern(vs):
        if agreed(vs):
            return "agreed_" + vs[0]
        return "split_in_vs_out" if {"in", "out"} <= set(vs) else "mixed_or_failed_without_in_out_split"

    pe_rows = [{"study": k[0], **{a: agreed(verdicts[a][k]) for a in (a1, a0)}} for k in keys]

    def panel_scope(trio):
        return None not in trio and len({v[0] == "scored" for v in trio}) == 1

    panel_rows = [{"study": r["study"], **{a: panel_scope(r[a + "_trio"]) for a in (a1, a0)}} for r in rows]

    def complete(trio):
        return None not in trio and all(v[0] == "scored" for v in trio)

    both_complete = [r for r in rows if complete(r[a1 + "_trio"]) and complete(r[a0 + "_trio"])]
    in_both = {k for k in keys if all(verdicts[a][k] == ["in"] * 3 for a in (a1, a0))}
    in_rows = [r for r in rows if (r["study"], r["execution"]) in in_both]

    def agree_score(c):
        return c == "agree_score"

    return {
        "a_scope_per_paper_execution": {
            "rule": "rater's call from P1-P3: in = all scored, out = none scored; agreed = three identical "
            "in/out",
            "paired": compare(pe_rows, bool, a1, a0, seed),
            "patterns": {a: dict(Counter(pattern(verdicts[a][k]) for k in keys)) for a in (a1, a0)},
        },
        "a_scope_per_panel": {
            "rule": "no failed judgment and all three scored or all three non-scored",
            "paired": compare(panel_rows, bool, a1, a0, seed),
        },
        "b_scores_on_panels_all_scored_in_both_arms": compare(both_complete, agree_score, a1, a0, seed)
        if both_complete
        else None,
        "b_scores_per_arm_unpaired": {
            a: {
                "complete_panels": sum(complete(r[a + "_trio"]) for r in rows),
                "agreeing": sum(r[a] == "agree_score" for r in rows),
            }
            for a in (a1, a0)
        },
        "b_resolved_on_paper_executions_agreed_in_scope_in_both_arms": {
            "paper_executions": len(in_both),
            **(compare(in_rows, resolved_measure, a1, a0, seed) if in_rows else {}),
        },
        "vocabulary": vocabulary(rows, (a1, a0)),
    }


def pillar_distributions(t: dict) -> dict:
    """Scored judgments by level per pillar and arm (plus non-scored and failed), classes per pillar, the
    resolved difference per pillar and without P3 (stage seed)."""
    a1, a0 = arms_of(t)
    rows, seed = t["rows"], t["seed"]
    dist, classes = {}, {}
    for a in (a1, a0):
        dist[a], classes[a] = {}, {}
        for p in PILLARS:
            c = Counter()
            for r in rows:
                if r["pillar"] != p:
                    continue
                for v in r[a + "_trio"]:
                    c["failed" if v is None else str(v[1]) if v[0] == "scored" else "not_scored"] += 1
            dist[a][p] = {k: c.get(k, 0) for k in ("0", "1", "2", "3", "not_scored", "failed")}
            classes[a][p] = dict(sorted(Counter(r[a] for r in rows if r["pillar"] == p).items()))
    return {
        "scored_judgments_by_level": dist,
        "classes_by_pillar": classes,
        "resolved_difference_by_pillar": {
            p: compare([r for r in rows if r["pillar"] == p], resolved_measure, a1, a0, seed) for p in PILLARS
        },
        "resolved_difference_without_P3": compare(
            [r for r in rows if r["pillar"] != "P3"], resolved_measure, a1, a0, seed
        ),
        "refined_arm_P3_scores_above_0": dist[a1]["P3"]["1"] + dist[a1]["P3"]["2"] + dist[a1]["P3"]["3"],
    }


def p3_above_zero_in_ledger(db, hashes: dict[str, str]) -> dict:
    """Every run in the backup rated under a rubric other than the published v1.0 (sha256 of the rated
    rubric differs from rubric/rubric.yaml): P3 scored judgments by level, independent round and discussion
    rounds apart, per condition. Revisions not kept as a file (v1.1 r1, v1.2 r1) are labelled by hash."""
    v10 = sha256_file(ROOT / "rubric/rubric.yaml")
    out: dict[str, Counter] = {}
    for r in db.execute("SELECT id, manifest FROM runs"):
        m = json.loads(r["manifest"])
        h = m["papers"][0]["files"].get("rubric.yaml", "")
        if h == v10:
            continue
        rubric = Path(hashes[h]).name if h in hashes else f"rubric not kept as a file, sha256:{h[:12]}"
        c = out.setdefault(f"{m['condition']} ({rubric})", Counter())
        for j in db.execute(
            "SELECT q.round, json_extract(j.payload,'$.score') AS s FROM judgments j JOIN requests q "
            "ON q.id=j.request_id WHERE q.run_id=? AND json_extract(j.payload,'$.pillar')='P3' AND "
            "json_extract(j.payload,'$.status')='scored'",
            (r["id"],),
        ):
            c[f"{'R0' if j['round'] == 0 else 'discussion'} level {j['s']}"] += 1
    any_above = {k: sum(n for x, n in v.items() if not x.endswith("level 0")) for k, v in out.items()}
    return {
        "by_condition": {k: dict(sorted(v.items())) for k, v in sorted(out.items())},
        "conditions_with_P3_above_0": {k: n for k, n in any_above.items() if n},
    }


def rater_shift_parts(rows: list[dict], arm: str) -> dict[int, dict[str, list[int]]]:
    """Per paper and rater: on panels where all three scored, pairwise matches with the other two (numerator,
    denominator) and leave-one-out matches when the other two agree (numerator, denominator)."""
    out: dict[int, dict] = {}
    for r in rows:
        t = r[arm + "_trio"]
        parts = out.setdefault(r["study"], {x: [0, 0, 0, 0] for x in RATERS})
        if None in t or any(v[0] != "scored" for v in t):
            continue
        for i, x in enumerate(RATERS):
            j, k = (y for y in range(3) if y != i)
            p = parts[x]
            p[0] += (t[i] == t[j]) + (t[i] == t[k])
            p[1] += 2
            p[2] += t[j] == t[k] and t[i] == t[j]
            p[3] += t[j] == t[k]
    return out


def rater_shifts(t: dict) -> dict:
    """Each rater's exact agreement with the other two on scored panels, per arm, and its change from v1.0 to
    the refined arm; contrasts r3 minus r1 and r3 minus r2. Joint paper bootstrap (RESAMPLES, SEED)."""
    a1, a0 = arms_of(t)
    parts = {a: rater_shift_parts(t["rows"], a) for a in (a1, a0)}
    papers = sorted(parts[a1])

    def stats(sample):
        out = {}
        for a in (a1, a0):
            for x in RATERS:
                tot = [sum(parts[a][s][x][q] for s in sample) for q in range(4)]
                out[(a, x, "pairwise")] = tot[0] / tot[1] if tot[1] else None
                out[(a, x, "leave_one_out")] = tot[2] / tot[3] if tot[3] else None
        return out

    def derived(st):
        d = {}
        for m in ("pairwise", "leave_one_out"):
            for x in RATERS:
                u, v = st[(a1, x, m)], st[(a0, x, m)]
                d[(m, x)] = None if u is None or v is None else u - v
            for other in ("r1", "r2"):
                u, v = d[(m, "r3")], d[(m, other)]
                d[(m, f"r3-{other}")] = None if u is None or v is None else u - v
        return d

    point = stats(papers)
    dpoint = derived(point)
    rng, draws = random.Random(SEED), {}
    for _ in range(RESAMPLES):
        for key, v in derived(stats(rng.choices(papers, k=len(papers)))).items():
            if v is not None:
                draws.setdefault(key, []).append(v)
    out = {}
    for m in ("pairwise", "leave_one_out"):
        out[m] = {
            "by_rater": {
                x: {
                    "refined": round(point[(a1, x, m)], 4) if point[(a1, x, m)] is not None else None,
                    "comparator": round(point[(a0, x, m)], 4) if point[(a0, x, m)] is not None else None,
                    "change": round(dpoint[(m, x)], 4) if dpoint[(m, x)] is not None else None,
                    "change_interval_95": percentile_interval(draws.get((m, x), [])),
                }
                for x in RATERS
            },
            "contrasts_of_change": {
                c: {
                    "estimate": round(dpoint[(m, c)], 4) if dpoint[(m, c)] is not None else None,
                    "interval_95": percentile_interval(draws.get((m, c), [])),
                }
                for c in ("r3-r1", "r3-r2")
            },
        }
    out["denominators"] = {
        a: {x: [sum(parts[a][s][x][q] for s in papers) for q in (1, 3)] for x in RATERS} for a in (a1, a0)
    }
    return out


def ac1_bp(items: list[Counter]) -> dict:
    """Gwet's AC1 and Brennan-Prediger for three raters over items (category counts), Q categories; None
    when there are no items."""
    n = len(items)
    if not n:
        return {"items": 0, "pa": None, "ac1": None, "bp": None}
    r = 3
    pa = sum(sum(c * (c - 1) for c in it.values()) / (r * (r - 1)) for it in items) / n
    pi = Counter()
    for it in items:
        for k, c in it.items():
            pi[k] += c / (r * n)
    pe_ac1 = sum(p * (1 - p) for p in pi.values()) / (Q - 1)
    pe_bp = 1 / Q
    return {
        "items": n,
        "pa": round(pa, 4),
        "ac1": round((pa - pe_ac1) / (1 - pe_ac1), 4),
        "bp": round((pa - pe_bp) / (1 - pe_bp), 4),
    }


def chance_robust(t: dict) -> dict:
    """AC1 and Brennan-Prediger on scores only (panels where all three scored), per pillar and pooled, per
    arm, with paper-bootstrap intervals (KAPPA_RESAMPLES, SEED)."""
    out = {}
    for a in arms_of(t):
        out[a] = {}
        for p in (*PILLARS, "pooled"):
            by_paper: dict[int, list[Counter]] = {}
            for r in t["rows"]:
                by_paper.setdefault(r["study"], [])
                trio = r[a + "_trio"]
                if (
                    (p == "pooled" or r["pillar"] == p)
                    and None not in trio
                    and all(v[0] == "scored" for v in trio)
                ):
                    by_paper[r["study"]].append(Counter(str(v[1]) for v in trio))
            point = ac1_bp([x for v in by_paper.values() for x in v])
            rng, papers, ac1, bp = random.Random(SEED), sorted(by_paper), [], []
            for _ in range(KAPPA_RESAMPLES):
                s = ac1_bp([x for q in rng.choices(papers, k=len(papers)) for x in by_paper[q]])
                if s["ac1"] is not None:
                    ac1.append(s["ac1"])
                    bp.append(s["bp"])
            out[a][p] = {
                **point,
                "ac1_interval_95": percentile_interval(ac1),
                "bp_interval_95": percentile_interval(bp),
            }
    return out


def repeat_stability(t: dict) -> dict:
    """Panels present in both executions: identical trio (all, and among panels resolved in both); per rater,
    test-retest exact agreement where both judgments are usable (any verdict, and scores only)."""
    out = {}
    for a in arms_of(t):
        by_panel: dict[tuple, dict] = {}
        for r in t["rows"]:
            by_panel.setdefault((r["study"], r["pillar"]), {})[r["execution"]] = r
        two = [(v[1], v[2]) for v in by_panel.values() if 1 in v and 2 in v]
        both_res = [(x, y) for x, y in two if resolved_measure(x[a]) and resolved_measure(y[a])]
        raters = {}
        for i, name in enumerate(RATERS):
            usable = [
                (x[a + "_trio"][i], y[a + "_trio"][i])
                for x, y in two
                if x[a + "_trio"][i] is not None and y[a + "_trio"][i] is not None
            ]
            scored = [(u, v) for u, v in usable if u[0] == "scored" and v[0] == "scored"]
            raters[name] = {
                "usable_pairs": len(usable),
                "same": sum(u == v for u, v in usable),
                "scored_pairs": len(scored),
                "same_score": sum(u == v for u, v in scored),
            }
        out[a] = {
            "panels_in_both_executions": len(two),
            "identical_trio": sum(x[a + "_trio"] == y[a + "_trio"] for x, y in two),
            "resolved_in_both": len(both_res),
            "resolved_in_both_identical_trio": sum(x[a + "_trio"] == y[a + "_trio"] for x, y in both_res),
            "same_class": sum(x[a] == y[a] for x, y in two),
            "per_rater_test_retest": raters,
        }
    return out


def without_types(t: dict, drop: set[int]) -> dict:
    a1, a0 = arms_of(t)
    rows = [r for r in t["rows"] if r["study"] not in drop]
    return {
        "papers_dropped_present": sorted(drop & {r["study"] for r in t["rows"]}),
        **compare(rows, resolved_measure, a1, a0, t["seed"]),
    }


def bootstrap_draws(per_paper: dict, seed: str, resamples: int = RESAMPLES) -> list[float]:
    """The draws of corpus_report.interval, kept (same seed, same order)."""
    rng, papers, diffs = random.Random(seed), sorted(per_paper), []
    for _ in range(resamples):
        a = b = n = 0
        for s in rng.choices(papers, k=len(papers)):
            x, y, k = per_paper[s]
            a, b, n = a + x, b + y, n + k
        diffs.append((a - b) / n)
    return diffs


def bca(per_paper: dict, seed: str) -> dict:
    """Bias-corrected (BC) and BCa intervals from the stage's own bootstrap draws (guard: their percentile
    interval equals the published one); acceleration from the leave-one-paper-out jackknife; ties with the
    estimate count half in the bias correction."""
    nd = statistics.NormalDist()
    draws = bootstrap_draws(per_paper, seed)
    if percentile_interval(draws) != interval(per_paper, seed):
        raise SystemExit("Bootstrap draws do not reproduce corpus_report.interval")
    papers = sorted(per_paper)
    theta = delta(per_paper, papers)
    below = sum(d < theta - 1e-12 for d in draws) + 0.5 * sum(abs(d - theta) <= 1e-12 for d in draws)
    z0 = nd.inv_cdf(min(max(below / len(draws), 1e-6), 1 - 1e-6))
    jack = [delta(per_paper, [q for q in papers if q != p]) for p in papers]
    mean = sum(jack) / len(jack)
    num = sum((mean - j) ** 3 for j in jack)
    den = 6 * sum((mean - j) ** 2 for j in jack) ** 1.5
    acc = num / den if den else 0.0
    s = sorted(draws)

    def at(alpha, a):
        z = nd.inv_cdf(alpha)
        q = nd.cdf(z0 + (z0 + z) / (1 - a * (z0 + z)))
        return round(s[min(len(s) - 1, max(0, int(q * len(s))))], 4)

    return {
        "estimate": round(theta, 4),
        "percentile_95": percentile_interval(draws),
        "z0": round(z0, 4),
        "acceleration": round(acc, 5),
        "bc_95": [at(0.025, 0.0), at(0.975, 0.0)],
        "bca_95": [at(0.025, acc), at(0.975, acc)],
    }


def sign_and_permutation(per_paper: dict) -> dict:
    """Paper-level exact two-sided sign test on h1 - h0 (ties dropped), and a paper-level sign-flip
    permutation test of the pooled difference (PERMUTATIONS random flips, seed SEED; two-sided)."""
    d = {s: x - y for s, (x, y, _) in per_paper.items()}
    pos, neg = sum(v > 0 for v in d.values()), sum(v < 0 for v in d.values())
    m = pos + neg
    tail = sum(comb(m, k) for k in range(min(pos, neg) + 1)) / 2**m if m else 1.0
    total = sum(n for *_, n in per_paper.values())
    obs = sum(d.values()) / total
    rng, hits = random.Random(SEED), 0
    vals = list(d.values())
    for _ in range(PERMUTATIONS):
        stat = sum(v if rng.random() < 0.5 else -v for v in vals) / total
        hits += abs(stat) >= abs(obs) - 1e-12
    return {
        "papers": len(d),
        "papers_favouring_refined": pos,
        "papers_favouring_comparator": neg,
        "ties": len(d) - m,
        "sign_test_p_two_sided": round(min(1.0, 2 * tail), 6),
        "permutation_p_two_sided": round((hits + 1) / (PERMUTATIONS + 1), 6),
        "permutations": PERMUTATIONS,
        "observed_difference": round(obs, 4),
    }


def checker_failed_cells(db, runs: list[str]) -> dict[tuple, tuple | str]:
    """(run, study, rater, pillar) -> the rater's own verdict for every R0 pillar that failed the quotation
    check (pillar failure status evidence_failure), read inside SQLite from the reply's cells (pillar, status,
    score only; never the quotation): the latest attempt that is not a correction turn. 'unrecoverable' when
    no parseable reply carries the pillar, 'ambiguous' when one reply carries conflicting cells for it."""
    marks = ",".join("?" * len(runs))
    failed: dict[tuple, str] = {}
    for r in db.execute(
        "SELECT q.id, q.run_id, q.study, q.rater, json_extract(q.context,'$.pending') AS pending, "
        "json_extract(d.payload,'$.failed_pillars') AS f, json_extract(d.payload,'$.pillar_failures') AS pf, "
        "json_extract(d.payload,'$.status') AS st FROM dispositions d JOIN requests q ON q.id=d.request_id "
        f"WHERE q.run_id IN ({marks}) AND q.round=0 AND q.kind='rating'",
        runs,
    ):
        pillars = (json.loads(r["f"]) if r["f"] else None) or json.loads(r["pending"])
        per = json.loads(r["pf"]) if r["pf"] else {}
        for p in pillars:
            if per.get(p, {}).get("status", r["st"]) == "evidence_failure":
                failed[(r["id"], p)] = (r["run_id"], r["study"], r["rater"], p)
    cells: dict[tuple, dict[int, set]] = {}
    for r in db.execute(
        "WITH t AS MATERIALIZED (SELECT q.id AS rid, a.stage AS stage, json_extract(c.result,'$.text') AS x "
        "FROM requests q JOIN attempts a ON a.request_id=q.id JOIN completions c ON c.attempt_id=a.id "
        f"WHERE q.run_id IN ({marks}) AND q.round=0 AND q.kind='rating' AND a.stage % 3 != 2 AND "
        "q.id IN (SELECT request_id FROM dispositions)), v AS MATERIALIZED (SELECT * FROM t WHERE "
        "x IS NOT NULL AND json_valid(x) AND json_type(x,'$.cells')='array') "
        "SELECT v.rid, v.stage, json_extract(e.value,'$.pillar') AS pillar, "
        "json_extract(e.value,'$.status') AS "
        "status, json_extract(e.value,'$.score') AS score FROM v, json_each(v.x,'$.cells') AS e",
        runs,
    ):
        if (r["rid"], r["pillar"]) in failed:
            verdict = ("scored", r["score"]) if r["status"] == "scored" else (r["status"], None)
            cells.setdefault((r["rid"], r["pillar"]), {}).setdefault(r["stage"], set()).add(verdict)
    out: dict[tuple, tuple | str] = {}
    for key, where in failed.items():
        by_stage = cells.get(key)
        if not by_stage:
            out[where] = "unrecoverable"
            continue
        latest = by_stage[max(by_stage)]
        out[where] = next(iter(latest)) if len(latest) == 1 else "ambiguous"
    return out


def checker_off(db, conds: dict, tests: dict) -> dict:
    """Hypothetical: each judgment that failed the quotation check is replaced by the rater's own verdict as
    it stood in its reply (unverified); every other failure stays a failure. Paired differences: stage
    seed."""
    out = {}
    for key in ("heldout", *EXTRA):
        t = tests[key]
        a1, a0 = arms_of(t)
        cf = checker_failed_cells(db, conds[a1]["runs"] + conds[a0]["runs"])
        rows, stats = [], {}
        for a in (a1, a0):
            stats[a] = Counter()
        for r in t["rows"]:
            new = {"study": r["study"]}
            for a in (a1, a0):
                run = conds[a]["runs"][r["execution"] - 1]
                trio = list(r[a + "_trio"])
                for i, x in enumerate(RATERS):
                    if trio[i] is not None:
                        continue
                    stats[a]["failed_judgments"] += 1
                    v = cf.get((run, r["study"], x, r["pillar"]))
                    if v is None:
                        stats[a]["other_failures_kept"] += 1
                    elif isinstance(v, str):
                        stats[a][f"checker_failure_{v}"] += 1
                    else:
                        stats[a]["checker_failure_recovered"] += 1
                        stats[a]["recovered_" + (f"level_{v[1]}" if v[0] == "scored" else v[0])] += 1
                        trio[i] = v
                new[a] = classify(trio)
            rows.append(new)
        out[key] = {
            "label": "HYPOTHETICAL: quotation check switched off for judgments that failed it",
            "failed_judgments": {a: dict(sorted(v.items())) for a, v in stats.items()},
            "observed_resolved": {a: sum(resolved_measure(r[a]) for r in t["rows"]) for a in (a1, a0)},
            "hypothetical_classes": {a: dict(sorted(Counter(r[a] for r in rows).items())) for a in (a1, a0)},
            "hypothetical_resolved_paired": compare(rows, resolved_measure, a1, a0, t["seed"]),
            "observed_resolved_paired": compare(t["rows"], resolved_measure, a1, a0, t["seed"]),
        }
    return out


def second_request(db, conds: dict, tests: dict, hashes: dict) -> dict:
    ex = {k: tests[k] for k in EXTRA}
    newc = tests["newlit_completed"]
    committed = json.loads(newc["source"].read_text())
    if sorted(committed["records_based_papers"]) != sorted(RECORDS_BASED_IDS):
        raise SystemExit("Records-based study ids differ from the committed report")
    hazard = set(committed["hazard_detector_papers"])
    no_rb = without_types(newc, set(RECORDS_BASED_IDS))
    want = committed["exploratory_by_paper_type"]["without_records_based"]
    if (no_rb["difference"], no_rb["interval_95"]) != (want["difference"], want["interval_95"]):
        raise SystemExit("Without-records-based primary does not reproduce the committed report")
    sens = {}
    for k, t in ex.items():
        pp = paper_hits(t["rows"], resolved_measure, arms_of(t))
        sens[k] = {**sign_and_permutation(pp), "bootstrap": bca(pp, t["seed"])}
    vocab = {k: vocabulary(t["rows"], arms_of(t)) for k, t in tests.items() if not k.startswith("_")}
    vocab.update({c: vocabulary(rows, (c,)) for c, rows in tests["_dev"].items()})
    return {
        "8_scope_vs_scores": {
            "note": NOTES["8_scope_vs_scores"],
            "tests": {k: scope_vs_scores(t) for k, t in ex.items()},
            "vocabulary_all_stages": vocab,
            "vocabulary_ledger_by_condition": vocabulary_ledger(db),
        },
        "9_pillar_distributions": {
            "note": NOTES["9_pillar_distributions"],
            "tests": {k: pillar_distributions(t) for k, t in ex.items()},
            "p3_in_all_v1_1_v1_2_runs": p3_above_zero_in_ledger(db, hashes),
        },
        "10_score_disagreement_by_pillar": {
            "note": NOTES["10_score_disagreement_by_pillar"],
            "tests": {
                k: {
                    a: {
                        p: sum(r[a] == "score_disagreement" for r in t["rows"] if r["pillar"] == p)
                        for p in PILLARS
                    }
                    for a in arms_of(t)
                }
                for k, t in ex.items()
            },
        },
        "11_rater_shifts": {
            "note": NOTES["11_rater_shifts"],
            "seed": SEED,
            "tests": {k: rater_shifts(t) for k, t in ex.items()},
        },
        "12_records_based": {
            "note": NOTES["12_records_based"],
            "newlit_completed_without_records_based": no_rb,
            "newlit_completed_without_records_based_and_hazard": without_types(
                newc, set(RECORDS_BASED_IDS) | hazard
            ),
            "newlit_stopped_without_records_based": without_types(
                tests["newlit_stopped"], set(RECORDS_BASED_IDS)
            ),
            "newlit_stopped_without_records_based_and_hazard": without_types(
                tests["newlit_stopped"], set(RECORDS_BASED_IDS) | hazard
            ),
        },
        "13_ac1_brennan_prediger": {
            "note": NOTES["13_ac1_brennan_prediger"],
            "seed": SEED,
            "tests": {k: chance_robust(t) for k, t in ex.items()},
        },
        "14_repeat_stability": {
            "note": NOTES["14_repeat_stability"],
            "tests": {k: repeat_stability(t) for k, t in ex.items()},
        },
        "15_primary_sensitivity": {"note": NOTES["15_primary_sensitivity"], "tests": sens},
        "16_checker_off_hypothetical": {
            "note": NOTES["16_checker_off_hypothetical"],
            "tests": checker_off(db, conds, tests),
        },
    }


# --------------------------------------------------------------------------------------------------------
# Parity: the ledger reader against the committed reports


def parity(db, conds: dict, tests: dict, ops: dict) -> dict:
    """Stop on any mismatch between this script's reading and the committed reports."""
    checks = {}

    def check(name: str, ok: bool, detail) -> None:
        if not ok:
            raise SystemExit(f"Parity failed: {name}: {detail}")
        checks[name] = detail

    for key in ("unseen", "exposed", "newlit_completed"):
        t = tests[key]
        arms = (t["refined"], t["comparator"])
        derived = ledger_rows(db, {a: conds[a]["runs"] for a in arms})
        check(
            f"{key}: ledger rows == committed rows",
            normalised(derived, arms) == normalised(t["rows"], arms),
            f"{len(derived)} panels",
        )
    r2 = (EXPOSED_R2["refined"], EXPOSED_R2["comparator"])
    derived = ledger_rows(db, {a: conds[a]["runs"] for a in r2})
    check(
        "exposed r2: ledger rows == committed rows",
        normalised(derived, r2) == normalised(committed_rows(EXPOSED_R2["source"], r2), r2),
        f"{len(derived)} panels",
    )
    arms = (tests["newlit_stopped"]["refined"], tests["newlit_stopped"]["comparator"])
    full = set(normalised(tests["newlit_completed"]["rows"], arms))
    check(
        "newlit stopped rows are a subset of the completed rows",
        set(normalised(tests["newlit_stopped"]["rows"], arms)) <= full,
        f"{len(tests['newlit_stopped']['rows'])} panels",
    )
    held = json.loads((RESULTS / "HELDOUT_CLASSES.json").read_text())["arms"]
    for a in ("EVAL_ORIGINAL", "EVAL_REFINED"):
        got = dict(sorted(Counter(r[a] for r in tests["heldout"]["rows"]).items()))
        check(f"heldout {a}: classes == HELDOUT_CLASSES.json", got == held[a], got)
        rep = json.loads((RESULTS / f"{a}.json").read_text())
        fails = {
            x: sum(r[a + "_trio"][i] is None for r in tests["heldout"]["rows"]) for i, x in enumerate(RATERS)
        }
        check(
            f"heldout {a}: failed judgments per rater == {a}.json",
            fails == {x: rep["by_rater"][x].get("failure", 0) for x in RATERS},
            fails,
        )
        usage = rep["usage"]
        cost = sum(usage[k] for k in ("openai_usd", "zai_usd", "anthropic_usd"))
        check(
            f"heldout {a}: ledger cost == {a}.json usage",
            abs(ops["heldout"][a]["cost_total_usd"] - cost) < 0.01,
            round(cost, 4),
        )
    for c in DEV_CYCLES:
        rep = json.loads((RESULTS / f"{c}.json").read_text())
        rows = tests["_dev"][c]
        got = (
            sum(r[c] == "agree_score" for r in rows),
            sum(None not in r[c + "_trio"] and all(v[0] == "scored" for v in r[c + "_trio"]) for r in rows),
        )
        check(
            f"{c}: complete-and-agreeing and complete == {c}.json",
            got == (rep["panels_complete_and_agreeing"], rep["panels_complete"]),
            got,
        )
    for key, t in tests.items():
        if key.startswith("_") or key == "heldout":
            continue
        arms = (t["refined"], t["comparator"])
        committed = json.loads(t["source"].read_text())["primary_resolved"]
        got = compare(t["rows"], lambda c: c in RESOLVED, *arms, t["seed"])
        check(
            f"{key}: primary difference and interval reproduce with seed {t['seed']}",
            (got["difference"], got["interval_95"]) == (committed["difference"], committed["interval_95"]),
            [got["difference"], got["interval_95"]],
        )
        mech = json.loads(t["source"].read_text())["mechanics"]
        for a in arms:
            check(
                f"{key} {a}: ledger cost == committed mechanics",
                abs(ops[key][a]["cost_total_usd"] - mech[a]["cost_usd"]) < 0.006,
                mech[a]["cost_usd"],
            )
    for key in ("newlit_stopped", "newlit_completed"):
        paths = json.loads(tests[key]["source"].read_text())["request_paths"]
        for a in (tests[key]["refined"], tests[key]["comparator"]):
            got = {k: v for k, v in ops[key][a]["r0"]["outcomes"].items() if v}
            check(
                f"{key} {a}: request outcomes == committed request_paths",
                got == paths[a]["request_outcomes"],
                got,
            )
    return checks


# --------------------------------------------------------------------------------------------------------
# Rendering


def pc(x: float | None) -> str:
    return "n/a" if x is None else f"{100 * x:.1f}"


def pts(x: float | None, tex: bool = False) -> str:
    if x is None:
        return "n/a"
    s = f"{100 * x:+.1f}"
    return s.replace("-", "$-$") if tex else s.replace("-", "−")


def ci(iv, tex: bool = False, points: bool = True) -> str:
    if not iv:
        return "n/a"
    if points:
        return f"[{pts(iv[0], tex)}, {pts(iv[1], tex)}]"
    f = (lambda v: f"{v:.2f}".replace("-", "$-$")) if tex else (lambda v: f"{v:.2f}".replace("-", "−"))
    return f"[{f(iv[0])}, {f(iv[1])}]"


def pct_iv(iv) -> str:
    return "n/a" if not iv else f"[{pc(iv[0])}, {pc(iv[1])}]"


def kap(x: float | None, tex: bool = False) -> str:
    if x is None:
        return "undef."
    s = f"{x:.2f}"
    return s.replace("-", "$-$") if tex else s.replace("-", "−")


def pval(p: float, tex: bool = False) -> str:
    if p < 0.0001:
        return "$<$0.0001" if tex else "<0.0001"
    return f"{p:.4f}"


def esc(s: str) -> str:
    return str(s).replace("_", r"\_").replace("&", r"\&").replace("%", r"\%")


def tex_table(
    name: str,
    caption: str,
    spec: str,
    head: list[str],
    body: list[list[str]],
    size: str = "footnotesize",
    colsep: int = 4,
):
    lines = [
        f"% {name}: generated by scripts/posthoc_analyses.py. Provenance: {PROVENANCE}.",
        r"\begin{table}[t]\centering" + "\\" + size,
        rf"\setlength{{\tabcolsep}}{{{colsep}pt}}",
        rf"\caption{{{caption}}}\label{{tab:posthoc-{name}}}",
        rf"\begin{{tabular}}{{{spec}}}\toprule",
        " & ".join(head) + r"\\\midrule",
    ]
    for row in body:
        lines.append(r"\midrule" if row == ["MIDRULE"] else " & ".join(row) + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}", ""]
    (OUT / f"tab_{name}.tex").write_text("\n".join(lines))


TEST_SHORT = {
    "heldout": "Held-out",
    "unseen": "Unseen corpus",
    "exposed": "Exposed corpus",
    "newlit_stopped": "New lit., stopped",
    "newlit_completed": "New lit., completed",
}
RULE_SHORT = {
    "unanimity (resolved)": "unanimity (resolved)",
    "majority of three": "majority, 2 of 3",
    "unanimity, failed judgments ignored": "failures ignored",
    "unanimity, complete cases only": "complete cases only",
}
SCHEME_SHORT = {
    "hazard vs rest": "hazard / rest",
    "four types": "four types",
    "four types, paper 63 as a people detector": "four types, 63 as people",
}
CLASS_SHORT = {
    "agree_score": "agreed",
    "agree_not_applicable": "agreed n/a",
    "split_not_applicable_vs_score": "n/a vs score",  # split_not_applicable_vs_score
    "score_disagreement": "score disagr.",
    "failure": "failed",
}
RUBRIC_SHORT = {
    "rubric.yaml": "v1.0",
    "rubric_v1_1.yaml": "v1.1",
    "rubric_v1_2.yaml": "v1.2 r2",
    "rubric_v1_2_r3.yaml": "v1.2 r3",
}


def first_only(rows: list[list[str]], columns: int) -> list[list[str]]:
    """Blank the leading label cells that repeat the row above (group labels printed once)."""
    out, previous = [], None
    for row in rows:
        if row == ["MIDRULE"]:
            out.append(row)
            previous = None
            continue
        shown = list(row)
        for i in range(columns):
            if previous and previous[i] == row[i] and all(previous[k] == row[k] for k in range(i)):
                shown[i] = ""
        out.append(shown)
        previous = row
    return out


def write_tex(res: dict) -> list[str]:
    a = res["analyses"]
    body = []
    for key, t in a["1_ablation"]["tests"].items():
        for name, c in t["paired_differences"].items():
            body.append(
                [
                    esc(TEST_SHORT[key]),
                    esc(RULE_SHORT.get(name, name)),
                    str(c["panels"]),
                    str(c["refined"]),
                    str(c["comparator"]),
                    pts(c["difference"], True),
                    ci(c["interval_95"], True),
                ]
            )
        body.append(["MIDRULE"])
    tex_table(
        "ablation",
        "Post hoc re-aggregation of the stored independent-round judgments: refined arm minus comparator "
        "in panels counted as agreed under each rule, in percentage points, with 95\\% paper-bootstrap "
        "intervals (each stage's declared seed; held-out: post hoc seed). No component was re-run; "
        "exploratory, AI judgments only. Held-out arms differ in handbook only; their pre-registered "
        "primary was complete-and-agreeing panels.",
        "llrrrrl",
        ["Test", "Rule", "Panels", "Refined", "Comparator", "Diff.", "95\\% interval"],
        first_only(body[:-1], 1),
        "scriptsize",
    )

    body = []
    for key, arms in a["2_operating_characteristics"]["stages"].items():
        for arm, o in arms.items():
            r = o["r0"]
            body.append(
                [
                    esc(key),
                    esc(arm),
                    str(r["requests"]),
                    pc(r["rates"]["failed"]),
                    pc(r["rates"]["partial"]),
                    str(r["process_failures"]),
                    str(r["attempts"].get("re_request", 0)),
                    str(r["attempts"].get("correction_turn", 0)),
                    f"{r['latency_s']['median']}",
                    f"{r['cost_usd']:.2f}",
                    f"{o['cost_total_usd']:.2f}",
                ]
            )
    tex_table(
        "operating",
        "Operating characteristics of the independent round (R0 rating requests) per stage and arm, from "
        "the ledger backup: failed and partial requests (\\%), process failures (provider error, timeout or "
        "incomplete output, no judgment; includes the request the stopped run parked), re-requests, "
        "correction turns, median attempt latency (s), and ledger charges (US\\$; R0 and all rounds). "
        "Post hoc, descriptive.",
        "llrrrrrrrrr",
        [
            "Stage",
            "Arm",
            "Req.",
            "Failed",
            "Partial",
            "Proc.",
            "Re-req.",
            "Corr.",
            "Lat.",
            "R0 \\$",
            "All \\$",
        ],
        body,
        "scriptsize",
    )

    body = []
    for key, arms in a["3_rater_pairs"]["tests"].items():
        for arm, pairs in arms.items():
            for pair, vs in pairs.items():
                row = [esc(TEST_SHORT[key]), esc(arm), pair.replace("+", "--")]
                for variant in ("scores_only", "with_not_applicable"):
                    v = vs[variant]
                    row += [
                        str(v["items"]),
                        pc(v["exact_agreement"]),
                        f"{kap(v['kappa'], True)} {ci(v['kappa_interval_95'], True, False)}",
                    ]
                body.append(row)
        body.append(["MIDRULE"])
    tex_table(
        "pairs",
        "Pairwise agreement in the independent round: items, exact agreement (\\%) and Cohen's $\\kappa$ "
        "with 95\\% paper-bootstrap interval (2,000 resamples, seed \\texttt{" + SEED + "}), for each pair "
        "of raters (r1 gpt-6.1-sol, r2 glm-5.3, r3 claude-sonnet-5-5), on scores only and with ``not "
        "applicable'' as a category; failed judgments excluded. Exploratory, post hoc.",
        "lllrrlrrl",
        ["Test", "Arm", "Pair", "$n$", "Exact", "$\\kappa$, scores", "$n$", "Exact", "$\\kappa$, with n/a"],
        first_only(body[:-1], 2),
        "scriptsize",
        3,
    )

    body = []
    d = a["4_difference_of_differences"]
    for key, tgt in d["targets"].items():
        for mname, mlabel in (("resolved", "Resolved"), ("complete_and_agreeing", "C\\&A")):
            e = tgt[mname]
            u = e["unweighted"]
            body.append(
                [
                    esc(TEST_SHORT[key]),
                    mlabel,
                    "none",
                    pts(u["exposed_gain"], True),
                    pts(u["new_literature_gain"], True),
                    pts(u["difference_of_differences"], True),
                    ci(u["interval_95"], True),
                ]
            )
            for sname, ps in e["poststratified"].items():
                dd = ps["difference_of_differences"]
                body.append(
                    [
                        esc(TEST_SHORT[key]),
                        mlabel,
                        esc(SCHEME_SHORT.get(sname, sname)) + ("*" if ps["note"] else ""),
                        pts(dd["exposed_gain"], True),
                        pts(dd["new_literature_gain"], True),
                        pts(dd["difference_of_differences"], True),
                        ci(dd["interval_95"], True),
                    ]
                )
    tex_table(
        "did",
        "Difference of differences: exposed-corpus gain (v1.2 r3 minus v1.0) minus new-literature gain, in "
        "percentage points, with 95\\% intervals from independent paper bootstraps (10,000 resamples, seed "
        "\\texttt{" + SEED + "}); new-literature gain also post-stratified to the corpus paper-type mix "
        "(hazard detectors typed for every paper; people detectors and records-based papers typed only where "
        "a ruling named them). *An empty stratum was dropped and the weights renormalised. Post hoc, "
        "exploratory.",
        "lllrrrl",
        ["Comparison", "Measure", "Post-stratification", "Exposed", "New lit.", "DiD", "95\\% interval"],
        first_only(body, 2),
        "scriptsize",
    )

    v = a["5_validity_anchors"]
    body = []
    if v.get("computed"):
        for cell, e in v["by_paper_pillar"].items():
            row = [esc(cell), str(e["review_score"])]
            for group in ANCHOR_ARMS:
                g = e.get(group)
                if not g:
                    row += ["--", "--"]
                    continue
                row.append(", ".join(f"{k}$\\times${n}" for k, n in g["agreed_scores"].items()) or "none")
                row.append(
                    ", ".join(f"{CLASS_SHORT.get(k, esc(k))} {n}" for k, n in g["other_classes"].items())
                    or "--"
                )
            body.append(row)
        tex_table(
            "validity",
            "The review authors' worked-example scores (post hoc; not a validity reference): "
            "the review authors' published worked-example scores (SLR "
            "supplementary, table of worked examples; the review authors' own scores, not an independent "
            "expert reference) against the AI raters' unanimous R0 scores on the same papers (study/pillar), "
            "as agreed level $\\times$ number of panels, and the other panel classes with their counts.",
            "lrllll",
            ["Study/pillar", "Review", "v1.0: agreed", "v1.0: other", "Refined: agreed", "Refined: other"],
            body,
            "scriptsize",
            3,
        )

    body = []
    for s in a["6_stage_table"]["rows"]:
        body.append(
            [
                esc(s["stage_short"]),
                esc(s["arm"]),
                RUBRIC_SHORT.get(Path(s["rubric_file"]).name, "other"),
                esc(
                    Path(s["procedure_file"])
                    .stem.replace("HANDBOOK_", "")
                    .replace("EVAL_ORIGINAL", "original")
                ),
                str(s["papers_compared"]),
                str(s["paper_executions_compared"]),
                str(s["panels"]),
                str(s["resolved"]),
                str(s["complete_and_agreeing"]),
                str(s["panels_with_a_failed_judgment"]),
                esc(
                    "; ".join(
                        p.get("unreadable_resample", "--").replace("unreadable-resample-", "")
                        for p in s["policies"]
                    )
                ),
                f"{s['cost_total_usd']:.2f}",
            ]
        )
    tex_table(
        "stages",
        "Stages and arms: rubric, procedure (handbook), papers and paper-executions compared, "
        "independent-round panels, resolved, complete-and-agreeing (C\\&A) and failed panels, re-request "
        "policy (unreadable-resample version in the run manifest; -- none recorded: earlier transport and "
        "format-recovery rules), and ledger cost (US\\$, all rounds; "
        "stopped "
        "row: launch 1 only). Raters and settings are in POSTHOC\\_ANALYSES.json.",
        "lllllrrrrrrr",
        [
            "Stage",
            "Arm",
            "Rubric",
            "Proc.",
            "Papers",
            "P-exec.",
            "Panels",
            "Res.",
            "C\\&A",
            "Fail.",
            "Re-req.",
            "Cost",
        ],
        body,
        "scriptsize",
        3,
    )

    body = [
        [
            str(c["id"]),
            esc(c["version"]) + f" rev.~{c['revision']}",
            esc(c["pillar"]),
            CLASS_SHORT.get(c["prompted_by_class"], esc(c["prompted_by_class"])),
            esc(c["class_basis"]),
            ", ".join(map(str, c["evidence_papers"])) or "--",
            "yes" if c["prompted_by_regression_of_an_earlier_revision"] else "",
            esc(Path(c["change_log_row"]).name),
        ]
        for c in a["7_change_log"]["changes"]
    ]
    tex_table(
        "changelog",
        "The 19 documented rubric changes: version and revision, pillar, the class of disagreement that "
        "prompted each (as stated in, or inferred from, its change-log row), evidence papers, whether a "
        "regression after an earlier revision prompted it, and the change-log row "
        "(docs/final-phase-2026-10-28/). "
        "The rubric text is in the files named in POSTHOC\\_ANALYSES.json; it is not paraphrased here.",
        "rllp{3.2cm}lp{2.0cm}ll",
        ["\\#", "Version", "Pillar", "Prompted by", "Basis", "Papers", "Regr.", "Source"],
        body,
        "scriptsize",
        3,
    )
    write_tex_second(a)
    return sorted(str(p.relative_to(ROOT)) for p in OUT.glob("tab_*.tex"))


def tex_diff(name: str, c: dict | None) -> list[str]:
    if not c or not c.get("panels"):
        return [esc(name), "--", "--", "--", "--", "--"]
    return [
        esc(name),
        str(c["panels"]),
        str(c["v1_2"]),
        str(c["v1_0"]),
        pts(c["difference"], True),
        ci(c["interval_95"], True),
    ]


def write_tex_second(a: dict) -> None:
    head = ["Test and measure", "Units", "Refined", "v1.0", "Diff.", "95\\% interval"]
    body = []
    for t, v in a["8_scope_vs_scores"]["tests"].items():
        body += [
            tex_diff(
                f"{TEST_SHORT[t]}: scope agreed (paper-executions)",
                v["a_scope_per_paper_execution"]["paired"],
            ),
            tex_diff(f"{TEST_SHORT[t]}: scope agreed (panels)", v["a_scope_per_panel"]["paired"]),
            tex_diff(
                f"{TEST_SHORT[t]}: scores agreeing (panels all-scored in both arms)",
                v["b_scores_on_panels_all_scored_in_both_arms"],
            ),
            ["MIDRULE"],
        ]
    for t, v in a["9_pillar_distributions"]["tests"].items():
        body.append(tex_diff(f"{TEST_SHORT[t]}: resolved without P3", v["resolved_difference_without_P3"]))
    body.append(["MIDRULE"])
    labels = {
        "newlit_completed_without_records_based": "New lit., completed: without records-based",
        "newlit_completed_without_records_based_and_hazard": "New lit., completed: without records-based "
        "and hazard",
        "newlit_stopped_without_records_based": "New lit., stopped: without records-based (none present)",
        "newlit_stopped_without_records_based_and_hazard": "New lit., stopped: without records-based and "
        "hazard",
    }
    for name, c in a["12_records_based"].items():
        if name != "note":
            body.append(tex_diff(labels[name], c))
    tex_table(
        "scope",
        "Post hoc decompositions of the paired difference (refined minus v1.0, percentage points, 95\\% "
        "paper-bootstrap intervals with each stage's seed): agreement on scope (P1--P3 all scored or none "
        "scored, per paper-execution; and per panel), agreement on scores where all three scored in both "
        "arms, the resolved difference without P3, and the new-literature difference without the "
        "records-based studies (and hazard detectors). Exploratory; units are paper-executions or panels.",
        "lrrrrl",
        head,
        body,
        "scriptsize",
    )

    body = []
    for t, s in a["15_primary_sensitivity"]["tests"].items():
        bs = s["bootstrap"]
        body.append(
            [
                esc(TEST_SHORT[t]),
                pts(bs["estimate"], True),
                ci(bs["percentile_95"], True),
                ci(bs["bc_95"], True),
                ci(bs["bca_95"], True),
                f"{s['papers_favouring_refined']}/{s['papers_favouring_comparator']}/{s['ties']}",
                pval(s["sign_test_p_two_sided"], True),
                pval(s["permutation_p_two_sided"], True),
            ]
        )
    tex_table(
        "sensitivity",
        "Sensitivity of the resolved difference (post hoc): percentile, bias-corrected (BC) and BCa "
        "intervals from each stage's own 10,000 paper-bootstrap draws; papers favouring the refined arm, "
        "the comparator, or tied; exact paper-level sign test and paper-level sign-flip permutation test "
        "(20,000 flips, seed \\texttt{" + SEED + "}), two-sided.",
        "lrlllrrr",
        ["Test", "Diff.", "Percentile", "BC", "BCa", "+/$-$/tie", "Sign $p$", "Perm. $p$"],
        body,
        "scriptsize",
        3,
    )

    body = []
    for t, v in a["13_ac1_brennan_prediger"]["tests"].items():
        for arm, d in v.items():
            body.append(
                [esc(TEST_SHORT[t]), esc(arm)]
                + [f"{kap(d[p]['ac1'], True)} ({d[p]['items']})" for p in (*PILLARS, "pooled")]
            )
    tex_table(
        "ac1",
        "Gwet's AC1 on scores only (panels where all three raters scored; four categories), per pillar and "
        "pooled, with the number of panels in brackets. Brennan--Prediger values and 95\\% paper-bootstrap "
        "intervals are in POSTHOC\\_ANALYSES.json. Exploratory, post hoc.",
        "llrrrrr",
        ["Test", "Arm", "P1", "P2", "P3", "P4", "Pooled"],
        first_only(body, 1),
        "scriptsize",
    )

    body = []
    for t, v in a["16_checker_off_hypothetical"]["tests"].items():
        for arm, f in v["failed_judgments"].items():
            above = sum(
                n for k, n in f.items() if k.startswith("recovered_level_") and k != "recovered_level_0"
            )
            hyp = v["hypothetical_classes"][arm]
            body.append(
                [
                    esc(TEST_SHORT.get(t, t)),
                    esc(arm),
                    str(f.get("failed_judgments", 0)),
                    str(f.get("checker_failure_recovered", 0)),
                    str(above),
                    str(v["observed_resolved"][arm]),
                    str(hyp.get("agree_score", 0) + hyp.get("agree_not_applicable", 0)),
                ]
            )
        o, h = v["observed_resolved_paired"], v["hypothetical_resolved_paired"]
        body.append(
            [
                esc(TEST_SHORT.get(t, t)),
                "difference",
                "",
                "",
                "",
                f"{pts(o['difference'], True)} {ci(o['interval_95'], True)}",
                f"{pts(h['difference'], True)} {ci(h['interval_95'], True)}",
            ]
        )
        body.append(["MIDRULE"])
    tex_table(
        "checker",
        "HYPOTHETICAL re-scoring with the quotation check switched off: failed judgments in the comparison, "
        "those that failed the check and whose verdict was recovered from the rater's reply (and of them, "
        "scores above 0), and resolved panels observed and with the recovered verdicts accepted unverified; "
        "last row per test: paired difference (points, 95\\% interval, stage seed). Not an estimate of the "
        "checker's value.",
        "llrrrrr",
        ["Test", "Arm", "Failed", "Recovered", "Above 0", "Observed", "Hypothetical"],
        first_only(body[:-1], 1),
        "scriptsize",
        3,
    )


TITLES = {
    "1_ablation": "Ablation and baselines from stored judgments (re-aggregation, not re-running)",
    "2_operating_characteristics": "Operating characteristics per stage and arm",
    "3_rater_pairs": "Per-rater-pair agreement (exact, Cohen's kappa)",
    "4_difference_of_differences": "Difference of differences and post-stratification",
    "5_validity_anchors": "Validity anchors: the review authors' worked-example scores",
    "6_stage_table": "Stage table",
    "7_change_log": "Change log of the 19 documented rubric changes",
    "8_scope_vs_scores": "Scope agreement against score agreement",
    "9_pillar_distributions": "Per-pillar score distributions; without P3",
    "10_score_disagreement_by_pillar": "Score disagreement by pillar",
    "11_rater_shifts": "Per-rater shifts between arms",
    "12_records_based": "New literature without records-based studies (and hazard detectors)",
    "13_ac1_brennan_prediger": "Gwet's AC1 and Brennan-Prediger, scores only",
    "14_repeat_stability": "Repeat stability across executions",
    "15_primary_sensitivity": "Sensitivity of the primary: sign test, permutation test, BC and BCa intervals",
    "16_checker_off_hypothetical": "HYPOTHETICAL: quotation check switched off",
}


def md(res: dict) -> str:
    a = res["analyses"]
    out = [
        "# Post hoc analyses (review cycle 5)",
        "",
        f"**Provenance:** {PROVENANCE}. Generated by `scripts/posthoc_analyses.py`; machine report "
        "[POSTHOC_ANALYSES.json](POSTHOC_ANALYSES.json); LaTeX tables `tab_*.tex` beside it. Numbers only: "
        "no paper "
        "text, figure or quotation; the rubric is referenced by file and row, never paraphrased.",
        "",
        f"- Seed for every new bootstrap: "
        f"`{SEED}` ({RESAMPLES:,} resamples for differences, {KAPPA_RESAMPLES:,} for "
        "agreement and kappa). Paired differences under alternative rules use each stage's declared seed, "
        "so the "
        "unanimity row reproduces the stage's published primary.",
        f"- Ledger: backup copy only, read-only "
        f"(`{LEDGER.relative_to(ROOT)}`, sha256 `{res['sources']['ledger_sha256']}`).",
        f"- Parity checks passed: {len(res['parity_checks'])} (listed in the JSON).",
        "",
    ]
    for key, block in a.items():
        out += [f"## {key.split('_', 1)[0]}. {TITLES[key]}", ""]
        note = block.get("note", {})
        if note:
            out += [f"**What it shows.** {note['shows']}", "", f"**Caveats.** {note['caveats']}", ""]
        out += md_section(key, block)
    out += ["## Not computed", ""] + [f"- {x}" for x in res["not_computed"]] + [""]
    return "\n".join(out)


def md_section(key: str, b: dict) -> list[str]:
    o = []
    if key == "1_ablation":
        o += [
            "| Test | Rule | Panels | Refined | Comparator | Difference | 95% interval |",
            "|---|---|---:|---:|---:|---:|---|",
        ]
        for t, v in b["tests"].items():
            for name, c in v["paired_differences"].items():
                o.append(
                    f"| {TEST_SHORT[t]} | {name} | {c['panels']} | {c['refined']} | {c['comparator']} | "
                    f"{pts(c['difference'])} | {ci(c['interval_95'])} |"
                )
        o += [
            "",
            "Per arm (counts of panels):",
            "",
            "| Test | Arm | Panels | Resolved (3) | Majority | Failures ignored | No-failure panels: "
            "resolved/n "
            "| Pair r1+r2 | r1+r3 | r2+r3 | LOO r1 match/2-agree | r2 | r3 |",
            "|---|---|---:|---:|---:|---:|---|---:|---:|---:|---|---|---|",
        ]
        for t, v in b["tests"].items():
            for arm, s in v["per_arm"].items():
                ex, lo = s["failed_judgments_excluded"], s["leave_one_out"]
                o.append(
                    f"| {TEST_SHORT[t]} | {arm} | {s['panels']} | {s['resolved_three_raters']} | "
                    f"{s['majority_of_three']} | "
                    f"{s['failures_ignored']} | {ex['resolved']}/{ex['panels_without_failure']} | "
                    + " | ".join(str(p["same_verdict"]) for p in s["pairs"].values())
                    + " | "
                    + " | ".join(f"{lo[x]['matches']}/{lo[x]['other_two_agree']}" for x in RATERS)
                    + " |"
                )
    elif key == "2_operating_characteristics":
        o += [
            "| Stage | Arm | R0 requests | Failed % | Partial % | Process failures | Pending | Re-requests "
            "| Corrections | "
            "Median / p90 latency (s) | R0 $ | Discussion $ | All $ | R0 hours |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|",
        ]
        for st, arms in b["stages"].items():
            for arm, x in arms.items():
                r = x["r0"]
                o.append(
                    f"| "
                    f"{st} | "
                    f"{arm} | "
                    f"{r['requests']} | "
                    f"{pc(r['rates']['failed'])} | {pc(r['rates']['partial'])} | "
                    f"{r['process_failures']} | "
                    f"{r['outcomes'].get('pending', 0)} | {r['attempts'].get('re_request', 0)} | "
                    f"{r['attempts'].get('correction_turn', 0)} | "
                    f"{r['latency_s']['median']} / {r['latency_s']['p90']} | "
                    f"{r['cost_usd']:.2f} | {x['discussion']['cost_usd']:.2f} | {x['cost_total_usd']:.2f} | "
                    f"{x['r0_wall_clock_hours']} |"
                )
        o += [
            "",
            "Per rater (R0): requests, failed / partial / process failures, failed pillar judgments in the "
            "comparison, "
            "median latency (s), cost (US$):",
            "",
            "| Stage | Arm | Rater | Requests | Failed | Partial | Process failures | "
            "Failed judgments / panels | Median latency | Cost |",
            "|---|---|---|---:|---:|---:|---:|---|---:|---:|",
        ]
        for st, arms in b["stages"].items():
            for arm, x in arms.items():
                for r, y in x["r0_by_rater"].items():
                    fj = x["failed_pillar_judgments_in_comparison"]
                    o.append(
                        f"| "
                        f"{st} | "
                        f"{arm} | "
                        f"{r} "
                        f"({NAMES[r]}) | "
                        f"{y['requests']} | {y['outcomes'].get('failed', 0)} | "
                        f"{y['outcomes'].get('partial', 0)} | {y['process_failures']} | "
                        f"{fj[r] if fj else 'n/a'} / "
                        f"{x['comparison_panels'] or 'n/a'} | {y['latency_s']['median']} | "
                        f"{y['cost_usd']:.2f} |"
                    )
    elif key == "3_rater_pairs":
        o += [
            "| Test | Arm | Pair | Variant | Items | Exact % [95%] | Cohen's κ [95%] (defined resamples) |",
            "|---|---|---|---|---:|---|---|",
        ]
        for t, arms in b["tests"].items():
            for arm, pairs in arms.items():
                for pair, vs in pairs.items():
                    for variant, v in vs.items():
                        o.append(
                            f"| {TEST_SHORT[t]} | {arm} | {pair} | {variant} | {v['items']} | "
                            f"{pc(v['exact_agreement'])} {pct_iv(v['exact_interval_95'])} | "
                            f"{kap(v['kappa'])} "
                            f"{ci(v['kappa_interval_95'], points=False)} "
                            f"({v['kappa_resamples_defined']}) |"
                        )
    elif key == "4_difference_of_differences":
        o += [
            "Corpus paper mix by scheme: " + json.dumps(b["corpus_paper_mix"]),
            "",
            "| Comparison | Measure | Post-stratification | Exposed gain | New-lit gain | DiD | 95% "
            "interval | Note |",
            "|---|---|---|---:|---:|---:|---|---|",
        ]
        for t, tgt in b["targets"].items():
            for m in ("resolved", "complete_and_agreeing"):
                u = tgt[m]["unweighted"]
                o.append(
                    f"| "
                    f"{TEST_SHORT[t]} | "
                    f"{m} | none | {pts(u['exposed_gain'])} | {pts(u['new_literature_gain'])} | "
                    f"{pts(u['difference_of_differences'])} | {ci(u['interval_95'])} | |"
                )
                for s, ps in tgt[m]["poststratified"].items():
                    dd = ps["difference_of_differences"]
                    o.append(
                        f"| "
                        f"{TEST_SHORT[t]} | "
                        f"{m} | {s} | {pts(dd['exposed_gain'])} | {pts(dd['new_literature_gain'])} | "
                        f"{pts(dd['difference_of_differences'])} | "
                        f"{ci(dd['interval_95'])} | {ps['note'] or ''} |"
                    )
        o += ["", "Stratum-specific differences (resolved; points, papers):", ""]
        for t, tgt in b["targets"].items():
            ps = tgt["resolved"]["poststratified"]["four types"]
            o.append(
                f"- {TEST_SHORT[t]}: new literature "
                + "; ".join(
                    f"{k} {pts(v['difference'])} ({v['papers']})"
                    for k, v in ps["new_literature_by_stratum"].items()
                )
                + " | exposed corpus "
                + "; ".join(
                    f"{k} {pts(v['difference'])} ({v['papers']})" for k, v in ps["exposed_by_stratum"].items()
                )
            )
    elif key == "5_validity_anchors":
        if not b.get("computed"):
            o.append(b.get("reason", ""))
            return o + [""]
        o += [
            "Reference (review authors' scores, P1–P4 / OVI): "
            + "; ".join(
                f"study "
                f"{s} "
                f"({v['study_key']}, SLR line "
                f"{v['slr_line']}): {'/'.join(str(v['scores'][p]) for p in PILLARS)}"
                f" / {v['ovi']}"
                for s, v in b["reference"].items()
            ),
            "",
            "| Group | Panels | Classes | Agreed-score items | Exact | Within one | AI higher | AI lower | "
            "Weighted κ |",
            "|---|---:|---|---:|---:|---:|---:|---:|---:|",
        ]
        for g, v in b["by_group"].items():
            s = v["agreed_score_panels"]
            o.append(
                f"| {g} | {v['panels']} | {json.dumps(v['panel_classes'])} | {s['items']} | {s['exact']} | "
                f"{s['within_one']} | "
                f"{s['ai_higher']} | {s['ai_lower']} | {kap(s['weighted_kappa_linear'])} |"
            )
        o += [
            "",
            "By pillar (agreed-score panels):",
            "",
            "| Group | Pillar | Items | Exact | Within one | Weighted κ |",
            "|---|---|---:|---:|---:|---:|",
        ]
        for g, v in b["by_group"].items():
            for p, s in v["agreed_score_panels_by_pillar"].items():
                o.append(
                    f"| "
                    f"{g} | "
                    f"{p} | "
                    f"{s['items']} | "
                    f"{s['exact']} | {s['within_one']} | {kap(s['weighted_kappa_linear'])} |"
                )
            m = v["one_item_per_paper_pillar_modal_agreed_score"]
            o.append(
                f"| {g} | one item per paper-pillar (modal agreed score) | {m['items']} | {m['exact']} | "
                f"{m['within_one']} | {kap(m['weighted_kappa_linear'])} |"
            )
        o += [
            "",
            "Per paper and pillar: " + json.dumps(b["by_paper_pillar"]),
            "",
            "Agreed four-pillar profiles: " + json.dumps(b["agreed_profiles"]),
        ]
    elif key == "6_stage_table":
        o += [
            "| Stage | Arm | Rubric | Procedure | Papers | Paper-exec. | Panels | Resolved | C&A | Failed "
            "panels | "
            "Re-request policy | R0 requests | Cost R0 / all (US$) |",
            "|---|---|---|---|---:|---:|---:|---:|---:|---:|---|---:|---|",
        ]
        for s in b["rows"]:
            o.append(
                f"| "
                f"{s['stage']} | "
                f"{s['arm']} | {s['rubric_file']} | {s['procedure_file']} | {s['papers_compared']} | "
                f"{s['paper_executions_compared']} | "
                f"{s['panels']} | {s['resolved']} | {s['complete_and_agreeing']} | "
                f"{s['panels_with_a_failed_judgment']} | "
                f"{'; '.join(json.dumps(p, sort_keys=True) for p in s['policies'])} | {s['r0_requests']} | "
                f"{s['cost_r0_usd']:.2f} / {s['cost_total_usd']:.2f} |"
            )
        o += ["", "Rater settings by arm (manifest `models`):", ""]
        for s in b["rows"]:
            o.append(
                f"- {s['stage']} / {s['arm']}: "
                + " | ".join(json.dumps(r, sort_keys=True) for r in s["raters"])
            )
    elif key == "7_change_log":
        o += [
            "| # | Version | Pillar | Prompted by (class) | Basis | Evidence papers | Handbook rules cited | "
            "Regression | Change-log row | Rubric text at |",
            "|---:|---|---|---|---|---|---|---|---|---|",
        ]
        for c in b["changes"]:
            o.append(
                f"| {c['id']} | {c['version']} r{c['revision']} | {c['pillar']} | {c['prompted_by_class']} | "
                f"{c['class_basis']} | {', '.join(map(str, c['evidence_papers'])) or '—'} | "
                f"{c['handbook_rules_cited'] or '—'} | "
                f"{'yes' if c['prompted_by_regression_of_an_earlier_revision'] else ''}"
                f" | {c['change_log_row']} | {c['rubric_text_at']} |"
            )
        o += ["", "Summary: " + json.dumps(b["summary"])]
    else:
        o += md_second(key, b)
    return o + [""]


def diff_row(name: str, c: dict | None) -> str:
    if not c or not c.get("panels"):
        return f"| {name} | — | — | — | — | — |"
    return (
        f"| {name} | {c['panels']} | {c['v1_2']} | {c['v1_0']} | {pts(c['difference'])} | "
        f"{ci(c['interval_95'])} |"
    )


DIFF_HEAD = [
    "| Test / measure | Units | Refined | Comparator | Difference (points) | 95% interval |",
    "|---|---:|---:|---:|---:|---|",
]


def md_second(key: str, b: dict) -> list[str]:
    o = []
    if key == "8_scope_vs_scores":
        o += DIFF_HEAD
        for t, v in b["tests"].items():
            o.append(
                diff_row(
                    f"{TEST_SHORT[t]}: (a) scope agreed, per paper-execution",
                    v["a_scope_per_paper_execution"]["paired"],
                )
            )
            o.append(
                diff_row(f"{TEST_SHORT[t]}: (a) scope agreed, per panel", v["a_scope_per_panel"]["paired"])
            )
            o.append(
                diff_row(
                    f"{TEST_SHORT[t]}: (b) agreeing, panels all-scored in both arms",
                    v["b_scores_on_panels_all_scored_in_both_arms"],
                )
            )
            o.append(
                diff_row(
                    f"{TEST_SHORT[t]}: (b) resolved, paper-executions agreed in scope in both arms",
                    v["b_resolved_on_paper_executions_agreed_in_scope_in_both_arms"],
                )
            )
        o += ["", "Scope patterns per paper-execution and score agreement per arm (unpaired):", ""]
        for t, v in b["tests"].items():
            o.append(
                f"- {TEST_SHORT[t]}: patterns {json.dumps(v['a_scope_per_paper_execution']['patterns'])}; "
                f"complete panels agreeing {json.dumps(v['b_scores_per_arm_unpaired'])}"
            )
        o += ["", "Non-scored status vocabulary and agreed not-applicable panels by status:", ""]
        for t, v in b["vocabulary_all_stages"].items():
            o.append(f"- {t}: {json.dumps(v)}")
        o += [
            "",
            "Every non-scored status in the ledger backup, by condition and round (all runs, including "
            "checks and "
            "smoke runs): " + json.dumps(b["vocabulary_ledger_by_condition"]),
        ]
    elif key == "9_pillar_distributions":
        o += [
            "| Test | Arm | Pillar | Level 0 | 1 | 2 | 3 | Not scored | Failed | Classes |",
            "|---|---|---|---:|---:|---:|---:|---:|---:|---|",
        ]
        for t, v in b["tests"].items():
            for a, d in v["scored_judgments_by_level"].items():
                for p, c in d.items():
                    o.append(
                        f"| {TEST_SHORT[t]} | {a} | {p} | {c['0']} | {c['1']} | {c['2']} | {c['3']} | "
                        f"{c['not_scored']} | {c['failed']} | {json.dumps(v['classes_by_pillar'][a][p])} |"
                    )
        o += [""] + DIFF_HEAD
        for t, v in b["tests"].items():
            for p, c in v["resolved_difference_by_pillar"].items():
                o.append(diff_row(f"{TEST_SHORT[t]}: resolved, {p} only", c))
            o.append(diff_row(f"{TEST_SHORT[t]}: resolved, without P3", v["resolved_difference_without_P3"]))
        o += [
            "",
            "P3 scores above 0 in the refined arm of each comparison: "
            + json.dumps({t: v["refined_arm_P3_scores_above_0"] for t, v in b["tests"].items()}),
            "",
            "P3 scored judgments in every run of the ledger backup rated under a rubric other than v1.0, by "
            "condition: " + json.dumps(b["p3_in_all_v1_1_v1_2_runs"]["by_condition"]),
            "",
            "Conditions with any P3 score above 0: "
            + json.dumps(b["p3_in_all_v1_1_v1_2_runs"]["conditions_with_P3_above_0"]),
        ]
    elif key == "10_score_disagreement_by_pillar":
        o += ["| Test | Arm | P1 | P2 | P3 | P4 |", "|---|---|---:|---:|---:|---:|"]
        for t, arms in b["tests"].items():
            for a, d in arms.items():
                o.append(f"| {TEST_SHORT[t]} | {a} | " + " | ".join(str(d[p]) for p in PILLARS) + " |")
    elif key == "11_rater_shifts":
        o += [
            "| Test | Measure | Rater | Refined | Comparator | Change (points) | 95% interval |",
            "|---|---|---|---:|---:|---:|---|",
        ]
        for t, v in b["tests"].items():
            for m in ("pairwise", "leave_one_out"):
                for x, s in v[m]["by_rater"].items():
                    o.append(
                        f"| "
                        f"{TEST_SHORT[t]} | "
                        f"{m} | {x} ({NAMES[x]}) | {pc(s['refined'])} | {pc(s['comparator'])} | "
                        f"{pts(s['change'])} | {ci(s['change_interval_95'])} |"
                    )
                for c, s in v[m]["contrasts_of_change"].items():
                    o.append(
                        f"| "
                        f"{TEST_SHORT[t]} | "
                        f"{m} | contrast {c} | | | {pts(s['estimate'])} | {ci(s['interval_95'])} |"
                    )
        o += [
            "",
            "Denominators (pairwise comparisons, leave-one-out panels): "
            + json.dumps({t: v["denominators"] for t, v in b["tests"].items()}),
        ]
    elif key == "12_records_based":
        o += DIFF_HEAD
        for name, c in b.items():
            if name != "note":
                o.append(
                    diff_row(name.replace("_", " ") + f" (dropped present: {c['papers_dropped_present']})", c)
                )
    elif key == "13_ac1_brennan_prediger":
        o += [
            "| Test | Arm | Pillar | Items | Observed | AC1 [95%] | Brennan–Prediger [95%] |",
            "|---|---|---|---:|---:|---|---|",
        ]
        for t, arms in b["tests"].items():
            for a, d in arms.items():
                for p, s in d.items():
                    o.append(
                        f"| {TEST_SHORT[t]} | {a} | {p} | {s['items']} | {kap(s['pa'])} | {kap(s['ac1'])} "
                        f"{ci(s['ac1_interval_95'], points=False)} | "
                        f"{kap(s['bp'])} {ci(s['bp_interval_95'], points=False)} |"
                    )
    elif key == "14_repeat_stability":
        o += [
            "| Test | Arm | Panels in both | Identical trio | Same class | Resolved in both | Identical "
            "among them | "
            "r1 same/usable | r2 | r3 | r1 same score/scored | r2 | r3 |",
            "|---|---|---:|---:|---:|---:|---:|---|---|---|---|---|---|",
        ]
        for t, arms in b["tests"].items():
            for a, s in arms.items():
                pr = s["per_rater_test_retest"]
                o.append(
                    f"| {TEST_SHORT[t]} | {a} | {s['panels_in_both_executions']} | {s['identical_trio']} | "
                    f"{s['same_class']} | {s['resolved_in_both']} | {s['resolved_in_both_identical_trio']} | "
                    + " | ".join(f"{pr[x]['same']}/{pr[x]['usable_pairs']}" for x in RATERS)
                    + " | "
                    + " | ".join(f"{pr[x]['same_score']}/{pr[x]['scored_pairs']}" for x in RATERS)
                    + " |"
                )
    elif key == "15_primary_sensitivity":
        o += [
            "| Test | Difference | Percentile 95% | BC 95% | BCa 95% (a) | Papers +/−/tie | Sign test p | "
            "Permutation p |",
            "|---|---:|---|---|---|---|---:|---:|",
        ]
        for t, s in b["tests"].items():
            bs = s["bootstrap"]
            o.append(
                f"| "
                f"{TEST_SHORT[t]} | "
                f"{pts(bs['estimate'])} | {ci(bs['percentile_95'])} | {ci(bs['bc_95'])} | "
                f"{ci(bs['bca_95'])} ({bs['acceleration']}) | {s['papers_favouring_refined']}/"
                f"{s['papers_favouring_comparator']}/{s['ties']} | {pval(s['sign_test_p_two_sided'])} | "
                f"{pval(s['permutation_p_two_sided'])} |"
            )
    elif key == "16_checker_off_hypothetical":
        o += [
            "| Test | Arm | Failed judgments in comparison | Of which checker failures recovered | Other / "
            "unrecoverable "
            "| Observed resolved | Hypothetical resolved |",
            "|---|---|---|---|---|---:|---:|",
        ]
        for t, v in b["tests"].items():
            hp = v["hypothetical_resolved_paired"]
            for a in v["failed_judgments"]:
                f = v["failed_judgments"][a]
                rec = {k[len("recovered_") :]: n for k, n in f.items() if k.startswith("recovered_")}
                other = {
                    k: n
                    for k, n in f.items()
                    if k
                    in ("other_failures_kept", "checker_failure_unrecoverable", "checker_failure_ambiguous")
                }
                hyp = hp["v1_2"] if a == list(v["observed_resolved"])[0] else hp["v1_0"]
                o.append(
                    f"| {TEST_SHORT.get(t, t)} | {a} | {f.get('failed_judgments', 0)} | "
                    f"{f.get('checker_failure_recovered', 0)} {json.dumps(rec)} | {json.dumps(other)} | "
                    f"{v['observed_resolved'][a]} | {hyp} |"
                )
        o += ["", "Paired differences, observed vs hypothetical (stage seed):", ""] + DIFF_HEAD
        for t, v in b["tests"].items():
            o.append(diff_row(f"{TEST_SHORT.get(t, t)}: observed", v["observed_resolved_paired"]))
            o.append(
                diff_row(
                    f"{TEST_SHORT.get(t, t)}: HYPOTHETICAL, checker off", v["hypothetical_resolved_paired"]
                )
            )
    return o


# --------------------------------------------------------------------------------------------------------
# Notes


NOTES = {
    "1_ablation": {
        "shows": "How the stored independent-round judgments behave under other aggregation rules: any two "
        "of the "
        "three raters (pair rules), a 2-of-3 majority, unanimity with failed judgments ignored, and "
        "unanimity on the "
        "panels without a failed judgment in either arm (complete cases); per arm, how often each rater "
        "matches the "
        "other two when those two agree (leave-one-out). Paired refined-minus-comparator differences under "
        "each rule "
        "use the stage's declared seed (held-out: the post hoc seed), so the unanimity row reproduces the "
        "published "
        "primary and every rule shares the same bootstrap draws.",
        "caveats": "No component was ablated: nothing was re-run with two raters, without the checker or "
        "without the "
        "correction turn. Every judgment was produced inside the three-rater design, so these are "
        "re-aggregations of "
        "the same judgments, not causal effects of removing a rater or any other component. The checker and "
        "the "
        "correction turn cannot be ablated from stored rows (a quotation that failed is stored as a failure "
        "and no "
        "unchecked run exists); analysis 16 gives only a hypothetical re-scoring. Rules were chosen after "
        "the results; several were examined.",
    },
    "2_operating_characteristics": {
        "shows": "Per stage and arm, from the ledger backup: R0 rating requests and how each ended "
        "(judgments; partial "
        "= judgments plus a failure record; failed = failure record only; pending = neither), process "
        "failures "
        "(failure status process_failure with no judgment: a provider error, timeout or incomplete output "
        "that was "
        "not recovered, with the runner's reason; among them the request the stopped run parked, HTTP 520), "
        "attempts by kind, ledger charges (completions.charged; the backup has no charge reconciliations, "
        "so charged "
        "is the effective charge), tokens, and latency (attempt created to completion created, per "
        "attempt). The "
        "stopped new-literature rows are launch 1 only (attempts created up to the stop at "
        f"{STOP_UTC} UTC).",
        "caveats": "Request-level, not judgment-level. Latency is the ledger's clock and includes provider "
        "queueing "
        "and the runner's own work between those two writes; an attempt without a completion row has no "
        "latency "
        "(attempts_without_completion). "
        "Costs are as recorded by the runner; provider invoices were not consulted. The completed "
        "new-literature "
        "wall clock spans two launches with a gap. The exposed-corpus v1.0 arm (CORPUS3_V10) is shared by "
        "revisions "
        "2 and 3 and is listed once.",
    },
    "3_rater_pairs": {
        "shows": "For each test and arm, each pair of raters: exact agreement and unweighted Cohen's kappa, "
        "on panels "
        "where both scored (scores only, levels 0-3) and with any non-scored status as one 'not applicable' "
        "category; "
        "failed judgments are excluded from both. Intervals resample papers (2,000 draws, fresh seed per "
        "call so all "
        "pairs of one arm share draws).",
        "caveats": "Most scores are 0, so kappa is prevalence-sensitive and can be low with high exact "
        "agreement; it "
        "is undefined when a pair used one category throughout (reported as undefined, and resamples where "
        "it is "
        "undefined are dropped from the interval). Kappa covers only the judgments obtained, not failures. "
        "Exploratory; not pre-registered.",
    },
    "4_difference_of_differences": {
        "shows": "The exposed-corpus gain (v1.2 r3 minus v1.0) minus the new-literature gain, in resolved "
        "and in "
        "complete-and-agreeing panels, for the stopped (pre-registered) and the completed (resumed) "
        "comparisons; "
        "intervals from independent paper bootstraps of the two sets. The new-literature gain is also "
        "post-stratified to the corpus paper-type mix (weights = corpus paper shares; new papers resampled "
        "within "
        "strata).",
        "caveats": "Descriptive: the two tests differ in more than exposure (paper mix, re-request policy "
        "v3 vs v4, "
        "dates, the exposed test's arms were not interleaved), so a non-zero DiD is not an effect of "
        "exposure. "
        "Corpus types: only hazard detectors were classified for every corpus paper (DEC-0010); people "
        "detectors "
        "(4, 11, 46) and the records-based paper (75) come from rulings documents that named the papers "
        "behind a "
        "ruling, so other corpus papers of those types may sit in 'other'; a variant counts paper 63 "
        "(drowning "
        "system or people detector, DEC-0010) as a people detector. The 'hazard vs rest' scheme rests only "
        "on "
        "systematic classifications on both sides. Post-stratification assumes the stratum-specific gains "
        "transport "
        "between sets; with 1 to 3 corpus papers in a stratum its weight is coarse, and the stopped "
        "comparison has "
        "no records-based paper.",
    },
    "5_validity_anchors": {
        "shows": "Where the AI raters' unanimous R0 scores meet the only human-assigned per-paper OVI "
        "scores found in "
        "the review's files: the four worked examples of the SLR supplement. Exact, within-one and "
        "linear-weighted "
        "kappa over agreed-score panels, per rubric group and per pillar, and over one item per "
        "paper-pillar (the "
        "modal agreed score across v1.0 panels).",
        "caveats": "These are the review authors' own scores (the rubric's authors, including this "
        "article's authors), "
        "made to illustrate the rubric; they are not an independent expert reference and were not made "
        "blind to "
        "anything. Only four papers (16 paper-pillars) exist; repeated executions and arms of the same "
        "paper are not "
        "independent items, so the panel-level statistics overstate the information; kappa on so few items "
        "is "
        "unstable or undefined. The review scored under its own strict-interpretation rules; the AI arms "
        "used v1.0 or "
        "a refined rubric with a procedure. Papers 25 and 27 are held-out papers, 34 a development paper "
        "and 4 a "
        "corpus paper; refined-rubric panels exist for paper 4 only.",
    },
    "6_stage_table": {
        "shows": "One row per stage and arm: rubric and procedure files (matched by sha256 of the rated "
        "inputs), "
        "papers and paper-executions compared, R0 panels, resolved, complete-and-agreeing and failed "
        "panels, policies "
        "and rater settings from the run manifests, R0 requests and ledger cost.",
        "caveats": "Development cycles are single-arm and their 'resolved' is the post hoc measure. Panel "
        "counts are "
        "those of the stage's comparison; requests and cost count every R0 request of the arm. The stopped "
        "new-literature cost is launch 1 only.",
    },
    "7_change_log": {
        "shows": "The 19 documented rubric changes with version and revision, pillar, the class of "
        "disagreement that "
        "prompted each, the evidence papers, the handbook rules its row cites, whether a fall in agreement "
        "after an "
        "earlier revision prompted it, and where the row and the changed text are.",
        "caveats": "The class is read from each row's evidence column: 'stated' when the row states the "
        "split or the "
        "scores, 'inferred' when it describes one rater's reading against the others', 'not stated' "
        "otherwise. The "
        "rubric text is referenced, never paraphrased. Handbook (procedure) changes are recorded separately "
        "in "
        "docs/final-phase-2026-10-28/CHANGESET_C1.md to CHANGESET_C3.md and are not counted among the 19.",
    },
}

NOTES.update(
    {
        "8_scope_vs_scores": {
            "shows": "The primary measure split into its two parts. (a) Agreement on scope: per "
            "paper-execution, each "
            "rater's call from P1-P3 (in = all three scored, out = none scored, else mixed or failed), "
            "agreed when all "
            "three raters make the same in/out call; and per panel (all three scored, or all three "
            "non-scored). (b) "
            "Agreement on scores where the pillar was scored: on panels all three raters scored in both "
            "arms (paired), "
            "per arm over its own complete panels (unpaired), and resolved panels on paper-executions "
            "agreed in scope "
            "in both arms. Paired differences use the stage seed. Also the non-scored status vocabulary of "
            "the rows of "
            "every stage and the status carried by each agreed not-applicable panel.",
            "caveats": "The scope call is derived here from the P1-P3 pattern; v1.0 has no scope statement, "
            "so under v1.0 "
            "an all-non-scored P1-P3 is a pattern, not a declared scope ruling. Restricting to panels "
            "scored in both "
            "arms conditions on a post-treatment outcome (what each rubric made raters score), so (b) is "
            "descriptive, "
            "not the effect of the rubric on score agreement.",
        },
        "9_pillar_distributions": {
            "shows": "Scored judgments by level (0-3), non-scored and failed judgments, per pillar and arm; "
            "panel classes "
            "per pillar; the resolved difference per pillar and without P3 (stage seed); whether P3 ever "
            "received a "
            "score above 0 under v1.1 or v1.2, in the comparisons and in every run of the ledger backup "
            "rated under a "
            "rubric other than v1.0 (sha256 of the rated rubric file; check and smoke runs included), "
            "independent round "
            "and discussion apart.",
            "caveats": "Per-pillar and without-P3 differences were chosen after the results and are "
            "exploratory; "
            "several were examined.",
        },
        "10_score_disagreement_by_pillar": {
            "shows": "Independent-round panels in the class score_disagreement (all three scored, not all "
            "equal) per "
            "pillar and arm.",
            "caveats": "Counts only; the full class split per pillar is in analysis 9.",
        },
        "11_rater_shifts": {
            "shows": "For each rater, exact agreement with the other two on panels where all three scored: "
            "the mean of its "
            "two pairwise matches, and leave-one-out (it matches when the other two agree). Per arm, the "
            "change from "
            "v1.0 to the refined arm, and whether r3 (claude-sonnet-5-5, the provider of the assistant that "
            "drafted the "
            "revisions) changed more than r1 or r2 (contrast of changes). Joint paper bootstrap.",
            "caveats": "The panel sets differ between arms (each arm's complete panels), so changes mix "
            "rubric effects with "
            "which panels were scored. A same-provider advantage would need a design that varies the "
            "drafting "
            "assistant; this can only show whether r3's agreement moved differently. Exploratory.",
        },
        "12_records_based": {
            "shows": "The resolved difference without the three records-based studies (study ids 10141, "
            "10589, 10973; "
            "S0141, S0589, S0973), and without them and the hazard detectors, for the completed comparison "
            "(and the "
            "stopped one, which has no records-based study). Stage seed; the first reproduces the committed "
            "exploratory "
            "value.",
            "caveats": "Subgroups chosen by paper type after the results (the records-based analysis was "
            "listed as "
            "exploratory before the run); not pre-registered as a sensitivity analysis.",
        },
        "13_ac1_brennan_prediger": {
            "shows": "Gwet's AC1 and the Brennan-Prediger coefficient for three raters on scores only "
            "(panels where all "
            "three scored; Q = 4 categories, levels 0-3), per pillar and pooled, per arm, with "
            "paper-bootstrap "
            "intervals. These coefficients are less affected than kappa by one dominant category.",
            "caveats": "Both depend on the number of categories assumed (Q = 4 fixed, whether or not all "
            "levels were "
            "used); computed only over complete panels, so they ignore failures and scope splits. "
            "Exploratory.",
        },
        "14_repeat_stability": {
            "shows": "Panels present in both executions: identical trio (all such panels, and among panels "
            "resolved in "
            "both), same class, and per-rater test-retest exact agreement (any usable verdict; scores only).",
            "caveats": "The two executions of an arm ran at different times and, in the completed "
            "new-literature run, "
            "partly in different launches; in the stopped comparison only papers finished in both "
            "executions count.",
        },
        "15_primary_sensitivity": {
            "shows": "For the resolved difference: a paper-level exact sign test (per paper, refined minus "
            "comparator "
            "resolved panels; ties dropped), a paper-level sign-flip permutation test of the pooled "
            "difference "
            f"({PERMUTATIONS:,} random flips, seed "
            f"{SEED}), and bias-corrected (BC) and BCa intervals built from the "
            "stage's own 10,000 bootstrap draws (guarded to reproduce the published percentile interval), "
            "with a "
            "leave-one-paper-out jackknife acceleration.",
            "caveats": "Post hoc. Every paper contributes the same number of panels within a test, so the "
            "bootstrap differences lie on a grid (1/456 in the completed comparison) and an interval bound "
            "can be "
            "exactly 0; under the pre-registered three-way rule a lower bound of exactly 0 reads 'not "
            "detected'. "
            "The sign test ignores the size of each paper's difference; the "
            "permutation test assumes "
            "the arms are exchangeable within a paper. None of these replaces the pre-registered reading, "
            "which rests "
            "on the percentile interval of the stopped comparison.",
        },
        "16_checker_off_hypothetical": {
            "shows": "HYPOTHETICAL. Every judgment that failed the quotation check (pillar failure status "
            "evidence_failure) is replaced by the rater's own verdict as it stood in its reply, read inside "
            "SQLite from "
            "the reply's cells (pillar, status and score only) of the latest attempt that was not a "
            "correction turn; "
            "the panels are then reclassified and the paired difference recomputed (stage seed). Format, "
            "provider and "
            "other failures stay failures.",
            "caveats": "Assumes the rater's unverified verdict would have stood unchanged and that raters "
            "would have "
            "answered the same with no checker in place; ignores that the correction turn existed from the "
            "corpus tests "
            "on (held-out had none). A recovered score above 0 is a score whose quotation could not be "
            "found on the "
            "cited page: accepting it is what the checker exists to prevent. Not an estimate of the "
            "checker's value.",
        },
    }
)

NOT_COMPUTED = [
    "A true ablation of the quotation checker or the correction turn (re-running without them). Analysis 16 "
    "is "
    "only a hypothetical re-scoring of the stored replies.",
    "Rater substitution or same-family bias (e.g. the figure describer and one rater share a provider): no "
    "other "
    "models rated these papers in these stages, so it cannot be estimated from stored data.",
    "Separating rubric text from procedure (handbook): the two always changed together between arms.",
    "Validity anchors beyond the four worked examples: no other human-assigned per-paper OVI scores were "
    "found in "
    "the read-only SLR tree (CORPUS_STATS.md has none; the only per-study OVI table is the worked-example "
    "table in "
    "supplementary.tex). data/scores_alpha_rater*.csv are agent ratings (agent:opus-4.8), not human, and "
    "were not used.",
    "Post-stratification of the stopped comparison exactly as specified: it has no records-based paper, so "
    "that "
    "stratum's corpus weight was dropped and the rest renormalised (flagged in the tables).",
    "Systematic people-detector and records-based typing of the 42 corpus papers: not recorded; only the "
    "papers "
    "named in rulings documents are typed (see analysis 4).",
    "Held-out operating characteristics are per arm over its three executions; the development loop's D0 "
    "smoke runs, "
    "the GLMFIX re-runs and the CHECK runs are not stages of the article's comparisons and were left out.",
]


# --------------------------------------------------------------------------------------------------------


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    db = open_ledger()
    conds = conditions()
    tests: dict = {}
    for key, spec in TESTS.items():
        arms = (spec["refined"], spec["comparator"])
        rows = (
            ledger_rows(db, {a: conds[a]["runs"] for a in arms}, require_all=True)
            if spec["source"] is None
            else committed_rows(spec["source"], arms)
        )
        tests[key] = {**spec, "rows": rows}
    dev = {c: ledger_rows(db, {c: conds[c]["runs"]}, require_all=True) for c in DEV_CYCLES}
    r2_rows = committed_rows(EXPOSED_R2["source"], (EXPOSED_R2["refined"], EXPOSED_R2["comparator"]))

    all_arms = sorted(
        {a for t in tests.values() for a in (t["refined"], t["comparator"])}
        | set(DEV_CYCLES)
        | {EXPOSED_R2["refined"]}
    )
    reqs = load_requests(db, [r for a in all_arms for r in conds[a]["runs"]])

    def arm_reqs(arm):
        runs = set(conds[arm]["runs"])
        return [{**q, "attempts": list(q["attempts"])} for q in reqs if q["run_id"] in runs]

    ops: dict = {}
    for key, t in tests.items():
        cutoff = STOP_UTC if key == "newlit_stopped" else None
        ops[key] = {a: operating(arm_reqs(a), t["rows"], a, cutoff) for a in (t["refined"], t["comparator"])}
    ops["exposed_r2"] = {
        EXPOSED_R2["refined"]: operating(
            arm_reqs(EXPOSED_R2["refined"]), r2_rows, EXPOSED_R2["refined"], None
        )
    }
    for c in DEV_CYCLES:
        ops[c.lower()] = {c: operating(arm_reqs(c), dev[c], c, None)}

    checks = parity(db, conds, {**tests, "_dev": dev}, ops)

    hashes = file_by_hash(
        sorted((ROOT / "rubric").glob("*.yaml")) + sorted(FINAL_DOCS.glob("HANDBOOK_*.txt"))
    )
    stage_rows = [
        stage_entry(
            db, conds, hashes, f"Development {c[-2:]}", c, dev[c], ops[c.lower()][c], f"Dev. {c[-2:]}"
        )
        for c in DEV_CYCLES
    ]
    for key, t in tests.items():
        if key == "exposed":
            r2 = EXPOSED_R2["refined"]
            stage_rows.append(
                stage_entry(
                    db,
                    conds,
                    hashes,
                    "Exposed corpus, v1.2 r2",
                    r2,
                    r2_rows,
                    ops["exposed_r2"][r2],
                    "Exposed, r2",
                )
            )
        for a in (t["refined"], t["comparator"]):
            stage_rows.append(
                stage_entry(db, conds, hashes, t["label"], a, t["rows"], ops[key][a], TEST_SHORT[key])
            )

    changes = change_log()
    summary = {
        "by_class": dict(Counter(c["prompted_by_class"] for c in changes)),
        "by_pillar": dict(Counter(c["pillar"] for c in changes)),
        "by_version": dict(Counter(f"{c['version']} r{c['revision']}" for c in changes)),
        "prompted_by_regression": sum(c["prompted_by_regression_of_an_earlier_revision"] for c in changes),
    }
    try:
        anchors = {"computed": True, **validity(db, conds)}
    except SystemExit as stop:  # a failed mapping guard ends this analysis only, and says so
        anchors = {"computed": False, "reason": f"No defensible mapping: {stop}"}
    extra = second_request(db, conds, {**tests, "_dev": dev}, hashes)
    for key in ("unseen", "exposed", "newlit_completed"):  # repeat stability against the committed reports
        t = tests[key]
        committed = json.loads(t["source"].read_text())["repeat_stability"]
        for a in arms_of(t):
            mine = extra["14_repeat_stability"]["tests"][key][a]
            got = {
                "same": mine["resolved_in_both_identical_trio"],
                "changed": mine["resolved_in_both"] - mine["resolved_in_both_identical_trio"],
                "not_resolved_in_both": mine["panels_in_both_executions"] - mine["resolved_in_both"],
            }
            if {k: v for k, v in got.items() if v} != {k: v for k, v in committed[a].items() if v}:
                raise SystemExit(f"Parity failed: {key} {a} repeat stability {got} != {committed[a]}")
            checks[f"{key} {a}: repeat stability == committed"] = got

    sources = {
        str(p.relative_to(ROOT)): sha256_file(p)
        for p in sorted(
            {t["source"] for t in tests.values() if t["source"]}
            | {EXPOSED_R2["source"], RESULTS / "HELDOUT_CLASSES.json", RESULTS / "HAZARD_SENSITIVITY.json"}
        )
    }
    res = {
        "provenance": PROVENANCE,
        "human_confirmed": False,
        "label": "Post hoc, exploratory analyses for the CH2 article (review cycle 5); not pre-registered",
        "generated": datetime.now().astimezone().isoformat(timespec="seconds"),
        "seeds": {
            "post_hoc": SEED,
            "stage_seeds": {k: t["seed"] for k, t in tests.items()},
            "resamples": RESAMPLES,
            "kappa_resamples": KAPPA_RESAMPLES,
        },
        "raters": NAMES,
        "sources": {
            "ledger": str(LEDGER.relative_to(ROOT)),
            "ledger_sha256": sha256_file(LEDGER),
            "ledger_mode": "sqlite read-only, immutable",
            "files_sha256": sources,
        },
        "parity_checks": checks,
        "analyses": {
            "1_ablation": {"note": NOTES["1_ablation"], "tests": ablation(tests)},
            "2_operating_characteristics": {
                "note": NOTES["2_operating_characteristics"],
                "stop_utc": STOP_UTC,
                "stages": ops,
            },
            "3_rater_pairs": {"note": NOTES["3_rater_pairs"], "seed": SEED, "tests": pairwise(tests)},
            "4_difference_of_differences": {
                "note": NOTES["4_difference_of_differences"],
                **difference_of_differences(tests),
            },
            "5_validity_anchors": {"note": NOTES["5_validity_anchors"], **anchors},
            "6_stage_table": {"note": NOTES["6_stage_table"], "rows": stage_rows},
            "7_change_log": {"note": NOTES["7_change_log"], "changes": changes, "summary": summary},
            **extra,
        },
        "not_computed": NOT_COMPUTED,
    }
    (OUT / "POSTHOC_ANALYSES.json").write_text(json.dumps(res, indent=1, default=list) + "\n")
    (OUT / "POSTHOC_ANALYSES.md").write_text(md(res))
    written = [
        "docs/chapter-draft/supplement/POSTHOC_ANALYSES.json",
        "docs/chapter-draft/supplement/POSTHOC_ANALYSES.md",
        *write_tex(res),
    ]
    print(json.dumps({"parity_checks": len(checks), "written": written}, indent=1))


if __name__ == "__main__":
    main()
