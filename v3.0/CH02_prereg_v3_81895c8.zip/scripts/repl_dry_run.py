"""Dry-run the replication freeze on a copy of the ledger: nothing live is written and nothing dispatches.

Usage: .venv/bin/python scripts/repl_dry_run.py --workdir <empty directory outside the live folder>

- Copies the live `programme.sqlite3` with SQLite's online backup from a read-only connection
  (`mode=ro`), and copies `FREEZE.json` beside it. ADMISSION.json is deliberately not copied, so no request
  could be admitted from the copy even by mistake.
- Points `final_phase.location()` at the copy for this process only, then runs `freeze_repl()`.
- Prints the requests, arms, seed, hashes and run IDs, and checks them against the post-SLR runs.
- Prints the sha256 of the live `programme.sqlite3` and `FREEZE.json` before and after, and fails if they
  differ.

The workdir holds packet copies of the rated papers' text (private): delete it after reading the output,
and never commit it.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pipeline.study import final_phase as fp  # noqa: E402

LIVE = ROOT / ".research-private/final-phase-live-v1"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def live_hashes() -> dict[str, str]:
    return {name: sha256(LIVE / name) for name in ("programme.sqlite3", "FREEZE.json")}


def copy_ledger(workdir: Path) -> None:
    """Read-only online backup of the live ledger and a byte copy of FREEZE.json; refuses a live workdir."""
    work = workdir.resolve()
    if work == ROOT.resolve() or ROOT.resolve() in work.parents:
        raise SystemExit("Refusing: the workdir is inside the repository (live ledger or committable files)")
    work.mkdir(parents=True, exist_ok=True)
    if any(work.iterdir()):
        raise SystemExit("Refusing: the workdir is not empty")
    source = sqlite3.connect((LIVE / "programme.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)
    target = sqlite3.connect(work / "programme.sqlite3")
    with target:
        source.backup(target)
    source.close()
    target.close()
    (work / "FREEZE.json").write_bytes((LIVE / "FREEZE.json").read_bytes())


def summary(entry: dict, freeze: dict) -> dict:
    """What the freeze would produce, with the checks Goal A's done-conditions name."""
    conditions = freeze["conditions"]
    arm_of = {r: a for a in fp.REPL_ARMS for r in conditions[a]["runs"]}
    sequence = [arm_of[row["run_id"]] for row in entry["schedule"]]
    postslr_conditions = (*fp.POSTSLR_ARMS, fp.POSTSLR_D0, fp.POSTSLR_SCHEDULE)
    postslr = {r for c in postslr_conditions for r in conditions[c]["runs"]}
    repl = (*fp.REPL_CONDITIONS, fp.REPL_SCHEDULE)
    earlier = {r for c, v in conditions.items() if c not in repl for r in v["runs"]}
    new = [*entry["runs"], *entry["smoke_runs"]]
    return {
        "seed": fp.REPL_SEED,
        "requests": len(entry["schedule"]),
        "papers": len({row["study"] for row in entry["schedule"]}),
        "requests_per_arm": {a: sequence.count(a) for a in fp.REPL_ARMS},
        "requests_per_rater": {
            r: sum(row["rater"] == r for row in entry["schedule"]) for r in ("r1", "r2", "r3")
        },
        "runs_per_arm": {a: conditions[a]["runs"] for a in fp.REPL_ARMS},
        "smoke": {fp.REPL_D0: entry["smoke_runs"]},
        "arm_switches_in_schedule": sum(a != b for a, b in zip(sequence, sequence[1:], strict=False)),
        "first_12_arms": sequence[:12],
        "rubric_sha256": entry["rubric_sha256"],
        "handbook_sha256": entry["handbook_sha256"],
        "run_ids_distinct": len(set(new)) == len(new),
        "collisions_with_postslr_runs": sorted(postslr & set(new)),
        "collisions_with_any_earlier_run": sorted(earlier & set(new)),
        "earlier_frozen_runs_checked": len(earlier),
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--workdir", type=Path, required=True)
    a = ap.parse_args()
    before = live_hashes()
    copy_ledger(a.workdir)
    work = a.workdir.resolve()
    fp.location = lambda: work  # this process only; the module on disk is unchanged
    entry = fp.freeze_repl()
    out = summary(entry, json.loads((work / "FREEZE.json").read_text()))
    from pipeline.study.scoring import implementation_provenance

    code = implementation_provenance()
    out["code_revision"], out["pipeline_files"] = code["revision"], code["files"]
    after = live_hashes()
    out["live_sha256_before"], out["live_sha256_after"] = before, after
    out["live_unchanged"] = before == after
    print(json.dumps(out, indent=1))
    if not out["live_unchanged"] or out["collisions_with_any_earlier_run"] or not out["run_ids_distinct"]:
        raise SystemExit("Dry run FAILED a check")


if __name__ == "__main__":
    main()
