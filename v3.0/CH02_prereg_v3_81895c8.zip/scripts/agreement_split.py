"""Which kind of agreement each corpus test gained (descriptive, post hoc; review cycle 1, 11 Nov 2026).

For CORPUS2 (v1.1, unseen) and CORPUS3B (v1.2 r3, exposed), from the committed rows of their reports:
resolved panels split into agreed level 0, agreed above 0 and agreed not applicable; agreement on panels where
all three scored and at least one scored above 0; and the distribution of every score given.
No ledger is read.
"""

from __future__ import annotations

import json
import random
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "docs/final-phase-2026-10-28/results"
SEED = "ch2-kappa-exploratory-20261111"
TESTS = {
    "CORPUS2 (v1.1, unseen)": ("CORPUS_RUN.json", "CORPUS2_V11", "CORPUS2_V10"),
    "CORPUS3B (v1.2 r3, exposed)": ("CORPUS3B_RUN.json", "CORPUS3B_V12", "CORPUS3_V10"),
}


def split(rows: list[dict], arm: str) -> dict:
    kinds, beyond, levels, statuses = Counter(), Counter(), Counter(), Counter()
    for r in rows:
        trio, cls = r[arm + "_trio"], r[arm]
        if cls == "agree_score":
            kinds["agreed_level_0" if trio[0][1] == 0 else "agreed_above_0"] += 1
        else:
            kinds[cls] += 1
        if all(v and v[0] == "scored" for v in trio) and any(v[1] > 0 for v in trio):
            beyond["panels"] += 1
            beyond["agreeing"] += len({tuple(v) for v in trio}) == 1
        for v in trio:
            if v and v[0] == "scored":
                levels[str(v[1])] += 1
            elif v:
                statuses[v[0]] += 1
    return {
        "classes": dict(sorted(kinds.items())),
        "agreement_beyond_zero": dict(beyond),
        "scores_given_by_level": dict(sorted(levels.items())),
        "other_statuses": dict(statuses),
    }


def fleiss_kappa(trios: list[list], with_not_applicable: bool = False) -> float | None:
    """Fleiss' kappa over panels where all three judgments are usable. Categories are the levels 0-3, plus
    'not applicable' when with_not_applicable (otherwise panels with a not-applicable judgment are left out).
    None when there are no panels or no variance (kappa undefined)."""
    rows = []
    for t in trios:
        if any(v is None for v in t):
            continue
        cats = [str(v[1]) if v[0] == "scored" else "na" for v in t]
        if "na" in cats and not with_not_applicable:
            continue
        rows.append(Counter(cats))
    if not rows:
        return None
    n, N = 3, len(rows)
    p_bar = sum(sum(c * (c - 1) for c in r.values()) / (n * (n - 1)) for r in rows) / N
    totals = Counter()
    for r in rows:
        totals.update(r)
    p_e = sum((v / (N * n)) ** 2 for v in totals.values())
    return None if p_e >= 1 else round((p_bar - p_e) / (1 - p_e), 4)


def kappa_with_interval(
    rows: list[dict], arm: str, with_not_applicable: bool, seed: str, resamples: int = 2000
) -> dict:
    """Point estimate and 95% percentile interval, resampling papers (exploratory)."""
    by_paper: dict[int, list] = {}
    for r in rows:
        by_paper.setdefault(r["study"], []).append(r[arm + "_trio"])
    point = fleiss_kappa([t for ts in by_paper.values() for t in ts], with_not_applicable)
    rng, papers, draws = random.Random(seed), sorted(by_paper), []
    for _ in range(resamples):
        sample = [t for s in rng.choices(papers, k=len(papers)) for t in by_paper[s]]
        k = fleiss_kappa(sample, with_not_applicable)
        if k is not None:
            draws.append(k)
    draws.sort()
    interval = [draws[int(0.025 * len(draws))], draws[int(0.975 * len(draws)) - 1]] if draws else None
    return {"kappa": point, "interval_95": interval, "resamples_defined": len(draws)}


def scope_and_levels(rows: list[dict], arm: str) -> dict:
    """Papers agreed out of scope (P1-P3 all agreed not applicable) and scores above 0 by pillar."""
    by_pe: dict[tuple, dict] = {}
    above = Counter()
    for r in rows:
        by_pe.setdefault((r["study"], r["execution"]), {})[r["pillar"]] = r[arm]
        above[r["pillar"]] += sum(1 for v in r[arm + "_trio"] if v and v[0] == "scored" and v[1] > 0)
    out = {
        s
        for (s, _), c in by_pe.items()
        if all(c.get(p) == "agree_not_applicable" for p in ("P1", "P2", "P3"))
    }
    return {"papers_out_of_scope": len(out), "scores_above_0_by_pillar": dict(sorted(above.items()))}


def rater_subsets(rows: list[dict], arm: str) -> dict:
    """Exploratory ablation from stored judgments: each rater's share of valid judgments, and how often each
    pair of raters gives the same verdict (both valid), as if the panel had two raters instead of three."""
    names = ("r1", "r2", "r3")
    valid = {n: sum(r[arm + "_trio"][i] is not None for r in rows) for i, n in enumerate(names)}
    pairs = {}
    for i in range(3):
        for j in range(i + 1, 3):
            both = [r for r in rows if r[arm + "_trio"][i] is not None and r[arm + "_trio"][j] is not None]
            same = sum(tuple(r[arm + "_trio"][i]) == tuple(r[arm + "_trio"][j]) for r in both)
            pairs[f"{names[i]}+{names[j]}"] = {"both_valid": len(both), "same_verdict": same}
    return {"panels": len(rows), "valid_judgments_by_rater": valid, "pairs": pairs}


def main() -> None:
    out = {
        "provenance": "agent:claude-opus-5-5",
        "human_confirmed": False,
        "label": "Agreement type per corpus test; post hoc, descriptive",
        "tests": {},
    }
    for name, (f, refined, published) in TESTS.items():
        rows = json.loads((RESULTS / f).read_text())["rows"]
        out["tests"][name] = {
            "refined": split(rows, refined),
            "v1.0": split(rows, published),
            "rater_subsets_exploratory": {
                "refined": rater_subsets(rows, refined),
                "v1.0": rater_subsets(rows, published),
            },
            "fleiss_kappa_exploratory": {
                arm_name: {
                    "scores_only": kappa_with_interval(rows, arm, False, SEED),
                    "with_not_applicable": kappa_with_interval(rows, arm, True, SEED),
                }
                for arm_name, arm in (("refined", refined), ("v1.0", published))
            },
            "scope_and_levels": {
                "refined": scope_and_levels(rows, refined),
                "v1.0": scope_and_levels(rows, published),
            },
            "p4_only_resolved": {
                arm_name: sum(
                    r[arm] in ("agree_score", "agree_not_applicable") for r in rows if r["pillar"] == "P4"
                )
                for arm_name, arm in (("refined", refined), ("v1.0", published))
            },
        }
    (RESULTS / "AGREEMENT_SPLIT.json").write_text(json.dumps(out, indent=1) + "\n")
    print(json.dumps(out["tests"], indent=1))


if __name__ == "__main__":
    main()
