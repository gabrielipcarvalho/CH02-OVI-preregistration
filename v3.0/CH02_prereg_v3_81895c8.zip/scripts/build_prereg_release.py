"""Build the v3.0 pre-registration release folder (docs/rerun-2026-11/prereg-release/) from a commit.

Usage:
    .venv/bin/python scripts/build_prereg_release.py                  # (re)build the folder from HEAD
    .venv/bin/python scripts/build_prereg_release.py --check-code       # Goal B: working tree = release code?

- The zip holds the exact files listed in FILES at the source commit (`git archive`, so it is reproducible
  for a given commit), as the v1.0 release held them. Every listed file must be committed and unchanged in the
  working tree, so the commit really is the source.
- CODE_HASHES.json lists the sha256 of the pipeline files the runner records in each run's manifest
  (`scoring.implementation_provenance`) and of the analysis scripts. Goal B refuses to freeze or launch if
  `--check-code` reports a difference.
- SHA256SUMS.txt covers every other file in the folder; verify with `shasum -a 256 -c SHA256SUMS.txt`.

Nothing here is sent anywhere: publishing the folder as v3.0 is Gabriel's step (README.md in the folder).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
OUT = ROOT / "docs/rerun-2026-11/prereg-release"
DOCS = ROOT / "docs/rerun-2026-11"
TEMPLATE = DOCS / "PREREG_RELEASE_README.template.md"
COPIED = {  # copied beside the zip, as the v1.0 release had PREREGISTRATION.md beside it
    "PREREGISTRATION_REPLICATION.md": DOCS / "PREREGISTRATION_REPLICATION.md",
    "REPORTING_RULES_REPLICATION.md": DOCS / "REPORTING_RULES_REPLICATION.md",
    "HANDBOOK_EVAL_ORIGINAL_NOCONJ.txt": (
        ROOT / "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL_NOCONJ.txt"
    ),
}
ANALYSIS = (
    "scripts/repl_report.py", "scripts/corpus_report.py", "scripts/discussion_report.py",
    "scripts/postslr_report.py", "scripts/posthoc_analyses.py", "scripts/v11_report.py",
    "scripts/agreement_split.py", "scripts/final_cycle_report.py",
    "scripts/repl_chain.sh",  # the run chain Goal B launches; hashed so --check-code verifies it
)
FILES = (
    "rubric/rubric.yaml", "rubric/rubric_v1_2_r3.yaml",
    "docs/final-phase-2026-10-28/HANDBOOK_H5.txt",
    "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt",
    "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL_NOCONJ.txt",
    "docs/final-phase-2026-10-28/FINAL_CHECK_V2.txt",
    "docs/final-phase-2026-10-28/QUALIFICATION_MD_V1_3.json",
    "calibration/protocol-ai-only-v1.md",
    "docs/study-2026-09-28/judgment.schema.json",
    "docs/postslr-2026-11/INPUTS_POSTSLR.json",
    "docs/postslr-2026-11/MARKDOWN_MANIFEST.json",
    "docs/postslr-2026-11/PREREGISTRATION_POSTSLR.md",
    "docs/postslr-2026-11/PREREGISTRATION_POSTSLR_STAGE2.md",
    "docs/rerun-2026-11/PREREGISTRATION_REPLICATION.md",
    "docs/rerun-2026-11/REPORTING_RULES_REPLICATION.md",
    "docs/rerun-2026-11/DRY_RUN_FREEZE.json",
    "docs/rerun-2026-11/PARITY_REPL_REPORT.json",
    "docs/rerun-2026-11/PREREG_RELEASE_README.template.md",
    "pipeline/study", "pipeline/calibration/providers.py", "pipeline/calibration/sources.py",
    "pipeline/calibration/store.py", "pipeline/schema.py",
    *ANALYSIS,
    "scripts/repl_spend.py", "scripts/repl_cost_estimate.py", "scripts/repl_dry_run.py",
    "scripts/build_prereg_release.py",
    "tests/test_repl_run.py", "tests/test_repl_report.py", "tests/test_postslr_run.py",
    "tests/test_study_scoring.py", "tests/test_study_transport.py", "tests/test_v11_rehearsal.py",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def code_hashes() -> dict:
    """What the runner records as its code (implementation_provenance) and the analysis scripts' bytes."""
    from pipeline.study.scoring import implementation_provenance

    return {
        "pipeline_files": implementation_provenance()["files"],
        "analysis_files": {name: sha256(ROOT / name) for name in ANALYSIS},
    }


def build() -> dict:
    """Build from HEAD only, so CODE_HASHES.json (computed from the working tree) describes the commit."""
    full = git("rev-parse", "HEAD")
    dirty = git("status", "--porcelain", "--", *FILES)
    if dirty:
        raise SystemExit("Refusing: listed files differ from the commit:\n" + dirty)
    dry = json.loads((DOCS / "DRY_RUN_FREEZE.json").read_text())
    if dry.get("pipeline_files") != code_hashes()["pipeline_files"]:
        raise SystemExit("Refusing: DRY_RUN_FREEZE.json was made with other pipeline code; re-run it")
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    zip_name = f"CH02_prereg_v3_{full[:7]}.zip"
    subprocess.run(["git", "archive", "--format=zip", "-o", str(OUT / zip_name), full, *FILES],
                   cwd=ROOT, check=True)
    for name, src in COPIED.items():
        shutil.copyfile(src, OUT / name)
    hashes = {"source_commit": full, **code_hashes()}
    (OUT / "CODE_HASHES.json").write_text(json.dumps(hashes, indent=1, sort_keys=True) + "\n")
    (OUT / "SOURCE_COMMIT.txt").write_text(
        f"Git commit: {full} (github.com/gabrielipcarvalho/CH2-Framework-Validation, private)\n"
    )
    (OUT / "README.md").write_text(readme(zip_name, full))
    names = sorted(p.name for p in OUT.iterdir() if p.name != "SHA256SUMS.txt")
    (OUT / "SHA256SUMS.txt").write_text("".join(f"{sha256(OUT / n)}  {n}\n" for n in names))
    return {"folder": str(OUT.relative_to(ROOT)), "commit": full, "files": names}


def check_code() -> dict:
    """Goal B's launch guard: the working tree's pipeline and analysis files equal the released hashes."""
    released = json.loads((OUT / "CODE_HASHES.json").read_text())
    now = code_hashes()
    diff = {
        kind: sorted(
            n for n in set(released[kind]) | set(now[kind]) if released[kind].get(n) != now[kind].get(n)
        )
        for kind in ("pipeline_files", "analysis_files")
    }
    return {"same": not any(diff.values()), "differs": diff, "source_commit": released["source_commit"]}


def readme(zip_name: str, commit: str) -> str:
    """The release README from PREREG_RELEASE_README.template.md (@ZIP@, @COMMIT@, @SHORT@ filled in)."""
    text = TEMPLATE.read_text()
    return text.replace("@ZIP@", zip_name).replace("@COMMIT@", commit).replace("@SHORT@", commit[:7])


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check-code", action="store_true")
    a = ap.parse_args()
    if a.check_code:
        result = check_code()
        print(json.dumps(result, indent=1))
        sys.exit(0 if result["same"] else 1)
    print(json.dumps(build(), indent=1))


if __name__ == "__main__":
    main()
