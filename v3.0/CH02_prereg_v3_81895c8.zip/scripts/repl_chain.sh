#!/bin/bash
# Replication chain (Goal B): the interleaved independent round of the three arms. No discussion stage.
# Launched as: nohup caffeinate -i scripts/repl_chain.sh > /dev/null 2>&1 &   (its hash is in the v3.0 release)
#
# Resumes are mechanical (PREREGISTRATION_REPLICATION.md, "Stopping rules"):
# - after an outage or network stop whose provider error has no credit words, the chain waits 5 x 2^k minutes
#   (k = automatic resumes so far: 5, 10, 20, ... minutes; at most nine fit in the 72 hours), then until all three
#   providers accept a TCP connection on port 443 (no request is sent), and relaunches itself, up to 10 times
#   per launch;
# - the 72 hours run in real time from the FIRST outage or network stop of the whole run: that time is kept in
#   $L/repl-first-wait and is never reset, also across a manual relaunch;
# - a launch that finds $L/repl-waiting (a wait cut short by a local interruption) goes straight back to waiting.
# - a final stop writes $L/repl-final, and the chain refuses to start while that file exists;
# - a launch first moves any earlier repl-r0.{log,err} aside, so no launch's logs are ever overwritten.
# Each launch's logs are kept as repl-r0-launchN.{log,err}; status lines go to repl-chain.status.
set -u
cd /Users/gabriel/Projects/Griffith/CH2-Framework-Validation || exit 1
L=.research-private/final-phase-live-v1
LIMIT=259200  # 72 hours, in seconds
MAX_RESUMES=10

run() { .venv/bin/python -m pipeline.study.final_phase repl > $L/repl-r0.log 2> $L/repl-r0.err; }
done_ok() { [ "$1" -eq 0 ] && ! tail -1 $L/repl-r0.log | grep -q '"stopped"'; }
resumable() {
  local line
  line=$(grep -o '(cause: [^)]*' $L/repl-r0.err | tail -1)
  echo "$line" | grep -Eq 'cause: (provider outage|network or transport);' || return 1
  echo "$line" | sed -n 's/.*provider error:\(.*\); reason.*/\1/p' \
    | grep -Eiq 'balance|credit|quota|billing|payment|arrears|insufficient|\b1113\b' && return 1
  return 0
}
reachable() { nc -z -G 10 api.openai.com 443 && nc -z -G 10 api.anthropic.com 443 && nc -z -G 10 api.z.ai 443; }
status() { echo "$(date '+%F %T') $*" >> $L/repl-chain.status; }
keep_logs() {
  local n
  n=$(ls $L/repl-r0-launch*.log 2>/dev/null | wc -l | tr -d ' ')
  mv $L/repl-r0.log $L/repl-r0-launch$((n + 1)).log
  mv $L/repl-r0.err $L/repl-r0-launch$((n + 1)).err
  echo $((n + 1))
}
final() { touch $L/repl-final; status "STOP repl $* (final)"; exit 1; }
wait_for_providers() {  # $1: minimum wait in seconds
  local start
  start=$(date +%s)
  [ -e $L/repl-first-wait ] || echo "$start" > $L/repl-first-wait
  touch $L/repl-waiting
  while :; do
    if [ $(( $(date +%s) - $(cat $L/repl-first-wait) )) -ge $LIMIT ]; then
      final "(72 real hours since the first outage or network stop)"
    fi
    sleep 300
    if [ $(( $(date +%s) - $(cat $L/repl-first-wait) )) -ge $LIMIT ]; then
      final "(72 real hours since the first outage or network stop)"
    fi
    [ $(( $(date +%s) - start )) -ge "$1" ] && reachable && break
  done
  rm -f $L/repl-waiting
}

if [ -e $L/repl-final ]; then
  status "REFUSED (a final stop is recorded in repl-final)"; exit 1
fi
[ -e $L/repl-r0.log ] || [ -e $L/repl-r0.err ] && keep_logs > /dev/null
resumes=0
status "START repl"
if [ -e $L/repl-waiting ]; then
  status "WAIT (a wait was cut short by a local interruption; waiting again)"
  wait_for_providers 300
fi
while :; do
  run; rc=$?
  if done_ok $rc; then status "ALL DONE"; exit 0; fi
  if ! resumable; then
    if grep -q '(cause: \|Traceback' $L/repl-r0.err || tail -1 $L/repl-r0.log | grep -q '"stopped"'; then
      final "rc=$rc ($(grep -o '(cause: [^;]*' $L/repl-r0.err | tail -1), a runner error or a budget stop)"
    fi
    status "STOP repl rc=$rc (no cause line and no traceback: a local interruption if the process was ended" \
      "by something other than the operator; the one manual resume may be used)"
    exit 1
  fi
  if [ $resumes -ge $MAX_RESUMES ]; then
    final "rc=$rc (an outage or network stop after the 10th automatic resume)"
  fi
  n=$(keep_logs)
  status "WAIT after $(grep -o '(cause: [^;]*' $L/repl-r0-launch$n.err | tail -1)"
  wait_for_providers $(( 300 * (1 << resumes) ))
  resumes=$((resumes + 1))
  status "RESUME $resumes"
done
