"""Cost estimate and caps for the replication run (Goal A, task C1), from the completed post-SLR run.

Usage: .venv/bin/python scripts/repl_cost_estimate.py --ledger <backup programme.sqlite3> \
    --freeze <FREEZE.json>

Read-only: the ledger is opened with `mode=ro`, and it must be a backup copy, never the live ledger.

For each post-SLR arm and provider it sums what the ledger charged (or still reserved) for every attempt of
the independent-round (R0) requests: first attempts, transport retries, re-requests and correction turns,
so the observed re-request overhead is included. The mean per R0 request is multiplied by the replication's
requests: 57 papers × 2 executions = 114 per arm and provider. REPL_V12 uses the POSTSLR_V12 rate; REPL_V10
and REPL_V10_NOCONJ (the same rubric, a procedure 125 bytes shorter) use the POSTSLR_V10 rate. The D0 smoke
run is added at the D0_V4 cost. Cap = estimate × 1.3 (01_GUIDELINES.md).
"""

from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIVE = (ROOT / ".research-private/final-phase-live-v1/programme.sqlite3").resolve()
PROVIDERS = ("anthropic", "openai", "zai")
REPL_FROM = {"REPL_V12": "POSTSLR_V12", "REPL_V10": "POSTSLR_V10", "REPL_V10_NOCONJ": "POSTSLR_V10"}
PER_ARM_PROVIDER = 57 * 2
CAP_FACTOR = 1.3

SPEND = """SELECT json_extract(r.manifest,'$.models.'||q.rater||'.provider') AS provider,
       count(DISTINCT q.id) AS requests,
       coalesce(sum(coalesce((SELECT z.amount FROM charge_reconciliations z WHERE z.attempt_id = a.id
                              ORDER BY z.sequence DESC LIMIT 1), c.charged, a.reserved)), 0) AS charged,
       count(a.id) AS attempts
FROM requests q JOIN runs r ON r.id = q.run_id
LEFT JOIN attempts a ON a.request_id = q.id
LEFT JOIN completions c ON c.attempt_id = a.id
WHERE q.run_id IN ({runs}) AND q.round = 0 AND q.kind = 'rating'
GROUP BY provider"""


def spend(db: sqlite3.Connection, runs: list[str]) -> dict[str, dict]:
    rows = db.execute(SPEND.format(runs=",".join("?" * len(runs))), runs).fetchall()
    return {p: {"requests": n, "charged": c, "attempts": k} for p, n, c, k in rows}


def estimate(ledger: Path, freeze: Path) -> dict:
    if ledger.resolve() == LIVE:
        raise SystemExit("Refusing: read a backup copy, never the live ledger")
    conditions = json.loads(freeze.read_text())["conditions"]
    db = sqlite3.connect(ledger.resolve().as_uri() + "?mode=ro", uri=True)
    observed = {arm: spend(db, conditions[arm]["runs"]) for arm in ("POSTSLR_V12", "POSTSLR_V10")}
    smoke = spend(db, conditions["D0_V4"]["runs"])
    db.close()
    out = {"observed_r0": observed, "observed_smoke": smoke, "per_provider": {}}
    for p in PROVIDERS:
        per_request = {a: observed[a][p]["charged"] / observed[a][p]["requests"] for a in observed}
        arms = {a: PER_ARM_PROVIDER * per_request[src] for a, src in REPL_FROM.items()}
        total = sum(arms.values()) + smoke.get(p, {}).get("charged", 0.0)
        out["per_provider"][p] = {
            "per_r0_request": per_request,
            "repl_requests": PER_ARM_PROVIDER * len(REPL_FROM),
            "estimate_by_arm": arms,
            "estimate": total,
            "cap": total * CAP_FACTOR,
        }
    out["total_estimate"] = sum(v["estimate"] for v in out["per_provider"].values())
    out["total_cap"] = sum(v["cap"] for v in out["per_provider"].values())
    return out


def markdown(out: dict) -> str:
    lines = [
        "| Provider | Observed per R0 request, V12 / V10 (US$) | Replication requests | Estimate (US$) |"
        " Cap = estimate × 1.3 = minimum balance (US$) |",
        "|---|---|---:|---:|---:|",
    ]
    for p, v in out["per_provider"].items():
        r = v["per_r0_request"]
        lines.append(f"| {p} | {r['POSTSLR_V12']:.4f} / {r['POSTSLR_V10']:.4f} | {v['repl_requests']} |"
                     f" {v['estimate']:.2f} | {v['cap']:.2f} |")
    lines.append(f"| **total** | | {sum(v['repl_requests'] for v in out['per_provider'].values())} |"
                 f" {out['total_estimate']:.2f} | {out['total_cap']:.2f} |")
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--ledger", type=Path, required=True)
    ap.add_argument("--freeze", type=Path, required=True)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    out = estimate(a.ledger, a.freeze)
    print(json.dumps(out, indent=1) if a.json else markdown(out))


if __name__ == "__main__":
    main()
