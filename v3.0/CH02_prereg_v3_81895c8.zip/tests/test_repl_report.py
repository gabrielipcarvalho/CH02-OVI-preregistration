"""The replication report (scripts/repl_report.py), tested before any replication data exists.

- Hand-built rows check each measure and reading.
- A synthetic ledger rehearses Goal B's whole path through the production code: freeze_repl, admission,
  the D0_REPL smoke run, the interleaved REPL schedule with scripted provider replies (MockTransport), then
  the report. Fictional papers and fictional text only; nothing dispatches to a provider.

The real parity check (the completed post-SLR comparison re-derived through this script equals the
committed reports) reads the private ledger, so it runs as `repl_report.py --parity`, not here.
"""

import base64
import json
import re
import sys
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import repl_report as rr  # noqa: E402
import repl_spend as rs  # noqa: E402

from pipeline.study import final_phase as fp  # noqa: E402
from pipeline.study.records import PILLARS, digest  # noqa: E402
from pipeline.study.transport import Dispatcher  # noqa: E402
from tests.test_postslr_run import fixture_set  # noqa: E402
from tests.test_v11_rehearsal import HOSTS, QUOTES, RATER, cell, reply  # noqa: E402

A, B, C = rr.REFINED, rr.PUBLISHED, rr.ABLATION
S0, S1, NA = ("scored", 0), ("scored", 1), ("applicability_uncertain", None)


def row(study, pillar, a, b, c=None, execution=1):
    c = c if c is not None else b
    out = {"execution": execution, "study": study, "pillar": pillar}
    for arm, trio in ((A, a), (B, b), (C, c)):
        out[arm], out[arm + "_trio"] = rr.classify(trio), trio
    return out


@pytest.mark.parametrize(("i90", "expected"), [
    ([-0.05, 0.08], "within the bound"), ([-0.1, 0.05], "not shown"), ([0.02, 0.12], "not shown"),
    ([0.01, 0.0999], "within the bound"), ([0.1, 0.2], "beyond the bound"),
    ([-0.3, -0.1], "beyond the bound"),
    ([0.09, 0.2], "not shown"), (None, None)])
def test_equivalence_needs_the_90_interval_strictly_inside_the_margin(i90, expected):
    assert rr.equivalence(i90) == expected


@pytest.mark.parametrize(("i95", "expected"), [
    ([0.01, 0.2], "transfers"), ([0.0, 0.1], "not detected"), ([-0.2, -0.01], "reverses"), (None, None)])
def test_three_way_reading_is_unchanged_from_v2(i95, expected):
    assert rr.reading(i95) == expected


def test_declared_constants():
    assert rr.SEED == fp.REPL_SEED == "ch2-repl-20261120"
    assert (rr.EQUIVALENCE_BOUND, rr.RESAMPLES, rr.PERMUTATIONS, rr.MIN_PAPERS) == (0.10, 10000, 20000, 10)
    assert rr.ARMS == ("REPL_V12", "REPL_V10", "REPL_V10_NOCONJ")


def test_ninety_percent_interval_comes_from_the_same_draws():
    pp = {1: (4, 2, 4), 2: (3, 3, 4), 3: (4, 1, 4), 4: (2, 2, 4)}
    got = rr.intervals(pp, "fixture-seed", 2000)
    assert got["interval_95"] == rr.interval(pp, "fixture-seed", 2000)
    lo95, hi95 = got["interval_95"]
    lo90, hi90 = got["interval_90"]
    assert lo95 <= lo90 <= hi90 <= hi95


def test_measures_on_hand_built_rows():
    rows = [row(1, "P1", [S0] * 3, [S0, S0, S1]),   # resolved in A only; all scored in both arms
            row(1, "P2", [NA] * 3, [NA] * 3),       # agreed not applicable in both
            row(1, "P3", [S1] * 3, [S1, S1, S0]),   # agreed above 0 in A; P3 left out of "without P3"
            row(1, "P4", [S0] * 3, [S0] * 3)]
    c = rr.comparison(rows, A, B, "s", hazard=set())
    assert (c["resolved"]["v1_2"], c["resolved"]["v1_0"]) == (4, 2)
    assert c["kind_of_agreement"][A] == {"agreed_0": 2, "agreed_above_0": 1, "agreed_not_applicable": 1}
    assert c["kind_of_agreement"][B] == {"agreed_0": 1, "agreed_above_0": 0, "agreed_not_applicable": 1}
    scores = c["score_agreement_all_scored_in_both_arms"]
    assert (scores["panels"], scores["v1_2"], scores["v1_0"]) == (3, 3, 1)
    no_p3 = c["score_agreement_all_scored_in_both_arms_without_p3"]
    assert (no_p3["panels"], no_p3["v1_2"], no_p3["v1_0"]) == (2, 2, 1)
    above = c["panels_with_a_score_above_0"]
    assert (above["v1_2"], above["v1_0"]) == (1, 2)
    failed = c["panels_with_a_failed_judgment"]
    assert (failed["v1_2"], failed["v1_0"]) == (0, 0)
    kinds = c["kind_of_agreement_paired"]
    assert {k: (v["v1_2"], v["v1_0"]) for k, v in kinds.items()} == {
        "agreed_0": (2, 1), "agreed_above_0": (1, 0), "agreed_not_applicable": (1, 1)}
    for measure in (scores, no_p3, c["scope_agreement_per_panel"]["paired"],
                    c["scope_agreement_per_paper_execution"]["paired"], *kinds.values()):
        assert "interval_95" in measure and "interval_90" in measure
    assert c["permutation"]["papers"] == 1 and c["bca"] is None  # one paper: no jackknife


def test_hazard_detectors_are_left_out_of_the_sensitivity_only():
    rows = [row(s, p, [S0] * 3, [S0, S0, S1]) for s in (1, 2) for p in PILLARS]
    c = rr.comparison(rows, A, B, "s", hazard={2})
    assert c["resolved"]["panels"] == 8 and c["without_hazard_detectors"]["resolved"]["panels"] == 4


def test_rows_use_paper_executions_complete_in_all_three_arms(monkeypatch):
    done = {"a1": {1, 2}, "a2": {1, 2}, "b1": {1, 2}, "b2": {1, 2}, "c1": {1}, "c2": {1, 2}}
    monkeypatch.setattr(rr, "complete", lambda store, run: done[run])
    monkeypatch.setattr(rr, "trios", lambda store, run, s: {p: [S0] * 3 for p in PILLARS})
    runs = {A: ["a1", "a2"], B: ["b1", "b2"], C: ["c1", "c2"]}
    rows, missing = rr.rows_all_arms(None, runs, [1, 2], rr.ARMS)
    assert sorted({(r["study"], r["execution"]) for r in rows}) == [(1, 1), (1, 2), (2, 2)]
    assert missing[f"{C}/1"] == [2]


def test_permutation_is_deterministic_and_counts_papers():
    pp = {1: (4, 2, 4), 2: (3, 3, 4), 3: (1, 4, 4)}
    a, b = rr.permutation(pp, "x", 500), rr.permutation(pp, "x", 500)
    assert a == b
    assert (a["papers_favouring_first_arm"], a["papers_favouring_second_arm"], a["ties"]) == (1, 1, 1)


# --- the synthetic ledger: Goal B's path through the production code ---------------------------------

TEXT = "[PDF PAGE 1]\n# A fictional paper\n\n" + " ".join(QUOTES.values()) + (
    " This fictional record describes a fictional pool camera and no real system." * 3
)
H5_MARK, V10_MARK = "Application procedure H5", "Semicolon-separated joint requirements are conjunctive."


def scripted_by_arm(calls):
    """V12 and the D0 smoke: all agree at 0. V10: r1 scores P1 at 1. NOCONJ: r1 P1 at 1 and r2 P2 at 1."""
    def handle(request):
        provider = HOSTS[request.url.host]
        body = json.loads(request.content)
        turns = body.get("input") if provider == "openai" else body["messages"]
        prompt = turns if isinstance(turns, str) else turns[0]["content"]
        assert "OWN PRECEDING" not in prompt  # R0 only: no discussion request is ever built
        rater = RATER[provider]
        arm = "V12" if H5_MARK in prompt else "V10" if V10_MARK in prompt else "NOCONJ"
        calls.append((arm, rater))
        ones = {"V12": set(), "V10": {("r1", "P1")}, "NOCONJ": {("r1", "P1"), ("r2", "P2")}}[arm]
        cells = [cell(p, 1 if (rater, p) in ones else 0) for p in PILLARS]
        return reply(provider, body["model"], json.dumps({"cells": cells}))

    return handle


def admitted_ledger(tmp_path, monkeypatch):
    """Goal B's steps 2-3 on a temporary ledger: two fictional papers, freeze-postslr, freeze-repl, admit."""
    private, papers = fixture_set(tmp_path, monkeypatch)
    for p in papers:
        (private / "markdown-v1" / f"study-{p['study_id']}" / "paper.md").write_text(TEXT)
        p["paper_txt_sha256"] = digest(TEXT.encode())
    (tmp_path / "INPUTS_POSTSLR.json").write_text(json.dumps({"papers": papers}))
    live = tmp_path / "live"
    monkeypatch.setattr(fp, "location", lambda: live)
    fp.freeze_postslr()  # the replication freezes beside the post-SLR test, as on the live ledger
    entry = fp.freeze_repl()
    fp.admit(billing_evidence="fixture balances")
    keys = tmp_path / "keys"
    keys.mkdir()
    for name in ("openai-api-key", "anthropic-api-key", "zai-coding-key"):
        (keys / name).write_text("FIXTURE-KEY")
    return live, papers, entry, keys, fp.FinalRecords(live / "programme.sqlite3")


def smoked(store, entry, keys, calls):
    dispatcher = Dispatcher(store, transport=httpx.MockTransport(scripted_by_arm(calls)), secret_dir=keys,
                            sleep=lambda t: None)
    assert fp.run_condition(fp.REPL_D0, dispatcher=dispatcher)["statuses"] == ["succeeded"] * 3
    fp.admit(smoke_run=entry["smoke_runs"][0], billing_evidence="fixture balances")
    return dispatcher


def test_goal_b_path_on_a_synthetic_ledger(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    dispatcher = Dispatcher(store, transport=httpx.MockTransport(scripted_by_arm(calls)), secret_dir=keys)

    smoke = fp.run_condition(fp.REPL_D0, dispatcher=dispatcher)
    assert smoke["statuses"] == ["succeeded"] * 3
    (smoke_run,) = entry["smoke_runs"]
    assert fp.admit(smoke_run=smoke_run, billing_evidence="fixture balances")["smoke_run"] == smoke_run
    result = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=dispatcher)
    assert result["dispositioned"] == 3 * 2 * len(papers) * 3
    assert set(result["statuses"]) == {"succeeded"}
    assert {arm for arm, _ in calls} == {"V12", "V10", "NOCONJ"}

    spent = rs.from_ledger(live / "programme.sqlite3", live / "FREEZE.json")["by_provider"]
    assert {p: v["requests"] for p, v in spent.items()} == {p: 13 for p in rs.CAPS}  # 12 + 1 smoke each
    assert all(0 < v["charged"] < v["cap"] for v in spent.values())
    with pytest.raises(SystemExit, match="live"):
        rs.from_ledger(rs.LIVE, live / "FREEZE.json")

    monkeypatch.setattr(rr, "MIN_PAPERS", 1)  # two fictional papers; the real rule needs 10
    out = rr.report(live / "programme.sqlite3")
    assert out["paper_executions_in_comparison"] == 4 and out["papers_compared"] == 2
    main, abl = out["confirmatory"], out["exploratory_ablation"]
    assert (main["resolved"]["panels"], main["resolved"]["v1_2"], main["resolved"]["v1_0"]) == (16, 16, 12)
    assert main["resolved"]["difference"] == 0.25 and out["reading"] == "transfers"
    assert (abl["resolved"]["v1_2"], abl["resolved"]["v1_0"], abl["resolved"]["difference"]) == (8, 12, -0.25)
    assert main["kind_of_agreement"][A]["agreed_0"] == 16
    assert main["by_pillar_resolved"]["P1"]["v1_0"] == 0 and abl["by_pillar_resolved"]["P2"]["v1_2"] == 0
    assert main["score_agreement_all_scored_in_both_arms_without_p3"]["panels"] == 12
    assert (out["ablation_paper_executions"], out["ablation_papers_compared"]) == (4, 2)
    assert main["panels_with_a_failed_judgment"]["v1_2"] == 0
    tex = rr.macros(out)
    assert "\\newcommand{\\replResolvedDiff}{+25.0}" in tex
    assert "\\newcommand{\\replAblResolvedDiff}{$-$25.0}" in tex
    assert "\\newcommand{\\replReading}{transfers}" in tex
    rules = (Path(rr.ROOT) / "docs/rerun-2026-11/REPORTING_RULES_REPLICATION.md").read_text()
    named = set(re.findall(r"\\(repl[A-Za-z]+)", rules))
    assert len(named) > 15 and named <= set(re.findall(r"\\newcommand\{\\(repl[A-Za-z]+)\}", tex))
    md = rr.markdown(out)
    assert "Three-way reading: transfers" in md and "| Resolved, R0 | 16 | 16 / 12 | +25.0 |" in md

    monkeypatch.setattr(rr, "MIN_PAPERS", 10)
    descriptive = rr.report(live / "programme.sqlite3")
    assert descriptive["reading"] is None and descriptive["equivalence"] is None
    assert "\\newcommand{\\replReading}{descriptive only}" in rr.macros(descriptive)


def test_spend_monitor_counts_statuses_from_the_log(tmp_path):
    log = tmp_path / "repl-r0.log"
    lines = [{"run_id": "run-a", "status": "succeeded"}, {"run_id": "run-b", "status": "parked"},
             {"run_id": "run-a", "status": "succeeded"}]
    log.write_text("\n".join(json.dumps(x) for x in lines) + "\nTraceback (not JSON)\n")
    got = rs.from_log(log)
    assert got["dispositioned"] == 3 and got["of"] == 1026
    assert got["statuses"] == {"succeeded": 2, "parked": 1} and "by_run" not in got  # totals only


def test_caps_match_the_cost_table():
    table = (Path(rr.ROOT) / "docs/rerun-2026-11/04_PROGRESS.md").read_text()
    for provider, cap in rs.CAPS.items():
        assert f"| {provider} |" in table and f"| {cap:.2f} |" in table


def outage_then(calls, failing_host, status=520, body=None):
    """The failing host answers every attempt with `status`; the others reply as scripted_by_arm."""
    ok = scripted_by_arm(calls)

    def handle(request):
        if request.url.host == failing_host:
            calls.append(("failed", request.url.host))
            if body is not None:
                return httpx.Response(status, json=body)
            return httpx.Response(status, text=f"<!DOCTYPE html><title>{status}</title>")
        return ok(request)

    return handle


def test_an_outage_that_outlasts_every_retry_stops_the_run_with_its_own_cause(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    down = Dispatcher(store, transport=httpx.MockTransport(outage_then(calls, "api.openai.com")),
                      secret_dir=keys, sleep=lambda t: None)
    with pytest.raises(rr.fp.StudyError, match=r"cause: provider outage; HTTP 520"):
        fp.run_condition(fp.REPL_SCHEDULE, dispatcher=down)
    assert calls.count(("failed", "api.openai.com")) == 12  # 3 transport attempts × (1 + 3 re-requests)
    # The pre-registered single resume: relaunch unchanged; the parked request is skipped, never re-sent.
    up = Dispatcher(store, transport=httpx.MockTransport(scripted_by_arm(calls)), secret_dir=keys,
                    sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=up)
    assert calls.count(("failed", "api.openai.com")) == 12
    assert out["dispositioned"] == 36 and out["statuses"].count("parked") == 1


def test_a_quota_error_is_a_credit_stop_not_an_outage(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    quota = {"error": {"type": "insufficient_quota", "code": "insufficient_quota"}}
    handler = outage_then(calls, "api.openai.com", status=429, body=quota)
    broke = Dispatcher(store, transport=httpx.MockTransport(handler), secret_dir=keys, sleep=lambda t: None)
    expected = (r"cause: credit, billing or configuration; HTTP 429; "
                r"provider error: insufficient_quota/insufficient_quota; reason: HTTP 429\)")
    with pytest.raises(rr.fp.StudyError, match=expected):
        fp.run_condition(fp.REPL_SCHEDULE, dispatcher=broke)
    assert calls.count(("failed", "api.openai.com")) == 1  # never retried


def test_a_request_in_flight_at_an_interruption_is_parked_not_re_sent(tmp_path, monkeypatch):
    """A kill or power loss mid-request leaves a reservation with no completion. On relaunch the runner
    records that request as a failure ("Unknown interrupted provider attempt"), never re-sends it, and
    carries on with the rest of the schedule."""
    from pipeline.study.scoring import build_prompt, payload_for
    from pipeline.study.transport import reservation

    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    first = entry["schedule"][0]
    m = store.manifest(first["run_id"])
    prompt, context = build_prompt(store, first["run_id"], first["study"], list(PILLARS))
    payload = payload_for(m["models"][first["rater"]], prompt)
    q = store.request(first["run_id"], first["study"], first["rater"], 0, "rating", 0, payload, context)
    store.reserve(q, 0, 0, reservation(m["models"][first["rater"]]["provider"], payload), payload)
    before = len(calls)
    relaunch = Dispatcher(store, transport=httpx.MockTransport(scripted_by_arm(calls)), secret_dir=keys,
                          sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=relaunch)
    assert out["dispositioned"] == 36 and out["statuses"][0] == "parked"
    assert out["statuses"][1:] == ["succeeded"] * 35 and len(calls) - before == 35
    assert "Unknown interrupted" in json.dumps(store.export(first["run_id"])["dispositions"])


def test_the_report_refuses_the_live_ledger():
    with pytest.raises(SystemExit, match="live"):
        rr.report(rr.LIVE)
    with pytest.raises(SystemExit, match="live"):
        rr.parity(rr.LIVE)


def test_a_network_loss_that_outlasts_every_retry_stops_the_run_and_may_be_resumed(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)

    def offline(request):
        if request.url.host == "api.anthropic.com":
            calls.append(("failed", request.url.host))
            raise httpx.ConnectError("fixture: network down", request=request)
        return ok(request)

    down = Dispatcher(store, transport=httpx.MockTransport(offline), secret_dir=keys, sleep=lambda t: None)
    expected = r"cause: network or transport; HTTP None; reason: ConnectError\)"
    with pytest.raises(rr.fp.StudyError, match=expected):
        fp.run_condition(fp.REPL_SCHEDULE, dispatcher=down)
    assert calls.count(("failed", "api.anthropic.com")) == 12
    up = Dispatcher(store, transport=httpx.MockTransport(ok), secret_dir=keys, sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=up)
    assert out["dispositioned"] == 36 and out["statuses"].count("parked") == 1


def test_a_missing_credential_is_a_runner_refusal(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    (keys / "zai-coding-key").unlink()
    runner = Dispatcher(store, transport=httpx.MockTransport(scripted_by_arm(calls)), secret_dir=keys,
                        sleep=lambda t: None)
    expected = r"cause: runner refusal; HTTP None; reason: Provider credential missing"
    with pytest.raises(rr.fp.StudyError, match=expected):
        fp.run_condition(fp.REPL_SCHEDULE, dispatcher=runner)


def test_an_unreadable_reply_is_a_recorded_outcome_not_a_stop(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)

    def garbled(request):
        if request.url.host == "api.z.ai":
            body = json.loads(request.content)
            return reply("zai", body["model"], "this is not JSON")
        return ok(request)

    runner = Dispatcher(store, transport=httpx.MockTransport(garbled), secret_dir=keys, sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=runner)
    assert out["dispositioned"] == 36 and out["statuses"].count("parked") == 12  # every GLM request


def test_an_interruption_during_a_retry_is_parked_and_does_not_stop(tmp_path, monkeypatch):
    """Killed while transport attempt 1 of a 520 was in flight: the earlier 520 is recorded, the stray
    attempt has no reply. The relaunch parks the request as interrupted and carries on (no outage stop)."""
    from pipeline.study.scoring import build_prompt, payload_for
    from pipeline.study.transport import reservation

    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    first = entry["schedule"][0]
    m = store.manifest(first["run_id"])
    provider = m["models"][first["rater"]]["provider"]
    prompt, context = build_prompt(store, first["run_id"], first["study"], list(PILLARS))
    payload = payload_for(m["models"][first["rater"]], prompt)
    q = store.request(first["run_id"], first["study"], first["rater"], 0, "rating", 0, payload, context)
    attempt = store.reserve(q, 0, 0, reservation(provider, payload), payload)
    failed = {"status": "failed", "http_status": 520, "retryable": True, "error": "HTTP 520"}
    store.complete(attempt, 0.0, failed)
    store.reserve(q, 0, 1, reservation(provider, payload), payload)  # in flight when the process died
    relaunch = Dispatcher(store, transport=httpx.MockTransport(scripted_by_arm(calls)), secret_dir=keys,
                          sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=relaunch)
    assert out["dispositioned"] == 36 and out["statuses"][0] == "parked"
    assert "Unknown interrupted" in json.dumps(store.export(first["run_id"])["dispositions"])


INCOMPLETE = "Incomplete observable output; retained, never scored zero"
ZAI_BROKE = base64.b64encode(json.dumps(
    {"error": {"code": "1113", "message": "Fixture: insufficient account balance"}}).encode()).decode()


def test_a_numeric_zai_balance_code_is_a_credit_stop():
    """Final code review (19 Nov): code 1113 as a number with a non-English message was classed as an outage,
    which the chain would have resumed."""
    body = base64.b64encode(json.dumps({"error": {"code": 1113, "message": "账户已欠费"}}).encode()).decode()
    done = [{"http_status": 429, "retryable": True, "error": "HTTP 429", "observable_response_base64": body}]
    result = {"status": "parked", "disposition": {"status": "process_failure", "reason": "HTTP 429"}}
    assert fp.stop_cause(result, done).startswith("(cause: credit, billing or configuration;")


@pytest.mark.parametrize(("result", "done", "expected"), [
    ({"status": "succeeded"}, [{"http_status": 200}], None),
    ({"status": "parked", "disposition": {"status": "format_failure", "reason": "x"}},
     [{"http_status": 520, "retryable": True}], None),
    ({"status": "parked", "disposition": {"status": "process_failure",
                                          "reason": INCOMPLETE}},
     [{"http_status": 200, "error": INCOMPLETE}], None),
    ({"status": "parked", "disposition": {"status": "process_failure",
                                          "reason": "Unusable page-aware common text; no source"}}, [], None),
    ({"status": "parked", "disposition": {"status": "process_failure", "reason": "HTTP 401"}},
     [{"http_status": 401, "retryable": False, "error": "HTTP 401"}], "credit, billing or configuration"),
    ({"status": "parked", "disposition": {"status": "process_failure", "reason": "HTTP 503"}},
     [{"http_status": 503, "retryable": True, "error": "HTTP 503"}], "provider outage"),
    ({"status": "parked", "disposition": {"status": "process_failure", "reason": "HTTP 429"}},
     [{"http_status": 429, "retryable": True, "error": "HTTP 429", "observable_response_base64": ZAI_BROKE}],
     "credit, billing or configuration"),
    ({"status": "parked", "disposition": {"status": "process_failure",
                                          "reason": "Frozen execution implementation drifted"}},
     [{"http_status": 503, "retryable": True, "error": "HTTP 503"}], "runner refusal"),
    *(({"status": "parked", "disposition": {"status": "process_failure", "reason": e}},
       [{"http_status": 200, "error": e}], "runner refusal")
      for e in ("Usage exceeded conservative reservation; programme halted", "Secret echo redacted; response "
                "rejected", "Returned model identity missing/invalid", "StudyError", "JSONDecodeError")),
    ({"status": "parked", "disposition": {"status": "resource_stop", "reason": "x"}}, [], "runner refusal"),
    ({"status": "parked", "disposition": {"status": "process_failure", "reason": "TypeError"}},
     [{"http_status": None, "retryable": False, "error": "TypeError"}], "runner refusal"),
    ({"status": "parked", "disposition": {"status": "model_change", "reason": "x"}},
     [{"http_status": 200, "model_change": True}], "model identity change"),
])
def test_stop_cause_decides_every_failure_path(result, done, expected):
    cause = fp.stop_cause(result, done)
    assert (cause is None) if expected is None else cause.startswith(f"(cause: {expected};")


def test_a_reply_with_non_object_cells_is_parked_not_a_crash(tmp_path, monkeypatch):
    """Final code review (18 Nov): {"cells": [null, ...]} raised AttributeError and crashed the runner."""
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)

    def nulls(request):
        if request.url.host == "api.z.ai":
            body = json.loads(request.content)
            return reply("zai", body["model"], json.dumps({"cells": [None, None, None, None]}))
        return ok(request)

    runner = Dispatcher(store, transport=httpx.MockTransport(nulls), secret_dir=keys, sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=runner)
    assert out["dispositioned"] == 36 and out["statuses"].count("parked") == 12


class Killed(BaseException):
    """A SIGKILL or power loss mid-request: nothing after the reservation is written."""


def test_an_interruption_during_format_recovery_is_parked_not_re_requested(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)
    target = next(r for r in entry["schedule"] if r["rater"] == "r2")

    def pillar_map(request):  # GLM answers with a P1..P4 map: readable science, wrong format, so recovery
        if request.url.host == "api.z.ai":
            calls.append(("glm", len(calls)))
            body = json.loads(request.content)
            return reply("zai", body["model"], json.dumps({p: cell(p) for p in PILLARS}))
        return ok(request)

    real = Dispatcher._attempt

    def dies_in_recovery(self, request_id, provider, model, payload, stage, transport_n):
        if stage == 1:
            self.store.reserve(request_id, stage, transport_n, 0.01, payload)
            raise Killed()
        return real(self, request_id, provider, model, payload, stage, transport_n)

    monkeypatch.setattr(Dispatcher, "_attempt", dies_in_recovery)
    first = Dispatcher(store, transport=httpx.MockTransport(pillar_map), secret_dir=keys,
                       sleep=lambda t: None)
    with pytest.raises(Killed):
        fp.run_condition(fp.REPL_SCHEDULE, dispatcher=first)
    monkeypatch.setattr(Dispatcher, "_attempt", real)
    before = len(calls)
    relaunch = Dispatcher(store, transport=httpx.MockTransport(ok), secret_dir=keys, sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=relaunch)
    assert out["dispositioned"] == 36 and "parked" in out["statuses"]
    exported = store.export(target["run_id"])
    assert "Unknown interrupted" in json.dumps(exported["dispositions"])
    glm_calls = sum(1 for _, rater in calls[before:] if rater == "r2")
    assert glm_calls == 3 * 2 * len(papers) - 1  # every other GLM request once; the killed one never again


@pytest.mark.parametrize("bad", [["P1"], {"code": "P1"}])
def test_a_cell_whose_pillar_is_not_a_string_is_a_recorded_outcome(tmp_path, monkeypatch, bad):
    """Final code review (18 Nov): the GLM repair step raised TypeError on "pillar": ["P1"], a final stop."""
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)

    def odd(request):
        if request.url.host == "api.z.ai":
            body = json.loads(request.content)
            cells = [cell(p) for p in PILLARS[:3]] + [{**cell("P4"), "pillar": bad}]
            return reply("zai", body["model"], json.dumps({"cells": cells}))
        return ok(request)

    runner = Dispatcher(store, transport=httpx.MockTransport(odd), secret_dir=keys, sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=runner)
    assert out["dispositioned"] == 36 and out["statuses"].count("succeeded") == 24


def test_a_malformed_provider_envelope_is_a_runner_refusal_with_a_cause_line(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)

    def listed(request):
        if request.url.host == "api.z.ai":
            return httpx.Response(200, json=[1, 2, 3])
        return ok(request)

    runner = Dispatcher(store, transport=httpx.MockTransport(listed), secret_dir=keys, sleep=lambda t: None)
    with pytest.raises(rr.fp.StudyError, match=r"cause: runner refusal; HTTP 200; reason: AttributeError"):
        fp.run_condition(fp.REPL_SCHEDULE, dispatcher=runner)


def test_an_interruption_in_recovery_after_a_partly_valid_reply_is_not_re_sent(tmp_path, monkeypatch):
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)

    def partly(request):  # three valid cells and one with a format failure: recovery or re-request follows
        if request.url.host == "api.z.ai":
            body = json.loads(request.content)
            cells = [cell(p) for p in PILLARS[:3]] + [{**cell("P4"), "confidence": "certainly"}]
            return reply("zai", body["model"], json.dumps({"cells": cells}))
        return ok(request)

    real = Dispatcher._attempt

    def dies_after_first_stage(self, request_id, provider, model, payload, stage, transport_n):
        if stage >= 1:
            self.store.reserve(request_id, stage, transport_n, 0.01, payload)
            raise Killed()
        return real(self, request_id, provider, model, payload, stage, transport_n)

    monkeypatch.setattr(Dispatcher, "_attempt", dies_after_first_stage)
    first = Dispatcher(store, transport=httpx.MockTransport(partly), secret_dir=keys, sleep=lambda t: None)
    with pytest.raises(Killed):
        fp.run_condition(fp.REPL_SCHEDULE, dispatcher=first)
    monkeypatch.setattr(Dispatcher, "_attempt", real)
    before = len(calls)
    relaunch = Dispatcher(store, transport=httpx.MockTransport(ok), secret_dir=keys, sleep=lambda t: None)
    out = fp.run_condition(fp.REPL_SCHEDULE, dispatcher=relaunch)
    assert out["dispositioned"] == 36
    assert sum(1 for _, rater in calls[before:] if rater == "r2") == 3 * 2 * len(papers) - 1


def run_with_glm(tmp_path, monkeypatch, glm):
    """The REPL schedule on a synthetic ledger, with GLM's replies produced by `glm(request, body)`."""
    live, papers, entry, keys, store = admitted_ledger(tmp_path, monkeypatch)
    calls = []
    smoked(store, entry, keys, calls)
    ok = scripted_by_arm(calls)

    def handle(request):
        if request.url.host == "api.z.ai":
            return glm(request, json.loads(request.content))
        return ok(request)

    runner = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys, sleep=lambda t: None)
    return store, fp.run_condition(fp.REPL_SCHEDULE, dispatcher=runner)


@pytest.mark.parametrize("defence", ["a string", ["a", "list"], 7])
def test_a_non_object_defence_through_format_recovery_is_not_a_crash(tmp_path, monkeypatch, defence):
    """Third code review (18 Nov, fuzzing): verify_format_equivalence called .get on a string defence."""
    def glm(request, body):
        if body["messages"][0]["content"].startswith("FORMAT-ONLY"):
            return reply("zai", body["model"], json.dumps({"cells": [cell(p) for p in PILLARS]}))
        cells = [{**cell(p), "anonymous_defence": defence} for p in PILLARS]
        return reply("zai", body["model"], json.dumps({"cells": cells}))

    _, out = run_with_glm(tmp_path, monkeypatch, glm)
    assert out["dispositioned"] == 36


@pytest.mark.parametrize("text", ['```json{"cells": []}```', "``````"])
def test_a_one_line_fenced_reply_is_not_a_crash(tmp_path, monkeypatch, text):
    _, out = run_with_glm(tmp_path, monkeypatch, lambda request, body: reply("zai", body["model"], text))
    assert out["dispositioned"] == 36 and out["statuses"].count("parked") == 12


def test_a_lone_surrogate_in_a_reply_is_stored_and_the_run_carries_on(tmp_path, monkeypatch):
    def glm(request, body):
        cells = [{**cell(p), "reason": "Fixture reason \ud800 with a lone surrogate."} for p in PILLARS]
        return reply("zai", body["model"], json.dumps({"cells": cells}))

    store, out = run_with_glm(tmp_path, monkeypatch, glm)
    assert out["dispositioned"] == 36
    with store.db() as db:
        orphans = db.execute("SELECT count(*) FROM attempts a LEFT JOIN completions c ON c.attempt_id=a.id "
                             "WHERE c.attempt_id IS NULL").fetchone()[0]
    assert orphans == 0


def test_a_non_finite_number_in_the_envelope_is_recorded_not_lost(tmp_path, monkeypatch):
    """NaN in the usage counters is refused as invalid usage before storage (a runner refusal); NaN in any
    stored field is kept as "Unstorable provider reply" with its body, never left as a reservation without a
    reply."""
    from pipeline.study.transport import storable

    def glm(request, body):
        nan = '{"id":"f","model":"glm-5.3","usage":{"prompt_tokens":NaN,"completion_tokens":1},' \
              '"choices":[{"finish_reason":"stop","message":{"content":"{}"}}]}'
        return httpx.Response(200, content=nan.encode(), headers={"content-type": "application/json"})

    with pytest.raises(rr.fp.StudyError, match=r"cause: runner refusal; HTTP 200; reason: StudyError"):
        run_with_glm(tmp_path, monkeypatch, glm)
    kept = storable({"status": "succeeded", "http_status": 200, "observable_response_base64": "e30=",
                     "text": "x", "input_tokens": float("nan")}, "SECRET")
    assert kept["status"] == "failed" and kept["error"] == "Unstorable provider reply"
    assert kept["observable_response_base64"] == "e30=" and "text" not in kept


def test_panels_with_a_failed_judgment_are_counted_per_arm():
    """Failures count as unresolved in the primary, so a failure-rate difference is reported beside it."""
    rows = [row(1, "P1", [S0, None, S0], [S0] * 3), row(1, "P2", [S0] * 3, [None, None, S0]),
            row(1, "P3", [None] * 3, [S0] * 3), row(1, "P4", [S0] * 3, [S0] * 3)]
    failed = rr.comparison(rows, A, B, "s", hazard=set())["panels_with_a_failed_judgment"]
    assert (failed["panels"], failed["v1_2"], failed["v1_0"]) == (4, 2, 1)
