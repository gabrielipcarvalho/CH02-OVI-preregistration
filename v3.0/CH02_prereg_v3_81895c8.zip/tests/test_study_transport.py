"""Network fixtures prove bounded retries, preserved content and spending without live model calls."""

import copy
import json

import httpx
import pytest

from pipeline.study.records import StudyError
from pipeline.study.scoring import build_prompt, payload_for
from pipeline.study.transport import Dispatcher, reservation
from tests.test_study_scoring import cell, fixture_run, response


def prepared(tmp_path):
    store, run, models, _ = fixture_run(tmp_path)
    store.programme({"cap_usd": 100, "final_reserve_usd": 25, "smoke_cap_usd": 3})
    prompt, context = build_prompt(store, run, 0, ["P1", "P2", "P3", "P4"])
    q = store.request(run, 0, "r1", 0, "rating", 0, payload_for(models["r1"], prompt), context)
    secrets = tmp_path / "keys"
    secrets.mkdir()
    (secrets / "openai-api-key").write_text("SECRET-FIXTURE-KEY")
    return store, run, q, secrets


def success(text=None, model="fixture"):
    return httpx.Response(
        200,
        json={
            "id": "fictional-response",
            "model": model,
            "status": "completed",
            "usage": {"input_tokens": 1000, "output_tokens": 100},
            "output": [
                {
                    "type": "message",
                    "content": [
                        {
                            "type": "output_text",
                            "text": text or response([cell(p) for p in ("P1", "P2", "P3", "P4")]),
                        }
                    ],
                }
            ],
        },
    )


def test_success_is_idempotent_and_synthetic_provenance_survives_export(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []

    def handle(req):
        calls.append(req.content)
        assert req.headers["Authorization"] == "Bearer SECRET-FIXTURE-KEY"
        return success()

    runner = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys, sleep=lambda t: None)
    assert runner.execute(q)["status"] == "succeeded"
    assert runner.execute(q)["reused"]
    assert len(calls) == 1
    exported = store.export(run)
    assert len(exported["judgments"]) == 4
    assert all(
        c["provenance"]["rater"] == "agent:fixture" and not c["provenance"]["human_confirmed"]
        for c in exported["judgments"]
    )
    assert "SECRET-FIXTURE-KEY" not in json.dumps(exported)


def test_transient_attempts_are_bounded_and_requests_identical(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []

    def handle(req):
        calls.append(req.content)
        return httpx.Response(503, json={"error": "fictional"})

    runner = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys, sleep=lambda t: None)
    assert runner.execute(q)["status"] == "parked"
    assert len(calls) == 3 and len(set(calls)) == 1
    assert len(store.export(run)["attempts"]) == 3
    assert store.usage()["spent_or_reserved_usd"] > 0
    assert runner.execute(q)["status"] == "parked" and len(calls) == 3


def test_overloaded_provider_is_retried_after_longer_waits(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    replies, waits = [529, 529, 200], []

    def handle(req):
        status = replies.pop(0)
        overloaded = httpx.Response(status, json={"error": {"type": "overloaded_error"}})
        return success() if status == 200 else overloaded

    runner = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys, sleep=waits.append)
    assert runner.execute(q)["status"] == "succeeded"
    assert waits == [60, 120] and len(store.export(run)["attempts"]) == 3


@pytest.mark.parametrize("status", [501, 520, 522, 524, 599])
def test_every_5xx_is_retried_as_declared_in_dec_0011(tmp_path, status):
    """An OpenAI Cloudflare 520 (origin error page, no JSON body) stopped the post-SLR run on 12 Nov."""
    store, run, q, keys = prepared(tmp_path)
    replies, waits = [status, status, 200], []

    def handle(req):
        code = replies.pop(0)
        page = httpx.Response(code, text="<!DOCTYPE html><title>api.openai.com | 520</title>")
        return success() if code == 200 else page

    runner = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys, sleep=waits.append)
    assert runner.execute(q)["status"] == "succeeded"
    assert waits == [1, 2] and len(store.export(run)["attempts"]) == 3


@pytest.mark.parametrize("status", [500, 503, 520])
@pytest.mark.parametrize("code", ["insufficient_quota", "credit_balance_exhausted"])
def test_a_5xx_carrying_a_quota_or_billing_error_is_never_retried(status, code):
    from pipeline.study.transport import transient_http_failure

    body = json.dumps({"error": {"type": "insufficient_quota", "code": code}}).encode()
    assert not transient_http_failure(status, body)
    assert transient_http_failure(status, b"<!DOCTYPE html>")


@pytest.mark.parametrize("status", [400, 401, 403, 404])
def test_nontransient_failure_never_retried_or_converted_to_zero(tmp_path, status):
    store, run, q, keys = prepared(tmp_path)
    calls = []

    def handle(req):
        calls.append(1)
        return httpx.Response(status, json={"error": "SECRET-FIXTURE-KEY"})

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "parked" and len(calls) == 1
    output = store.export(run)
    assert not output["judgments"] and "SECRET-FIXTURE-KEY" not in json.dumps(output)


def test_one_format_recovery_preserves_original_and_scientific_fields(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []
    original = [cell(p) for p in ("P1", "P2", "P3", "P4")]
    original[0]["pillar"] = "Fixture pillar 1"
    original[0]["alternative"] = None

    def handle(req):
        calls.append(req.content)
        return success(response(original) if len(calls) == 1 else None)

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "succeeded" and len(calls) == 2
    output = store.export(run)
    assert "Fixture pillar 1" in output["completions"][0]["result"]["text"]
    assert output["events"][0]["payload"]["scientific_equivalence_verified"]


def test_format_recovery_that_changes_score_is_rejected_without_third_call(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []
    original = [cell(p) for p in ("P1", "P2", "P3", "P4")]
    original[0]["alternative"] = None
    revised = [cell(p) for p in ("P1", "P2", "P3", "P4")]
    revised[0]["score"] = 2

    def handle(req):
        calls.append(1)
        return success(response(original if len(calls) == 1 else revised))

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "partial" and len(calls) == 2
    assert {c["pillar"] for c in store.export(run)["judgments"]} == {"P2", "P3", "P4"}
    assert all(c["payload"]["score"] == 1 for c in store.export(run)["judgments"])
    assert "changed scientific field" in result["disposition"]["reason"]


def test_unrecognisable_truncated_output_is_parked_without_rescoring(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []

    def handle(req):
        calls.append(1)
        return success('{"cells":[incomplete')

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "parked" and len(calls) == 1


def test_model_change_is_reported_and_never_substituted(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    result = Dispatcher(
        store, transport=httpx.MockTransport(lambda req: success(model="different-model")), secret_dir=keys
    ).execute(q)
    assert result["disposition"]["status"] == "model_change"
    assert not store.export(run)["judgments"]


def test_budget_and_offline_stops_happen_before_network(tmp_path, monkeypatch):
    store, run, q, keys = prepared(tmp_path)
    store.import_spend("exhausted", 3, "synthetic_fixture", {"fixture": True})

    def forbidden(req):
        raise AssertionError("Network must not be reached")

    runner = Dispatcher(store, transport=httpx.MockTransport(forbidden), secret_dir=keys)
    assert runner.execute(q)["disposition"]["status"] == "resource_stop"
    assert not store.export(run)["attempts"]
    monkeypatch.setenv("OVI_PANEL_OFFLINE", "1")
    with pytest.raises(StudyError, match="Offline"):
        runner._attempt(
            q, "openai", "fixture", {"model": "fixture", "input": "fixture", "max_output_tokens": 6000}, 0, 0
        )


def test_unknown_interrupted_attempt_does_not_redispatch(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    payload = store.export(run)["requests"][0]["payload"]
    store.reserve(q, 0, 0, reservation("openai", payload), payload)

    def forbidden(req):
        raise AssertionError("Unknown attempt must not be repeated")

    result = Dispatcher(store, transport=httpx.MockTransport(forbidden), secret_dir=keys).execute(q)
    assert result["status"] == "parked" and "Unknown interrupted" in result["disposition"]["reason"]
    assert store.usage()["spent_or_reserved_usd"] > 0


def test_content_retained_failures_do_not_generate_desired_answer_retries(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []
    cells = [cell(p) for p in ("P1", "P2", "P3", "P4")]
    cells[0]["quote"] = "unsupported fabricated quote"
    cells[0]["anonymous_defence"]["quote"] = cells[0]["quote"]

    def handle(req):
        calls.append(1)
        return success(response(cells))

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "partial" and len(calls) == 1
    assert {c["pillar"] for c in store.export(run)["judgments"]} == {"P2", "P3", "P4"}
    assert result["failed_pillars"] == ["P1"]
    assert result["disposition"]["status"] == "evidence_failure"
    assert "unsupported fabricated quote" in store.export(run)["completions"][0]["result"]["text"]


def test_envelope_preserves_long_inputs_and_reserves_long_context_premium():
    request = {"model": "fixture", "input": "x" * 290000, "max_output_tokens": 6000}
    amount = reservation("openai", request)
    assert amount > 6  # conservative 2x input tier applied, not token-estimate discounts
    request["input"] = "x" * 320001
    with pytest.raises(StudyError):
        reservation("openai", request)


def test_competing_dispatcher_does_not_mark_live_request_as_orphan(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event

    store, run, q, keys = prepared(tmp_path)
    started, release = Event(), Event()

    def handle(req):
        started.set()
        assert release.wait(timeout=5)
        return success()

    runner = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys)
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(runner.execute, q)
        assert started.wait(timeout=5)
        try:
            with pytest.raises(StudyError, match="already active"):
                runner.execute(q)
        finally:
            release.set()
        assert future.result()["status"] == "succeeded"
    assert not store.export(run)["dispositions"]
    assert len(store.export(run)["attempts"]) == 1


def test_oversized_complete_input_is_dispositioned_without_truncation_or_network(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    large = {"model": "fixture", "input": "full-paper-marker " + ("x" * 320001), "max_output_tokens": 6000}
    q2 = store.request(run, 0, "r2", 0, "rating", 0, large, {"pending": ["P1", "P2", "P3", "P4"]})

    def forbidden(req):
        raise AssertionError("Oversized input must not reach provider")

    result = Dispatcher(store, transport=httpx.MockTransport(forbidden), secret_dir=keys).execute(q2)
    assert result["status"] == "parked" and not store.export(run)["attempts"]
    original = next(r for r in store.export(run)["requests"] if r["id"] == q2)
    assert original["payload"]["input"] == large["input"]
    assert "envelope" in result["disposition"]["reason"]


def test_boolean_score_is_not_reinterpreted_by_format_recovery(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []
    original = [cell(p) for p in ("P1", "P2", "P3", "P4")]
    original[0]["score"] = True

    def handle(req):
        calls.append(1)
        return success(response(original))

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "partial" and len(calls) == 1
    assert {c["pillar"] for c in store.export(run)["judgments"]} == {"P2", "P3", "P4"}


def test_secret_echo_in_response_metadata_is_redacted(tmp_path):
    store, run, q, keys = prepared(tmp_path)

    def handle(req):
        reply = success()
        data = reply.json()
        data["id"] = "SECRET-FIXTURE-KEY"
        return httpx.Response(200, json=data)

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "succeeded"
    assert "SECRET-FIXTURE-KEY" not in json.dumps(store.export(run))


def test_unsafe_defence_parks_release_without_discarding_valid_initial_scores(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []
    cells = [cell(p) for p in ("P1", "P2", "P3", "P4")]
    cells[0]["anonymous_defence"]["reason"] = "I choose level 2"

    def handle(req):
        calls.append(1)
        return success(response(cells))

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys).execute(q)
    assert result["status"] == "succeeded" and result["peer_release_withheld"]
    assert len(calls) == 2 and len(store.export(run)["judgments"]) == 4
    assert store.export(run)["judgments"][0]["payload"]["defence_check"]["status"] == "withheld"
    assert not store.export(run)["dispositions"]


def test_format_recovery_cannot_rewrite_scientific_defence_body():
    from pipeline.study.transport import verify_format_equivalence

    raw = cell()
    raw["anonymous_defence"]["reason"] = "The river water level 2 is the reported observation."
    repaired = copy.deepcopy(raw)
    repaired["anonymous_defence"]["reason"] = "The river water is the reported observation."
    rubric = {"pillars": {"P1": {"title": "Fixture"}}}
    with pytest.raises(StudyError, match="scientific body"):
        verify_format_equivalence(response([raw]), [repaired], rubric)


@pytest.mark.parametrize("status", [200, 400])
def test_full_observable_body_is_preserved_even_for_errors_without_encoded_secret_leaks(tmp_path, status):
    import base64

    from pipeline.study.records import digest

    store, run, q, keys = prepared(tmp_path)
    data = success().json() if status == 200 else {"error": {"type": "fixture_invalid_request"}}
    data["diagnostic"] = "prefix SECRET-FIXTURE-KEY suffix"
    reply = httpx.Response(status, json=data)
    calls = []

    def handle(request):
        calls.append(request.content)
        return reply

    dispatcher = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys)
    dispatcher.execute(q)
    exported = store.export(run)
    result = exported["completions"][0]["result"]
    body = base64.b64decode(result["observable_response_base64"])
    assert body == reply.content.replace(b"SECRET-FIXTURE-KEY", b"[REDACTED]")
    assert b"SECRET-FIXTURE-KEY" not in body
    assert result["response_secret_redacted"]
    assert result["observable_response_sha256"] == digest(body)
    assert result["response_sha256"] == digest(reply.content)
    dispatcher.execute(q)
    assert len(calls) == 1 and len(store.export(run)["completions"]) == 1
    if status == 400:
        assert result["http_status"] == 400 and not exported["judgments"]


def test_permanent_credit_exhaustion_does_not_retry_even_when_http429(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []

    def handle(req):
        calls.append(req.content)
        return httpx.Response(
            429, json={"error": {"type": "insufficient_quota", "code": "credit_balance_exhausted"}}
        )

    dispatcher = Dispatcher(
        store, transport=httpx.MockTransport(handle), secret_dir=keys, sleep=lambda _: None
    )
    assert dispatcher.execute(q)["status"] == "parked"
    assert len(calls) == 1 and len(store.export(run)["attempts"]) == 1
    assert not store.export(run)["judgments"]
    assert dispatcher.execute(q)["status"] == "parked" and len(calls) == 1


def test_true_rate_limit_remains_bounded_to_three_identical_attempts(tmp_path):
    store, run, q, keys = prepared(tmp_path)
    calls = []

    def handle(req):
        calls.append(req.content)
        return httpx.Response(
            429, json={"error": {"type": "rate_limit_error", "code": "rate_limit_exceeded"}}
        )

    dispatcher = Dispatcher(
        store, transport=httpx.MockTransport(handle), secret_dir=keys, sleep=lambda _: None
    )
    assert dispatcher.execute(q)["status"] == "parked"
    assert len(calls) == 3 and len(set(calls)) == 1


def test_linked_checkout_cannot_use_another_database_to_reset_programme_spending(tmp_path, monkeypatch):
    from pipeline.study.transport import central_live_ledger

    production = tmp_path / "production"
    linked = tmp_path / "linked"
    production.mkdir()
    linked.mkdir()

    def common(command, *, cwd, text):
        return ".git\n" if cwd == production else str(production / ".git") + "\n"

    monkeypatch.setattr("pipeline.study.transport.subprocess.check_output", common)
    assert central_live_ledger(production) == central_live_ledger(linked)
    assert central_live_ledger(linked) != linked / ".research-private/programme-v1/programme.sqlite3"


@pytest.mark.parametrize("error", [
    {"code": "1113", "message": "Fixture: account in arrears"},
    {"code": "9999", "message": "Fixture: Insufficient balance or no resource package"},
    {"type": "billing_error", "message": "Your credit balance is too low"},
    {"code": 1113, "message": "账户已欠费"},  # the code as a number, a message with no English credit word
    {"type": "billing_error", "message": "Fixture"},
])
def test_a_billing_error_by_code_or_wording_is_never_retried(error):
    """Replication review (18 Nov): Z.AI reports exhausted credit as a 429 with its own code (1113)."""
    from pipeline.study.transport import transient_http_failure

    body = json.dumps({"error": error}).encode()
    assert not transient_http_failure(429, body) and not transient_http_failure(503, body)
    rate_limited = json.dumps({"error": {"code": "1302", "message": "Rate limit"}}).encode()
    assert transient_http_failure(429, rate_limited)
