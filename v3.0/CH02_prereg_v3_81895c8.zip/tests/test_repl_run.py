"""The replication (18 Nov 2026; docs/rerun-2026-11/, pre-registration v3.0): three interleaved arms on the
57 post-SLR papers, R0 only, with the completed post-SLR run's settings after the code amendment.

Freezes run on a temporary ledger with two fictional post-SLR papers (tests/test_postslr_run.fixture_set);
no private paper text is read and nothing dispatches to a provider (MockTransport only).
"""

import json

import httpx
import pytest

from pipeline.study import final_phase as fp
from pipeline.study.records import RESAMPLE_POLICY_V4, StudyError, canonical, digest
from pipeline.study.scoring import build_prompt, payload_for
from pipeline.study.transport import Dispatcher
from tests.test_postslr_run import fixture_set
from tests.test_study_scoring import cell, response
from tests.test_study_transport import success


def test_arms_are_the_declared_packages():
    assert fp.REPL_ARMS == {
        "REPL_V12": ("rubric/rubric_v1_2_r3.yaml", "docs/final-phase-2026-10-28/HANDBOOK_H5.txt"),
        "REPL_V10": ("rubric/rubric.yaml", "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt"),
        "REPL_V10_NOCONJ": ("rubric/rubric.yaml",
                            "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL_NOCONJ.txt"),
    }
    assert fp.REPL_SEED == "ch2-repl-20261120" and fp.REPL_SEED != fp.POSTSLR_SEED
    assert not set(fp.REPL_CONDITIONS) & {*fp.POSTSLR_ARMS, fp.POSTSLR_D0, fp.POSTSLR_SCHEDULE}


def test_arms_have_the_completed_post_slr_settings_without_discussion():
    for c in fp.REPL_CONDITIONS:
        assert c in fp.RESAMPLE_V4 and fp.is_glmfix(c)
        assert c not in fp.DISCUSSED  # no discussion stage, declared in advance
        assert fp.reminder_for(c) == fp.reminder_for(fp.ARM_POSTSLR_V12)  # final check v2
        assert fp.models_for(c) == fp.models_for(fp.ARM_POSTSLR_V12)
    assert fp.population_of(fp.REPL_D0) == "synthetic_fixture"
    assert all(fp.population_of(a) == "final_evaluation" for a in fp.REPL_ARMS)


def test_noconj_procedure_is_the_original_minus_exactly_the_two_conjunction_sentences():
    original = (fp.ROOT / fp.HANDBOOK_EVAL_ORIGINAL).read_bytes()
    noconj = (fp.ROOT / fp.HANDBOOK_NOCONJ).read_bytes()
    cut = (b"Semicolon-separated joint requirements are conjunctive. An explicit OR\n"
           b"allows its stated alternatives; preserve that choice. ")
    assert original.count(cut) == 1 and original.replace(cut, b"") == noconj
    assert digest(noconj) == "c4dae86198cac755ed830979190c54c01e555946158784552a2541e77611fd2a"
    assert b"requires both" in noconj  # the P3 sentence is kept (D42)


def test_the_full_set_schedules_1026_requests():
    assert len(fp.postslr_papers()) == 57
    assert len(fp.REPL_ARMS) * 2 * len(fp.postslr_papers()) * 3 == 1026


def page_aware_fixture_set(tmp_path, monkeypatch):
    """fixture_set, with a page-aware fictional text so a request is dispatchable (not an input failure)."""
    private, papers = fixture_set(tmp_path, monkeypatch)
    for p in papers:
        md = ("[PDF PAGE 1]\n# Fictional paper\n\n"
              + "A fictional pool camera detects a fictional swimmer in a fictional test. No real data. " * 4)
        (private / "markdown-v1" / f"study-{p['study_id']}" / "paper.md").write_text(md)
        p["paper_txt_sha256"] = digest(md.encode())
    (tmp_path / "INPUTS_POSTSLR.json").write_text(json.dumps({"papers": papers}))
    return private, papers


def frozen_postslr_and_repl(tmp_path, monkeypatch):
    _, papers = page_aware_fixture_set(tmp_path, monkeypatch)
    monkeypatch.setattr(fp, "location", lambda: tmp_path / "live")
    postslr = fp.freeze_postslr()
    return papers, postslr, fp.freeze_repl()


def test_freeze_repl_refuses_without_the_post_slr_schedule(tmp_path, monkeypatch):
    fixture_set(tmp_path, monkeypatch)
    monkeypatch.setattr(fp, "location", lambda: tmp_path / "live")
    fp.freeze(fp.POSTSLR_D0, (0,), (1,), fp.ROOT / fp.HANDBOOK_H5, rubric=fp.ROOT / fp.RUBRIC_V1_2_R3)
    with pytest.raises(StudyError, match="post-SLR"):
        fp.freeze_repl()


def test_freeze_repl_interleaves_three_arms_with_new_run_ids(tmp_path, monkeypatch):
    papers, postslr, entry = frozen_postslr_and_repl(tmp_path, monkeypatch)
    frozen = json.loads((tmp_path / "live/FREEZE.json").read_text())["conditions"]
    assert {fp.REPL_D0, *fp.REPL_ARMS, fp.REPL_SCHEDULE} <= set(frozen)
    assert len(entry["runs"]) == 6 and len(set(entry["runs"])) == 6  # three arms × two executions
    assert len(entry["schedule"]) == 3 * 2 * len(papers) * 3
    repl = (*fp.REPL_CONDITIONS, fp.REPL_SCHEDULE)
    earlier = {r for c, v in frozen.items() if c not in repl for r in v["runs"]}
    assert set(postslr["runs"]) <= earlier
    assert not earlier & {*entry["runs"], *entry["smoke_runs"]}
    arm_of = {r: a for a in fp.REPL_ARMS for r in frozen[a]["runs"]}
    sequence = [arm_of[row["run_id"]] for row in entry["schedule"]]
    assert {sequence.count(a) for a in fp.REPL_ARMS} == {2 * len(papers) * 3}
    switches = sum(a != b for a, b in zip(sequence, sequence[1:], strict=False))
    assert switches > len(fp.REPL_ARMS)  # interleaved, not one arm after another
    assert entry["schedule"] == fp.interleave([r for a in fp.REPL_ARMS for r in frozen[a]["schedule"]],
                                              fp.REPL_SEED)
    assert fp.freeze_repl() == entry  # an unchanged refreeze is idempotent


def test_each_arm_records_its_rubric_and_procedure_hashes(tmp_path, monkeypatch):
    _, _, entry = frozen_postslr_and_repl(tmp_path, monkeypatch)
    for arm, (rubric, handbook) in fp.REPL_ARMS.items():
        assert entry["rubric_sha256"][arm] == digest((fp.ROOT / rubric).read_bytes())
        assert entry["handbook_sha256"][arm] == digest((fp.ROOT / handbook).read_bytes())
    store = fp.FinalRecords(tmp_path / "live/programme.sqlite3")
    frozen = json.loads((tmp_path / "live/FREEZE.json").read_text())["conditions"]
    protocol = {}
    for arm in fp.REPL_ARMS:
        m = store.manifest(frozen[arm]["runs"][0])
        files = m["papers"][0]["files"]
        protocol[arm] = store.asset(files["protocol.md"]).decode()
        assert digest(store.asset(files["rubric.yaml"])) == entry["rubric_sha256"][arm]
    assert "conjunctive" in protocol["REPL_V10"] and "conjunctive" not in protocol["REPL_V10_NOCONJ"]
    assert "explicit OR" in protocol["REPL_V10"] and "explicit OR" not in protocol["REPL_V10_NOCONJ"]


def test_runs_are_frozen_under_v4_without_discussion_and_refuse_later_rounds(tmp_path, monkeypatch):
    _, _, entry = frozen_postslr_and_repl(tmp_path, monkeypatch)
    store = fp.FinalRecords(tmp_path / "live/programme.sqlite3")
    for run in (*entry["runs"], *entry["smoke_runs"]):
        m = store.manifest(run)
        assert m["versions"]["unreadable_resample"] == RESAMPLE_POLICY_V4
        assert "discussion" not in m["versions"]
        assert m["versions"]["final_reminder"]
    run = entry["runs"][0]
    assert store.paper_count_ok(store.manifest(run))
    sid = store.manifest(run)["papers"][0]["study_id"]
    prompt, context = build_prompt(store, run, sid, ["P1", "P2", "P3", "P4"])
    payload = payload_for(store.manifest(run)["models"]["r1"], prompt)
    with pytest.raises(StudyError):
        store.request(run, sid, "r1", 1, "rating", 0, payload, context)


def test_a_changed_refreeze_is_refused(tmp_path, monkeypatch):
    frozen_postslr_and_repl(tmp_path, monkeypatch)
    altered = tmp_path / "ALTERED.txt"
    altered.write_text((fp.ROOT / fp.HANDBOOK_NOCONJ).read_text() + "\nOne more sentence.\n")
    monkeypatch.setitem(fp.REPL_ARMS, fp.ARM_REPL_NOCONJ, (fp.RUBRIC_V1_0, str(altered)))
    with pytest.raises(StudyError):
        fp.freeze_repl()


def test_an_http_520_on_a_replication_arm_is_re_requested(tmp_path, monkeypatch):
    """B2: the 5xx retry is the transport's, so every REPL request has it by design (12 Nov amendment)."""
    _, _, entry = frozen_postslr_and_repl(tmp_path, monkeypatch)
    store = fp.FinalRecords(tmp_path / "live/programme.sqlite3")
    row = next(r for r in entry["schedule"] if r["rater"] == "r1")
    m = store.manifest(row["run_id"])
    prompt, context = build_prompt(store, row["run_id"], row["study"], ["P1", "P2", "P3", "P4"])
    payload = payload_for(m["models"]["r1"], prompt)
    assert digest(canonical(payload)) == row["payload_sha256"]  # the frozen request, unchanged
    q = store.request(row["run_id"], row["study"], "r1", 0, "rating", 0, payload, context)
    keys = tmp_path / "keys"
    keys.mkdir()
    (keys / "openai-api-key").write_text("SECRET-FIXTURE-KEY")
    replies, waits = [520, 520], []

    def handle(req):
        if replies:
            code = replies.pop(0)
            return httpx.Response(code, text=f"<!DOCTYPE html><title>api.openai.com | {code}</title>")
        return success(response([cell(p, 0) for p in ("P1", "P2", "P3", "P4")]), model="gpt-6.1-sol")

    result = Dispatcher(store, transport=httpx.MockTransport(handle), secret_dir=keys,
                        sleep=waits.append).execute(q)
    assert result["status"] == "succeeded"
    exported = store.export(row["run_id"])
    attempts = [a for a in exported["attempts"] if a["request_id"] == q]
    assert len(attempts) == 3 and waits == [1, 2]


def test_the_preregistration_states_the_frozen_design():
    """PREREGISTRATION_REPLICATION.md (v3.0) names what the runner and report use, and quotes the rubric."""
    prereg = (fp.ROOT / "docs/rerun-2026-11/PREREGISTRATION_REPLICATION.md").read_text()
    assert fp.REPL_SEED in prereg and "1,026 requests" in prereg and "10 percentage points" in prereg
    for arm, (rubric, handbook) in fp.REPL_ARMS.items():
        assert f"| `{arm}` |" in prereg
        assert digest((fp.ROOT / rubric).read_bytes()) in prereg
        assert digest((fp.ROOT / handbook).read_bytes()) in prereg
    assert digest((fp.ROOT / "calibration/protocol-ai-only-v1.md").read_bytes()) in prereg
    assert digest((fp.ROOT / fp.FINAL_CHECK_V2).read_bytes()) in prereg
    assert digest((fp.ROOT / fp.POSTSLR_INPUTS).read_bytes()) in prereg
    rule = (fp.ROOT / fp.RUBRIC_V1_2_R3).read_text().splitlines()[30].strip()
    flat = prereg.replace("\n  ", " ").replace("\n", " ")
    assert rule.startswith("Within a level") and f'"{rule}"' in flat
    for word in ("TBD", "TODO"):
        assert word not in prereg


def test_every_command_in_the_goal_b_scaffold_exists():
    """F1: each `final_phase <action>`, script and `--flag` named in docs/rerun-2026-11/goal-b/ exists."""
    import re

    source = (fp.ROOT / "pipeline/study/final_phase.py").read_text()
    actions = set(re.findall(r'"([a-z0-9-]+)"', "".join(re.findall(r"actions \+?= \[[^\]]*\]", source))))
    assert {"freeze-repl", "repl-smoke", "repl", "admit"} <= actions
    folder = fp.ROOT / "docs/rerun-2026-11/goal-b"
    text = "\n".join(p.read_text() for p in sorted(folder.glob("*.md")))
    named = set(re.findall(r"pipeline\.study\.final_phase ([a-z0-9-]+)", text))
    assert named and named <= actions, named - actions
    for script in set(re.findall(r"scripts/([a-z_]+\.(?:py|sh))", text)):
        assert (fp.ROOT / "scripts" / script).exists(), script
    flags = {
        "repl_report.py": {"--parity", "--ledger"},
        "repl_spend.py": {"--log", "--ledger", "--freeze"},
        "build_prereg_release.py": {"--check-code"},
    }
    for script, wanted in flags.items():
        body = (fp.ROOT / "scripts" / script).read_text()
        assert all(f'"{flag}"' in body for flag in wanted), script
    assert '"--smoke-run"' in source and '"--billing-evidence"' in source


def test_the_run_chain_is_the_committed_hashed_script():
    """Goal B launches scripts/repl_chain.sh unchanged; the release hashes it, so --check-code verifies it."""
    import subprocess
    import sys

    chain = fp.ROOT / "scripts/repl_chain.sh"
    assert chain.exists() and chain.stat().st_mode & 0o111
    assert subprocess.run(["bash", "-n", str(chain)], capture_output=True).returncode == 0
    body = chain.read_text()
    for needed in ("final_phase repl", "MAX_RESUMES=10", "LIMIT=259200", "repl-first-wait", "repl-waiting",
                   "cause: (provider outage|network or transport);", "insufficient", "nc -z"):
        assert needed in body, needed
    sys.path.insert(0, str(fp.ROOT / "scripts"))
    import build_prereg_release

    assert "scripts/repl_chain.sh" in build_prereg_release.ANALYSIS
    runbook = (fp.ROOT / "docs/rerun-2026-11/goal-b/01_RUN.md").read_text()
    assert "nohup caffeinate -i scripts/repl_chain.sh" in runbook and "#!/bin/bash" not in runbook


ABSTRACT_PIECES = (  # the longest case: a final stop, transfers, beyond the bound, hazard dependence
    "A pre-registered replication",
    "(stopped after `\\replRequestsDispositioned{}` of 1,026 requests)",
    "on the same papers found the revision resolved more panels",
    "(D points, L to U)",
    ", by Δ points or more (90% interval)",  # the longer of the two piece-5 options
    "(points: level 0 KZ, above 0 KA, not applicable KN)",
    "; the gain depended on the hazard-detector papers",
    "; not all sensitivity analyses agreed",
)
ABSTRACT_CUTS = (  # (text in the current abstract, replacement), in the rules' order
    ("Our system records both.", ""),
    (", and failures are counted", ""),
    ("The study measures consistency and checked evidence, not accuracy against expert judgment.", ""),
    ("The gap came from mechanical failures, then scope disputes and unclear wording; the latter led to 19 "
     "rubric changes.", "Unclear wording led to 19 rubric changes."),
    ("(paper-pillars)", ""),
    ("LLM systems that apply appraisal rubrics are usually judged by agreement, which hides judgments they "
     "fail to produce and those disputing whether the rubric applies.",
     "LLM appraisal is usually judged by agreement, which hides failed judgments and scope disputes."),
    ("three models from different providers", "three models"),
)


def test_the_longest_abstract_case_fits_the_current_length():
    """REPORTING_RULES_REPLICATION.md §3: the replication sentence, the closing change and the ordered cuts
    keep the abstract no longer than it is now (250 words). Words are whitespace tokens; a macro is one."""
    import re

    def norm(text):
        return " ".join(text.split())

    def words(text):
        return len(text.split())

    rules = norm((fp.ROOT / "docs/rerun-2026-11/REPORTING_RULES_REPLICATION.md").read_text())
    tex = (fp.ROOT / "docs/chapter-draft/ch2_article.tex").read_text()
    abstract = norm(re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", tex, re.S).group(1))
    assert '", excluding Δ-point differences (90% interval)"' in rules
    for piece in ABSTRACT_PIECES:
        assert f'"{piece}"' in rules or f'{piece}"' in rules, piece
    closing_old = "Evidence of transfer is inconclusive;"
    closing_new = "Evidence of transfer remains inconclusive;"  # with piece 8, the closing that applies
    assert closing_old in abstract and f'"{closing_new}"' in rules
    before = words(abstract)
    after = abstract
    for old, new in ABSTRACT_CUTS:
        assert old in after and f'"{old}"' in rules, old
        after = after.replace(old, new)
    after = after.replace(closing_old, closing_new)
    # every placeholder as the macro(s) it stands for: D, L, U, KZ, KA, KN and Δ are one macro each
    added = [p.replace("`", "") for p in ABSTRACT_PIECES]
    sentence_full = " ".join(added)
    added[2] = added[2].replace("on the same papers ", "", 1)  # cut 8
    sentence_cut = " ".join(p for i, p in enumerate(added) if i != 3)  # cut 7; the stop clause is never cut
    assert words(after) + words(sentence_cut) <= before, (words(after) + words(sentence_cut), before)
    # the other long case: no disagreement (no piece 8), with the longer transfers closing
    other = after.replace(closing_new, "Evidence of transfer now comes from one replication;")
    sentence_other = " ".join(p for i, p in enumerate(added[:-1]) if i != 3)
    assert '"Evidence of transfer now comes from one replication;"' in rules
    assert words(other) + words(sentence_other) <= before, (words(other) + words(sentence_other), before)
    assert words(sentence_full) > words(sentence_cut)


def test_every_article_passage_the_rules_replace_exists_verbatim():
    """REPORTING_RULES_REPLICATION.md §5 fixes replacements for passages quoted from the article; each quoted
    passage must exist in the article as it stands, so Goal B replaces text rather than choosing it."""
    tex = " ".join((fp.ROOT / "docs/chapter-draft/ch2_article.tex").read_text().split())
    rules = " ".join((fp.ROOT / "docs/rerun-2026-11/REPORTING_RULES_REPLICATION.md").read_text().split())
    for passage in (
        "The evidence on transfer is therefore inconclusive,",
        "The evidence on transfer is therefore inconclusive, and paper mix may explain part of the "
        "difference.",
        "on new papers the evidence is inconclusive.",
        "Only the reading of the unseen-corpus gain changes (its interval then includes zero).",
        "Final test on papers published after the review's search",
        "Testing on papers the rubric was refined from",
        "Hazard detectors in scope by our ruling",
        "Raters may have seen the papers in training",
        "The original procedure already stated the conjunctive reading (ruling D2), so every arm of every "
        "test applied the criteria with the convention stated, and the study does not measure how models "
        "read the "
        "criteria without it.",
        "(we did not test the models without it)",
        ", and the gain on the refinement papers is reported, as pre-registered, as specific to them.",
        "The exposed-corpus gain is specific to those papers;",
        "The study tested refinement three times on papers the refinement had not used.",
        "Two of the three refinements therefore looked better on the papers they were developed from than on "
        "fresh papers,",
        "None of this replaces the pre-registered reading.",
        "pre-registered (2 tests)",
        "Our final test applies this time split",
        "final test pre-registered",
        "Stages and pre-registration",
    ):
        assert passage in tex, passage
        assert passage in rules, passage
