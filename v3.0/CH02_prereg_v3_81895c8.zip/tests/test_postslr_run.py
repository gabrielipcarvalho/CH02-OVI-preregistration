"""The post-SLR evaluation (10 Nov 2026; PREREGISTRATION_POSTSLR.md, v2.0): two interleaved arms on the 57
screened papers, inputs checked against the published stage 2 hashes.

The freeze rehearsal builds two fictional post-SLR papers on a temporary ledger and a temporary input list;
no private paper text is read and nothing dispatches.
"""

import json
import shutil

import pytest

from pipeline.study import final_phase as fp
from pipeline.study.records import RESAMPLE_POLICY_V4, StudyError, digest

FIXTURE_PDF = fp.ROOT / "calibration/fixtures/D0.pdf"


def test_arms_match_the_preregistration():
    prereg = (fp.ROOT / "docs/postslr-2026-11/PREREGISTRATION_POSTSLR.md").read_text()
    assert fp.POSTSLR_SEED in prereg
    assert "POSTSLR_V12 | `rubric/rubric_v1_2_r3.yaml` | `HANDBOOK_H5.txt`" in prereg
    assert fp.POSTSLR_ARMS[fp.ARM_POSTSLR_V12] == (fp.RUBRIC_V1_2_R3, fp.HANDBOOK_H5)
    assert fp.POSTSLR_ARMS[fp.ARM_POSTSLR_V10][0] == fp.RUBRIC_V1_0
    assert fp.POSTSLR_ARMS[fp.ARM_POSTSLR_V10][1].endswith("HANDBOOK_EVAL_ORIGINAL.txt")
    for arm in fp.POSTSLR_ARMS:
        assert fp.population_of(arm) == "final_evaluation"
        assert arm in fp.RESAMPLE_V4 and arm in fp.DISCUSSED and fp.is_glmfix(arm)
        assert fp.reminder_for(arm) == fp.reminder_for(fp.ARM_V12_R3)  # final check v2, as in CORPUS3B
        assert fp.models_for(arm) == fp.models_for(fp.ARM_V12_R3)


def test_published_input_list_is_the_57_with_14_hazard_flags():
    inputs = fp.postslr_inputs()
    assert len(inputs) == 57 and all(sid > fp.POSTSLR_OFFSET for sid in inputs)
    assert not set(inputs) & set(range(1, 83))
    assert sum(p["hazard_detector"] for p in inputs.values()) == 14
    stage2 = (fp.ROOT / "docs/postslr-2026-11/PREREGISTRATION_POSTSLR_STAGE2.md").read_text()
    assert all(f"| {p['record_id']} | {sid} |" in stage2 for sid, p in inputs.items())


def fixture_set(tmp_path, monkeypatch, n=2):
    """n fictional post-SLR papers (the D0 fixture PDF, a short fictional text) and their input list."""
    private = tmp_path / "private"
    papers = []
    for i in range(1, n + 1):
        record, sid = f"S900{i}", fp.POSTSLR_OFFSET + 9000 + i
        (private / "papers" / record).mkdir(parents=True)
        shutil.copy(FIXTURE_PDF, private / "papers" / record / "paper.pdf")
        pdf_hash = digest(FIXTURE_PDF.read_bytes())
        folder = private / "markdown-v1" / f"study-{sid}"
        folder.mkdir(parents=True)
        md = f"# Fictional paper {i}\n\nA fictional pool camera detects a fictional swimmer. No real data.\n"
        (folder / "paper.md").write_text(md)
        (folder / "conversion.json").write_text(json.dumps({"pdf_sha256": pdf_hash, "figures": []}))
        papers.append({"record_id": record, "study_id": sid, "hazard_detector": False, "pdf_sha256": pdf_hash,
                       "paper_txt_source": "paper.md", "paper_txt_sha256": digest(md.encode())})
    inputs = tmp_path / "INPUTS_POSTSLR.json"
    inputs.write_text(json.dumps({"papers": papers}))
    monkeypatch.setattr(fp, "POSTSLR_INPUTS", str(inputs))  # absolute: ROOT / absolute == absolute
    monkeypatch.setattr(fp, "POSTSLR_PRIVATE", str(private))
    return private, papers


def test_paper_refuses_unlisted_or_altered_inputs(tmp_path, monkeypatch):
    private, papers = fixture_set(tmp_path, monkeypatch)
    sid = papers[0]["study_id"]
    pdf, md = fp.postslr_paper(sid)
    assert pdf == FIXTURE_PDF.read_bytes() and md.startswith("# Fictional paper 1")
    with pytest.raises(StudyError, match="not in the published"):
        fp.postslr_paper(sid + 100)
    (private / "markdown-v1" / f"study-{sid}" / "paper.md").write_text("altered")
    with pytest.raises(StudyError, match="rater text differs"):
        fp.postslr_paper(sid)
    other = papers[1]
    (private / "papers" / other["record_id"] / "paper.pdf").write_bytes(b"%PDF-altered")
    with pytest.raises(StudyError, match="PDF differs"):
        fp.postslr_paper(other["study_id"])


def test_described_text_is_required_when_figures_are_pending(tmp_path, monkeypatch):
    private, papers = fixture_set(tmp_path, monkeypatch, n=1)
    sid = papers[0]["study_id"]
    conv = private / "markdown-v1" / f"study-{sid}" / "conversion.json"
    conv.write_text(json.dumps({"pdf_sha256": papers[0]["pdf_sha256"], "figures": [{"to_describe": True}]}))
    with pytest.raises(StudyError, match="text source differs"):
        fp.postslr_paper(sid)


def test_input_list_refuses_a_broken_offset(tmp_path, monkeypatch):
    _, papers = fixture_set(tmp_path, monkeypatch, n=1)
    papers[0]["study_id"] += 1
    (tmp_path / "INPUTS_POSTSLR.json").write_text(json.dumps({"papers": papers}))
    with pytest.raises(StudyError, match="offset rule"):
        fp.postslr_inputs()


def test_freeze_postslr_interleaves_both_arms_under_v4(tmp_path, monkeypatch):
    _, papers = fixture_set(tmp_path, monkeypatch)
    monkeypatch.setattr(fp, "location", lambda: tmp_path / "live")
    entry = fp.freeze_postslr()
    frozen = json.loads((tmp_path / "live/FREEZE.json").read_text())["conditions"]
    assert set(frozen) == {fp.POSTSLR_D0, *fp.POSTSLR_ARMS, fp.POSTSLR_SCHEDULE}
    assert len(entry["runs"]) == 4  # two arms × two executions
    assert len(entry["schedule"]) == 4 * len(papers) * 3
    arms_in_order = [r["run_id"] in frozen[fp.ARM_POSTSLR_V12]["runs"] for r in entry["schedule"]]
    assert any(arms_in_order) and not all(arms_in_order)
    assert arms_in_order != sorted(arms_in_order, reverse=True)  # interleaved, not one arm then the other
    store = fp.FinalRecords(tmp_path / "live/programme.sqlite3")
    for run in entry["runs"]:
        versions = store.manifest(run)["versions"]
        assert versions["unreadable_resample"] == RESAMPLE_POLICY_V4
        assert versions["discussion"] == fp.DISCUSSION_POLICY
        assert store.paper_count_ok(store.manifest(run))
    assert fp.freeze_postslr() == entry  # an unchanged refreeze is idempotent


def test_admit_records_the_billing_evidence_given(tmp_path, monkeypatch):
    monkeypatch.setattr(fp, "location", lambda: tmp_path / "live")
    fp.freeze(fp.POSTSLR_D0, (0,), (1,), fp.ROOT / fp.HANDBOOK_H5, rubric=fp.ROOT / fp.RUBRIC_V1_2_R3)
    assert fp.admit(billing_evidence="fixture balances")["billing_evidence"] == "fixture balances"
    with pytest.raises(StudyError, match="billing evidence"):
        fp.admit(billing_evidence="  ")
