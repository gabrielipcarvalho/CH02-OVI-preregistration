"""Scoring projection and guards exercise synthetic evidence; never use the real SLR or ratings."""

import copy
import json
from pathlib import Path

import pytest
from jsonschema import ValidationError

from pipeline.study.records import Records, StudyError
from pipeline.study.scoring import (
    build_prompt,
    defence_violations,
    freeze_run,
    payload_for,
    validate_response,
)

SCHEMA = json.loads(
    (Path(__file__).resolve().parents[1] / "docs/study-2026-09-28/judgment.schema.json").read_text()
)
TEXT = (
    "[PDF PAGE 1]\nA fictional study documented two physical pools and a price of 2400 USD.\n"
    + ("Fictional fixture. " * 20)
    + "\n[PDF PAGE 2]\nAnother page with no matching quote."
)


def cell(p="P1", score=1):
    quote = "two physical pools" if score else "NO_DOCUMENTED_EVIDENCE"
    locator = "PDF page 1" if score else ""
    return {
        "pillar": p,
        "status": "scored",
        "score": score,
        "quote": quote,
        "locator": locator,
        "reason": "The paper documents the relevant evidence.",
        "alternative": "",
        "confidence": "high",
        "action": "initial",
        "change_reason": "",
        "anonymous_defence": {
            "quote": quote,
            "locator": locator,
            "reason": "The source evidence is documented.",
            "alternative": "",
        },
    }


def response(cells):
    return json.dumps({"cells": cells})


def test_explicit_schema_rejects_verbose_labels_and_null_strings():
    raw = cell()
    raw["pillar"] = "Generalisation & External Validity"
    with pytest.raises(ValidationError):
        validate_response(response([raw]), SCHEMA, ["P1"], TEXT)
    raw = cell()
    raw["alternative"] = None
    with pytest.raises(ValidationError):
        validate_response(response([raw]), SCHEMA, ["P1"], TEXT)


@pytest.mark.parametrize("score", [True, 1.0, 4, -1])
def test_boolean_float_and_out_of_domain_scores_refused(score):
    raw = cell()
    raw["score"] = score
    with pytest.raises((StudyError, ValidationError)):
        validate_response(response([raw]), SCHEMA, ["P1"], TEXT)


def test_missing_duplicate_or_extra_pillars_cannot_partially_persist():
    for cells in ([cell("P1")], [cell("P1"), cell("P1")], [cell("P1"), cell("P2"), cell("P3")]):
        with pytest.raises(ValidationError):
            validate_response(response(cells), SCHEMA, ["P1", "P2"], TEXT)


def test_quote_and_false_page_are_rejected_without_replacing_score():
    raw = cell()
    raw["quote"] = "invented non-existent evidence"
    raw["anonymous_defence"]["quote"] = raw["quote"]
    with pytest.raises(StudyError, match="not locatable"):
        validate_response(response([raw]), SCHEMA, ["P1"], TEXT)
    raw = cell()
    raw["locator"] = "PDF page 2"
    raw["anonymous_defence"]["locator"] = raw["locator"]
    with pytest.raises(StudyError, match="claimed PDF page"):
        validate_response(response([raw]), SCHEMA, ["P1"], TEXT)


def test_absence_and_access_failure_remain_distinct_and_locatability_not_validity():
    absent = cell(score=0)
    result = validate_response(response([absent]), SCHEMA, ["P1"], TEXT)[0]
    assert result["score"] == 0 and result["evidence_check"]["status"] == "absence_not_verified"
    missing = cell()
    missing.update(status="unable_to_assess", score=None, quote="", locator="")
    missing["anonymous_defence"].update(quote="", locator="")
    result = validate_response(response([missing]), SCHEMA, ["P1"], TEXT)[0]
    assert result["score"] is None and result["evidence_check"]["status"] == "not_assessable"
    result = validate_response(response([cell()]), SCHEMA, ["P1"], TEXT)[0]
    assert result["evidence_check"]["pages"] == [1] and not result["evidence_check"]["semantic_validity"]


@pytest.mark.parametrize("message", ["I choose level 2", "As Claude I agree", "Both raters agree", "P1=1"])
def test_advocated_scores_identity_and_tallies_block_exchange(message):
    raw = cell()
    raw["anonymous_defence"]["reason"] = message
    assert defence_violations(raw)
    with pytest.raises(StudyError, match="prohibited"):
        validate_response(response([raw]), SCHEMA, ["P1"], TEXT)


def test_legitimate_numbers_inside_exact_quote_are_preserved():
    raw = cell()
    raw.update(quote="a price of 2400 USD")
    raw["anonymous_defence"]["quote"] = raw["quote"]
    result = validate_response(response([raw]), SCHEMA, ["P1"], TEXT)[0]
    assert result["anonymous_defence"]["quote"] == "a price of 2400 USD"


def test_changed_retained_explanation_is_recorded_as_revision_and_triggers_signature_change():
    prior = cell()
    revised = copy.deepcopy(prior)
    revised.update(
        action="retain", reason="A new interpretation of the same source.", change_reason="Reconsidered"
    )
    result = validate_response(response([revised]), SCHEMA, ["P1"], TEXT, {"P1": prior})[0]
    assert result["reason"] == revised["reason"] and result["reported_action"] == "retain"
    assert result["action"] == "revise"


def fixture_run(tmp_path):
    packet = tmp_path / "packet"
    packet.mkdir()
    for name, data in {
        "paper.pdf": b"%PDF-fixture",
        "paper.txt": TEXT.encode(),
        "rubric.yaml": (
            "note: FROZEN-RUBRIC-FIXTURE\npillars:\n"
            + "".join(f"  P{n}: {{title: Fixture pillar {n}}}\n" for n in range(1, 5))
        ).encode(),
        "protocol.md": b"Common procedure fixture",
    }.items():
        (packet / name).write_bytes(data)
    store = Records(tmp_path / "programme.sqlite3")
    models = {
        r: {
            "provider": "openai",
            "model": "fixture",
            "generation": {"model": "fixture", "store": False, "max_output_tokens": 6000},
        }
        for r in ("r1", "r2", "r3")
    }
    run = freeze_run(
        store,
        population="synthetic_fixture",
        condition="D0",
        execution=1,
        packet_paths={0: packet},
        models=models,
        limits={"max_prompt_utf8_bytes": 320000},
        seed="fixture",
        schema=SCHEMA,
        code={"revision": "fictional", "withheld": "TRL_CANARY"},
    )
    return store, run, models, packet


def test_r0_projection_contains_common_assets_but_not_coordinator_canaries(tmp_path):
    store, run, models, packet = fixture_run(tmp_path)
    prompt, context = build_prompt(store, run, 0, ["P1", "P2", "P3", "P4"])
    assert TEXT in prompt and "FROZEN-RUBRIC-FIXTURE" in prompt
    assert "TRL_CANARY" not in prompt and "fixture" not in prompt.split("FROZEN RUBRIC")[0]
    assert "ANONYMOUS PEER" not in prompt and "OWN PRECEDING" not in prompt
    request = payload_for(models["r1"], prompt)
    assert "previous_response_id" not in request and "tools" not in request
    (packet / "paper.txt").write_text("CHANGED AFTER FREEZE")
    assert build_prompt(store, run, 0, list(("P1", "P2", "P3", "P4")))[0] == prompt
    assert context["prompt_hash"]


def test_revision_projection_excludes_other_private_scores_and_audit_fields(tmp_path):
    store, run, models, _ = fixture_run(tmp_path)
    prior = cell()
    prior["private_canary"] = "DO_NOT_RELEASE"
    prior["evidence_check"] = {"secret": "audit-only"}
    packet = {"P1": [{"quote": "two physical pools", "locator": "PDF page 1", "reason": "Peer argument"}]}
    prompt, _ = build_prompt(store, run, 0, ["P1"], {"P1": prior}, packet)
    assert "DO_NOT_RELEASE" not in prompt and "audit-only" not in prompt
    assert "OWN PRECEDING" in prompt and "Peer argument" in prompt


def test_majority_real_evidence_is_not_mistaken_for_a_vote_tally():
    raw = cell()
    raw["anonymous_defence"]["reason"] = "The majority of source samples are authentic events."
    assert not defence_violations(raw)


def test_extra_root_fields_are_validated_but_headline_metrics_do_not_discard_pillars():
    with pytest.raises(ValidationError):
        validate_response(json.dumps({"cells": [cell()], "unexpected": "metadata"}), SCHEMA, ["P1"], TEXT)
    result = validate_response(
        json.dumps({"cells": [cell()], "headline_metric": {"unparseable": "example"}}), SCHEMA, ["P1"], TEXT
    )[0]
    assert result["score"] == 1 and not result["auxiliary_metric"]["used_for_pillar_scoring"]


def test_two_column_frozen_pdf_quotes_are_verified_without_rewriting_common_input(tmp_path):
    import subprocess

    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    from pipeline.study.scoring import reading_order_text

    pdf = tmp_path / "two-column.pdf"
    fig = plt.figure(figsize=(8, 5))
    fig.text(0.08, 0.8, "The source author reports independent", fontsize=12)
    fig.text(0.08, 0.75, "validation at two real facilities.", fontsize=12)
    fig.text(0.58, 0.8, "Right column has unrelated text.", fontsize=12)
    fig.text(0.58, 0.75, "It must not split the left quotation.", fontsize=12)
    fig.savefig(pdf)
    plt.close(fig)
    layout = subprocess.check_output(["pdftotext", "-layout", str(pdf), "-"]).decode()
    common = "[PDF PAGE 1]\n" + layout
    quote = "The source author reports independent validation at two real facilities."
    alternate = reading_order_text(pdf.read_bytes())
    raw = cell()
    raw["quote"] = quote
    raw["anonymous_defence"]["quote"] = quote
    with pytest.raises(StudyError, match="not locatable"):
        validate_response(response([raw]), SCHEMA, ["P1"], common)
    result = validate_response(response([raw]), SCHEMA, ["P1"], common, reading_order=alternate)[0]
    assert result["quote"] == quote
    assert result["evidence_check"]["method"] == "frozen_pdf_reading_order"
    assert result["evidence_check"]["pages"] == [1]
    raw["locator"] = "PDF page 2"
    raw["anonymous_defence"]["locator"] = raw["locator"]
    with pytest.raises(StudyError, match="claimed PDF page"):
        validate_response(response([raw]), SCHEMA, ["P1"], common, reading_order=alternate)


def test_content_order_fallback_and_printed_page_do_not_rewrite_or_weaken_physical_claims():
    from pipeline.study.scoring import evidence_check

    raw = cell()
    raw["quote"] = "Source paragraph on a single physical page."
    raw["locator"] = "PDF page 3 (printed page 191), Results"
    interleaved = "[PDF PAGE 3]\nSource paragraph UNRELATED on a single physical page."
    content = "[PDF PAGE 3]\nSource paragraph on a single physical page."
    with pytest.raises(StudyError, match="not locatable"):
        evidence_check(raw, interleaved, interleaved)
    result = evidence_check(raw, interleaved, interleaved, content)
    assert result["method"] == "frozen_pdf_content_order" and result["pages"] == [3]
    assert raw["quote"] == "Source paragraph on a single physical page."
    raw["locator"] = "PDF page 2 (printed page 191)"
    with pytest.raises(StudyError, match="claimed PDF page"):
        evidence_check(raw, interleaved, interleaved, content)
    raw["locator"] = "printed page 191, Results"
    assert not evidence_check(raw, content)["locator_page_verified"]
    raw["quote"] = "Source paragraph on a physical page."
    with pytest.raises(StudyError, match="not locatable"):
        evidence_check(raw, interleaved, interleaved, content)
