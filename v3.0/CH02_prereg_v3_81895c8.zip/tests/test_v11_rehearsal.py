"""Rehearsal of the D0_V11 smoke path through the real final-phase code: freeze, admission, the
FinalRecords ledger, the quote-correction turn and a discussion round, with scripted provider replies.

The 29 Oct ledger incident reached a paid run because unit tests used a plain Records store; this test
drives the production path on a temporary ledger instead. Fictional fixture text only.
"""

import json

import httpx
import pytest

from pipeline.study import final_phase as fp
from pipeline.study.records import PILLARS, StudyError
from pipeline.study.transport import Dispatcher

QUOTES = {
    "P1": "Validation used one pool only.",
    "P2": "All demonstration episodes were staged by volunteers.",
    "P3": "No deployment cost or LMIC-context design is reported in this fictional record.",
    "P4": "No privacy mitigation, user-acceptance assessment or consent framework is reported.",
}


def cell(p, score=0, quote=None):
    quote = quote or QUOTES[p]
    reason = "The fixture documents this directly."
    return {
        "pillar": p, "status": "scored", "score": score, "quote": quote, "locator": "PDF page 1",
        "reason": reason, "alternative": "", "confidence": "high", "action": "initial", "change_reason": "",
        "anonymous_defence": {"quote": quote, "locator": "PDF page 1", "reason": reason, "alternative": ""},
    }


R0 = {
    "r1": [cell("P1", 1), *(cell(p) for p in PILLARS[1:])],  # contested P1 → one discussion round
    "r2": [cell("P1"), cell("P2", quote="All demonstration episodes were filmed by volunteers."),
           *(cell(p) for p in PILLARS[2:])],  # P2 quote not in the source → one correction turn
    "r3": [cell(p) for p in PILLARS],
}
RATER = {"openai": "r1", "zai": "r2", "anthropic": "r3"}
HOSTS = {"api.openai.com": "openai", "api.anthropic.com": "anthropic", "api.z.ai": "zai"}


def reply(provider, model, text):
    if provider == "openai":
        body = {"model": model, "status": "completed", "usage": {"input_tokens": 1000, "output_tokens": 100},
                "output": [{"type": "message", "content": [{"type": "output_text", "text": text}]}]}
    elif provider == "anthropic":
        usage = {"input_tokens": 1000, "output_tokens": 100}
        body = {"model": model, "stop_reason": "end_turn", "usage": usage,
                "content": [{"type": "text", "text": text}]}
    else:
        body = {"model": model, "usage": {"prompt_tokens": 1000, "completion_tokens": 100},
                "choices": [{"finish_reason": "stop", "message": {"content": text}}]}
    return httpx.Response(200, json={"id": "fictional", **body})


def scripted(calls):
    def handle(request):
        provider = HOSTS[request.url.host]
        body = json.loads(request.content)
        turns = body.get("input") if provider == "openai" else body["messages"]
        rater = RATER[provider]
        prompt = turns if isinstance(turns, str) else turns[0]["content"]
        if not isinstance(turns, str) and len(turns) == 3:
            calls.append((rater, "correction"))
            text = json.dumps({"cells": [{"pillar": "P2", "quote": QUOTES["P2"], "locator": "PDF page 1"}]})
        elif "OWN PRECEDING" in prompt:
            calls.append((rater, "discussion"))
            own = {c["pillar"]: c for c in R0[rater]}
            if rater == "r1":
                cells = [{**cell("P1"), "action": "revise", "change_reason": "Only one pool was used."}]
            else:
                cells = [{**own["P1"], "action": "retain", "change_reason": "The cited text is unchanged."}]
            text = json.dumps({"cells": cells})
        else:
            calls.append((rater, "r0"))
            text = json.dumps({"cells": R0[rater]})
        return reply(provider, body["model"], text)

    return handle


def test_v11_smoke_path_runs_correction_and_discussion_through_the_final_ledger(tmp_path, monkeypatch):
    monkeypatch.setattr(fp, "location", lambda: tmp_path / "live")
    rubric, handbook = fp.ROOT / fp.RUBRIC_V1_1, fp.ROOT / fp.HANDBOOK_H4
    (run,) = fp.freeze("D0_V11", (0,), (1,), handbook, rubric=rubric)
    frozen = json.loads((tmp_path / "live/FREEZE.json").read_text())["conditions"]["D0_V11"]
    assert frozen["rubric_sha256"] == fp.digest(rubric.read_bytes())
    assert (tmp_path / "live/packets/D0_V11/0/rubric.yaml").read_bytes() == rubric.read_bytes()
    fp.admit()
    keys = tmp_path / "keys"
    keys.mkdir()
    for name in ("openai-api-key", "anthropic-api-key", "zai-coding-key"):
        (keys / name).write_text("FIXTURE-KEY")
    calls = []
    store = fp.FinalRecords(tmp_path / "live/programme.sqlite3")
    dispatcher = Dispatcher(store, transport=httpx.MockTransport(scripted(calls)), secret_dir=keys)
    result = fp.run_discussion("D0_V11", dispatcher=dispatcher)

    outcome = result["discussion"][run]["0"]
    agreed = {r: ("scored", 0) for r in RATER.values()}
    assert outcome["P1"] == {"stop": "resolved", "round": 1, "final": agreed}
    assert all(outcome[p]["stop"] == "resolved" and outcome[p]["round"] == 0 for p in PILLARS[1:])
    assert ("r2", "correction") in calls and sum(k == "discussion" for _, k in calls) == 3
    exported = store.export(run)
    assert 2 in {a["stage"] for a in exported["attempts"]}
    assert fp.smoke_passed(exported) and len(exported["judgments"]) > 12
    assert fp.admit(smoke_run=run)["smoke_run"] == run


def test_v11_conditions_use_rubric_v1_1_papers_and_populations():
    assert fp.population_of("D0_V11") == "synthetic_fixture"
    assert fp.population_of("CHECK_V11") == "final_evaluation"
    assert fp.population_of("CHECK_V11_DEV") == "development"
    assert fp.population_of("D0_V11B") == "synthetic_fixture"
    assert fp.population_of("CHECK_V11B") == "final_evaluation"
    papers_b = [{"study_id": s} for s in fp.V11B]
    v11b = {"population": "final_evaluation", "condition": "CHECK_V11B", "papers": papers_b}
    assert fp.FinalRecords.__new__(fp.FinalRecords).paper_count_ok(v11b) and "CHECK_V11B" in fp.DISCUSSED
    assert set(fp.V11) < set(fp.HELDOUT)
    assert "CHECK_V11" in fp.DISCUSSED and "CHECK_V11_DEV" not in fp.DISCUSSED
    store = fp.FinalRecords.__new__(fp.FinalRecords)
    papers = [{"study_id": s} for s in fp.V11]
    manifest = {"population": "final_evaluation", "condition": "CHECK_V11", "papers": papers}
    assert store.paper_count_ok(manifest)
    assert "one cell for each REQUESTED PILLAR" in fp.reminder_for("CHECK_V11_DEV")
    with pytest.raises(StudyError):
        fp.population_of("CHECK_V99")


def test_rubric_v1_1_keeps_v1_0_text_except_the_two_amended_p4_criteria():
    import yaml

    old = yaml.safe_load((fp.ROOT / fp.RUBRIC_V1_0).read_text())
    new = yaml.safe_load((fp.ROOT / fp.RUBRIC_V1_1).read_text())
    changed = {(p, n) for p in PILLARS for n in range(4)
               if old["pillars"][p]["levels"][n] != new["pillars"][p]["levels"][n]}
    assert changed == {("P4", 0), ("P4", 1)}
    assert old["thresholds"]["published_paragraph"] == new["thresholds"]["published_paragraph"]
    assert old["ovi_bands"] == new["ovi_bands"] and old["level_labels"] == new["level_labels"]
    assert all(new["pillars"][p]["title"] == old["pillars"][p]["title"] for p in PILLARS)


DUPLICATED = [*R0["r2"], {**cell("P1"), "status": "applicability_uncertain", "score": None,
                          "reason": "Duplicate cell removed: see the judgment above."}]


def glm_duplicates(calls, times):
    """GLM's first `times` independent-round replies repeat P1 with a conflicting status (as paper 47)."""
    base = scripted(calls)

    def handle(request):
        body = json.loads(request.content)
        first = body.get("messages", [{}])[0].get("content", "") if "z.ai" in request.url.host else ""
        if "z.ai" in request.url.host and len(body["messages"]) == 1 and "OWN PRECEDING" not in first:
            done = sum(k == "r0" for r, k in calls if r == "r2")
            if done < times:
                calls.append(("r2", "r0"))
                return reply("zai", body["model"], json.dumps({"cells": DUPLICATED}))
        return base(request)

    return handle


def frozen_d0(tmp_path, monkeypatch):
    monkeypatch.setattr(fp, "location", lambda: tmp_path / "live")
    (run,) = fp.freeze("D0_V11", (0,), (1,), fp.ROOT / fp.HANDBOOK_H4, rubric=fp.ROOT / fp.RUBRIC_V1_1)
    fp.admit()
    keys = tmp_path / "keys"
    keys.mkdir()
    for name in ("openai-api-key", "anthropic-api-key", "zai-coding-key"):
        (keys / name).write_text("FIXTURE-KEY")
    return run, fp.FinalRecords(tmp_path / "live/programme.sqlite3"), keys


def glm_r0(store, run, dispatcher):
    """Run the frozen independent round; return GLM's request and its (reused) outcome."""
    fp.run_condition("D0_V11", dispatcher=dispatcher)
    q = next(r["id"] for r in store.export(run)["requests"] if r["rater"] == "r2" and r["round"] == 0)
    return q, dispatcher.execute(q)


def test_unreadable_reply_is_re_requested_once_and_both_replies_are_kept(tmp_path, monkeypatch):
    run, store, keys = frozen_d0(tmp_path, monkeypatch)
    assert store.manifest(run)["versions"]["unreadable_resample"] == fp.RESAMPLE_POLICY
    calls = []
    dispatcher = Dispatcher(store, transport=httpx.MockTransport(glm_duplicates(calls, 1)), secret_dir=keys)
    q, out = glm_r0(store, run, dispatcher)
    assert out["status"] == "succeeded" and sorted(c["pillar"] for c in out["cells"]) == list(PILLARS)
    exported = store.export(run)
    stages = sorted(a["stage"] for a in exported["attempts"] if a["request_id"] == q)
    # stage 5: the re-request's own P2 quote goes through the quote-correction turn
    assert stages == [0, 3, 5] and not exported["dispositions"]
    events = [e for e in exported["events"] if e["kind"] == "unreadable_resample"]
    assert len(events) == 1 and events[0]["payload"]["original_error"] == "Ambiguous raw pillar identity"


def test_a_second_unreadable_reply_stays_a_format_failure(tmp_path, monkeypatch):
    run, store, keys = frozen_d0(tmp_path, monkeypatch)
    calls = []
    dispatcher = Dispatcher(store, transport=httpx.MockTransport(glm_duplicates(calls, 2)), secret_dir=keys)
    q, out = glm_r0(store, run, dispatcher)
    assert out["status"] == "parked" and out["disposition"]["status"] == "format_failure"
    exported = store.export(run)
    assert sorted(a["stage"] for a in exported["attempts"] if a["request_id"] == q) == [0, 3]
    assert sum(k == "r0" for r, k in calls if r == "r2") == 2


def test_runs_frozen_without_the_policy_never_re_request(tmp_path, monkeypatch):
    monkeypatch.setattr(fp, "is_glmfix", lambda condition: False)
    run, store, keys = frozen_d0(tmp_path, monkeypatch)
    assert "unreadable_resample" not in store.manifest(run)["versions"]
    calls = []
    dispatcher = Dispatcher(store, transport=httpx.MockTransport(glm_duplicates(calls, 1)), secret_dir=keys)
    q, out = glm_r0(store, run, dispatcher)
    assert out["status"] == "parked" and sum(k == "r0" for r, k in calls if r == "r2") == 1
    with pytest.raises(StudyError, match="Re-request attempt"):
        store.reserve(q, 3, 0, 0.01, {"model": "fixture"})
