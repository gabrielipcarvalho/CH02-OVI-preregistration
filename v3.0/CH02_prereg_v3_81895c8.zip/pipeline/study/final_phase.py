"""Final phase (approved 28 Oct 2026): md-v1 inputs, cost-reduced panel, develop → freeze → test once.

A separate append-only ledger; the October programme and next-phase ledgers are never written.
Design: docs/final-phase-2026-10-28/LOOP_DESIGN.md.
"""

from __future__ import annotations

import argparse
import base64
import json
import math
import random
import re
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from pipeline.study.evidence_md import VERSION as VERSION_MD
from pipeline.study.markdown_inputs import convert
from pipeline.study.phase import PhaseRecords, provider_spent
from pipeline.study.quote_correction import POLICY as CORRECTION_POLICY
from pipeline.study.records import (
    PILLARS,
    RESAMPLE_POLICY,
    RESAMPLE_POLICY_V2,
    RESAMPLE_POLICY_V3,
    RESAMPLE_POLICY_V4,
    BudgetStop,
    StudyError,
    canonical,
    digest,
)
from pipeline.study.response_repair import POLICY as REPAIR_POLICY
from pipeline.study.scoring import (
    DISCUSSION_POLICY,
    ROOT,
    build_prompt,
    freeze_run,
    implementation_provenance,
    payload_for,
)

PHASE = "final-phase-md-v1"
DEV = (38, 42, 53, 77, 34, 60, 83, 6)
HELDOUT = (14, 17, 18, 25, 27, 28, 31, 40, 47, 51, 59, 71, 72, 74, 79)
OUTPUT_CAP = 16000
MODELS = {
    "r1": {
        "provider": "openai",
        "model": "gpt-6.1-sol",
        "generation": {
            "model": "gpt-6.1-sol",
            "max_output_tokens": OUTPUT_CAP,
            "reasoning": {"effort": "low"},
            "store": False,
        },
        "rate_usd_per_million": [2, 10],
    },
    "r2": {
        "provider": "zai",
        "model": "glm-5.3",
        "generation": {
            "model": "glm-5.3",
            "max_tokens": OUTPUT_CAP,
            "reasoning_effort": "low",
            "thinking": {"type": "enabled"},
            # Change C1-A (28 Oct): provider-enforced JSON syntax; cycle 0 lost 6/16 responses to brackets.
            "response_format": {"type": "json_object"},
        },
        "rate_usd_per_million": [1.4, 4.4],
    },
    "r3": {
        "provider": "anthropic",
        "model": "claude-sonnet-5-5",
        # Thinking is on by default and counts against max_tokens; effort is fixed, never tuned mid-study.
        "generation": {
            "model": "claude-sonnet-5-5",
            "max_tokens": OUTPUT_CAP,
            "output_config": {"effort": "medium"},
        },
        "rate_usd_per_million": [2, 10],
    },
}
# Exploratory GLM follow-up (28 Oct, after the pre-registered result): GLM at reasoning_effort "high"
# (Z.AI allows low/high/max for glm-5.3); gpt and Sonnet unchanged. Only r2 is requested in GLMFIX runs.
MODELS_GLMFIX = json.loads(json.dumps(MODELS))
MODELS_GLMFIX["r2"]["generation"]["reasoning_effort"] = "high"
GLMFIX_REMINDER = "docs/final-phase-2026-10-28/GLMFIX_REMINDER.txt"
GLMFIX = {
    "GLMFIX_ORIGINAL": "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt",
    "GLMFIX_REFINED": "docs/final-phase-2026-10-28/HANDBOOK_C3.txt",
}


# Exploratory check of md-page-v1.3 + quote-correction-v1 (29 Oct, after the pre-registered result):
# five already-exposed held-out papers (four with the most failures, 31 as a clean control), the refined
# handbook, and the whole improved pipeline: every rater gets the final check, GLM runs at high reasoning.
CHECK = (17, 18, 27, 31, 72)
CHECK_HANDBOOK = "docs/final-phase-2026-10-28/HANDBOOK_C3.txt"
CHECK_CONDITIONS = ("D0_V13", "CHECK_V13")
# Exploratory discussion check (29 Oct): independent R0, then discussion-v1 rounds on contested pillars.
# Papers: the four that assess no drowning system (scope splits) plus 17 and 27 (score disagreements).
DISC = (17, 27, 28, 40, 47, 59)
DISC_CONDITIONS = ("D0_DISC", "DISC_V13", "D0_DISC_B", "DISC_V13_B")
# DISC_V13 stopped after R0: the phase ledger refused discussion rounds. DISC_V13_B is the re-freeze with
# FinalRecords.request admitting them; DISC_V13's R0 is kept as an extra independent replicate.
DISC_RUNS = ("DISC_V13", "DISC_V13_B")
FINAL_CHECK_V2 = "docs/final-phase-2026-10-28/FINAL_CHECK_V2.txt"
# Rubric v1.1 (30 Oct, DEC-0008): the published v1.0 is the default and stays untouched; v1.1 runs pair it
# with the procedure-only handbook H4. Exploratory checks before the 42-paper run (WORKPLAN_RUBRIC_V1_1.md):
# CHECK_V11 repeats the nine held-out papers of CHECK_V13 and DISC_V13_B with only rubric and handbook
# changed; CHECK_V11_DEV asks whether the development papers keep their verdicts (R0 only).
RUBRIC_V1_0 = "rubric/rubric.yaml"
RUBRIC_V1_1 = "rubric/rubric_v1_1.yaml"
HANDBOOK_H4 = "docs/final-phase-2026-10-28/HANDBOOK_H4.txt"
V11 = (17, 18, 27, 28, 31, 40, 47, 59, 72)
# CHECK_V11B (30 Oct): re-check after rubric v1.1 revision 2 on the papers the rulings target (27, 47, 72),
# a scope control (40) and a clean control (31); expectations F1–F5 in WORKPLAN_RUBRIC_V1_1.md §C2.
V11B = (27, 31, 40, 47, 72)
V11_CONDITIONS = ("D0_V11", "CHECK_V11", "CHECK_V11_DEV", "D0_V11B", "CHECK_V11B")
# Rubric v1.2 (31 Oct, DEC-0009): v1.1 plus the rulings on CORPUS2's recurring disagreements, applied with
# procedure H5. CHECK_V12 re-checks the papers behind the rulings (4, 11, 46 scope; 26, 41, 66, 81 P4;
# 50 P1) and three controls: 22 (agreed out of scope), 23 (agreed P4 level 1) and 29 (acoustic rescue-target
# detection, a boundary case for the new scope sentence). Expectations in WORKPLAN_RUBRIC_V1_2.md.
RUBRIC_V1_2 = "rubric/rubric_v1_2.yaml"
HANDBOOK_H5 = "docs/final-phase-2026-10-28/HANDBOOK_H5.txt"
V12 = (4, 11, 22, 23, 26, 29, 41, 46, 50, 66, 81)
# CHECK_V12B (31 Oct): re-check after v1.2 revision 2 on the papers it targets (29 staged drowning, 50 a built
# alert system evaluated in part, 41 a local-only wearable) and 46 (a person detector that must stay out).
V12B = (29, 41, 46, 50)
V12_CONDITIONS = ("D0_V12", "CHECK_V12", "D0_V12B", "CHECK_V12B")
# Revision 3 (31 Oct, after CORPUS3; DEC-0009 addendum 2): non-transmission needs a statement that the system
# has no communication component or leaves it to future work (CORPUS3_P4_FINDINGS.md). Revision 2 stays in
# rubric_v1_2.yaml, the text CORPUS3 ran. CHECK_V12C: the camera papers revision 2 split (35, 48, 64, 67), the
# wearable (41) and controls 23 (edge processing that sends only alerts) and 26 (event-triggered upload).
RUBRIC_V1_2_R3 = "rubric/rubric_v1_2_r3.yaml"
V12C = (23, 26, 35, 41, 48, 64, 67)
V12C_CONDITIONS = ("D0_V12C", "CHECK_V12C")
# The 42-paper run (design C, Gabriel's choice 30 Oct; measures in CORPUS_RUN_MEASURES.md): the papers never
# exposed to any run, two arms × 2 executions on the same pipeline. Only the rubric and handbook differ:
# the published package (v1.0 + the EVAL_ORIGINAL handbook) against the refined one (v1.1 + H4).
CORPUS = (3, 4, 5, 7, 8, 10, 11, 12, 13, 15, 19, 20, 22, 23, 24, 26, 29, 30, 33, 35, 37, 39, 41, 44, 45,
          46, 48, 50, 61, 62, 63, 64, 66, 67, 68, 69, 70, 75, 76, 78, 81, 82)
# Earlier corpus freezes, kept and reported. CORPUS (30 Oct) stopped at 15:23 on an Anthropic HTTP 529 the
# transport did not then retry: a stopped attempt, never results. CORPUS2 (v1.1 against v1.0) completed its
# independent round; its v1.1 discussion was refused by the spending limits since removed. Gabriel judged it a
# failed experiment for the final objective (31 Oct) and it is reported as the unseen-paper comparison.
CORPUS_EARLIER = ("D0_CORPUS", "CORPUS_V11", "CORPUS_V10", "D0_CORPUS2", "CORPUS2_V11", "CORPUS2_V10")
CORPUS_EARLIER_ARMS = ("CORPUS_V11", "CORPUS_V10", "CORPUS2_V11", "CORPUS2_V10")
# CORPUS3 (31 Oct, DEC-0009): the complete experiment, v1.2 + H5 against the published package, discussion in
# both arms. Measures in CORPUS_RUN_MEASURES.md (31 Oct addendum).
ARM_V12, ARM_V10 = "CORPUS3_V12", "CORPUS3_V10"
CORPUS_ARMS = {
    ARM_V12: (RUBRIC_V1_2, HANDBOOK_H5),
    ARM_V10: (RUBRIC_V1_0, "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt"),
}
CORPUS_D0, CORPUS_SCHEDULE, CORPUS_SEED = "D0_CORPUS3", "CORPUS3", "corpus3-run-20261031"
# CORPUS3B (31 Oct, Gabriel's choice): the v1.2 arm re-run under revision 3 on the same papers and executions,
# compared with CORPUS3's v1.0 arm, which revision 3 does not touch. D0_V12C is its smoke run (same package).
ARM_V12_R3 = "CORPUS3B_V12"
CORPUS_RERUN = {ARM_V12_R3: (RUBRIC_V1_2_R3, HANDBOOK_H5)}
CORPUS_CONDITIONS = (*CORPUS_EARLIER, CORPUS_D0, *CORPUS_ARMS, *CORPUS_RERUN)
# Conditions frozen with unreadable-resample-v2 (a reply with format failures in some pillars is re-requested)
# and v3 (an incomplete reply too).
RESAMPLE_V2 = ("D0_V12", "CHECK_V12")
RESAMPLE_V3 = ("D0_V12B", "CHECK_V12B", CORPUS_D0, *CORPUS_ARMS, *V12C_CONDITIONS, *CORPUS_RERUN)
# The post-SLR evaluation (approved 10 Nov 2026; PREREGISTRATION_POSTSLR.md, published with its stage 2
# amendment as v2.0 of CH02-OVI-preregistration): v1.2 revision 3 + H5 against the published package on the
# 57 screened papers no rater has seen. Two arms × 2 executions, one schedule interleaving both arms with the
# stage 1 seed, discussion in both arms after R0. The paper set and every input hash are those published in
# the stage 2 amendment's INPUTS_POSTSLR.json; a packet whose bytes differ is refused.
POSTSLR_INPUTS = "docs/postslr-2026-11/INPUTS_POSTSLR.json"
POSTSLR_PRIVATE = ".research-private/postslr-2026-11"
POSTSLR_OFFSET = 10000  # study_id = 10000 + record number (S0021 -> 10021); never one of the packet's 1-82
ARM_POSTSLR_V12, ARM_POSTSLR_V10 = "POSTSLR_V12", "POSTSLR_V10"
POSTSLR_ARMS = {
    ARM_POSTSLR_V12: (RUBRIC_V1_2_R3, HANDBOOK_H5),
    ARM_POSTSLR_V10: (RUBRIC_V1_0, "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt"),
}
POSTSLR_D0, POSTSLR_SCHEDULE, POSTSLR_SEED = "D0_V4", "POSTSLR", "ch2-postslr-20261101"
# unreadable-resample-v4 (1 Nov 2026, Gabriel): up to three re-requests of a failure that shows nothing of the
# judgment, for the next frozen experiment. D0_V4 is its smoke run; that experiment's arms join V4_CONDITIONS.
V4_CONDITIONS = (POSTSLR_D0, *POSTSLR_ARMS)
# The replication (18 Nov 2026, Gabriel's go after the fresh review; docs/rerun-2026-11/, pre-registration
# v3.0): the post-SLR test re-run on the same 57 papers and inputs with three interleaved arms, 2 new
# executions each, a new seed, and the independent round (R0) only. REPL_V12 against REPL_V10 is the
# confirmatory comparison; REPL_V10_NOCONJ is the exploratory ablation, the original procedure without its
# two sentences on how semicolons and OR combine (D42). Settings are those of the completed post-SLR run
# after the code amendment: unreadable-resample-v4, every 5xx retried (transport.py), final check v2, GLM at
# high reasoning. No discussion: the arms are frozen without discussion-v1, so the ledger refuses any round
# above 0.
HANDBOOK_EVAL_ORIGINAL = "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt"
HANDBOOK_NOCONJ = "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL_NOCONJ.txt"
ARM_REPL_V12, ARM_REPL_V10, ARM_REPL_NOCONJ = "REPL_V12", "REPL_V10", "REPL_V10_NOCONJ"
REPL_ARMS = {
    ARM_REPL_V12: (RUBRIC_V1_2_R3, HANDBOOK_H5),
    ARM_REPL_V10: (RUBRIC_V1_0, HANDBOOK_EVAL_ORIGINAL),
    ARM_REPL_NOCONJ: (RUBRIC_V1_0, HANDBOOK_NOCONJ),
}
REPL_D0, REPL_SCHEDULE, REPL_SEED = "D0_REPL", "REPL", "ch2-repl-20261120"
REPL_CONDITIONS = (REPL_D0, *REPL_ARMS)
RESAMPLE_V4 = (*V4_CONDITIONS, *REPL_CONDITIONS)
# Runs frozen with discussion-v1. The D0 runs have it too, so the smoke run exercises the discussion path.
DISCUSSED = (*DISC_RUNS, "D0_V11", "CHECK_V11", "D0_V11B", "CHECK_V11B", "D0_CORPUS", "CORPUS_V11",
             "D0_CORPUS2", "CORPUS2_V11", *V12_CONDITIONS, CORPUS_D0, *CORPUS_ARMS, *V12C_CONDITIONS,
             *CORPUS_RERUN, *V4_CONDITIONS)


def is_glmfix(condition: str) -> bool:
    """Conditions on the GLM follow-up configuration: high reasoning, final check, logged repair."""
    later = ("D0_GLMFIX", *CHECK_CONDITIONS, *DISC_CONDITIONS, *V11_CONDITIONS, *V12_CONDITIONS,
             *V12C_CONDITIONS, *CORPUS_CONDITIONS, *V4_CONDITIONS, *REPL_CONDITIONS)
    return condition in GLMFIX or condition in later


def reminder_for(condition: str) -> str | None:
    """The final check is per condition; discussion conditions use v2, which allows fewer pillars."""
    if condition in (*DISC_CONDITIONS, *V11_CONDITIONS, *V12_CONDITIONS, *V12C_CONDITIONS,
                     *CORPUS_CONDITIONS, *V4_CONDITIONS, *REPL_CONDITIONS):
        return (ROOT / FINAL_CHECK_V2).read_text()
    return (ROOT / GLMFIX_REMINDER).read_text() if is_glmfix(condition) else None


def models_for(condition: str) -> dict:
    return MODELS_GLMFIX if is_glmfix(condition) else MODELS


POLICY = {
    "phase": PHASE,
    "cap_usd": 100,
    "final_reserve_usd": 25,
    "smoke_cap_usd": 3,
    "authorisation": "user:final-phase-2026-10-28-existing-credit-only",
    # Gabriel's console balances on 28 Oct less a US$5 margin;
    # Anthropic is also reduced by ≈US$10.5 for the figure descriptions.
    "provider_limit_usd": {"openai": 45.72, "anthropic": 35.0, "zai": 33.19},
}
# Gabriel, 31 Oct 2026: no spending limits. The policy above stays recorded in the ledger, but nothing
# enforces it; provider credit is the only limit, and a provider's billing error stops the run.
SPENDING_LIMITS = "none: provider credit is the only limit (Gabriel, 31 Oct 2026)"


def location() -> Path:
    return ROOT / ".research-private/final-phase-live-v1"


def population_of(condition: str) -> str:
    fixtures = ("D0_GLMFIX", "D0_V13", "D0_DISC", "D0_DISC_B", "D0_V11", "D0_V11B", "D0_V12", "D0_V12B",
                "D0_CORPUS", CORPUS_D0, "D0_V12C", "D0_V4", REPL_D0)
    if condition == "D0" or condition.startswith("D0_C") or condition in fixtures:
        return "synthetic_fixture"
    if condition.startswith("DEV_C") or condition == "CHECK_V11_DEV":
        return "development"
    held_out = ("EVAL_ORIGINAL", "EVAL_REFINED", *GLMFIX, "CHECK_V13", *DISC_RUNS, "CHECK_V11", "CHECK_V11B")
    if condition in (*held_out, "CHECK_V12", "CHECK_V12B", "CHECK_V12C", *CORPUS_ARMS, *CORPUS_EARLIER_ARMS,
                     *CORPUS_RERUN, *POSTSLR_ARMS, *REPL_ARMS):
        return "final_evaluation"
    raise StudyError("Unknown final-phase condition")


class FinalRecords(PhaseRecords):
    """Final-phase store: own policy, declared paper sets, independent R0 by all three raters only."""

    PHASE_ID = PHASE

    def programme(self, config: dict | None = None) -> dict:
        if config is not None:
            limits = config.get("provider_limit_usd", {})
            if {k: v for k, v in config.items() if k != "provider_limit_usd"} != {
                k: v for k, v in POLICY.items() if k != "provider_limit_usd"
            } or set(limits) != {"openai", "anthropic", "zai"} or any(
                type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in limits.values()
            ):
                raise StudyError("Final phase requires the approved allowance and provider spending caps")
            value = canonical(config)
            with self.db() as db:
                db.execute("INSERT OR IGNORE INTO programme VALUES(?,?)", (PHASE, value))
                if db.execute("SELECT payload FROM programme WHERE id=?", (PHASE,)).fetchone()[0] != value:
                    raise StudyError("Cannot reset final-phase spending or credit limits")
        with self.db() as db:
            row = db.execute("SELECT payload FROM programme WHERE id=?", (PHASE,)).fetchone()
        if row is None:
            raise StudyError("Final-phase allowance not initialised")
        return json.loads(row[0])

    def envelope_guard(self, db, population: str, amount: float, config: dict) -> None:
        """No programme cap, final reserve or D0 allowance (SPENDING_LIMITS)."""

    def additional_budget_guard(self, db, request_id: str, amount: float) -> None:
        """No per-provider caps (SPENDING_LIMITS); spend is still recorded per attempt."""

    def paper_count_ok(self, manifest: dict) -> bool:
        ids = {p["study_id"] for p in manifest["papers"]}
        if manifest.get("condition") == "CHECK_V13":
            return ids == set(CHECK)
        if manifest.get("condition") in DISC_RUNS:
            return ids == set(DISC)
        if manifest.get("condition") == "CHECK_V11":
            return ids == set(V11)
        if manifest.get("condition") == "CHECK_V11B":
            return ids == set(V11B)
        if manifest.get("condition") == "CHECK_V12":
            return ids == set(V12)
        if manifest.get("condition") == "CHECK_V12B":
            return ids == set(V12B)
        if manifest.get("condition") == "CHECK_V12C":
            return ids == set(V12C)
        if manifest.get("condition") in (*CORPUS_ARMS, *CORPUS_EARLIER_ARMS, *CORPUS_RERUN):
            return ids == set(CORPUS)
        if manifest.get("condition") in (*POSTSLR_ARMS, *REPL_ARMS):
            return ids == set(postslr_papers())
        return ids == set(DEV if manifest["population"] == "development" else HELDOUT)

    def create_run(self, manifest: dict, assets: dict[str, bytes]) -> str:
        value = json.loads(canonical(manifest))
        if value["versions"].get("evidence_validator") != VERSION_MD:
            raise StudyError("Final phase requires the qualified md-page-v1 validator")
        if value["population"] != population_of(value["condition"]):
            raise StudyError("Condition/population mismatch; no substitution")
        if value["models"] != json.loads(canonical(models_for(value["condition"]))):
            raise StudyError("Final phase uses only the approved model configuration")
        value["study_phase"] = PHASE
        value["active_raters"] = ["r1", "r2", "r3"]
        return super(PhaseRecords, self).create_run(value, assets)

    def admission(self, manifest: dict) -> None:
        check_final_admission(self, manifest)

    def request(self, run_id, study, rater, round_n, kind, replicate, payload, context):
        """Independent R0 as in the phase; a discussion-v1 run may add rating rounds 1..MAX_ROUNDS only."""
        from pipeline.study.discussion import MAX_ROUNDS

        if round_n and kind == "rating" and replicate == 0:
            m = self.manifest(run_id)
            if (
                m["versions"].get("discussion") == DISCUSSION_POLICY
                and round_n <= MAX_ROUNDS
                and rater in m["active_raters"]
            ):
                return super(PhaseRecords, self).request(
                    run_id, study, rater, round_n, kind, replicate, payload, context
                )
        return super().request(run_id, study, rater, round_n, kind, replicate, payload, context)


def check_final_admission(store: FinalRecords, manifest: dict) -> None:
    """Central store, unchanged policy and code, frozen run, recorded billing state, and a clean D0 first."""
    if store.path != (location() / "programme.sqlite3").resolve() or manifest.get("study_phase") != PHASE:
        raise StudyError("Final phase cannot use an isolated or historical ledger")
    receipt = location() / "ADMISSION.json"
    value = json.loads(receipt.read_text()) if receipt.exists() else {}
    run_id = "run-" + digest(canonical(manifest))[:32]
    if (
        value.get("qualification_passed") is not True
        or value.get("policy") != store.programme()
        or implementation_provenance()["files"] != amended_code(value.get("code_files"), run_id)
        or manifest["code"]["files"] != value["code_files"]
        or value.get("automatic_topups_disabled") is not True
    ):
        raise StudyError("Final-phase qualification, policy, billing record or frozen code drifted")
    if run_id not in value.get("allowed_runs", []):
        raise StudyError("Run is not in the final-phase freeze")
    if manifest["population"] != "synthetic_fixture":
        smoke = value.get("smoke_run")
        exported = store.export(smoke) if smoke else None
        if not exported or not smoke_passed(exported):
            raise StudyError("D0 smoke has not passed for all three raters")


CODE_AMENDMENT = "CODE_AMENDMENT.json"
# The only files a declared amendment may change (post-SLR resume, Gabriel's choice in chat, 12 Nov 2026):
# transport.py retries every HTTP 5xx as DEC-0011 declares; final_phase.py stops a relaunch only on a failure
# it dispatched itself, and carries this guard.
AMENDABLE = ("pipeline/study/final_phase.py", "pipeline/study/transport.py")
POSTSLR_AMENDMENT_REASON = (
    "Post-SLR resume as a declared deviation (Gabriel, 12 Nov 2026): the run stopped on an OpenAI HTTP 520 "
    "that DEC-0011 says is re-requested; transport.py now retries every 5xx, and final_phase.py lets a "
    "relaunch pass requests dispositioned by the earlier launch without re-sending them."
)


def amended_code(frozen: dict | None, run_id: str) -> dict | None:
    """Frozen code hashes, with a declared amendment applied only to its listed runs, files and exact hashes.

    Any other drift, an amendment whose `from` hash is not the frozen one, or a file outside AMENDABLE
    still refuses admission.
    """
    path = location() / CODE_AMENDMENT
    if frozen is None or not path.exists():
        return frozen
    amendment = json.loads(path.read_text())
    if run_id not in amendment.get("runs", []):
        return frozen
    if not amendment.get("approved_by") or not amendment.get("reason"):
        raise StudyError("Code amendment lacks its approval or reason")
    expected = dict(frozen)
    for name, change in amendment.get("files", {}).items():
        if name not in AMENDABLE or frozen.get(name) != change.get("from"):
            raise StudyError("Code amendment does not match the frozen code")
        expected[name] = change["to"]
    return expected


def record_code_amendment(condition: str, reason: str, approved_by: str) -> dict:
    """Write the amendment for a frozen schedule's runs: old and new hashes of exactly the drifted files.

    Refuses when nothing drifted, when a file outside AMENDABLE drifted, or when an amendment exists.
    """
    path = location() / CODE_AMENDMENT
    if path.exists():
        raise StudyError("A code amendment is already recorded; it is never rewritten")
    frozen = json.loads((location() / "ADMISSION.json").read_text())["code_files"]
    current = implementation_provenance()["files"]
    if set(current) != set(frozen):
        raise StudyError("Code file set changed; not amendable")
    drift = {n: {"from": frozen[n], "to": current[n]} for n in sorted(frozen) if frozen[n] != current[n]}
    if not drift or set(drift) - set(AMENDABLE):
        raise StudyError("Nothing to amend, or drift outside the amendable files")
    runs = json.loads((location() / "FREEZE.json").read_text())["conditions"][condition]["runs"]
    value = {
        "condition": condition,
        "runs": sorted(runs),
        "files": drift,
        "reason": reason,
        "approved_by": approved_by,
        "recorded": datetime.now(UTC).isoformat(),
        "provenance": "agent:claude-opus-5-5",
    }
    path.write_text(json.dumps(value, indent=2) + "\n")
    return value


def smoke_passed(exported: dict) -> bool:
    """D0 passes when all twelve R0 judgments validate; discussion rounds and corrections may add more."""
    r0 = [j for j in exported["judgments"] if j["round"] == 0]
    return len(r0) == 12 and not exported["dispositions"]


def write_once(path: Path, data: bytes) -> None:
    if path.exists():
        if path.read_bytes() != data:
            raise StudyError("Frozen packet drift: " + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def procedure(handbook: Path) -> bytes:
    """AI-only rater protocol plus the cycle's handbook text (cycle 0: SCOPE_v1 + CLARIFICATIONS_v1)."""
    base = (ROOT / "calibration/protocol-ai-only-v1.md").read_text()
    return (base + "\n\n" + handbook.read_text()).encode()


def postslr_inputs() -> dict[int, dict]:
    """The published stage 2 input list, by study ID. Refuses an ID outside the declared offset rule."""
    papers = json.loads((ROOT / POSTSLR_INPUTS).read_text())["papers"]
    out = {}
    for p in papers:
        if p["study_id"] != POSTSLR_OFFSET + int(p["record_id"][1:]):
            raise StudyError(f"{p['record_id']}: study ID breaks the post-SLR offset rule")
        out[p["study_id"]] = p
    return out


def postslr_papers() -> tuple[int, ...]:
    return tuple(sorted(postslr_inputs()))


def postslr_paper(sid: int) -> tuple[bytes, str]:
    """PDF bytes and rater text for one post-SLR paper, each at its published hash, or a loud refusal."""
    entry = postslr_inputs().get(sid)
    if entry is None:
        raise StudyError(f"Study {sid} is not in the published post-SLR input list")
    private = ROOT / POSTSLR_PRIVATE
    folder = private / "markdown-v1" / f"study-{sid}"
    conversion = json.loads((folder / "conversion.json").read_text())
    pdf = (private / "papers" / entry["record_id"] / "paper.pdf").read_bytes()
    if not digest(pdf) == conversion["pdf_sha256"] == entry["pdf_sha256"]:
        raise StudyError(f"Study {sid} PDF differs from the published input hash")
    pending = any(f["to_describe"] for f in conversion["figures"])
    source = "paper.described.md" if pending else "paper.md"
    if source != entry["paper_txt_source"]:
        raise StudyError(f"Study {sid} text source differs from the published input list")
    md = (folder / source).read_text()
    if digest(md.encode()) != entry["paper_txt_sha256"]:
        raise StudyError(f"Study {sid} rater text differs from the published input hash")
    return pdf, md


def packet(condition: str, sid: int, handbook: Path, rubric: Path | None = None) -> Path:
    """Exactly the four allowed files; the md-v1 text (with frozen figure descriptions) is the paper text."""
    target = location() / "packets" / condition / str(sid)
    rubric = (rubric or ROOT / RUBRIC_V1_0).read_bytes()
    if sid == 0:
        pdf = (ROOT / "calibration/fixtures/D0.pdf").read_bytes()
        with tempfile.TemporaryDirectory() as folder:
            md = convert(ROOT / "calibration/fixtures/D0.pdf", Path(folder) / "figures")["markdown"]
    elif sid >= POSTSLR_OFFSET:
        pdf, md = postslr_paper(sid)
    else:
        folder = ROOT / ".research-private/markdown-v1" / f"study-{sid}"
        conversion = json.loads((folder / "conversion.json").read_text())
        pdf = next((ROOT / "reviewer_packet/papers").glob(f"{sid}.*.pdf")).read_bytes()
        if digest(pdf) != conversion["pdf_sha256"]:
            raise StudyError(f"Study {sid} PDF differs from the md-v1 conversion source")
        described = folder / "paper.described.md"
        pending = any(f["to_describe"] for f in conversion["figures"])
        if pending and not described.exists():
            raise StudyError(f"Study {sid} figure descriptions are not frozen yet")
        md = (described if pending else folder / "paper.md").read_text()
    for name, data in {
        "paper.pdf": pdf,
        "paper.txt": md.encode(),
        "rubric.yaml": rubric,
        "protocol.md": procedure(handbook),
    }.items():
        write_once(target / name, data)
    return target


def freeze(
    condition: str,
    papers: tuple[int, ...],
    executions: tuple[int, ...],
    handbook: Path,
    rubric: Path | None = None,
) -> list[str]:
    """Freeze runs and their randomised request schedule; append to FREEZE.json without rewriting it.

    The rubric defaults to the published v1.0; a run frozen with another version records its hash.
    """
    store = FinalRecords(location() / "programme.sqlite3")
    store.programme(POLICY)
    paths = {sid: packet(condition, sid, handbook, rubric) for sid in papers}
    code = implementation_provenance()
    runs = []
    for execution in executions:
        runs.append(
            freeze_run(
                store,
                population=population_of(condition),
                condition=condition,
                execution=execution,
                packet_paths=paths,
                models=models_for(condition),
                limits={"max_prompt_utf8_bytes": 320000},
                seed="final-phase-20261028",
                schema=json.loads((ROOT / "docs/study-2026-09-28/judgment.schema.json").read_text()),
                code=code,
                validator_version=VERSION_MD,
                final_reminder=reminder_for(condition),
                response_policy=REPAIR_POLICY if is_glmfix(condition) else None,
                # md-page-v1.3 runs (29 Oct): one quote self-correction turn per evidence-failed response.
                evidence_correction=CORRECTION_POLICY,
                discussion=DISCUSSION_POLICY if condition in DISCUSSED else None,
                # 30 Oct, after CHECK_V11B: a wholly unreadable reply is re-requested once (all raters);
                # 31 Oct, after CORPUS2: so is one with format failures in some pillars (v2).
                unreadable_resample=(
                    RESAMPLE_POLICY_V4 if condition in RESAMPLE_V4
                    else RESAMPLE_POLICY_V3 if condition in RESAMPLE_V3
                    else RESAMPLE_POLICY_V2 if condition in RESAMPLE_V2
                    else RESAMPLE_POLICY if is_glmfix(condition) else None
                ),
            )
        )
    rng = random.Random(digest(canonical([condition, runs])))
    schedule = []
    for run in runs:
        raters = ("r2",) if condition in GLMFIX else ("r1", "r2", "r3")
        order = [(sid, r) for sid in papers for r in raters]
        rng.shuffle(order)
        for sid, rater in order:
            m = store.manifest(run)
            prompt, _ = build_prompt(store, run, sid, list(PILLARS))
            schedule.append({
                "run_id": run, "study": sid, "rater": rater,
                "payload_sha256": digest(canonical(payload_for(m["models"][rater], prompt))),
            })
    path = location() / "FREEZE.json"
    frozen = json.loads(path.read_text()) if path.exists() else {"phase": PHASE, "conditions": {}}
    entry = {"runs": runs, "schedule": schedule, "handbook_sha256": digest(handbook.read_bytes())}
    if rubric is not None:
        entry["rubric_sha256"] = digest(rubric.read_bytes())
    if condition in frozen["conditions"] and frozen["conditions"][condition] != entry:
        raise StudyError("Condition already frozen with different inputs")
    frozen["conditions"][condition] = entry
    path.write_text(json.dumps(frozen, indent=2) + "\n")
    return runs


QUALIFICATION = "docs/final-phase-2026-10-28/QUALIFICATION_MD_V1_3.json"


BILLING_28_OCT = (
    "Gabriel pasted OpenAI, Anthropic and Z.AI console pages on 28 Oct 2026: "
    "auto-reload/auto-recharge OFF on all three; balances US$50.72, US$50.64, US$38.19."
)


def admit(smoke_run: str | None = None, billing_evidence: str = BILLING_28_OCT) -> dict:
    """Record the admission receipt from verifiable facts only; the D0 run is added once it has passed.

    The billing evidence is Gabriel's latest report of console balances and top-up settings, quoted as given.
    """
    if not billing_evidence.strip():
        raise StudyError("Admission needs Gabriel's billing evidence")
    qualification = json.loads((ROOT / QUALIFICATION).read_text())
    if qualification["validator"] != VERSION_MD:
        raise StudyError("Qualification record is for a different validator version")
    frozen = json.loads((location() / "FREEZE.json").read_text())
    store = FinalRecords(location() / "programme.sqlite3")
    receipt = {
        "phase": PHASE,
        "qualification_passed": qualification["passed"] == qualification["total"] == 72,
        "policy": store.programme(),
        "code_files": implementation_provenance()["files"],
        "allowed_runs": sorted(r for c in frozen["conditions"].values() for r in c["runs"]),
        "spending_limits": SPENDING_LIMITS,
        "automatic_topups_disabled": True,
        "billing_evidence": billing_evidence,
    }
    if smoke_run:
        exported = store.export(smoke_run)
        if not smoke_passed(exported):
            raise StudyError("Refusing to record a D0 run that did not pass cleanly")
        receipt["smoke_run"] = smoke_run
    (location() / "ADMISSION.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


EVAL_HANDBOOKS = {
    "EVAL_ORIGINAL": "docs/final-phase-2026-10-28/HANDBOOK_EVAL_ORIGINAL.txt",
    "EVAL_REFINED": "docs/final-phase-2026-10-28/HANDBOOK_C3.txt",
}


def interleave(rows: list[dict], seed: str) -> list[dict]:
    """One seeded order across both arms, so neither arm systematically runs first or later."""
    order = list(rows)
    random.Random(seed).shuffle(order)
    return order


def freeze_eval() -> dict:
    """Freeze both held-out arms (3 executions each) and one interleaved dispatch schedule "EVAL"."""
    for condition, handbook in EVAL_HANDBOOKS.items():
        freeze(condition, HELDOUT, (1, 2, 3), ROOT / handbook)
    path = location() / "FREEZE.json"
    frozen = json.loads(path.read_text())
    arms = [frozen["conditions"][c] for c in EVAL_HANDBOOKS]
    entry = {
        "runs": [r for arm in arms for r in arm["runs"]],
        "schedule": interleave([row for arm in arms for row in arm["schedule"]], "final-eval-20261028"),
        "handbook_sha256": {c: frozen["conditions"][c]["handbook_sha256"] for c in EVAL_HANDBOOKS},
    }
    if "EVAL" in frozen["conditions"] and frozen["conditions"]["EVAL"] != entry:
        raise StudyError("Evaluation schedule already frozen with different inputs")
    frozen["conditions"]["EVAL"] = entry
    path.write_text(json.dumps(frozen, indent=2) + "\n")
    return entry


def freeze_arms(arms: dict, papers: tuple[int, ...], schedule: str, seed: str) -> dict:
    """Freeze each arm (2 executions) and one schedule interleaving them; refuses a changed refreeze."""
    for condition, (rubric, handbook) in arms.items():
        freeze(condition, papers, (1, 2), ROOT / handbook, rubric=ROOT / rubric)
    path = location() / "FREEZE.json"
    frozen = json.loads(path.read_text())
    frozen_arms = [frozen["conditions"][c] for c in arms]
    entry = {
        "runs": [r for arm in frozen_arms for r in arm["runs"]],
        "schedule": interleave([row for arm in frozen_arms for row in arm["schedule"]], seed),
        "handbook_sha256": {c: frozen["conditions"][c]["handbook_sha256"] for c in arms},
        "rubric_sha256": {c: frozen["conditions"][c]["rubric_sha256"] for c in arms},
    }
    if schedule in frozen["conditions"] and frozen["conditions"][schedule] != entry:
        raise StudyError(f"Schedule {schedule} already frozen with different inputs")
    frozen["conditions"][schedule] = entry
    path.write_text(json.dumps(frozen, indent=2) + "\n")
    return entry


def freeze_corpus() -> dict:
    """Freeze both arms (2 executions each) and one interleaved independent-round schedule CORPUS3."""
    return freeze_arms(CORPUS_ARMS, CORPUS, CORPUS_SCHEDULE, CORPUS_SEED)


def freeze_postslr() -> dict:
    """D0_V4 on the revision 3 package, then both post-SLR arms and the interleaved POSTSLR schedule."""
    rubric, handbook = POSTSLR_ARMS[ARM_POSTSLR_V12]
    freeze(POSTSLR_D0, (0,), (1,), ROOT / handbook, rubric=ROOT / rubric)
    return freeze_arms(POSTSLR_ARMS, postslr_papers(), POSTSLR_SCHEDULE, POSTSLR_SEED)


def freeze_repl() -> dict:
    """D0_REPL on the revision 3 package (R0 only), then the three replication arms and the REPL schedule.

    Refuses unless the post-SLR schedule is already frozen in this FREEZE.json, so the replication's run IDs
    can be checked against it. The collision check is a backstop that runs after writing: a run ID hashes its
    manifest, which names the condition, so it cannot match an earlier run; if it ever fired, nothing may be
    admitted or dispatched and the freeze must be investigated.
    """
    frozen = json.loads((location() / "FREEZE.json").read_text())["conditions"]
    if POSTSLR_SCHEDULE not in frozen:
        raise StudyError("The replication freezes beside the post-SLR test; its schedule is missing")
    earlier = {r for c, v in frozen.items() if c not in (*REPL_CONDITIONS, REPL_SCHEDULE) for r in v["runs"]}
    rubric, handbook = REPL_ARMS[ARM_REPL_V12]
    smoke = freeze(REPL_D0, (0,), (1,), ROOT / handbook, rubric=ROOT / rubric)
    entry = freeze_arms(REPL_ARMS, postslr_papers(), REPL_SCHEDULE, REPL_SEED)
    if earlier & {*smoke, *entry["runs"]}:
        raise StudyError("A replication run ID collides with an earlier frozen run")
    return {**entry, "smoke_runs": smoke}


def provider_spend(store: FinalRecords) -> dict[str, float]:
    """Charged, or still reserved, per provider across this ledger, for comparison with the consoles."""
    with store.db() as db:
        return {p: round(provider_spent(db, p), 4) for p in ("openai", "anthropic", "zai")}


def discuss_corpus(arm: str, execution: int, *, dispatcher=None) -> dict:
    """Discussion for one arm's execution; only a provider's billing error stops it."""
    from pipeline.study.discussion import discuss
    from pipeline.study.transport import Dispatcher

    store = FinalRecords(location() / "programme.sqlite3")
    runs = json.loads((location() / "FREEZE.json").read_text())["conditions"][arm]["runs"]
    run = runs[execution - 1]
    store.admission(store.manifest(run))
    outcome = discuss(store, run, dispatcher or Dispatcher(store))
    return {"arm": arm, "run": run, "spend_before": provider_spend(store), "discussion": outcome}


INTERRUPTED = "Unknown interrupted provider attempt"  # transport._stage: a reservation with no reply
INPUT_FAILURE = "Unusable page-aware common text"  # scoring.freeze_run: a paper flagged at freeze


def provider_error(last: dict) -> str:
    """The provider's error type, code and message (first 100 characters) from the stored, key-redacted
    body of a failed reply, so a balance or quota message is visible in the stop line."""
    raw = last.get("observable_response_base64")
    if not raw or last.get("http_status") in (None, 200):
        return ""
    try:
        error = json.loads(base64.b64decode(raw)).get("error")
    except (ValueError, AttributeError):
        return ""
    if not isinstance(error, dict):
        return f"; provider error: {str(error)[:100]}" if error else ""
    parts = [str(error.get(k)) for k in ("type", "code") if error.get(k)]
    message = " ".join(str(error.get("message", "")).split())[:100]
    return "; provider error: " + "/".join(parts) + (f" {message}" if message else "")


CREDIT_WORDS = ("balance", "credit", "quota", "billing", "payment", "arrears", "insufficient")
CREDIT_CODES = re.compile(r"\b1113\b")  # Z.AI's balance code, as a string or a number
INCOMPLETE = "Incomplete observable output"  # transport._attempt: a 200 reply cut short, a recorded outcome


def stop_cause(result: dict, done: list[dict]) -> str | None:
    """Whether a request this launch dispositioned stops the run, and why (None: carry on).

    Carry on after a success, a recorded content outcome (format or evidence failure, including a provider
    failure inside the format-recovery or quotation-correction turn, which ends as one), an incomplete 200
    reply, a paper whose input was flagged at freeze, and a request in flight at an earlier interruption
    (parked by the transport, never re-sent). Stop, with a cause the replication's stopping rules act on
    (PREREGISTRATION_REPLICATION.md):
    - "credit, billing or configuration": a non-200 status that is not transient, or any provider error
      whose text mentions balance, credit, quota, billing, payment, arrears or insufficient funds;
    - "provider outage": a transient 5xx or 429 that outlasted every retry and re-request;
    - "network or transport": a connection error or timeout (no HTTP status) that outlasted them;
    - "model identity change";
    - "runner refusal": a failure before any provider reply (credential, admission, code drift, budget
      guard), including one after an earlier failed attempt, or a 200 reply the runner refuses (usage beyond
      the reservation, an echoed secret, a missing model identity, an unreadable provider envelope).
    The disposition reason is quoted in the cause line.
    """
    last = done[-1] if done else {}
    status = last.get("http_status")
    disposition = result.get("disposition") or {}
    reason, kind = str(disposition.get("reason", "")), disposition.get("status")
    error = str(last.get("error", ""))
    detail = provider_error(last)
    tail = f"; HTTP {status}{detail}; reason: {' '.join(reason.split())[:100]})"
    if any(c.get("model_change") for c in done) or kind == "model_change":
        return "(cause: model identity change" + tail
    if result.get("status") == "succeeded" or INTERRUPTED in reason or reason.startswith(INPUT_FAILURE):
        return None
    if kind in ("format_failure", "evidence_failure"):
        return None
    if kind == "resource_stop" or not done or (kind == "process_failure" and reason != error):
        return "(cause: runner refusal" + tail
    if any(word in detail.lower() for word in CREDIT_WORDS) or CREDIT_CODES.search(detail):
        return "(cause: credit, billing or configuration" + tail
    if status not in (None, 200):
        transient = last.get("retryable") and (status == 429 or 500 <= status <= 599)
        return ("(cause: provider outage" if transient else "(cause: credit, billing or configuration") + tail
    if status is None:
        return ("(cause: network or transport" if last.get("retryable") else "(cause: runner refusal") + tail
    if status == 200 and error and not error.startswith(INCOMPLETE):
        return "(cause: runner refusal" + tail
    return None


def run_condition(condition: str, *, dispatcher=None) -> dict:
    """Dispatch a frozen schedule in order; stop on billing, identity or provider configuration errors."""
    from pipeline.study.transport import Dispatcher

    frozen = json.loads((location() / "FREEZE.json").read_text())["conditions"][condition]
    store = FinalRecords(location() / "programme.sqlite3")
    dispatcher = dispatcher or Dispatcher(store)
    statuses = []
    for row in frozen["schedule"]:
        m = store.manifest(row["run_id"])
        store.admission(m)
        prompt, context = build_prompt(store, row["run_id"], row["study"], list(PILLARS))
        payload = payload_for(m["models"][row["rater"]], prompt)
        if digest(canonical(payload)) != row["payload_sha256"]:
            raise StudyError("Frozen request changed")
        q = store.request(row["run_id"], row["study"], row["rater"], 0, "rating", 0, payload, context)
        try:
            result = dispatcher.execute(q)
        except BudgetStop as stop:
            return {"condition": condition, "stopped": str(stop), "dispositioned": len(statuses)}
        statuses.append(result["status"])
        print(canonical({**row, "request_id": q, "status": result["status"]}), flush=True)
        exported = store.export(row["run_id"])
        attempts = {a["id"] for a in exported["attempts"] if a["request_id"] == q}
        done = [c["result"] for c in exported["completions"] if c["attempt_id"] in attempts]
        # Only a failure dispatched by this launch stops it: a request dispositioned by an earlier launch was
        # handled when that launch stopped, and is skipped, never re-sent (post-SLR resume, 12 Nov 2026).
        cause = None if result.get("reused") else stop_cause(result, done)
        if cause:
            raise StudyError("Provider/configuration/credit error preserved; stopped without top-up " + cause)
    return {"condition": condition, "dispositioned": len(statuses), "statuses": statuses}


def run_discussion(condition: str, *, dispatcher=None) -> dict:
    """Frozen independent R0 schedule first, then discussion-v1 rounds run by run; resumable."""
    from pipeline.study.discussion import discuss
    from pipeline.study.transport import Dispatcher

    store = FinalRecords(location() / "programme.sqlite3")
    dispatcher = dispatcher or Dispatcher(store)
    initial = run_condition(condition, dispatcher=dispatcher)
    if "stopped" in initial:
        return initial
    runs = json.loads((location() / "FREEZE.json").read_text())["conditions"][condition]["runs"]
    discussed = {r: discuss(store, r, dispatcher) for r in runs}
    return {"condition": condition, "r0": initial, "discussion": discussed}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    actions = ["freeze-smoke", "admit", "smoke", "freeze-dev", "dev", "freeze-eval", "eval"]
    actions += ["freeze-glmfix", "glmfix", "freeze-check", "check-smoke", "check"]
    actions += ["freeze-disc", "disc-smoke", "disc"]
    actions += ["freeze-v11", "v11-smoke", "v11", "v11-dev", "freeze-v11b", "v11b-smoke", "v11b"]
    actions += ["freeze-v12", "v12-smoke", "v12", "freeze-v12b", "v12b-smoke", "v12b"]
    actions += ["freeze-corpus", "corpus-smoke", "corpus", "corpus-spend", "corpus-disc"]
    actions += ["freeze-v12c", "v12c-smoke", "v12c", "freeze-corpus3b", "corpus3b"]
    actions += ["freeze-postslr", "postslr-smoke", "postslr", "amend-postslr-code"]
    actions += ["freeze-repl", "repl-smoke", "repl"]
    ap.add_argument("action", choices=actions)
    ap.add_argument("--smoke-run")
    ap.add_argument("--billing-evidence", default=BILLING_28_OCT)
    ap.add_argument("--execution", type=int, choices=(1, 2))
    ap.add_argument("--arm", choices=(*CORPUS_ARMS, *CORPUS_RERUN, *POSTSLR_ARMS))
    ap.add_argument("--cycle", type=int, default=0)
    ap.add_argument("--handbook", type=Path, default=ROOT / "docs/final-phase-2026-10-28/HANDBOOK_C0.txt")
    a = ap.parse_args()
    if a.action == "freeze-smoke":
        # Each model-configuration change needs its own D0; cycle 0 keeps the original "D0" label.
        print(freeze("D0" if a.cycle == 0 else f"D0_C{a.cycle}", (0,), (1,), a.handbook))
    elif a.action == "admit":
        print(json.dumps(admit(a.smoke_run, a.billing_evidence), indent=1)[:600])
    elif a.action == "smoke":
        print(canonical(run_condition("D0")))
    elif a.action == "freeze-eval":
        entry = freeze_eval()
        print(json.dumps({"runs": entry["runs"], "requests": len(entry["schedule"])}))
    elif a.action == "eval":
        print(canonical(run_condition("EVAL")))
    elif a.action == "freeze-glmfix":
        print(freeze("D0_GLMFIX", (0,), (1,), ROOT / GLMFIX["GLMFIX_REFINED"]))
        for condition, handbook in GLMFIX.items():
            print(condition, freeze(condition, HELDOUT, (1, 2, 3), ROOT / handbook))
    elif a.action == "glmfix":
        for condition in GLMFIX:
            print(canonical(run_condition(condition)))
    elif a.action == "freeze-check":
        print("D0_V13", freeze("D0_V13", (0,), (1,), ROOT / CHECK_HANDBOOK))
        print("CHECK_V13", freeze("CHECK_V13", CHECK, (1, 2, 3), ROOT / CHECK_HANDBOOK))
    elif a.action == "check-smoke":
        print(canonical(run_condition("D0_V13")))
    elif a.action == "check":
        print(canonical(run_condition("CHECK_V13")))
    elif a.action == "freeze-disc":
        print("D0_DISC_B", freeze("D0_DISC_B", (0,), (1,), ROOT / CHECK_HANDBOOK))
        print("DISC_V13_B", freeze("DISC_V13_B", DISC, (1, 2), ROOT / CHECK_HANDBOOK))
    elif a.action == "disc-smoke":
        print(canonical(run_condition("D0_DISC_B")))
    elif a.action == "disc":
        print(canonical(run_discussion("DISC_V13_B")))
    elif a.action == "freeze-v11":
        v11 = {"handbook": ROOT / HANDBOOK_H4, "rubric": ROOT / RUBRIC_V1_1}
        print("D0_V11", freeze("D0_V11", (0,), (1,), **v11))
        print("CHECK_V11", freeze("CHECK_V11", V11, (1, 2), **v11))
        print("CHECK_V11_DEV", freeze("CHECK_V11_DEV", DEV, (1,), **v11))
    elif a.action == "v11-smoke":
        print(canonical(run_discussion("D0_V11")))
    elif a.action == "v11":
        print(canonical(run_discussion("CHECK_V11")))
    elif a.action == "v11-dev":
        print(canonical(run_condition("CHECK_V11_DEV")))
    elif a.action == "freeze-v11b":
        v11 = {"handbook": ROOT / HANDBOOK_H4, "rubric": ROOT / RUBRIC_V1_1}
        print("D0_V11B", freeze("D0_V11B", (0,), (1,), **v11))
        print("CHECK_V11B", freeze("CHECK_V11B", V11B, (1, 2), **v11))
    elif a.action == "v11b-smoke":
        print(canonical(run_discussion("D0_V11B")))
    elif a.action == "v11b":
        print(canonical(run_discussion("CHECK_V11B")))
    elif a.action == "freeze-v12":
        v12 = {"handbook": ROOT / HANDBOOK_H5, "rubric": ROOT / RUBRIC_V1_2}
        print("D0_V12", freeze("D0_V12", (0,), (1,), **v12))
        print("CHECK_V12", freeze("CHECK_V12", V12, (1, 2), **v12))
    elif a.action == "v12-smoke":
        print(canonical(run_discussion("D0_V12")))
    elif a.action == "v12":
        print(canonical(run_discussion("CHECK_V12")))
    elif a.action == "freeze-v12b":
        v12 = {"handbook": ROOT / HANDBOOK_H5, "rubric": ROOT / RUBRIC_V1_2}
        print("D0_V12B", freeze("D0_V12B", (0,), (1,), **v12))
        print("CHECK_V12B", freeze("CHECK_V12B", V12B, (1, 2), **v12))
    elif a.action == "v12b-smoke":
        print(canonical(run_discussion("D0_V12B")))
    elif a.action == "v12b":
        print(canonical(run_discussion("CHECK_V12B")))
    elif a.action == "freeze-v12c":
        r3 = {"handbook": ROOT / HANDBOOK_H5, "rubric": ROOT / RUBRIC_V1_2_R3}
        print("D0_V12C", freeze("D0_V12C", (0,), (1,), **r3))
        print("CHECK_V12C", freeze("CHECK_V12C", V12C, (1, 2), **r3))
    elif a.action == "v12c-smoke":
        print(canonical(run_discussion("D0_V12C")))
    elif a.action == "v12c":
        print(canonical(run_discussion("CHECK_V12C")))
    elif a.action == "freeze-corpus3b":
        r3 = {"handbook": ROOT / HANDBOOK_H5, "rubric": ROOT / RUBRIC_V1_2_R3}
        print(ARM_V12_R3, freeze(ARM_V12_R3, CORPUS, (1, 2), **r3))
    elif a.action == "corpus3b":
        # Independent round only; discussion follows per execution with corpus-disc --arm CORPUS3B_V12.
        print(canonical(run_condition(ARM_V12_R3)))
    elif a.action == "freeze-corpus":
        print(CORPUS_D0, freeze(CORPUS_D0, (0,), (1,), ROOT / HANDBOOK_H5, rubric=ROOT / RUBRIC_V1_2))
        entry = freeze_corpus()
        print(json.dumps({"runs": entry["runs"], "requests": len(entry["schedule"])}))
    elif a.action == "corpus-smoke":
        print(canonical(run_discussion(CORPUS_D0)))
    elif a.action == "corpus":
        print(canonical(run_condition(CORPUS_SCHEDULE)))
    elif a.action == "corpus-spend":
        print(canonical(provider_spend(FinalRecords(location() / "programme.sqlite3"))))
    elif a.action == "corpus-disc":
        if a.execution is None or a.arm is None:
            ap.error("corpus-disc needs --arm and --execution 1 or 2")
        print(canonical(discuss_corpus(a.arm, a.execution)))
    elif a.action == "freeze-postslr":
        entry = freeze_postslr()
        print(json.dumps({"smoke": POSTSLR_D0, "runs": entry["runs"], "requests": len(entry["schedule"])}))
    elif a.action == "postslr-smoke":
        print(canonical(run_discussion(POSTSLR_D0)))
    elif a.action == "amend-postslr-code":
        approval = "Gabriel Carvalho, in chat, 12 Nov 2026 ('Narrow code amendment')"
        value = record_code_amendment(POSTSLR_SCHEDULE, POSTSLR_AMENDMENT_REASON, approval)
        print(json.dumps(value, indent=2))
    elif a.action == "postslr":
        # Independent round of both arms; discussion follows per arm and execution with corpus-disc --arm.
        print(canonical(run_condition(POSTSLR_SCHEDULE)))
    elif a.action == "freeze-repl":
        entry = freeze_repl()
        print(json.dumps({
            "smoke": REPL_D0, "smoke_runs": entry["smoke_runs"], "seed": REPL_SEED,
            "runs": entry["runs"], "requests": len(entry["schedule"]),
            "rubric_sha256": entry["rubric_sha256"], "handbook_sha256": entry["handbook_sha256"],
        }, indent=1))
    elif a.action == "repl-smoke":
        # R0 only, as the replication arms: the smoke run exercises exactly the path the run takes.
        print(canonical(run_condition(REPL_D0)))
    elif a.action == "repl":
        # Independent round of the three arms, interleaved; no discussion stage (pre-registration v3.0).
        print(canonical(run_condition(REPL_SCHEDULE)))
    elif a.action == "freeze-dev":
        print(freeze(f"DEV_C{a.cycle}", DEV, (1, 2), a.handbook))
    else:
        print(canonical(run_condition(f"DEV_C{a.cycle}")))


if __name__ == "__main__":
    main()
