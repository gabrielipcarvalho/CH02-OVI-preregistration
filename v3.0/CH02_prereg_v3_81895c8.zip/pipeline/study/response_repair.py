"""glm-repair-v1/v2: declared, logged structural repairs; no score, status, quote or locator is changed.

Exploratory GLM follow-up (28 Oct 2026). Applied only to runs whose manifest names this policy.
v2 (29 Oct): an extra cell labelled as a note or duplicate of one pillar ("P2 duplicate check",
"P1-dup", "P4_note") is dropped when it repeats that pillar's score and status; if it conflicts,
the response is left unchanged and stays a format failure. Runs frozen under v1 keep v1.
"""

from __future__ import annotations

import json
import re

POLICY = "glm-repair-v2"
POLICY_V1 = "glm-repair-v1"
LABELLED = re.compile(
    r"^\s*(P[1-4])\s*[-_ (]+\s*(?:dup(?:licate)?|check|note|copy|repeat)\b[\w\s()-]*$", re.I
)
PLACEHOLDER = re.compile(r"placeholder|duplicate|see above", re.I)
PILLARS = ("P1", "P2", "P3", "P4")


def _load(text: str):
    clean = text.strip()
    if "```" in clean:
        blocks = re.findall(r"```(?:json)?\s*\n(.*?)\n```", clean, flags=re.S)
        if len(blocks) != 1:
            return None
        clean = blocks[0]
    try:
        value = json.loads(clean)
    except ValueError:
        return None
    return value if isinstance(value, dict) and isinstance(value.get("cells"), list) else None


def _redundant(extra: dict, first: dict) -> bool:
    """An extra cell may be dropped only if it changes nothing scientific about the first one."""
    if extra == first:
        return True
    if extra.get("score") != first.get("score") or extra.get("status") != first.get("status"):
        return False
    filler = " ".join(str(extra.get(k, "")) for k in ("quote", "reason"))
    return not str(extra.get("quote", "")).strip() or bool(PLACEHOLDER.search(filler))


def repair(text: str, policy: str = POLICY) -> tuple[str, list[dict]]:
    """Return (text to validate, actions). Unrepairable or conflicting responses are returned unchanged."""
    if policy not in (POLICY, POLICY_V1):
        raise ValueError("Unknown response repair policy")
    value = _load(text)
    if value is None or any(not isinstance(c, dict) for c in value["cells"]):
        return text, []
    if any(not isinstance(c.get("pillar"), (str, type(None))) for c in value["cells"]):
        return text, []  # e.g. "pillar": ["P1"]: unreadable, left to validation, never a crash (18 Nov)
    actions, kept, first = [], [], {}
    coded = {c.get("pillar"): c for c in value["cells"] if c.get("pillar") in PILLARS}
    for cell in value["cells"]:
        pillar = cell.get("pillar")
        label = LABELLED.match(pillar) if policy == POLICY and isinstance(pillar, str) else None
        if label:
            target = coded.get(label[1].upper())
            same = target is not None and (cell.get("score"), cell.get("status")) == (
                target.get("score"),
                target.get("status"),
            )
            if not same:
                return text, []  # a conflicting or orphan labelled cell stays an ambiguous response
            actions.append({"action": "drop_labelled_duplicate", "pillar": label[1].upper(), "label": pillar})
            continue
        if pillar in first:
            if not _redundant(cell, first[pillar]):
                return text, []  # a substantive conflict stays an ambiguous response
            actions.append({"action": "drop_redundant_duplicate", "pillar": pillar})
            continue
        first[pillar] = cell
        kept.append(cell)
    for cell in kept:
        d = cell.get("anonymous_defence")
        own = (cell.get("quote"), cell.get("locator"))
        if isinstance(d, dict) and (d.get("quote"), d.get("locator")) != own:
            # R0-only runs never use the defence; restore it as the exact copy the schema requires.
            d["quote"], d["locator"] = cell.get("quote"), cell.get("locator")
            actions.append({"action": "restore_defence_copy", "pillar": cell.get("pillar")})
    if not actions:
        return text, []
    value["cells"] = kept
    return json.dumps(value, ensure_ascii=False), actions
