"""quote-correction-v1: one self-correction turn for cells whose quote failed evidence verification.

Approved by Gabriel on 29 Oct 2026 for runs frozen under md-page-v1.3; applied only to runs whose manifest
names this policy. The same rater sees its own response and the validator's reason, and may re-copy the
quote and locator only. Score, status, reason, alternative and confidence come from the original cell
whatever the reply says, and the new quote must pass the same validator. A correction can therefore move
the evidence onto verbatim text; it can never change a judgment.
"""

from __future__ import annotations

import copy
import json
import re

from pipeline.study.records import StudyError

POLICY = "quote-correction-v1"
FIELDS = ("quote", "locator")


def prompt(cells: dict[str, dict], failures: dict[str, dict]) -> str:
    """Name each failed pillar with the rater's own quote, locator and the validator's reason."""
    lines = [
        f"QUOTE CHECK ({POLICY}). Your judgments above are kept exactly as given. For the pillars below, "
        "the quote was not found verbatim on the PDF page your locator names, so the judgment cannot be "
        "used yet.",
        "Copy the supporting passage again, character for character, from the paper text above: one "
        "contiguous passage of the authors' own words, with no ellipses, paraphrase, added or dropped words, "
        "and never from a FIGURE DESCRIPTION block. Start the locator with 'PDF page N', N being the "
        "[PDF PAGE N] marker above where the passage starts.",
        "Score, status, reason and alternative cannot be changed here and are ignored if sent. If no "
        "verbatim passage supports your judgment, return your original quote unchanged.",
        'Return only JSON: {"cells":[{"pillar":"P1","quote":"...","locator":"PDF page N; context: ..."}]}',
        "",
    ]
    for pillar in sorted(failures):
        lines.append(
            f"{pillar}: your quote: {json.dumps(cells[pillar].get('quote'), ensure_ascii=False)}; "
            f"your locator: {json.dumps(cells[pillar].get('locator'), ensure_ascii=False)}; "
            f"check result: {failures[pillar]['reason']}"
        )
    return "\n".join(lines)


def payload(request: dict, provider: str, original: str, text: str) -> dict:
    """The frozen request continued by the rater's own reply and the check: same settings, same paper."""
    corrected = copy.deepcopy(request)
    turns = [{"role": "assistant", "content": original}, {"role": "user", "content": text}]
    if provider == "openai":
        corrected["input"] = [{"role": "user", "content": request["input"]}, *turns]
    else:
        corrected["messages"] = [*request["messages"], *turns]
    return corrected


def parse(text: str, pillars: set[str]) -> dict[str, dict]:
    """Exactly one {pillar, quote, locator} per returned pillar, all of them requested; nothing inferred."""
    clean = text.strip()
    if "```" in clean:
        blocks = re.findall(r"```(?:json)?\s*\n(.*?)\n```", clean, flags=re.S)
        if len(blocks) != 1:
            raise StudyError("Quote correction: ambiguous JSON blocks")
        clean = blocks[0]
    value = json.loads(clean)
    cells = value.get("cells") if isinstance(value, dict) else None
    if not isinstance(cells, list):
        raise StudyError("Quote correction: no cells array")
    result = {}
    for c in cells:
        if not isinstance(c, dict) or c.get("pillar") not in pillars or c["pillar"] in result:
            raise StudyError("Quote correction: unrequested or repeated pillar")
        if not all(isinstance(c.get(f), str) for f in FIELDS):
            raise StudyError("Quote correction: quote and locator must be strings")
        result[c["pillar"]] = {f: c[f] for f in FIELDS}
    return result


def merge(cell: dict, reply: dict) -> dict:
    """The original cell with only quote and locator replaced, in the cell and its defence copy alike."""
    merged = copy.deepcopy(cell)
    for field in FIELDS:
        merged[field] = reply[field]
        if isinstance(merged.get("anonymous_defence"), dict):
            merged["anonymous_defence"][field] = reply[field]
    return merged
