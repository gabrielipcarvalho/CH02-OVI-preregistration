"""discussion-v1: reconciliation rounds after independent R0, for contested pillars only (29 Oct 2026).

Approved by Gabriel for an exploratory check. R0 stays the independent reliability measure; discussion
is a separate, dependent reconciliation stage and is always reported apart from it.

- A pillar is *resolved* when all three raters score it the same, or all three give the same non-scored
  status (e.g. applicability_uncertain under D1). Resolved pillars are never discussed.
- A pillar is *contested* when all three raters returned a valid judgment that does not resolve it.
  A pillar with a failed judgment is excluded: a failure is never argued away.
- Each round, every rater sees its own preceding judgment and its peers' anonymous arguments with their
  status and score, in a seeded random order. An argument naming a model or a vote tally is withheld.
- A pillar stops when it resolves, when no rater changes status or score in a round (stable
  disagreement), when a rater's revision fails, or after MAX_ROUNDS rounds.
"""

from __future__ import annotations

import json
import random

from pipeline.study.records import PILLARS, RATERS, Records, StudyError, canonical, digest, stamp
from pipeline.study.scoring import DISCUSSION_POLICY as POLICY
from pipeline.study.scoring import IDENTITY, TALLY, build_prompt, payload_for

MAX_ROUNDS = 3


def verdict(cell: dict) -> tuple:
    return ("scored", cell["score"]) if cell["status"] == "scored" else (cell["status"], None)


def resolved(trio: list[dict | None]) -> bool:
    return all(c is not None for c in trio) and len({verdict(c) for c in trio}) == 1


def round_results(store: Records, run_id: str, study: int, n: int) -> dict:
    """(rater, pillar) → cell, or None for a failed pillar, for the requests of round n only."""
    with store.db() as db:
        rows = db.execute(
            "SELECT j.payload,q.rater FROM judgments j JOIN requests q ON q.id=j.request_id "
            "WHERE q.run_id=? AND q.study=? AND q.round=? AND q.kind='rating'",
            (run_id, study, n),
        ).fetchall()
        failed = db.execute(
            "SELECT q.rater,q.context,d.payload FROM dispositions d JOIN requests q "
            "ON q.id=d.request_id WHERE q.run_id=? AND q.study=? AND q.round=? AND q.kind='rating'",
            (run_id, study, n),
        ).fetchall()
    result = {}
    for r in failed:
        pending = json.loads(r["context"])["pending"]
        for p in json.loads(r["payload"]).get("failed_pillars") or pending:
            result[(r["rater"], p)] = None
    for r in rows:
        cell = json.loads(r["payload"])
        result[(r["rater"], cell["pillar"])] = cell
    return result


def packet_for(recipient: str, pillars: list[str], cells: dict, seed: list) -> tuple[dict, list]:
    """Peers' anonymous arguments with status and score; identity or tally text is withheld, logged."""
    packet, withheld = {}, []
    for p in pillars:
        arguments = []
        for peer in RATERS:
            if peer == recipient:
                continue
            cell = cells[(peer, p)]
            d = cell["anonymous_defence"]
            text = "\n".join((d["reason"], d["alternative"]))
            if IDENTITY.search(text) or TALLY.search(text):
                withheld.append({"pillar": p, "peer": peer})
                continue
            arguments.append({
                "status": cell["status"],
                "score": cell["score"],
                **{k: d[k] for k in ("quote", "locator", "reason", "alternative")},
            })
        random.Random(digest(canonical([*seed, recipient, p]))).shuffle(arguments)
        packet[p] = [{"label": f"Argument {i}", **a} for i, a in enumerate(arguments, 1)]
    return packet, withheld


def event_once(store: Records, run_id: str, kind: str, payload: dict) -> None:
    """Resume-safe: an identical event is recorded once."""
    with store.db() as db:
        seen = db.execute(
            "SELECT 1 FROM events WHERE run_id=? AND kind=? AND payload=?", (run_id, kind, canonical(payload))
        ).fetchone()
    if not seen:
        store.event(run_id, kind, payload)


def record_packet(store: Records, run_id: str, study: int, n: int, rater: str, packet: dict) -> None:
    """Packets are written once; a resume must rebuild exactly the same packet."""
    with store.db() as db:
        row = db.execute(
            "SELECT payload FROM packets WHERE run_id=? AND study=? AND round=? AND rater=?",
            (run_id, study, n, rater),
        ).fetchone()
        if row is None:
            values = (run_id, study, n, rater, canonical(packet), stamp())
            db.execute("INSERT INTO packets VALUES(?,?,?,?,?,?)", values)
        elif row[0] != canonical(packet):
            raise StudyError("Discussion packet changed on resume")


def discuss_paper(store: Records, run_id: str, study: int, dispatcher) -> dict:
    """Run the rounds for one paper after its R0 is dispositioned; idempotent on resume."""
    m = store.manifest(run_id)
    current = round_results(store, run_id, study, 0)
    if any((r, p) not in current for r in RATERS for p in PILLARS):
        raise StudyError("R0 incomplete for this paper; discussion cannot start")
    outcome = {}
    for p in PILLARS:
        trio = [current[(r, p)] for r in RATERS]
        if None in trio:
            outcome[p] = {"stop": "excluded_failure", "round": 0}
        elif resolved(trio):
            outcome[p] = {"stop": "resolved", "round": 0}
    for n in range(1, MAX_ROUNDS + 1):
        open_pillars = [p for p in PILLARS if p not in outcome]
        if not open_pillars:
            break
        for rater in RATERS:
            packet, withheld = packet_for(rater, open_pillars, current, [m["seed"], run_id, study, n])
            record_packet(store, run_id, study, n, rater, packet)
            if withheld:
                detail = {"study": study, "round": n, "recipient": rater, "withheld": withheld}
                event_once(store, run_id, "discussion_withheld", detail)
            own = {p: current[(rater, p)] for p in open_pillars}
            prompt, context = build_prompt(store, run_id, study, open_pillars, own, packet)
            payload = payload_for(m["models"][rater], prompt)
            q = store.request(run_id, study, rater, n, "rating", 0, payload, context)
            result = dispatcher.execute(q, previous=own)
            stop = result.get("disposition", {})
            if stop.get("status") in ("model_change", "resource_stop") or str(stop.get("reason")).startswith(
                ("HTTP", "Provider")
            ):
                raise StudyError("Provider/configuration/credit stop during discussion: " + str(stop))
        latest = round_results(store, run_id, study, n)
        before = {p: [verdict(current[(r, p)]) for r in RATERS] for p in open_pillars}
        for p in open_pillars:
            trio = [latest.get((r, p)) for r in RATERS]
            if None in trio:
                outcome[p] = {"stop": "discussion_failure", "round": n}
                continue
            for r in RATERS:
                current[(r, p)] = latest[(r, p)]
            if resolved(trio):
                outcome[p] = {"stop": "resolved", "round": n}
            elif [verdict(c) for c in trio] == before[p]:
                outcome[p] = {"stop": "stable_disagreement", "round": n}
            elif n == MAX_ROUNDS:
                outcome[p] = {"stop": "round_limit", "round": n}
    final = {p: {r: current[(r, p)] and verdict(current[(r, p)]) for r in RATERS} for p in PILLARS}
    return {p: {**outcome[p], "final": final[p]} for p in PILLARS}


def discuss(store: Records, run_id: str, dispatcher) -> dict:
    """All papers of a run whose manifest names this policy; R0 must be complete for the whole run."""
    m = store.manifest(run_id)
    if m["versions"].get("discussion") != POLICY:
        raise StudyError("Run was frozen without the discussion policy")
    result = {
        str(p["study_id"]): discuss_paper(store, run_id, p["study_id"], dispatcher)
        for p in m["papers"]
    }
    event_once(store, run_id, "discussion_dispositioned", {"policy": POLICY, "outcomes": result})
    return result
