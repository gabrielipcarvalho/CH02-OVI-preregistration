"""md-v1 page-section localisation: quotes must occur in the authors' Markdown text on the claimed page.

The model input and the validation source are the same frozen md-v1 text, so extraction differences
cannot reject a correct quotation. Generated figure descriptions are removed before matching.
"""

from __future__ import annotations

import re
from collections import Counter

from pipeline.study.evidence_v2 import contains
from pipeline.study.evidence_v3 import anchor_page, typographic, variants
from pipeline.study.markdown_inputs import source_text
from pipeline.study.records import StudyError

VERSION = "md-page-v1.3"  # v1.1 (C2): unmapped glyphs, URL/DOI lines, running headers, page counters
# v1.2 (29 Oct): printed-pagination and next-page continuation labels never count as anchor pages
# v1.3 (29 Oct): conversion-artefact tolerance, interposed layout blocks, flagged adjacent-page match
VERSION_V1_2 = "md-page-v1.2"  # kept so frozen v1.2 runs re-validate exactly as they were dispatched
INSTRUCTION = """Evidence localisation md-page-v1.3: the paper text is Markdown with [PDF PAGE N] markers.
Quote one contiguous passage of the authors' text exactly; Markdown symbols may be omitted.
Start the locator with 'PDF page N', N being the nearest [PDF PAGE N] marker above the passage.
Write no other page number in the locator: no printed or journal page, no page range, no second PDF
page. A quotation may run onto the next page; still name only the page where it starts.
Put section, table or figure references after '; context:'. Do not splice quotations with ellipses.
FIGURE DESCRIPTION blocks are generated, not the authors' words: never quote them; use them only to
find the authors' own captions, tables or text. Source location does not establish criterion adequacy."""
PAGE_SPLIT = re.compile(r"^\[PDF PAGE (\d+)\]$", re.M)
PRINTED = re.compile(
    r"\b(?:printed|journal|publication)(?:\s+(?:journal|publication|page|pagination))*\s+"
    r"(?:pages?|pp?\.)\s*\d+(?:\s*[-–]\s*\d+)?",
    re.I,
)
CONTINUES = re.compile(
    r"\b(?:(?:passage|quotation|quote|text)\s+)?continu\w*\s+(?:onto|on|into|to)\s+PDF\s+page\s*(\d+)", re.I
)


def plain(text: str) -> str:
    """Drop Markdown/HTML presentation only; words, numbers, signs and units stay literal."""
    text = re.sub(r"<!--.*?-->", " ", text, flags=re.S)
    text = re.sub(r"<br\s*/?>", " ", text)
    text = re.sub(r"</?(?:sup|sub|u|b|i|em|strong)>", "", text)
    text = re.sub(r"^\[(?:FIGURE|IMAGE|OCR-DERIVED)[^\n]*\]$", " ", text, flags=re.M)
    text = re.sub(r"^\s{0,3}(?:#{1,6}|>)\s?", "", text, flags=re.M)
    text = re.sub(r"^\|?\s*:?-{3,}.*$", " ", text, flags=re.M)  # table rule rows
    # Change C2-I: URL/DOI-only lines are publisher page furniture; converters can drop them mid-sentence.
    text = re.sub(r"^\s*(?:https?://\S+|doi:\s*\S+|10\.\d{4,}/\S+)\s*$", " ", text, flags=re.M | re.I)
    text = text.replace("**", "").replace("|", " ")
    return re.sub(r"(?<!\w)_|_(?!\w)", "", text)  # emphasis underscores, not identifier underscores


COUNTER = re.compile(r"^\s*\d+\s+of\s+\d+\s*$")


def furniture(raw: dict[int, str]) -> set[str]:
    """Running headers/footers: a plain line repeated identically on 3+ pages."""
    seen: Counter = Counter()
    for text in raw.values():
        seen.update({s.strip() for s in text.split("\n") if s.strip()})
    return {line for line, n in seen.items() if n >= 3} if len(raw) >= 3 else set()


def _kept(line: str, removed: set[str]) -> bool:
    return line.strip() not in removed and not COUNTER.match(line)


def pages(markdown: str) -> dict[int, str]:
    """Quotable page sections: authors' text only, with generated description blocks removed.

    Change C2-I extension: running headers/footers (a line repeated identically on 3+ pages) and
    "N of M" page counters are page furniture, removed so a sentence crossing a page still matches.
    """
    parts = PAGE_SPLIT.split(source_text(markdown))
    raw = {int(parts[i]): plain(parts[i + 1]) for i in range(1, len(parts) - 1, 2)}
    removed = furniture(raw)
    return {n: "\n".join(s for s in text.split("\n") if _kept(s, removed)) for n, text in raw.items()}


def dehyphen(text: str) -> str:
    """Drop hyphens between two letters only: the converter joins line-broken compounds ("lowcost").

    Hyphens and minus signs next to digits stay literal, so signed or ranged quantities still must match.
    """
    return re.sub(r"(?<=[^\W\d_])-(?=[^\W\d_])", "", text)


def unmapped_glyph_match(needle: str, source: str) -> bool:
    """Change C2-H: a source U+FFFD (a glyph the PDF font could not map) matches any one non-space
    character of the quote. Every other character, and the word/number boundaries, stay exact."""
    if "\ufffd" not in source or not needle:
        return False
    pattern = "".join(re.escape(c) if c.isspace() else f"(?:{re.escape(c)}|\ufffd)" for c in needle)
    for match in re.finditer(pattern, source):
        before = source[match.start() - 1 : match.start()] if match.start() else ""
        after = source[match.end() : match.end() + 1]
        if (before and before.isalnum() and needle[0].isalnum()) or (
            after and after.isalnum() and needle[-1].isalnum()
        ):
            continue
        return True
    return False


def _found(needles: tuple[str, ...], text: str) -> bool:
    hays = variants(typographic(text))
    return any(
        contains(n, h) or contains(dehyphen(n), dehyphen(h)) or unmapped_glyph_match(n, h)
        for n in needles
        for h in hays
    )


SPACED = re.compile(r"\s+([,.;:!?)\]])|([(\[])\s+")


def spacing(text: str) -> str:
    """Change v1.3-A: emphasis markup leaves a space before punctuation ("swimming , treading").

    Applied to quote and source alike; no character other than that space is removed.
    """
    return SPACED.sub(lambda m: m.group(1) or m.group(2), text)


def tolerant(needle: str) -> re.Pattern:
    """Change v1.3-B: a converter space inside one of the quote's words ("ill u strates") is allowed.

    Only between two letters; the quote's own word breaks, digits and signs stay exact.
    """
    out = []
    for i, c in enumerate(needle):
        if c.isspace():
            out.append(r"\s+")
            continue
        out.append(re.escape(c))
        if c.isalpha() and i + 1 < len(needle) and needle[i + 1].isalpha():
            out.append(" ?")
    return re.compile("".join(out))


def _clash(neighbour: str, edge: str) -> bool:
    return bool(neighbour) and edge.isalnum() and (
        neighbour.isalpha() or neighbour == "_" or (neighbour.isdigit() and edge.isdigit())
    )


def _bounded(start: int, end: int, needle: str, hay: str) -> bool:
    """Change v1.3-C: a footnote numeral glued to the quote's first or last word ("2All") is not a
    word-boundary violation. A digit next to a quoted digit, or a letter next to a quoted letter, still is."""
    before, after = hay[start - 1 : start] if start else "", hay[end : end + 1]
    if _clash(before, needle[0]) or _clash(after, needle[-1]):
        return False
    if needle[0].isdigit() and before and before in "+-.$€£":
        return False
    return not (needle[-1].isdigit() and after and after in ".%")


def _found_tolerant(needles: tuple[str, ...], text: str) -> bool:
    hays = [spacing(h) for h in variants(typographic(text))]
    for n in needles:
        for a, b in ((n, None), (dehyphen(n), dehyphen)):
            needle = spacing(a)
            if not needle:
                continue
            pattern = tolerant(needle)
            for h in hays:
                h = b(h) if b else h
                if any(_bounded(m.start(), m.end(), needle, h) for m in pattern.finditer(h)):
                    return True
    return False


PUBLISHER = re.compile(
    r"©|authorized licensed use|restrictions apply|downloaded (?:on|from)|\b97[89]-\d|https?://", re.I
)
LAYOUT_LINE = re.compile(
    r"^\s*(?:\d{1,4}"  # bare printed page number
    r"|[_*#>\s]*(?:fig(?:ure)?|table)\.?\s*[\dIVXivx]+\b.*"  # figure or table caption
    r"|#{1,6}\s.{0,120}"  # heading
    r"|([_*]{1,2})[^\n]{1,120}\1"  # fully emphasised caption or sub-heading line
    r"|\|.*"  # table row
    r")\s*$",
    re.I,
)
CAPTION_LABEL = re.compile(r"^[_*\s]*(?:fig(?:ure)?|table)\.?\s*[\dIVXivx]+[_*.:\s]*$", re.I)
MAX_INTERPOSED = 4


def layout_block(block: str) -> bool:
    """Change v1.3-D: captions, tables, headings, page numbers and publisher lines are layout, not prose."""
    lines = [s for s in block.split("\n") if s.strip()]
    return bool(lines) and all(LAYOUT_LINE.match(s) or (len(s) <= 200 and PUBLISHER.search(s)) for s in lines)


def page_blocks(markdown: str) -> dict[int, list[tuple[str, bool]]]:
    """Blank-line blocks per page in plain form, each marked as layout or not; furniture lines removed."""
    parts = PAGE_SPLIT.split(source_text(markdown))
    removed = furniture({int(parts[i]): plain(parts[i + 1]) for i in range(1, len(parts) - 1, 2)})
    result = {}
    for i in range(1, len(parts) - 1, 2):
        blocks, label = [], False
        for raw in re.split(r"\n\s*\n", parts[i + 1]):
            text = "\n".join(s for s in plain(raw).split("\n") if _kept(s, removed))
            if text.strip():
                # A one-line caption directly under a bare "Table 1" / "Fig. 2" label belongs to it.
                caption = label and "\n" not in raw.strip() and len(raw.strip()) <= 200
                blocks.append((text, layout_block(raw) or caption))
                label = bool(CAPTION_LABEL.match(raw.strip()))
        result[int(parts[i])] = blocks
    return result


def _found_interposed(needles: tuple[str, ...], blocks: list[tuple[str, bool]], start_count: int) -> bool:
    """Change v1.3-D: the quote reads continuously once 1–4 consecutive layout blocks inside it are skipped.

    The match must start in the first ``start_count`` blocks (the claimed page). Without the skip the text
    is unchanged, so a new match necessarily spans the skipped position: nothing else is relaxed.
    """
    for i in range(1, len(blocks)):
        for k in range(1, MAX_INTERPOSED + 1):
            window = blocks[i : i + k]
            if len(window) < k or not all(layout for _, layout in window) or i + k >= len(blocks):
                break
            head = "\n\n".join(t for t, _ in blocks[:i])
            tail = "\n\n".join(t for t, _ in blocks[i + k :])
            joined = head + "\n\n" + tail
            if i <= start_count and _found_tolerant(needles, joined) and not _found_tolerant(needles, tail):
                return True
    return False


def anchor_page_md(locator: str) -> int:
    """Drop printed pagination and a next-page continuation note; any other second page stays ambiguous."""
    anchor, sep, context = locator.partition("; context:")
    anchor = PRINTED.sub("", anchor)
    continued = [int(n) for n in CONTINUES.findall(anchor)]
    page = anchor_page(CONTINUES.sub("", anchor) + sep + context)
    if any(n != page + 1 for n in continued):
        raise StudyError("Ambiguous or missing claimed PDF page; review required")
    return page


def _locate(needles: tuple[str, ...], page: int, sections: dict, blocks: dict | None) -> dict | None:
    """v1.2 exact match on the page or running onto the next; v1.3 adds the artefact and layout tiers."""
    following = sections.get(page + 1)
    joined = sections[page] + "\n" + following if following is not None else None
    if _found(needles, sections[page]):
        return {"method": "md_page_section", "pages": [page]}
    if joined and not _found(needles, following) and _found(needles, joined):
        return {"method": "md_page_continuation", "pages": [page, page + 1]}
    if blocks is None:
        return None
    if _found_tolerant(needles, sections[page]):
        return {"method": "md_artefact_tolerant", "pages": [page]}
    if joined and not _found_tolerant(needles, following) and _found_tolerant(needles, joined):
        return {"method": "md_artefact_tolerant", "pages": [page, page + 1]}
    own = blocks.get(page, [])
    if _found_interposed(needles, own + blocks.get(page + 1, []), len(own)):
        return {"method": "md_interposed_layout", "pages": [page, page + 1] if page + 1 in blocks else [page]}
    return None


def evidence_check_md(cell: dict, markdown: str, version: str = VERSION) -> dict:
    """Contiguous match on the claimed page, or starting there and running onto the next page.

    v1.3 only: when the claimed page fails, the same match on the page before or after is accepted with
    ``locator_page_verified`` false and the claimed page recorded, so a wrong page is flagged, never hidden.
    """
    if version not in (VERSION, VERSION_V1_2):
        raise StudyError("Unknown md-page validator version")
    base = {"validator_version": version, "semantic_validity": False}
    if cell["quote"] == "NO_DOCUMENTED_EVIDENCE":
        return {**base, "status": "absence_not_verified"}
    if not cell["quote"].strip():
        if cell["status"] == "scored":
            raise StudyError("Scored evidence is empty")
        return {**base, "status": "not_assessable"}
    if "DESCRIPTION — generated by" in cell["quote"]:
        raise StudyError("Quote not locatable: generated figure descriptions are not source text")
    page = anchor_page_md(cell["locator"])
    sections = pages(markdown)
    if page not in sections:
        raise StudyError("Quote not locatable: claimed PDF page is outside the frozen source")
    quotation = typographic(plain(cell["quote"]))
    needles = variants(quotation)
    if quotation.startswith("The "):
        needles += variants("the " + quotation[4:])
    elif quotation.startswith("the "):
        needles += variants("The " + quotation[4:])
    blocks = page_blocks(markdown) if version == VERSION else None
    found = _locate(needles, page, sections, blocks)
    if found:
        return {**base, "status": "text_match", **found, "locator_page_verified": True}
    for other in (page - 1, page + 1) if blocks is not None else ():
        found = _locate(needles, other, sections, blocks) if other in sections else None
        if found:
            return {**base, "status": "text_match", **found, "method": found["method"] + "+adjacent_page",
                    "claimed_page": page, "locator_page_verified": False}
    raise StudyError("Quote not locatable on claimed PDF page in md-v1 source; original preserved")
