"""Transactional, append-only judgments with capability-scoped reviewer access."""

from __future__ import annotations

import json
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from pipeline.calibration import sources as src

STATUSES = ("scored", "unable_to_assess", "applicability_uncertain")
SUBSTANTIVE = ("status", "score", "quote", "locator", "reason", "alternative")
MAX_ROUNDS = 4


def now() -> str:
    return datetime.now(UTC).isoformat()


class PanelError(ValueError):
    """Invalid workflow transition; rejected atomically."""


def validate_cell(c: dict) -> dict:
    if not isinstance(c, dict) or c.get("pillar") not in src.PILLARS:
        raise PanelError("A judgment must name P1, P2, P3 or P4")
    out = {k: c.get(k, "") for k in (*SUBSTANTIVE, "pillar", "confidence", "change_reason", "action")}
    if out["status"] not in STATUSES:
        raise PanelError("Select scored, unable_to_assess, or applicability_uncertain")
    for key in ("quote", "locator", "reason", "alternative", "confidence", "change_reason", "action"):
        if not isinstance(out[key], str) or len(out[key]) > 12000:
            raise PanelError(f"{key} must be text of at most 12,000 characters")
        out[key] = out[key].strip()
    if not out["reason"]:
        raise PanelError("A brief justification or failure explanation is required")
    if out["confidence"] not in ("", "low", "medium", "high"):
        raise PanelError("Confidence must be low, medium, high, or blank")
    if out["status"] == "scored":
        if type(out["score"]) is not int or out["score"] not in range(4):
            raise PanelError("Scored judgments require an integer from 0 to 3")
        if not out["quote"]:
            raise PanelError("Record a quotation or NO_DOCUMENTED_EVIDENCE")
        from pipeline.schema import has_locator, is_absence_marker, is_substantive_quote

        if is_absence_marker(out["quote"]):
            if out["score"] != 0:
                raise PanelError("NO_DOCUMENTED_EVIDENCE requires score 0")
            out["quote"] = "NO_DOCUMENTED_EVIDENCE"
        elif not is_substantive_quote(out["quote"]) or not has_locator(out["locator"]):
            raise PanelError("A quoted judgment requires substantive evidence and a locator")
    elif out["score"] is not None:
        raise PanelError("Technical/applicability failures carry null, never a zero score")
    return out


def signature(c: dict) -> tuple:
    return tuple(c[k] for k in SUBSTANTIVE)


class Store:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS sessions(
                    id TEXT PRIMARY KEY, name TEXT NOT NULL, mode TEXT NOT NULL,
                    participants TEXT NOT NULL, cases TEXT NOT NULL, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS access(
                    hash TEXT PRIMARY KEY, role TEXT NOT NULL, session_id TEXT, reviewer TEXT);
                CREATE TABLE IF NOT EXISTS reviews(
                    id INTEGER PRIMARY KEY, session_id TEXT NOT NULL, study_id INTEGER NOT NULL,
                    pillar TEXT NOT NULL, reviewer TEXT NOT NULL, round INTEGER NOT NULL,
                    payload TEXT NOT NULL, provenance TEXT NOT NULL, created TEXT NOT NULL,
                    UNIQUE(session_id,study_id,pillar,reviewer,round));
                CREATE TABLE IF NOT EXISTS releases(
                    session_id TEXT, study_id INTEGER, round INTEGER, packet TEXT, created TEXT,
                    PRIMARY KEY(session_id,study_id,round));
                CREATE TABLE IF NOT EXISTS adjudications(
                    id INTEGER PRIMARY KEY, session_id TEXT, study_id INTEGER, pillar TEXT,
                    payload TEXT, created TEXT);
                CREATE TABLE IF NOT EXISTS checks(
                    id INTEGER PRIMARY KEY, session_id TEXT, study_id INTEGER, pillar TEXT,
                    reviewer TEXT, round INTEGER, payload TEXT, created TEXT);
                CREATE TABLE IF NOT EXISTS calls(
                    id TEXT PRIMARY KEY, provider TEXT, status TEXT, reserved REAL,
                    payload TEXT, created TEXT);
                CREATE TABLE IF NOT EXISTS jobs(
                    id TEXT PRIMARY KEY, session_id TEXT, study_id INTEGER, reviewer TEXT,
                    kind TEXT, status TEXT, message TEXT, created TEXT);
                CREATE TRIGGER IF NOT EXISTS immutable_review_update BEFORE UPDATE ON reviews
                    BEGIN SELECT RAISE(ABORT,'Judgments are immutable'); END;
                CREATE TRIGGER IF NOT EXISTS immutable_review_delete BEFORE DELETE ON reviews
                    BEGIN SELECT RAISE(ABORT,'Judgments are immutable'); END;
                CREATE TRIGGER IF NOT EXISTS immutable_release BEFORE UPDATE ON releases
                    BEGIN SELECT RAISE(ABORT,'Released context is immutable'); END;
            """)
            if "protocol_version" not in {r[1] for r in db.execute("PRAGMA table_info(sessions)")}:
                db.execute(
                    "ALTER TABLE sessions ADD COLUMN protocol_version TEXT NOT NULL "
                    f"DEFAULT '{src.LEGACY_PROTOCOL}'"
                )
            if "owner_pid" not in {r[1] for r in db.execute("PRAGMA table_info(jobs)")}:
                db.execute("ALTER TABLE jobs ADD COLUMN owner_pid INTEGER")

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA foreign_keys=ON")
            with db:
                yield db
        finally:
            db.close()

    def coordinator(self, token: str) -> None:
        with self.db() as db:
            db.execute(
                "INSERT OR IGNORE INTO access VALUES(?,?,?,?)", (src.sha(token), "coordinator", None, None)
            )

    def authenticate(self, token: str) -> dict:
        with self.db() as db:
            row = db.execute("SELECT * FROM access WHERE hash=?", (src.sha(token),)).fetchone()
        if row is None:
            raise PanelError("Invalid or missing access token")
        return {k: row[k] for k in ("role", "session_id", "reviewer")}

    def create(self, name: str, mode: str = "sandbox", cases=None) -> dict:
        if mode not in ("sandbox", "ai_experiment", "human_calibration"):
            raise PanelError("Unknown session mode")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 120:
            raise PanelError("Use a session name of 1–120 characters")
        cases = ([0] if mode == "sandbox" else list(src.CASE_IDS)) if cases is None else cases
        allowed = (*src.CASE_IDS, 0) if mode == "sandbox" else src.CASE_IDS
        if not cases or len(cases) != len(set(cases)) or any(s not in allowed for s in cases):
            raise PanelError("Select unique proposed C1–C5 cases")
        participants = ["r1", "r2", "r3"]
        if mode != "ai_experiment":
            participants += ["H1", "H2", "H3"]
        sid = secrets.token_hex(8)
        tokens = {r: secrets.token_urlsafe(32) for r in participants}
        with self.db() as db:
            db.execute(
                "INSERT INTO sessions VALUES(?,?,?,?,?,?,?)",
                (
                    sid,
                    name.strip(),
                    mode,
                    json.dumps(participants),
                    json.dumps(cases),
                    now(),
                    src.AI_PROTOCOL if mode == "ai_experiment" else src.LEGACY_PROTOCOL,
                ),
            )
            for r, token in tokens.items():
                db.execute("INSERT INTO access VALUES(?,?,?,?)", (src.sha(token), "reviewer", sid, r))
        return {"id": sid, "reviewer_tokens": tokens}

    def session(self, sid: str) -> dict:
        with self.db() as db:
            row = db.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
        if row is None:
            raise PanelError("Session not found")
        out = dict(row)
        for k in ("participants", "cases"):
            out[k] = json.loads(out[k])
        return out

    def sessions(self) -> list[dict]:
        with self.db() as db:
            ids = [r[0] for r in db.execute("SELECT id FROM sessions ORDER BY created DESC")]
        return [self.session(s) for s in ids]

    def reviews(self, sid: str, study: int, reviewer: str | None = None) -> list[dict]:
        with self.db() as db:
            query = "SELECT * FROM reviews WHERE session_id=? AND study_id=?"
            params = [sid, study]
            if reviewer is not None:
                query += " AND reviewer=?"
                params.append(reviewer)
            rows = db.execute(query + " ORDER BY round,id", params).fetchall()
        return [
            {**dict(r), "payload": json.loads(r["payload"]), "provenance": json.loads(r["provenance"])}
            for r in rows
        ]

    def current_round(self, sid: str, study: int) -> int:
        with self.db() as db:
            n = db.execute(
                "SELECT MAX(round) FROM releases WHERE session_id=? AND study_id=?", (sid, study)
            ).fetchone()[0]
        return n or 0

    def cell_states(self, sid: str, study: int) -> dict:
        session = self.session(sid)
        current = self.current_round(sid, study)
        records = {(r["reviewer"], r["pillar"], r["round"]): r["payload"] for r in self.reviews(sid, study)}
        result = {}
        for p in src.PILLARS:
            complete = all((r, p, current) in records for r in session["participants"])
            stable = (
                current >= 2
                and complete
                and all(
                    len(
                        {
                            signature(records[r, p, n])
                            for n in range(current - 2, current + 1)
                            if (r, p, n) in records
                        }
                    )
                    == 1
                    and all((r, p, n) in records for n in range(current - 2, current + 1))
                    for r in session["participants"]
                )
            )
            judgments = [
                records[r, p, current] for r in session["participants"] if (r, p, current) in records
            ]
            non_assessable = complete and any(c["status"] != "scored" for c in judgments)
            agree = complete and not non_assessable and len({c["score"] for c in judgments}) == 1
            state = (
                "awaiting_ratings"
                if not complete
                else "non_assessable"
                if non_assessable
                else "stable_agreement"
                if stable and agree
                else "stable_disagreement"
                if stable
                else "round_limit"
                if current >= MAX_ROUNDS
                else "agreement_under_review"
                if agree
                else "contested"
            )
            result[p] = {
                "state": state,
                "complete": complete,
                "stopping_reason": "stability"
                if stable
                else "round_limit"
                if complete and current >= MAX_ROUNDS
                else None,
                "terminal": stable or (complete and current >= MAX_ROUNDS),
            }
        return result

    def submit(
        self,
        sid: str,
        study: int,
        reviewer: str,
        round_n: int,
        cells: list[dict],
        provenance: dict | None = None,
    ) -> list[dict]:
        session = self.session(sid)
        if session["mode"] == "ai_experiment" and session["protocol_version"] != src.AI_PROTOCOL:
            raise PanelError("Historical AI session is replay-only; create a new AI experiment")
        if study not in session["cases"] or reviewer not in session["participants"]:
            raise PanelError("Reviewer or paper is outside this session")
        if type(round_n) is not int or round_n != self.current_round(sid, study):
            raise PanelError("Stale round: refresh before submitting")
        if not isinstance(cells, list) or not cells:
            raise PanelError("Submit at least one complete pillar judgment")
        clean = [validate_cell(c) for c in cells]
        if len({c["pillar"] for c in clean}) != len(clean):
            raise PanelError("Duplicate pillar in submission")
        old = {(r["pillar"], r["round"]): r["payload"] for r in self.reviews(sid, study, reviewer)}
        for c in clean:
            if (c["pillar"], round_n) in old:
                raise PanelError("This judgment is locked; it cannot be overwritten")
            if round_n:
                previous = old.get((c["pillar"], round_n - 1))
                if not previous:
                    raise PanelError("Previous round is missing")
                if c["action"] not in ("retain", "revise") or not c["change_reason"]:
                    raise PanelError("Retain/revise and a change explanation are required")
                if c["action"] == "retain" and signature(c) != signature(previous):
                    raise PanelError("Retain must preserve the previous substantive fields exactly")
            else:
                c["action"] = "initial"
            c["evidence_check"] = src.quote_check(study, c["quote"])
        provenance = {
            **(provenance or {}),
            "mode": session["mode"],
            "human_confirmed": False,
            "instrument": session["protocol_version"],
        }
        if session["mode"] != "sandbox" and reviewer.startswith("r") and not provenance.get("call_id"):
            raise PanelError("AI experiment judgments require a recorded provider call")
        try:
            with self.db() as db:
                db.execute("BEGIN IMMEDIATE")
                for c in clean:
                    db.execute(
                        "INSERT INTO reviews(session_id,study_id,pillar,reviewer,round,"
                        "payload,provenance,created) VALUES(?,?,?,?,?,?,?,?)",
                        (
                            sid,
                            study,
                            c["pillar"],
                            reviewer,
                            round_n,
                            json.dumps(c),
                            json.dumps(provenance),
                            now(),
                        ),
                    )
        except sqlite3.IntegrityError as exc:
            raise PanelError("Submission conflicts with an already locked judgment") from exc
        return clean

    def advance(self, sid: str, study: int) -> int:
        session = self.session(sid)
        if session["mode"] == "ai_experiment" and session["protocol_version"] != src.AI_PROTOCOL:
            raise PanelError("Historical AI session is replay-only; create a new AI experiment")
        if study not in session["cases"]:
            raise PanelError("Paper not assigned to this session")
        n = self.current_round(sid, study)
        states = self.cell_states(sid, study)
        if not all(s["complete"] for s in states.values()):
            raise PanelError("Every participant must finish all four pillars before evidence is released")
        if n >= MAX_ROUNDS or all(s["terminal"] for s in states.values()):
            raise PanelError("This case has reached its stopping state; review the recorded outcomes")
        records = [r for r in self.reviews(sid, study) if r["round"] == n]

        def build_packet(recipient=None):
            packet = {}
            for pillar in src.PILLARS:
                unique = {}
                for row in records:
                    if row["pillar"] == pillar and row["reviewer"] != recipient:
                        c = row["payload"]
                        argument = {k: c[k] for k in ("quote", "locator", "reason", "alternative", "status")}
                        unique[json.dumps(argument, sort_keys=True)] = argument
                arguments = list(unique.values())
                secrets.SystemRandom().shuffle(arguments)
                packet[pillar] = [{"label": f"Argument {i}", **a} for i, a in enumerate(arguments, 1)]
            return packet

        # Persist each projection once, from the same completed round snapshot.
        packet = {
            "format": "recipient-packets-v1",
            "coordinator": build_packet(),
            "recipients": {r: build_packet(r) for r in self.session(sid)["participants"]},
        }
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                db.execute(
                    "INSERT INTO releases VALUES(?,?,?,?,?)", (sid, study, n + 1, json.dumps(packet), now())
                )
            except sqlite3.IntegrityError as exc:
                raise PanelError("Round already opened; refresh the case") from exc
            for row in records:
                if states[row["pillar"]]["terminal"]:
                    provenance = {**row["provenance"], "carried_forward": True}
                    db.execute(
                        "INSERT INTO reviews(session_id,study_id,pillar,reviewer,round,"
                        "payload,provenance,created) VALUES(?,?,?,?,?,?,?,?)",
                        (
                            sid,
                            study,
                            row["pillar"],
                            row["reviewer"],
                            n + 1,
                            json.dumps(row["payload"]),
                            json.dumps(provenance),
                            now(),
                        ),
                    )
        return n + 1

    def packet(
        self, sid: str, study: int, round_n: int | None = None, *, reviewer: str | None = None
    ) -> dict:
        """Return only the recipient's frozen projection; preserve legacy packets for replay."""
        if reviewer is not None and reviewer not in self.session(sid)["participants"]:
            raise PanelError("Reviewer is outside this session")
        n = self.current_round(sid, study) if round_n is None else round_n
        with self.db() as db:
            row = db.execute(
                "SELECT packet FROM releases WHERE session_id=? AND study_id=? AND round=?", (sid, study, n)
            ).fetchone()
        packet = json.loads(row[0]) if row else {}
        if packet.get("format") == "recipient-packets-v1":
            return packet["coordinator"] if reviewer is None else packet["recipients"][reviewer]
        return packet  # Historical releases remain byte-for-byte as originally delivered.

    def adjudicate(self, sid: str, study: int, pillar: str, payload: dict) -> None:
        session = self.session(sid)
        if session["mode"] == "ai_experiment":
            raise PanelError("AI-only experiments cannot create a human reference")
        if study not in session["cases"] or pillar not in src.PILLARS:
            raise PanelError("Unknown case or pillar")
        if not self.cell_states(sid, study)[pillar]["terminal"]:
            raise PanelError("Finish the cell's stability/round-limit procedure before adjudication")
        if any(
            not isinstance(payload.get(k), str) or not payload[k].strip()
            for k in ("rule", "reason", "ratified_by", "uncertainty")
        ):
            raise PanelError("Record a general rule, reason, ratifying humans, and residual uncertainty")
        if payload.get("attested") is not True:
            raise PanelError("Explicitly attest that these are real decisions or labelled sandbox inputs")
        if type(payload.get("score")) is not int or payload["score"] not in range(4):
            raise PanelError("The reference score must be 0–3")
        evidence = validate_cell(
            {
                "pillar": pillar,
                "status": "scored",
                "score": payload["score"],
                "quote": payload.get("quote", ""),
                "locator": payload.get("locator", ""),
                "reason": payload["reason"],
            }
        )
        row = {
            **payload,
            "quote": evidence["quote"],
            "locator": evidence["locator"],
            "evidence_check": src.quote_check(study, evidence["quote"]),
            "status": "synthetic_demonstration"
            if session["mode"] == "sandbox"
            else "human_decision_recorded_by_coordinator",
            "protocol_adopted": False,
        }
        with self.db() as db:
            db.execute(
                "INSERT INTO adjudications(session_id,study_id,pillar,payload,created) VALUES(?,?,?,?,?)",
                (sid, study, pillar, json.dumps(row), now()),
            )

    def extra(self, table: str, sid: str, study: int) -> list[dict]:
        if table not in ("adjudications", "checks"):
            raise PanelError("Unknown record type")
        with self.db() as db:
            rows = db.execute(
                f"SELECT * FROM {table} WHERE session_id=? AND study_id=? ORDER BY id", (sid, study)
            ).fetchall()
        return [{**dict(r), "payload": json.loads(r["payload"])} for r in rows]
