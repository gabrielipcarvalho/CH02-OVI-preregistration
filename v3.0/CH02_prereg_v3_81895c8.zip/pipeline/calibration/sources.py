"""Read-only corpus projection and page-aware evidence checks for the calibration prototype."""

from __future__ import annotations

import csv
import hashlib
import json
import re
import subprocess
import unicodedata
from functools import lru_cache
from pathlib import Path

from pipeline.config import REPO_ROOT
from pipeline.rubric_source import load as load_rubric

ROOT = REPO_ROOT
CALIBRATION = ROOT / "calibration"
RUNTIME = CALIBRATION / "runtime"
CASE_IDS = (38, 42, 53, 77, 34)
ALTERNATIVES = (60, 83, 6)
PILLARS = ("P1", "P2", "P3", "P4")
LABELS = {sid: f"C{i}" for i, sid in enumerate(CASE_IDS, 1)}


def sha(value: str | bytes) -> str:
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def catalog() -> list[dict]:
    return json.loads((CALIBRATION / "catalog.json").read_text())


def paper(sid: int) -> dict:
    if sid == 0:
        return {
            "study_id": 0,
            "label": "D0 · fictional demo",
            "authors": "Synthetic software fixture",
            "year": "2026",
            "title": "Poolside Demo — fictional practice record",
            "venue": "Not a publication or corpus study",
            "doi": "",
        }
    for item in catalog():
        if item["study_id"] == sid:
            return item
    raise ValueError("Paper is outside the proposed calibration and alternative set")


def pdf_path(sid: int) -> Path:
    paper(sid)
    if sid == 0:
        return CALIBRATION / "fixtures/D0.pdf"
    matches = list((ROOT / "reviewer_packet/papers").glob(f"{sid}.*.pdf"))
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one local PDF for study {sid}")
    return matches[0]


@lru_cache(maxsize=16)
def pages(sid: int) -> tuple[str, ...]:
    result = subprocess.run(
        ["pdftotext", "-layout", str(pdf_path(sid)), "-"],
        capture_output=True,
        text=True,
        check=True,
        timeout=30,
    )
    texts = result.stdout.split("\f")
    if not texts[-1].strip():
        texts.pop()
    if sum(len(t.strip()) for t in texts) < 200:
        raise ValueError("Unable to assess: no usable PDF text layer; never automatically score zero")
    return tuple(texts)


def paper_text(sid: int) -> str:
    return "\n\n".join(f"[PDF PAGE {n}]\n{t}" for n, t in enumerate(pages(sid), 1))


@lru_cache(maxsize=16)
def reading_order_pages(sid: int) -> tuple[str, ...]:
    """A second extraction for quote diagnostics, never a replacement for recorded model input."""
    result = subprocess.run(
        ["pdftotext", str(pdf_path(sid)), "-"], capture_output=True, text=True, check=True, timeout=30
    )
    return tuple(result.stdout.split("\f"))


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).casefold()
    text = re.sub(r"(?<=\w)[\-\u00ad]\s*\n\s*(?=\w)", "", text)
    text = text.replace("≤", "<=").replace("≥", ">=")
    # Comparators, percentages and currency symbols carry evidence meaning, not just typography.
    return " ".join(re.findall(r"<=|>=|[<>$%€£]|\w+", text))


def quote_check(sid: int, quote: str) -> dict:
    """Flag, never silently repair, quotations; an exact match is not scoring validation."""
    if quote == "NO_DOCUMENTED_EVIDENCE":
        return {"status": "absence_not_verified", "pages": []}
    if not quote.strip():
        return {"status": "not_applicable", "pages": []}
    needle = norm(quote)
    if not needle:
        return {"status": "needs_review", "pages": []}
    matched = [n for n, text in enumerate(pages(sid), 1) if needle in norm(text)]
    if matched:
        return {"status": "text_match", "pages": matched}
    reading = [n for n, text in enumerate(reading_order_pages(sid), 1) if needle in norm(text)]
    return {"status": "reading_order_match" if reading else "needs_review", "pages": reading}


LEGACY_PROTOCOL = "calibration-prototype-2026-09-16-draft1"
AI_PROTOCOL = "ai-only-2026-09-28-draft1"


def rubric_bundle(version: str = AI_PROTOCOL) -> dict:
    """Select an explicit procedure without changing the historical instrument."""
    paths = {LEGACY_PROTOCOL: "protocol.md", AI_PROTOCOL: "protocol-ai-only-2026-09-28.md"}
    if version not in paths:
        raise ValueError("Unknown calibration protocol version")
    protocol = (CALIBRATION / paths[version]).read_text()
    return {
        "rubric": load_rubric(),
        "rubric_yaml": (ROOT / "rubric/rubric.yaml").read_text(),
        "protocol": protocol,
        "original_protocol": (ROOT / "docs/scoring_protocol.md").read_text(),
        "version": version,
        "rubric_hash": sha((ROOT / "rubric/rubric.yaml").read_bytes()),
        "protocol_hash": sha(protocol),
    }


def alpha_summary() -> dict:
    """Coordinator-only; never used by independent scoring or reviewer endpoints."""
    sets = []
    for n in (1, 2, 3):
        with (ROOT / f"data/scores_alpha_rater{n}.csv").open() as f:
            sets.append({(int(r["study_id"]), r["pillar"]): r for r in csv.DictReader(f)})
    common = sorted(set.intersection(*(set(s) for s in sets)))
    differences = []
    for sid, pillar in common:
        rows = [s[sid, pillar] for s in sets]
        if len({r["score"] for r in rows}) > 1:
            differences.append({"study_id": sid, "pillar": pillar, "rows": rows})
    selected = {
        str(sid): [[sets[n].get((sid, p), {}) for p in PILLARS] for n in range(3)]
        for sid in CASE_IDS + ALTERNATIVES
    }
    return {
        "provenance": "Original synthetic alpha; not human; not final",
        "common_studies": len({k[0] for k in common}),
        "cells": len(common),
        "disputed_cells": len(differences),
        "disputed_studies": len({d["study_id"] for d in differences}),
        "differences": differences,
        "selected": selected,
    }
