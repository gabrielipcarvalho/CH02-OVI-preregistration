"""Bounded real provider calls. Secrets never leave headers or appear in recorded payloads."""

from __future__ import annotations

import json
import os
import re
import secrets
from pathlib import Path

import httpx

from pipeline.calibration import sources as src
from pipeline.calibration.store import PanelError, Store, now

# Standard token prices checked in official docs on 2026-09-16, USD per million.
# Conservative accounting ignores discounts and retains a full reservation on unknown failures.
PROVIDERS = {
    "openai": {
        "model": "gpt-6-astra",
        "key": "openai-api-key",
        "input": 10,
        "output": 50,
        "budget": 8,
        "endpoint": "https://api.openai.com/v1/responses",
    },
    "anthropic": {
        "model": "claude-opus-4-8",
        "key": "anthropic-api-key",
        "input": 5,
        "output": 25,
        "budget": 5,
        "endpoint": "https://api.anthropic.com/v1/messages",
    },
    "zai": {
        "model": "glm-5.3",
        "key": "zai-coding-key",
        "input": 1.4,
        "output": 4.4,
        "budget": 3,
        "endpoint": "https://api.z.ai/api/paas/v4/chat/completions",
    },
}
ROSTER = {"r1": "openai", "r2": "zai", "r3": "anthropic"}
MAX_CALLS_PER_PROVIDER = 30
MAX_INPUT_BYTES = 240000
MAX_OUTPUT = 6000


def payload(provider: str, prompt: str, max_output: int) -> dict:
    model = PROVIDERS[provider]["model"]
    if provider == "openai":
        return {
            "model": model,
            "input": prompt,
            "max_output_tokens": max_output,
            "reasoning": {"effort": "low"},
            "store": False,
        }
    out = {"model": model, "messages": [{"role": "user", "content": prompt}], "max_tokens": max_output}
    if provider == "zai":
        out.update(thinking={"type": "enabled"}, reasoning_effort="low")
    return out


def extract(provider: str, response: dict) -> tuple[str, int, int, str]:
    usage = response.get("usage", {})
    if provider == "openai":
        text = "\n".join(
            c.get("text", "")
            for item in response.get("output", [])
            if item.get("type") == "message"
            for c in item.get("content", [])
            if c.get("type") == "output_text"
        )
        return (
            text,
            usage.get("input_tokens", 0),
            usage.get("output_tokens", 0),
            response.get("status", "unknown"),
        )
    if provider == "anthropic":
        text = "\n".join(c["text"] for c in response.get("content", []) if c.get("type") == "text")
        return text, usage.get("input_tokens", 0), usage.get("output_tokens", 0), response.get("stop_reason")
    choices = response.get("choices", [])
    text = choices[0].get("message", {}).get("content", "") if choices else ""
    return (
        text or "",
        usage.get("prompt_tokens", 0),
        usage.get("completion_tokens", 0),
        choices[0].get("finish_reason") if choices else "empty",
    )


def call(
    store: Store,
    provider: str,
    prompt: str,
    *,
    max_output: int = MAX_OUTPUT,
    transport=None,
    secret_dir: Path | None = None,
) -> dict:
    """One attempt only. Reserve spend before network access; persist results even if parsing fails."""
    if os.environ.get("OVI_PANEL_OFFLINE") == "1":
        raise PanelError("Offline replay mode: live model calls are disabled")
    if provider not in PROVIDERS:
        raise PanelError("Unknown provider")
    config = PROVIDERS[provider]
    key_path = (secret_dir or Path.home() / ".secrets") / config["key"]
    if not key_path.is_file():
        raise PanelError(f"{provider}: API key file is missing")
    key = key_path.read_text().strip()
    if not key:
        raise PanelError(f"{provider}: API key file is empty")
    if not 32 <= max_output <= MAX_OUTPUT or len(prompt.encode()) > MAX_INPUT_BYTES:
        raise PanelError("Input/output exceeds the bounded experiment limits")
    request = payload(provider, prompt, max_output)
    # UTF-8 bytes plus envelope overhead is deliberately conservative for the selected text-only APIs.
    reserve = (
        (len(json.dumps(request).encode()) + 2048) * config["input"] + max_output * config["output"]
    ) / 1e6
    call_id = secrets.token_hex(12)
    record = {
        "provider": provider,
        "model_requested": config["model"],
        "request": request,
        "prompt_sha256": src.sha(prompt),
        "started": now(),
        "call_id": call_id,
        "synthetic": True,
        "human_confirmed": False,
        "reserved_usd": reserve,
    }
    with store.db() as db:
        db.execute("BEGIN IMMEDIATE")
        rows = db.execute("SELECT reserved FROM calls WHERE provider=?", (provider,)).fetchall()
        if len(rows) >= MAX_CALLS_PER_PROVIDER or sum(r[0] for r in rows) + reserve > config["budget"]:
            raise PanelError(f"{provider}: local request/spend cap reached; replay remains available")
        db.execute(
            "INSERT INTO calls VALUES(?,?,?,?,?,?)",
            (call_id, provider, "running", reserve, json.dumps(record), now()),
        )
    headers = {"Content-Type": "application/json"}
    if provider == "anthropic":
        headers.update({"x-api-key": key, "anthropic-version": "2023-06-01"})
    else:
        headers["Authorization"] = "Bearer " + key
    status, charged = "failed", reserve
    try:
        with httpx.Client(
            timeout=httpx.Timeout(150, connect=15), transport=transport, follow_redirects=False
        ) as client:
            response = client.post(config["endpoint"], headers=headers, json=request)
        record["http_status"] = response.status_code
        if response.status_code != 200:
            # Do not persist arbitrary upstream error bodies: some proxies echo credentials.
            raise PanelError(f"{provider}: HTTP {response.status_code}; no ratings were generated")
        data = response.json()
        text, input_n, output_n, finish = extract(provider, data)
        # Store useful observable output, never private reasoning fields from provider payloads.
        record.update(
            text=text.replace(key, "[REDACTED]"),
            model_returned=data.get("model"),
            input_tokens=input_n,
            output_tokens=output_n,
            finish_reason=finish,
            response_id=data.get("id"),
            finished=now(),
        )
        charged = (input_n * config["input"] + output_n * config["output"]) / 1e6
        if not input_n and not output_n:
            charged = reserve
        record["estimated_usd"] = charged
        if not text.strip() or finish in ("length", "max_tokens", "incomplete"):
            raise PanelError(f"{provider}: incomplete output; retained for inspection, never scored as zero")
        status = "succeeded"
    except (httpx.HTTPError, ValueError, KeyError, TypeError) as exc:
        message = str(exc) if isinstance(exc, PanelError) else f"{provider}: {type(exc).__name__}"
        record["error"] = message.replace(key, "[REDACTED]")
    finally:
        record["finished"] = now()
        with store.db() as db:
            db.execute(
                "UPDATE calls SET status=?,reserved=?,payload=? WHERE id=?",
                (status, charged, json.dumps(record), call_id),
            )
    if status != "succeeded":
        raise PanelError(f"{record['error']} (call {call_id})")
    return record


def usage(store: Store) -> dict:
    with store.db() as db:
        rows = db.execute(
            "SELECT id,provider,status,reserved,payload,created FROM calls ORDER BY created"
        ).fetchall()
    return {
        p: {
            "model": cfg["model"],
            "cap_usd": cfg["budget"],
            "spent_or_reserved_usd": round(sum(r["reserved"] for r in rows if r["provider"] == p), 6),
            "calls": [
                {
                    "id": r["id"],
                    "status": r["status"],
                    "created": r["created"],
                    "usd": r["reserved"],
                    "input_tokens": json.loads(r["payload"]).get("input_tokens"),
                    "output_tokens": json.loads(r["payload"]).get("output_tokens"),
                    "error": json.loads(r["payload"]).get("error"),
                }
                for r in rows
                if r["provider"] == p
            ],
        }
        for p, cfg in PROVIDERS.items()
    }


def parse_cells(text: str) -> list[dict]:
    clean = text.strip()
    # Accept one explicitly fenced JSON value even if the provider adds explanatory prose.
    # Never choose between multiple candidates or repair the substantive JSON contents.
    if "```" in clean:
        blocks = re.findall(r"```(?:json)?\s*\n(.*?)\n```", clean, flags=re.S)
        if len(blocks) != 1 or clean.count("```") != 2:
            raise PanelError("Ambiguous model response: expected one JSON block")
        clean = blocks[0]
    try:
        result = json.loads(clean)
    except json.JSONDecodeError as exc:
        raise PanelError("Model response is not valid JSON; no judgments persisted") from exc
    if not isinstance(result, dict) or not isinstance(result.get("cells"), list):
        raise PanelError("Model must return a cells array")
    return result["cells"]
