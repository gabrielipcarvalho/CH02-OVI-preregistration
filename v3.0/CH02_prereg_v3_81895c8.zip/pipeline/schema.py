"""Score-record schema and validator — the single source for what a scored cell is.

Columns and domains are `SPRINT_SPEC.md` Shared Conventions, plus `rule_id` (DEC-0002 requires a rule-id
per machine-draft cell, and REQ-SCORE-03 requires rule-id provenance; without a column for it Phase 3
must overload `flags` or reopen this schema).

Errors name the offending **cell** — `study_id` × `pillar` — never just "invalid". A 260-cell dataset
whose validator says "invalid" is unauditable.

Threshold rule 1 is binding here: a cell whose evidence is the literal `NO_DOCUMENTED_EVIDENCE` must
score 0. That is the one evidence-threshold rule that is machine-enforceable today; the other four are
rater-facing and belong to the protocol (Phase 2b, gated).

**SB-0013 applies to this module.** The columns defined here are score-record fields withheld from every
rater; blinded delivery (REQ-IRR-02, implemented in `pipeline/blinded_delivery.py`, P1) enforces that
structurally — its `{PDF, rubric, protocol}` packet admits no CSV at all, so a column added here is
withheld by the packet's fail-closed file allowlist, never carried to a rater.

@impl REQ-SCORE-01
"""
from __future__ import annotations

from collections.abc import Iterable, Sequence

from pipeline.rubric import LEVELS, PILLARS

NO_EVIDENCE = "NO_DOCUMENTED_EVIDENCE"

RATERS = ("machine-draft", "rater1", "rater2", "consensus")
CONFIDENCES = ("high", "medium", "low")

# (column, required-non-empty, closed domain or None)
COLUMNS: tuple[tuple[str, bool, tuple[str, ...] | None], ...] = (
    ("study_id", True, None),
    ("study_key", True, None),
    ("pillar", True, PILLARS),
    ("score", True, None),
    ("evidence_quote", True, None),
    ("source_locator", True, None),
    ("rater", True, None),   # domain enforced separately below (RATERS ∪ agent-family, P3); kept out of
                              # the generic loop so an agent rater is admitted without loosening this table
    ("confidence", True, CONFIDENCES),
    ("rule_id", False, None),
    ("flags", False, None),
    ("rationale", False, None),
)
FIELDNAMES = tuple(c for c, _, _ in COLUMNS)


class SchemaError(ValueError):
    """A score record violates the schema. The message always names the cell."""


def _cell(row: dict) -> str:
    return f"[study_id={row.get('study_id', '?')} pillar={row.get('pillar', '?')}]"


# --------------------------------------------------------------------------- rater domain (P3)
# The `rater` domain is RATERS (the fixed human/draft set) OR the synthetic agent family, never-list #2:
# an agent (synthetic) rater is `agent:<model_id>`, watermarking every P3 record on a required, domain-
# checked field. Kept out of the generic COLUMNS loop (that entry's domain is None, above) so admitting
# the agent family cannot be confused with loosening any other closed domain.
SYNTHETIC_RATER_PREFIX = "agent:"


def is_agent_rater(rater: str) -> bool:
    """A synthetic agent rater, e.g. 'agent:opus-4.8'. Fail-closed: a bare 'agent:' is not one."""
    return (isinstance(rater, str) and rater.startswith(SYNTHETIC_RATER_PREFIX)
            and len(rater) > len(SYNTHETIC_RATER_PREFIX))


def is_synthetic(rater: str) -> bool:
    """The predicate a figure/table (M2) calls to refuse presenting agent data as human/final."""
    return is_agent_rater(rater)


# --------------------------------------------------------------------------- quotation handling
# Threshold rule 1 rests on what counts as a quotation, so the test for it lives in ONE place and both
# `validate_row` and `scoring_cli.build_row` call it. They previously each compared for exact equality
# against NO_EVIDENCE, which let `no_documented_evidence`, `NO DOCUMENTED EVIDENCE`, `.` and a
# zero-width space through as "evidence" supporting a score of 3.
_ZERO_WIDTH = "​‌‍﻿⁠"


def normalise_quote(value: str) -> str:
    """Strip whitespace and zero-width characters. Zero-width space is invisible to `str.strip`."""
    return str(value).strip().strip(_ZERO_WIDTH).strip()


def is_absence_marker(value: str) -> bool:
    """Is this the NO_DOCUMENTED_EVIDENCE marker, however the rater cased or spaced it?

    Deliberately generous: a rater who typed `no documented evidence` meant the marker, and reading it
    as a quotation would let an unsupported claim carry a score above Absent.
    """
    squashed = "".join(ch for ch in normalise_quote(value).upper() if ch.isalnum())
    return squashed == NO_EVIDENCE.replace("_", "")


NO_LOCATOR = "not recorded"


def is_substantive_quote(value: str) -> bool:
    """Could this plausibly be text quoted from a paper?

    A floor, not a judgement of adequacy: at least one letter and at least two alphanumeric characters.
    It rejects `.`, `-`, `​` and the empty string.

    **Deliberately not a length rule** (SB-0043, settled 2026-08-13). A minimum word or character count
    was considered and rejected: it measures the wrong thing. *"two pools"* is a perfectly good
    quotation for P1 and *"the system was evaluated extensively"* is five words and worthless, so any
    threshold high enough to exclude the second rejects the first. What separates evidence from
    assertion is not length but **locatability** — see `has_locator`.
    """
    q = normalise_quote(value)
    if is_absence_marker(q):
        return False
    return sum(ch.isalnum() for ch in q) >= 2 and any(ch.isalpha() for ch in q)


def has_locator(value: str) -> bool:
    """Does the cell say WHERE the quotation came from?

    The operative half of SB-0043's resolution. A score above Absent asserts the paper documents
    something; a rater who can quote it can say where it is, and an auditor (or the co-author, or a
    reviewer) must be able to go and look. `not recorded` is the schema's default and is not a locator.

    Why this and not automated verification against the PDF text layer: that check is *possible* here
    (`pipeline/fidelity.py` already normalises `pdftotext` output) and is planned as a non-blocking
    **flag**, but it must never hard-reject. Paper #12 has no text layer at all (SB-0040), ligature and
    hyphenation noise produce false mismatches, and — the deciding reason — an over-strict automated
    check on evidence creates pressure to reword a true quotation until the checker accepts it. A flag
    gives the auditor a list; a rejection corrupts the data it was meant to protect.
    """
    return normalise_quote(value).lower() not in ("", NO_LOCATOR)


def validate_row(row: dict) -> None:
    missing = [c for c in FIELDNAMES if c not in row]
    if missing:
        raise SchemaError(f"{_cell(row)} missing column(s): {', '.join(missing)}")

    for name, required, domain in COLUMNS:
        value = row[name]
        if required and str(value).strip() == "":
            raise SchemaError(f"{_cell(row)} column {name!r} is required and empty")
        if domain is not None and value not in domain:
            raise SchemaError(
                f"{_cell(row)} column {name!r} value {value!r} is not one of {list(domain)}")

    # rater domain: the fixed human/draft set OR the synthetic agent family (P3, never-list #2). Kept out
    # of the generic COLUMNS loop so an agent rater is admitted without loosening any other closed domain.
    if not (row["rater"] in RATERS or is_agent_rater(row["rater"])):
        raise SchemaError(
            f"{_cell(row)} rater {row['rater']!r} is not one of {list(RATERS)} nor a synthetic agent "
            f"rater ('{SYNTHETIC_RATER_PREFIX}<model>')")

    # A row is validated in memory and again after a CSV round-trip, so both forms must be accepted and
    # both must agree. `int()` alone does not do that: it maps True->1 and 2.7->2, so a row could validate
    # in memory and then fail on re-read of the file it produced. `pipeline.rubric` already guards this
    # (bool subclasses int); the two modules police the same 0..3 domain and must not disagree.
    raw = row["score"]
    if isinstance(raw, (bool, float)):
        raise SchemaError(
            f"{_cell(row)} score {raw!r} is {type(raw).__name__}, not an integer; it would not survive "
            f"the CSV round-trip")
    if isinstance(raw, str):
        if not raw.strip().isdigit():
            raise SchemaError(f"{_cell(row)} score {raw!r} is not an integer")
        score = int(raw)
    elif type(raw) is int:
        score = raw
    else:
        raise SchemaError(f"{_cell(row)} score {raw!r} is not an integer")
    if score not in LEVELS:
        raise SchemaError(f"{_cell(row)} score {score} is outside 0..3")

    # Threshold rule 1: unsupported claims score Absent. Enforced in one direction only -- a score of 0
    # may rest on documented evidence for a genuinely absent capability.
    quote = row["evidence_quote"]
    if is_absence_marker(quote) and score != 0:
        raise SchemaError(
            f"{_cell(row)} evidence is {NO_EVIDENCE} but score is {score}; "
            f"threshold rule 1 requires 0")
    # ... and a score above Absent needs something that could actually be a quotation. Without this,
    # `.` or a zero-width space passes as the documented evidence the criterion demands.
    if score > 0 and not is_substantive_quote(quote):
        raise SchemaError(
            f"{_cell(row)} score {score} rests on {quote!r}, which is not a quotation; "
            f"threshold rule 1 scores unsupported claims at the Absent level")
    # SB-0043: evidence is a quotation AND a place to find it. A machine draft is exempt -- it has read
    # no paper and says so -- but it can only ever score 0, so the exemption grants nothing.
    if score > 0 and not has_locator(row["source_locator"]):
        raise SchemaError(
            f"{_cell(row)} score {score} has no source locator; a score above Absent must be "
            f"checkable against the paper, so record the page or section")


def validate_scores(rows: Iterable[dict], population: Sequence[int] | None = None) -> None:
    """Validate every row, then completeness and uniqueness over `population`.

    `population` is a parameter, read by the caller from `data/primaries.csv`. It is not hard-coded
    here: which studies are primaries rests on DEC-0004, a deviation the human has not adopted
    (readiness decision 7). The published *count* is a fixed fact and lives in `pipeline.config`; the
    *membership* is what is undecided.
    """
    rows = list(rows)
    for row in rows:
        validate_row(row)

    seen: set[tuple[int, str]] = set()
    for row in rows:
        key = (int(row["study_id"]), row["pillar"])
        if key in seen:
            raise SchemaError(f"{_cell(row)} duplicate (study_id, pillar) pair")
        seen.add(key)

    if population is None:
        return
    expected = {(int(s), p) for s in population for p in PILLARS}
    if missing := sorted(expected - seen):
        raise SchemaError(
            f"incomplete score set: {len(missing)} cell(s) absent, "
            f"first {min(5, len(missing))}: {missing[:5]}")
    if extra := sorted(seen - expected):
        raise SchemaError(
            f"score set contains {len(extra)} cell(s) outside the population, e.g. {extra[:5]}")


def sort_key(row: dict) -> tuple[int, int]:
    """Deterministic row order: study_id, then pillar in published order (Shared Conventions)."""
    return (int(row["study_id"]), PILLARS.index(row["pillar"]))
